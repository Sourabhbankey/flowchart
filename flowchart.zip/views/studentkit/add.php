<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-cubes"></i> Add New Kit</h1>
    </section>

    <section class="content">
        <div class="box box-primary">
            <div class="box-header with-border"><h3 class="box-title">Kit Details</h3></div>
            <form role="form" id="addSupport" action="<?php echo base_url() ?>studentkit/addNewStudentkit" method="post" role="form" enctype="multipart/form-data">
                <div class="box-body">
                    <div class="row">
                        <!-- Franchise Number -->
                        <div class="col-md-4">
                             <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                       <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchFranchiseData(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                    foreach ($branchDetail as $bd) {
                                                        $selected = ($bd->franchiseNumber == (isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->franchiseNumber : $defaultFranchise)) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($bd->franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($bd->franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                    </div>    
                        </div>

                        <!-- Class Selection -->
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="kitClass">Class <span class="text-danger">*</span></label>
                                <select required class="form-control" name="kitClass" id="kitClass">
                                    <option value="">Select Class</option>
                                    <option value="Nursery">Nursery</option>
                                    <option value="PG">PG</option>
                                    <option value="LKG">LKG</option>
                                    <option value="UKG">UKG</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Dynamic Kit Items Table -->
                    <div class="row">
                        <div class="col-md-12">
                            <label>Kit Items</label>
                            <table class="table table-bordered" id="kitItemsTable">
                                <thead>
                                    <tr>
                                        <th>Item Name</th>
                                        <th>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Kit items will be appended here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Submit -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit Kit</button>
                </div>
            </form>
        </div>
    </section>
</div>

<script>
    const kitItems = {
        'Nursery': [
            { item: 'Crayons', qty: 1 },
            { item: 'Drawing Book', qty: 2 },
            { item: 'Color Pencils', qty: 1 }
        ],
        'PG': [
            { item: 'Clay Set', qty: 1 },
            { item: 'Rhymes Book', qty: 1 },
            { item: 'Color Pencils', qty: 1 }
        ],
        'LKG': [
            { item: 'Math Workbook', qty: 1 },
            { item: 'Writing Slate', qty: 1 },
            { item: 'Pencil Box', qty: 1 }
        ],
        'UKG': [
            { item: 'English Workbook', qty: 1 },
            { item: 'Drawing Kit', qty: 1 },
            { item: 'Color Pencils', qty: 1 }
        ]
    };

    document.getElementById('kitClass').addEventListener('change', function () {
        const selectedClass = this.value;
        const tableBody = document.querySelector('#kitItemsTable tbody');
        tableBody.innerHTML = ''; // Clear existing rows

        if (kitItems[selectedClass]) {
            kitItems[selectedClass].forEach((item, index) => {
                const row = `
                    <tr>
                        <td>
                            <input type="text" readonly class="form-control" name="kitItems[${index}][item]" value="${item.item}">
                        </td>
                        <td>
                            <input type="number" min="1" required class="form-control" name="kitItems[${index}][qty]" value="${item.qty}">
                        </td>
                    </tr>
                `;
                tableBody.insertAdjacentHTML('beforeend', row);
            });
        }
    });
</script>
