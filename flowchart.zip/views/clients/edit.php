<?php
$clientId = $clientsrecordInfo->clientId;
$issuedon = $clientsrecordInfo->issuedon;
$firstcall = $clientsrecordInfo->firstcall;
$clientname = $clientsrecordInfo->clientname;
$contactno = $clientsrecordInfo->contactno;
$altercontactno = $clientsrecordInfo->altercontactno;
$emailid = $clientsrecordInfo->emailid;
$city = $clientsrecordInfo->city;
$location = $clientsrecordInfo->location;
$lastcall = $clientsrecordInfo->lastcall;
$nextfollowup = $clientsrecordInfo->nextfollowup;
$status = $clientsrecordInfo->status;
$description = $clientsrecordInfo->description;
$description2 = $clientsrecordInfo->description2;
$offername = $clientsrecordInfo->offername;
$offercost = $clientsrecordInfo->offercost;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Clients Record Management
        <small>Add / Edit Clients Record</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Clients Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>clients/editClientsrecord" method="post" id="editClientsrecord" role="form">
                        <div class="box-body">
                        <div class="row">
                                <input type="hidden" name="clientId" value="<?php echo $clientId; ?>">
                            
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">IssuedOn</label>
                                        <input  type="date" class="form-control required" value="<?php echo $issuedon; ?>" id="issuedon" name="issuedon" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">First call</label>
                                        <input  type="date" class="form-control required" value="<?php echo $firstcall; ?>" id="firstcall" name="firstcall" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Client name</label>
                                        <input  type="text" class="form-control required" value="<?php echo $clientname; ?>" id="clientname" name="clientname" maxlength="256" />
                                    </div>
                                </div>

                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Contactno</label>
                                        <input  type="text" class="form-control required" value="<?php echo $contactno; ?>" id="contactno" name="contactno" maxlength="256" />
                                    </div>
                                </div>

                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Altercontactno</label>
                                        <input type="text" class="form-control required" value="<?php echo $altercontactno; ?>" id="altercontactno" name="altercontactno" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Emailid</label>
                                        <input  type="text" class="form-control required" value="<?php echo $emailid; ?>" id="emailid" name="emailid" maxlength="256" />
                                    </div>
                                </div>

                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">city</label>
                                        <input  type="text" class="form-control required" value="<?php echo $city; ?>" id="city" name="city" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">location</label>
                                        <input  type="text" class="form-control required" value="<?php echo $location; ?>" id="location" name="location" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Last call</label>
                                        <input type="date" class="form-control required" value="<?php echo $lastcall; ?>" id="lastcall" name="lastcall" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Nextfollowup</label>
                                        <input type="date" class="form-control required" value="<?php echo $nextfollowup; ?>" id="nextfollowup" name="nextfollowup" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Offer Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $offername; ?>" id="offername" name="offername" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Offer Cost</label>
                                        <input type="text" class="form-control required" value="<?php echo $offercost; ?>" id="offercost" name="offercost" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                                                       
    <div class="form-group">
        <label for="status">Status</label>
        <select class="form-control required" id="status" name="status">
            <option value="Interested" <?php echo ($status == 'Interested') ? 'selected' : ''; ?>>Interested</option>
            <option value="Not Interested" <?php echo ($status == 'Not Interested') ? 'selected' : ''; ?>>Not Interested</option>
            <option value="Future Clients" <?php echo ($status == 'Future Clients') ? 'selected' : ''; ?>>Future Clients</option>
            <option value="Positive Leads" <?php echo ($status == 'Positive Leads') ? 'selected' : ''; ?>>Positive Leads</option>
            <option value="Hot Lead" <?php echo ($status == 'Hot Lead') ? 'selected' : ''; ?>>Hot Lead</option>
             <option value="Converted Leads" <?php echo ($status == 'Converted Leads') ? 'selected' : ''; ?>>Converted Leads</option>
            <option value="Discussion Pending" <?php echo ($status == 'Discussion Pending') ? 'selected' : ''; ?>>Discussion Pending</option>
        </select>
    </div>
</div>

                                    </div>
                                </div>

                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">description</label>
                                        <textarea required class="form-control" id="description" name="description" maxlength="256"><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                                    </div>
                                </div>
                                   <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfsale">Comment</label>
                                        
                                        <textarea required class="form-control" id="description2" name="description2" maxlength="256"><?php echo isset($description2) ? htmlspecialchars($description2) : ''; ?></textarea>

                                    </div>
                                </div>
                               
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>