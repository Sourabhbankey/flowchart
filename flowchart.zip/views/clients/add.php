<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Clients Record
        <small>Add / Edit Clients Record</small>
      </h1>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Clients Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>clients/addNewClientsrecord" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
							
                              
								
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="issuedon">Issued On</label>
                                        <input required type="date" class="form-control required" value="" id="issuedon" name="issuedon" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">First Call</label>
                                        <input required type="date" class="form-control required" value="" id="firstcall" name="firstcall" maxlength="256" />
                                    </div>
                                </div>    
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Name Of Client</label>
                                        <input required type="text" class="form-control required" value="" id="clientname" name="clientname" maxlength="256" />
                                    </div>
                                </div>  
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Contact No</label>
                                        <input required type="text" class="form-control required" value="" id="contactno" name="contactno" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Alternate Contact No</label>
                                        <input required type="text" class="form-control required" value="" id="altercontactno" name="altercontactno" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Email ID</label>
                                        <input required type="text" class="form-control required" value="" id="emailid" name="emailid" maxlength="256" />
                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">City</label>
                                        <input required type="text" class="form-control required" value="" id="city" name="city" maxlength="256" />
                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Location</label>
                                        <input required type="text" class="form-control required" value="" id="location" name="location" maxlength="256" />
                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Last Call</label>
                                        <input required type="date" class="form-control required" value="" id="lastcall" name="lastcall" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Next FollowUp</label>
                                        <input  type="date" class="form-control required" value="" id="nextfollowup" name="nextfollowup" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Status</label>
                                        <select  class="form-control required" id="status" name="status">
    <option value="">Select Status</option> <!-- Default empty option -->
    <option value="Interested">Interested</option>
    <option value="Not Interested" >Not Interested</option>
    <option value="Future Clients" >Future Clients</option>
    <option value="Positive Leads">Positive Leads</option>
    <option value="Hot Lead" >Hot Lead</option>
    <option value="Converted leads" >Converted leads</option>
    <option value="Discussion Pending" >Discussion Pending</option>
</select> 

                                    </div> 
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Offer Name</label>
                                        <input required type="text" class="form-control required" value="" id="offername" name="offername" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Offer Cost</label>
                                        <input required type="text" class="form-control required" value="" id="offercost" name="offercost" maxlength="256" />
                                    </div>
                                </div> 
                              <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Final franchise cost</label>
                                        <input required type="text" class="form-control required" value="" id="finalfranchisecost" name="finalfranchisecost" maxlength="256" />
                                    </div>
                                </div>  
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Amount Resceived</label>
                                        <input required type="text" class="form-control required" value="" id="amountreceived" name="amountreceived" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Initial kits offered</label>
                                        <input required type="text" class="form-control required" value="" id="initialkitsoffered" name="initialkitsoffered" maxlength="256" />
                                    </div>
                                </div> 
                              <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productCode">Premise Status</label>
                                      <select class="form-control required" id="premisestatus" name="premisestatus" required>
    <option value="ready">Ready</option>
<option value="underprocess">Underprocess</option>

</select>

                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Expected installation date</label>
                                        <input required type="date" class="form-control required" value="" id="expectedinstallationdate" name="expectedinstallationdate" maxlength="256" />
                                    </div>
                                </div> 
                                   <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Additional offerings</label>
                                        <input required type="text" class="form-control required" value="" id="additionaloffer" name="additionaloffer" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Description</label>
                                      <textarea required class="form-control" id="description" name="description" maxlength="256"></textarea>

                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Comment 2</label>
                                       <textarea  class="form-control" id="description2" name="description2" maxlength="256"></textarea>

                                    </div>
                                </div> 
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>


