<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Orders Management
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <form action="<?= base_url('OrderController/all_orders') ?>" method="GET" class="form-inline">
                        <label for="from_date">From Date:</label>
                        <input type="date" id="from_date" name="from_date" class="form-control" style="margin: 0 10px;">
                        <label for="to_date">To Date:</label>
                        <input type="date" id="to_date" name="to_date" class="form-control" style="margin: 0 10px;">
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </form>
                </div>
            </div>
        </div>

        <?php $this->load->helper('form'); ?>
        <?php if ($error = $this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success = $this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <?= validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Orders List</h3>
                    </div>
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Email</th>
                                    <th>Total</th>
                                    <th>Branch Number</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>#<?= $order['number'] ?></td>
                                        <td><?= $order['billing']['first_name'] . ' ' . $order['billing']['last_name'] ?></td>
                                        <td><?= $order['billing']['email'] ?></td>
                                        <td><?= $order['total'] . ' ' . $order['currency'] ?></td>
                                        <td><?php echo $order['billing']['company']; ?></td>
                                        <td><?= ucfirst($order['status']) ?></td>
                                        <td><?= date('Y-m-d H:i:s', strtotime($order['date_created'])) ?></td>
                                        <td>
                                            <a class="btn btn-info btn-sm" href="<?= base_url('OrderController/order_details/' . $order['id']); ?>" target="_blank">View</a>
                                        </td>
                                        <!-- <td></td> -->
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <div class="pagination br-pagi">
                            <?php if (!empty($prevChunk)): ?>
                                <a href="<?= base_url('OrderController/all_orders/' . $prevChunk) ?>">« Prev</a>
                            <?php endif; ?>

                            <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <a href="<?= base_url('OrderController/all_orders/' . $i) ?>" class="<?= ($i == $currentPage) ? 'active' : '' ?>">
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>

                            <?php if (!empty($nextChunk)): ?>
                                <a href="<?= base_url('OrderController/all_orders/' . $nextChunk) ?>">Next »</a>
                            <?php endif; ?>
                        </div>

                        <div class="box-footer clearfix">
                            <div class="br-pagi">
                                Showing <?= (($currentPage - 1) * 10 + 1) ?> to <?= (($currentPage - 1) * 10 + count($orders)) ?> of approx <?= ($totalPages * 10) ?> entries
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
    tr:nth-child(even) { background-color: #D6EEEE !important; }
    .pagination a.active { font-weight: bold; color: red; }
    .pagination a { margin: 0 5px; }
    .form-inline { display: flex; align-items: center; }
    .form-control { padding: 5px; font-size: 14px; }
    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        padding: 5px 15px;
        font-size: 14px;
        border-radius: 4px;
    }
    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
    }
</style>