<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-eye"></i> Individual Order History Details</h1>
        <h3 style="font-weight: 700;">GST No. : 23AAFCE2177C1Z3</h3>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-body">

                <h3><strong>Order History #<?php echo isset($customerId) ? $customerId : ''; ?></strong></h3> 

                <!-- Summary Stats -->
                <div class="row mb-4">
                    <!-- Total Orders -->
                    <div class="col-md-3 mb-3">
                        <div class="card text-white bg-primary shadow-sm">
                            <div class="card-body text-center">
                                <h6 class="card-title mb-1">Total Orders</h6>
                                <h4 class="card-text mb-0"><?php echo isset($totalOrders) ? $totalOrders : 0; ?></h4>
                            </div>
                        </div>
                    </div>

                    <!-- Total Revenue -->
                    <div class="col-md-3 mb-3">
                        <div class="card text-white bg-success shadow-sm">
                            <div class="card-body text-center">
                                <h6 class="card-title mb-1">Total Revenue</h6>
                                <h4 class="card-text mb-0">₹<?php echo isset($totalRevenue) ? number_format($totalRevenue, 2) : '0.00'; ?></h4>
                            </div>
                        </div>
                    </div>

                    <!-- Average Order Value -->
                    <div class="col-md-3 mb-3">
                        <div class="card text-white bg-info shadow-sm">
                            <div class="card-body text-center">
                                <h6 class="card-title mb-1">Average Order Value</h6>
                                <h4 class="card-text mb-0">₹<?php echo isset($averageOrderValue) ? number_format($averageOrderValue, 2) : '0.00'; ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card text-white bg-danger shadow-sm">
                            <div class="card-body text-center">
                                <h6 class="card-title mb-1">Cancelled Orders</h6>
                                <h4 class="card-text mb-0"><?php echo isset($cancelledOrders) ? $cancelledOrders : 0; ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
        <div class="row">
        <div class="col-xs-12 text-left">
            <div class="form-group filterfrmgroup">
                <form method="get" action="<?php echo base_url('OrderController/customer_history/' . $customerId); ?>" class="mb-4">
                    <div class="row" style="display: inline-flex;margin: auto;">
                        <div class="flbtn-cls">
                            <label>From Date:</label>
                            <input type="date" name="from" class="form-control" value="<?php echo $this->input->get('from'); ?>">
                        </div>
                        <div class="flbtn-cls">
                            <label>To Date:</label>
                            <input type="date" name="to" class="form-control" value="<?php echo $this->input->get('to'); ?>">
                        </div>
                        <!-- <div class="flbtn-cls">
                            <div class="input-group active">
                                <label></label>
                                <button type="submit" class="btn btn-primary">Filter</button>
                                 <a href="<?php //echo base_url('OrderController/customer_history/' . $customerId); ?>" class="btn btn-secondary">Reset</a>
                            </div>
                        </div> -->
                        <div class="flbtn-cls">
                                <label>&nbsp;</label>
                                <div class="input-group active">
                                    <span class="input-group-btn">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            </i> Filter
                                        </button>
                                    </span><a href="<?php echo base_url('OrderController/customer_history/' . $customerId); ?>" class="btn btn-secondary btn-sm active">
                                        <i class="fa fa-refresh"></i> Reset
                                    </a>
                                    
                                </div>

                            </div>
                    </div>
                </form>
            </div>
        </div>
    </div>      
    </section>
    <section class="content">
        <div class="box">
            <div class="box-body">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Orders List</h3>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Total</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($orders)): ?>
                                            <?php foreach ($orders as $order): ?>
                                                <tr>
                                                    <td>#<?php echo $order['number']; ?></td>
                                                    <td><?php echo date('d M Y', strtotime($order['date_created'])); ?></td>
                                                    <td><?php echo ucfirst($order['status']); ?></td>
                                                    <td><?php echo $order['total']; ?> <?php echo $order['currency']; ?></td>
                                                    <td>
                                                        <a href="<?php echo base_url('OrderController/order_details/' . $order['id']); ?>" class="btn btn-info btn-sm">View</a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr><td colspan="5" class="text-center">No orders found for this customer.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
    </section>       
</div>
<style type="text/css">
.shadow-sm {
    padding: 5px;
    border-radius: 5px;
}
.card-title.mb-1 {
    font-size: 16px;
}
.flbtn-cls {
    margin: 5px;
}
</style>
