<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Shop Orders History
            <small>View, Orders</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group"></div>
            </div>
        </div>

        <?php $this->load->helper('form'); ?>
        <?php if ($error = $this->session->flashdata('error')): ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?= $error ?>
            </div>
        <?php endif; ?>

        <?php if ($success = $this->session->flashdata('success')): ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?= $success ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <?= validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Users List</h3>
                    </div>

                    <div class="box-body table-responsive no-padding1">
                        <table class="table table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    
                                    <th>Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($users)): ?>
                                    <?php foreach ($users as $user): ?>
                                        <?php
                                            $fullName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
                                            if (empty($fullName)) {
                                                $fullName = $user['username'];
                                            }
                                        ?>
                                        <tr>
                                            
                                            <td><?= htmlspecialchars($fullName); ?></td>
                                            <td>
                                                <a href="<?= site_url('OrderController/customer_history/' . $user['id']); ?>" class="btn btn-primary btn-sm">View Orders</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="3" class="text-center">No users found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <!-- Pagination Style -->
                        <div class="pagination br-pagi">
                            <?php if (!empty($prevChunk)): ?>
                                <a href="<?= base_url('OrderController/user_list/' . $prevChunk) ?>">« Prev</a>
                            <?php endif; ?>

                            <?php for ($i = $startPage; $i <= $endPage; $i++): ?>
                                <a href="<?= base_url('OrderController/user_list/' . $i) ?>" class="<?= ($i == $currentPage) ? 'active' : '' ?>">
                                    <?= $i ?>
                                </a>
                            <?php endfor; ?>

                            <?php if (!empty($nextChunk)): ?>
                                <a href="<?= base_url('OrderController/user_list/' . $nextChunk) ?>">Next »</a>
                            <?php endif; ?>
                        </div>

                        <div class="box-footer clearfix">
                            <div class="br-pagi">
                                Showing <?= (($currentPage - 1) * 10 + 1) ?> to <?= (($currentPage - 1) * 10 + count($users)) ?> of approx <?= ($totalPages * 10) ?> entries
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
    tr:nth-child(even) { background-color: #D6EEEE !important; }
    .pagination a.active { font-weight: bold; color: red; }
    .pagination a { margin: 0 5px; }
</style>
