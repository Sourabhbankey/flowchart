<?php
$amcId = $amcInfo->amcId;
$franchiseName = $amcInfo->franchiseName;
$franchiseNumber = $amcInfo->franchiseNumber;
$branchcityName = $amcInfo->branchcityName;
$branchState = $amcInfo->branchState;
$amcAmount = $amcInfo->amcAmount;

$oldAMCdue = $amcInfo->oldAMCdue;
$totalAmc = $amcInfo->totalAmc;
$statusAmc = $amcInfo->statusAmc;
$branchFranchiseAssigned = $amcInfo->branchFranchiseAssigned;

//$brInstallationStatusAMC = $amcInfo->brInstallationStatusAMC;
$dueDateAmc = $amcInfo->dueDateAmc;
/*--New-Added---*/
$amcYear1 = $amcInfo->amcYear1;
$amcYear1dueAmount = $amcInfo->amcYear1dueAmount;
$amcYear1date = $amcInfo->amcYear1date;
$statusYear1Amc = $amcInfo->statusYear1Amc;
$amcYear2 = $amcInfo->amcYear2;
$amcYear2dueAmount = $amcInfo->amcYear2dueAmount;
$amcYear2date = $amcInfo->amcYear2date;
$statusYear2Amc = $amcInfo->statusYear2Amc;
$amcYear3 = $amcInfo->amcYear3;
$amcYear3dueAmount = $amcInfo->amcYear3dueAmount;
$amcYear3date = $amcInfo->amcYear3date;
$statusYear3Amc = $amcInfo->statusYear3Amc;
$amcYear4 = $amcInfo->amcYear4;
$amcYear4dueAmount = $amcInfo->amcYear4dueAmount;
$amcYear4date = $amcInfo->amcYear4date;
$statusYear4Amc = $amcInfo->statusYear4Amc;
$amcYear5 = $amcInfo->amcYear5;
$amcYear5dueAmount = $amcInfo->amcYear5dueAmount;
$amcYear5date = $amcInfo->amcYear5date;
$statusYear5Amc = $amcInfo->statusYear5Amc;
$descAmc = $amcInfo->descAmc;
$amcYear1S3File = $amcInfo->amcYear1S3File;
$amcYear2S3File = $amcInfo->amcYear2S3File;
$amcYear3S3File = $amcInfo->amcYear3S3File;
$amcYear4S3File = $amcInfo->amcYear4S3File;
$amcYear5S3File = $amcInfo->amcYear5S3File;
$currentStatus = $amcInfo->currentStatus;

// New fields for penalty and other charges
$penaltyCharges = $amcInfo->penaltyCharges;
$penaltyAmount = $amcInfo->penaltyAmount;
$otherChargesTitle = $amcInfo->otherChargesTitle;
$otherChargesAmount = $amcInfo->otherChargesAmount;
//print_r($currentStatus);exit;
//$selectUserId ='';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Amc Management
        <small>Add / Edit Amc</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Amc Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start --> 
                    <form role="form" action="<?php echo base_url() ?>amc/editAmc" method="post" id="editAmc" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                        <div class="row">
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise No.</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseNumber; ?>" id="franchiseNumber" name="franchiseNumber" maxlength="256"  readonly />
                                        <input type="hidden" value="<?php echo $amcId; ?>" name="amcId" id="amcId" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="franchiseName">Branch Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseName; ?>" id="franchiseName" name="franchiseName" maxlength="256" readonly />
                                        <input type="hidden" value="<?php echo $franchiseName; ?>" name="franchiseName" id="franchiseName"/>
                                    </div>  
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="branchLocation">Location</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchcityName; ?>" id="branchLocation" name="branchcityName" maxlength="256" readonly />                                 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="branchState">State</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchState; ?>" id="branchState" name="branchState" maxlength="256" readonly />
                                    </div>
                                </div>
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="oldAMCdue">Old AMC Due</label>
                                        <input type="text" class="form-control required" value="<?php //echo $oldAMCdue; ?>" id="oldAMCdue" name="oldAMCdue" maxlength="256" />
                                    </div>
                                </div> -->
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="curAmc">AMC (Including GST)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcAmount; ?>" id="curAmc" name="amcAmount" maxlength="256" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Total Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $totalAmc; ?>" id="totalAmc" name="totalAmc" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="statusAmc">Status Of AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusAmc" tabindex="-1" aria-hidden="true">

                                        <option value="<?= INACTIVE ?>" <?php if($statusAmc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusAmc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                      
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Current Status</label>
                                        <input type="text" class="form-control required" value="<?php echo $currentStatus; ?>" id="totalAmc" readonly name="currentStatus" maxlength="256" />
                                    </div>
                                </div>
                              <!--   <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Support Manager</label>
                                        <select class="form-control check required" id="branchFranchiseAssigned" name="branchFranchiseAssigned" disabled>
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $drl)
                                                {
                                                    $userText = $drl->name;
                                                    ?>
                                                    <option value="<?php echo $drl->userId ?>" <?php if($drl->userId == set_value('branchFranchiseAssigned', $branchFranchiseAssigned)) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    
                                </div> -->
                               <!--  <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Status <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brInstallationStatusAMC" tabindex="-1" aria-hidden="true" disabled>
                                            <option value="<?= ACTIVE ?>" <?php if($brInstallationStatusAMC == ACTIVE) {echo "selected=selected";} ?>>Installed</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brInstallationStatusAMC == INACTIVE) {echo "selected=selected";} ?> >Not Installed</option>
                                    </select>
                                    </div>
                                </div> -->
                                <!--   <div class="col-md-6 mb-sm">
                                <div class="form-group">
                                        <label class="control-label">Current Status</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brInstallationStatusAMC" tabindex="-1" aria-hidden="true">
                                            <option value="<?php echo $brInstallationStatusAMC; ?>" <?php echo "selected=selected"; ?>><?php echo $brInstallationStatusAMC; ?></option>
                                          <option value="Installed-Active">Installed Active</option>
                                          <option value="Installed-Closed"> Installed Closed</option>
                                          <option value="UnInstalled-Active"> UnInstalled Active</option>
                                          <option value="UnInstalled-Closed"> UnInstalled Closed</option>
                                        </select>
                                    </div>
                                </div>  -->
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="dueDateAmc">Due Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $dueDateAmc; ?>" id="dueDateAmc" name="dueDateAmc" maxlength="256" /> 
                                    </div>
                                </div>
                                  <!-- New Fields for Penalty and Other Charges -->
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="penaltyCharges">Penalty Charges</label>
                                        <input type="text" class="form-control" value="<?php echo $penaltyCharges; ?>" id="penaltyCharges" name="penaltyCharges" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="penaltyAmount">Penalty Amount</label>
                                        <input type="text" class="form-control" value="<?php echo $penaltyAmount; ?>" id="penaltyAmount" name="penaltyAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="otherChargesTitle">Other Charges </label>
                                        <input type="text" class="form-control" value="<?php echo $otherChargesTitle; ?>" id="otherChargesTitle" name="otherChargesTitle" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="otherChargesAmount">Other Charges Amount</label>
                                        <input type="text" class="form-control" value="<?php echo $otherChargesAmount; ?>" id="otherChargesAmount" name="otherChargesAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <!-- End New Fields -->
                                <!-- New-Field - Added -->
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amamcYear2datecYear1">AMC Paid (Year 1)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear1; ?>" id="amcYear1" name="amcYear1" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear1dueAmount">AMC Year 1 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear1dueAmount; ?>" id="amcYear1dueAmount" name="amcYear1dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear1date">AMC Year-1 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $amcYear1date; ?>" id="amcYear1date" name="amcYear1date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3"> 
                                <div class="form-group">
                                        <label for="statusYear1Amc">Status Of Year-1 AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusYear1Amc" tabindex="-1" aria-hidden="true">
                                             <option value="<?= INACTIVE ?>" <?php if($statusYear1Amc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusYear1Amc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                        
                                       
                                    </select>
                                    </div>
                                </div> 
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File AMC Year-1 </label>
                                        <input  type="file" name="file" multiple>
                                    </div>
                                    <a href="<?php echo $amcYear1S3File ?>" target="_blank"><button class="btn"><img src="<?php echo $amcYear1S3File ?>" style="height: 50px !important;width: 50px;">  View</a>
                                    
                                </div>  

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amamcYear2datecYear2">AMC Paid (Year 2)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear2; ?>" id="amcYear2" name="amcYear2" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear2dueAmount">AMC Year 2 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear2dueAmount; ?>" id="amcYear2dueAmount" name="amcYear2dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear2date">AMC Year-2 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $amcYear2date; ?>" id="amcYear1date" name="amcYear2date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3"> 
                                <div class="form-group">
                                        <label for="statusYear2Amc">Status Of Year-2 AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusYear2Amc" tabindex="-1" aria-hidden="true">
                                             <option value="<?= INACTIVE ?>" <?php if($statusYear2Amc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusYear2Amc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                        
                                       
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File AMC Year-2 </label>
                                        <input  type="file" name="file2" multiple>
                                    </div>
                                    <a href="<?php echo $amcYear2S3File ?>" target="_blank"><button class="btn"><img src="<?php echo $amcYear2S3File ?>" style="height: 50px !important;width: 50px;">  View</a>
                                </div>    
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amamcYear3datecYear3">AMC Paid (Year 3)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear3; ?>" id="amcYear2" name="amcYear3" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear3dueAmount">AMC Year 3 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear3dueAmount; ?>" id="amcYear3dueAmount" name="amcYear3dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear3date">AMC Year-3 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $amcYear3date; ?>" id="amcYear3date" name="amcYear3date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3"> 
                                <div class="form-group">
                                        <label for="statusYear3Amc">Status Of Year-3 AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusYear3Amc" tabindex="-1" aria-hidden="true">

                                            <option value="<?= INACTIVE ?>" <?php if($statusYear3Amc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusYear3Amc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                        
                                        X
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File AMC Year-3 </label>
                                        <input  type="file" name="file3" multiple>
                                    </div>
                                    <a href="<?php echo $amcYear3S3File ?>" target="_blank"><button class="btn"><img src="<?php echo $amcYear3S3File ?>" style="height: 50px !important;width: 50px;">  View</a>
                                </div>    
                                
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amamcYear4datecYear4">AMC  Paid (Year 4)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear4; ?>" id="amcYear4" name="amcYear4" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear4dueAmount">AMC Year 4 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear4dueAmount; ?>" id="amcYear4dueAmount" name="amcYear4dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear4date">AMC Year-4 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $amcYear4date; ?>" id="amcYear4date" name="amcYear4date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3"> 
                                <div class="form-group">
                                        <label for="statusYear4Amc">Status Of Year-4 AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusYear4Amc" tabindex="-1" aria-hidden="true">
                                            <option value="<?= INACTIVE ?>" <?php if($statusYear4Amc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusYear4Amc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                        
                                    
                                    </select>
                                    </div>
                                </div>

                            <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File AMC Year-4 </label>
                                        <input  type="file" name="file4" multiple>
                                    </div>
                                   <a href="<?php echo $amcYear4S3File ?>" target="_blank"><button class="btn"><img src="<?php echo $amcYear4S3File ?>" style="height: 50px !important;width: 50px;">  View</a>
                                </div>   
                               
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amamcYear5datecYear5">AMC Paid (Year 5)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear5; ?>" id="amcYear2" name="amcYear3" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear5dueAmount">AMC Year 5 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcYear5dueAmount; ?>" id="amcYear5dueAmount" name="amcYear5dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="amcYear5date">AMC Year-3 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $amcYear5date; ?>" id="amcYear5date" name="amcYear5date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-3"> 
                                <div class="form-group">
                                        <label for="statusYear5Amc">Status Of Year-5 AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusYear5Amc" tabindex="-1" aria-hidden="true">
                                             <option value="<?= INACTIVE ?>" <?php if($statusYear5Amc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusYear5Amc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                        
                                       
                                    </select>
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File AMC Year-5 </label>
                                        <input  type="file" name="file5" multiple>
                                    </div>
                                    <a href="<?php echo $amcYear5S3File ?>" target="_blank"><button class="btn"><img src="<?php echo $amcYear5S3File ?>" style="height: 50px !important;width: 50px;">  View</a>
                                </div>    
                                <!-- End- New-Field - Added -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="descAmc">Description</label>
                                        <textarea class="form-control required" id="descAmc" name="descAmc"><?php echo $descAmc; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('descAmc', {
            filebrowserUploadUrl: "<?= base_url('amc/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>