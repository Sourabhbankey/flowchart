<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Admission Enquiry Management
            <small>Add / Edit Staff</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Admission Enquiry Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>admenquiry/addNewAdmenquiry" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25 ) { ?>
                                            <!-- Franchise users: Non-editable field -->
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: ''; // Use session franchise number or empty
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                             
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                            <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                                <span>Select a franchise to assign</span>
                                            </div>
                                            <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                        </div>
                                    </div>
                             

                               
                                <?php
                                $role = $this->session->userdata('role');
                                $franchiseNumber = $this->session->userdata('franchiseNumber');

                                if (in_array($role, [1, 14, 20, 25])):
                                    // Set value based on role
                                    $updatedByValue = ($role == 25) ? $franchiseNumber : 'HO';

                                ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="updatedBy">Updated By <span class="re-mend-field">*</span></label>
                                            <input required type="text" class="form-control required"
                                                value="<?php echo $updatedByValue; ?>"
                                                id="editBy" name="editBy" maxlength="256" readonly />
                                        </div>
                                    </div>
                                <?php endif; ?>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="studentName">Student Name<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('studentName'); ?>" id="studentName" name="studentName" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="class">Class <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo set_value('class'); 
                                                                                                                ?>" id="class" name="class" maxlength="256"> -->
                                        <select class="form-control required" id="class" name="class" required>
                                            <option value="">Select Class </option>
                                            <option value="Toddlers">Toddlers</option>
                                            <option value="Play Group">Play Group</option>
                                            <option value="Nursery">Nursery</option>
                                            <option value="KG-1">KG-1</option>
                                            <option value="KG-2">KG-2</option>
                                            <option value="1st">1st</option>
                                            <option value="2nd">2nd</option>
                                            <option value="3rd">3rd</option>
                                            <option value="4th">4th</option>
                                            <option value="5th">5th</option>
                                            <option value="Day Care">Day Care</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="how-to-know">How do you get to know about us?<span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="how_to_know" name="how_to_know" required>
                                            <option value="">Select Type</option>
                                            <option value="Facebook">Facebook</option>
                                            <option value="Instagram">Instagram</option>
                                            <option value="Google">Google</option>
                                            <option value="Just Dial">Just Dial</option>
                                            <option value="Friends">Friends</option>
                                            <option value="Pamphlet">Pamphlet</option>
                                            <option value="No Parking">No Parking</option>
                                            <option value="Paper Ad">Paper Ad</option>
                                            <option value="Hording">Hording</option>
                                            <option value="Existing Parents">Existing Parents</option>
                                            <option value="Staff & Walking">Staff & Walking</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="enq-status">Enquiry Status<span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="enq_status" name="enq_status" required>
                                            <option value="">Select Status</option>
                                            <option value="Facebook">Positive</option>
                                            <option value="Instagram">Not interested</option>
                                            <option value="Google">Confirmed</option>
                                            <option value="Just Dial">Next session</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="birthday">Date Of Birth <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('birthday'); ?>" id="birthday" name="birthday" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="age">Age <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('age'); ?>" id="age" name="age" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('city'); ?>" id="city" name="city" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="state">State <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('state'); ?>" id="state" name="state" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="addressResidencial">Residential Address<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('addressResidencial'); ?>" id="addressResidencial" name="addressResidencial" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="addressPerma">Permanent Address<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('addressPerma'); ?>" id="addressPerma" name="addressPerma" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fathername">Father's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('fathername'); ?>" id="fathername" name="fathername" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatheremail">Father's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo set_value('fatheremail'); ?>" id="fatheremail" name="fatheremail" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatherMobile_no">Father's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('fatherMobile_no'); ?>" id="fatherMobile_no" name="fatherMobile_no" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="mothername">Mother's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('mothername'); ?>" id="mothername" name="mothername" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motheremail">Mother's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo set_value('motheremail'); ?>" id="motheremail" name="motheremail" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motherMobile_no">Mother's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('motherMobile_no'); ?>" id="motherMobile_no" name="motherMobile_no" maxlength="256">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="feeOffered">Fee Offered <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('feeOffered'); ?>" id="feeOffered" name="feeOffered" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="remark">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="remark" name="remark"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup1">follow up </label>
                                        <textarea class="form-control required" id="followup1" name="followup1"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup2">follow up </label>
                                        <textarea class="form-control required" id="followup2" name="followup2"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup3">follow up </label>
                                        <textarea class="form-control required" id="followup3" name="followup3"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup4">follow up </label>
                                        <textarea class="form-control required" id="followup4" name="followup4"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup5">follow up </label>
                                        <textarea class="form-control required" id="followup5" name="followup5"></textarea>
                                    </div>
                                </div>
                                <!-- </div> -->
                            </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>

<script>
    function fetchAssignedFranchise(franchiseNumber) {
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("admenquiry/fetchAssignedUsers"); ?>', // Update to match your controller and method
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber
                },
                success: function(response) {
                    $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    alert('Error fetching data');
                }
            });
        } else {
            $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
        }
    }
</script>


<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });

    // Updated fetchAssignedFranchise function to fetch Growth Manager's name
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue'); // Reference hidden input
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.html) {
                        assignedDiv.innerHTML = response.html; // Display Growth Manager's name(s)
                        hiddenInput.value = response.userIds || ''; // Set hidden input to userIds
                    } else {
                        assignedDiv.innerText = 'No Growth Manager assigned';
                        hiddenInput.value = ''; // Clear hidden input
                        alert(response.message || 'No Growth Manager found for this franchise');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    assignedDiv.innerText = 'Error fetching Growth Manager';
                    hiddenInput.value = ''; // Clear hidden input
                    alert('Error fetching Growth Manager data');
                }
            });
        } else {
            assignedDiv.innerText = 'Select a franchise to assign';
            hiddenInput.value = ''; // Clear hidden input
        }
    }

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        // For dropdown (non-readonly, roles other than 25)
        if (franchiseInput && franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }

        // For readonly input (role 25)
        if (franchiseInput && franchiseInput.readOnly) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        const dobInput = document.getElementById('birthday');
        const ageInput = document.getElementById('age');

        dobInput.addEventListener('change', function() {
            const dob = new Date(this.value);
            const today = new Date();

            if (isNaN(dob)) return;

            // If DOB is in the future, treat age as 0
            if (dob > today) {
                ageInput.value = "0 Year - 0 Months - 0 Days";
                return;
            }

            let years = today.getFullYear() - dob.getFullYear();
            let months = today.getMonth() - dob.getMonth();
            let days = today.getDate() - dob.getDate();

            if (days < 0) {
                months--;
                const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
                days += prevMonth.getDate();
            }

            if (months < 0) {
                years--;
                months += 12;
            }

            // Ensure no negative values even in edge cases
            years = Math.max(0, years);
            months = Math.max(0, months);
            days = Math.max(0, days);

            const ageStr = `${years} Year - ${months} Months - ${days} Days`;
            ageInput.value = ageStr;
        });
    });

</script>