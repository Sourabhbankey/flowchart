<?php
$enqid = $admenquiryInfo->enqid;
$studentName = $admenquiryInfo->studentName;
$class = $admenquiryInfo->class;
$birthday = $admenquiryInfo->birthday;
$age = $admenquiryInfo->age;
$city = $admenquiryInfo->city;
$state = $admenquiryInfo->state;
$addressResidencial = $admenquiryInfo->addressResidencial;
$addressPerma = $admenquiryInfo->addressPerma;
$fathername = $admenquiryInfo->fathername;
$fatheremail = $admenquiryInfo->fatheremail;
$fatherMobile_no = $admenquiryInfo->fatherMobile_no;
$mothername = $admenquiryInfo->mothername;
$motheremail = $admenquiryInfo->motheremail;
$motherMobile_no = $admenquiryInfo->motherMobile_no;
$feeOffered = $admenquiryInfo->feeOffered;

$followup1 = $admenquiryInfo->followup1;
$followup2 = $admenquiryInfo->followup2;
$followup3 = $admenquiryInfo->followup3;
$followup4 = $admenquiryInfo->followup4;
$followup5 = $admenquiryInfo->followup5;
/*$fathername = $admenquiryInfo->fathername;*/
$franchiseNumberArray = explode(",",$admenquiryInfo->franchiseNumber);
$remark = $admenquiryInfo->remark;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Admission  Enquiry  Management
        <small>Add / Edit Admission  Enquiry </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Admission  Enquiry Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>admenquiry/editAdmenquiry" method="post" id="editAdmenquiry" role="form">
                        <div class="box-body">
                        <div class="row">
                                <!--  -->
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="studentName">Student Name<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $studentName; ?>" id="studentName" name="studentName" maxlength="256" />
                                        <input type="hidden" value="<?php echo $enqid; ?>" name="enqid" id="enqid" />
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;

                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>" <?php if(in_array($franchiseNumber,$franchiseNumberArray)){echo "selected=selected";} ?>><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="class">Class <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo $class; ?>" id="class" name="class" maxlength="256"> -->
                                        <select class="form-control required" id="selectUserId" name="class" required>
                                            <option value="<?php echo $class; ?>" <?php echo "selected=selected"; ?>><?php echo $class; ?></option>
                                            <option value="Toddlers">Toddlers</option>
                                            <option value="Play Group">Play Group</option> 
                                            <option value="Nursery">Nursery</option>
                                            <option value="KG-1">KG-1</option>
                                            <option value="KG-2">KG-2</option>  
                                            <option value="1st">1st</option> 
                                            <option value="2nd">2nd</option>
                                            <option value="3rd">3rd</option>
                                            <option value="4th">4th</option>
                                            <option value="5th">5th</option>
                                            <option value="Day Care">Day Care</option>    
                                        </select>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="birthday">Date Of Birth <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $birthday; ?>" id="birthday" name="birthday" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="age">Age <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $age; ?>" id="age" name="age" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $city; ?>" id="city" name="city" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="state">State <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $state; ?>" id="state" name="state" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="addressResidencial">Residential Address  <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $addressResidencial; ?>" id="addressResidencial" name="addressResidencial" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="addressPerma">Permanent Address  <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $addressPerma; ?>" id="addressPerma" name="addressPerma" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fathername">Father's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $fathername; ?>" id="fathername" name="fathername" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fatheremail">Father's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo $fatheremail; ?>" id="fatheremail" name="fatheremail" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fatherMobile_no">Father's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $fatherMobile_no; ?>" id="fatherMobile_no" name="fatherMobile_no" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="mothername">Mother's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $mothername; ?>" id="mothername" name="mothername" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="motheremail">Mother's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo $motheremail; ?>" id="motheremail" name="motheremail" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="motherMobile_no">Mother's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $motherMobile_no; ?>" id="motherMobile_no" name="motherMobile_no" maxlength="256">
                                    </div>   
                                </div>
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="feeOffered">Fee Offered <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $feeOffered; ?>" id="feeOffered" name="feeOffered" maxlength="256">
                                    </div>   
                                </div>
                                <!--  -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="remark">Remark <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="remark" name="remark"><?php echo $remark; ?></textarea>
                                    </div>
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup1">follow up <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="followup1" name="followup1"><?php echo $followup1; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup2">follow up <span class="re-mend-field">*</span></label>
                                        <textarea  class="form-control required" id="followup2" name="followup2"><?php echo $followup2; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup3">follow up <span class="re-mend-field">*</span></label>
                                        <textarea  class="form-control required" id="followup3" name="followup3"><?php echo $followup3; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup4">follow up <span class="re-mend-field">*</span></label>
                                        <textarea  class="form-control required" id="followup4" name="followup4"><?php echo $followup4; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="followup5">follow up <span class="re-mend-field">*</span></label>
                                        <textarea  class="form-control required" id="followup5" name="followup5"><?php echo $followup5; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>