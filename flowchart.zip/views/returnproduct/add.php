<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Return product Management
        <small>Add / Edit ReturnProduct</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Returnproduct Details</h3>
                         <div class="pull-right">
            <a href="<?php echo base_url() ?>returnproduct/returnproductListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <!-- <h2>Return a Product</h2> -->
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>returnproduct/addNewReturnproduct" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                           <!--       <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber"  data-live-search="true" required>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div> -->
                                <input type="hidden" name="franchiseNumber" value="<?php echo $this->session->userdata('franchiseNumber'); ?>">

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Order ID:</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('order_id'); ?>" id="order_id" name="order_id" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Product Title</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('product_title'); ?>" id="product_title" name="product_title" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Quantity</label>
                                        <input type="number" class="form-control required" value="<?php echo set_value('quantity'); ?>" id="quantity" name="quantity" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Return Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('return_date'); ?>" id="return_date" name="return_date" maxlength="256" />
                                    </div>
                                    
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Upload File <span class="re-mend-field">*</span></label>
                                        <input required type="file" name="file" multiple>
                                    </div>

                                </div>

                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Receipt Attachment <span class="re-mend-field">*</span></label>
                                        <input required type="file" name="file2" multiple>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Reason</label>
                                        <textarea class="form-control required" id="reason" name="reason"></textarea>
                                    </div>
                                </div>
             

                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('ticket/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>