<?php
$prodreturnId = $returnproductInfo->prodreturnId;
// Assuming $returnproductInfo has the current status value, e.g. $returnproductInfo->status
// You can adjust the value accordingly.

// Determine attributes based on role
$isReadOnly = ($role == 35);
$statusAttr = $isReadOnly ? 'disabled' : '';  // for select, use disabled
$replyAttr  = $isReadOnly ? 'readonly' : '';    // for textarea, use readonly
// $acattachmentInvoiceS3File = $despatchInfo->acattachmentInvoiceS3File;
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Return Product Management
            <small>Edit Return Product</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Details</h3>
                        <div class="pull-right">
                            <a href="<?php echo base_url() ?>returnproduct/returnproductListing" class="btn btn-info">Back to Listing</a>
                        </div>
                    </div>

                    <form role="form" action="<?php echo base_url('returnproduct/editReturnproduct'); ?>" method="post" id="editReturnproduct" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- Hidden Product Return Id -->
                                <input type="hidden" value="<?php echo $prodreturnId; ?>" name="prodreturnId" id="prodreturnId" />

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <!-- Mark the select as disabled if role is 35 -->
                                        <select name="status" id="status" class="form-control" required <?php echo $statusAttr; ?>>
                                            <option value="">-- Select Status --</option>
                                            <option value="Approved" <?php echo (isset($returnproductInfo->status) && $returnproductInfo->status == 'Approved') ? 'selected' : ''; ?>>Approve</option>
                                            <option value="Rejected" <?php echo (isset($returnproductInfo->status) && $returnproductInfo->status == 'Rejected') ? 'selected' : ''; ?>>Reject</option>
                                        </select>
                                        <?php
                                        // If disabled, include a hidden field so the value is submitted.
                                        if ($isReadOnly) { ?>
                                            <input type="hidden" name="status" value="<?php echo isset($returnproductInfo->status) ? $returnproductInfo->status : ''; ?>" />
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="replyMessage">Reply</label>
                                        <!-- Mark the textarea as readonly if role is 35 -->
                                        <textarea class="form-control" id="reply" name="reply" rows="5" <?php echo $replyAttr; ?>><?php echo isset($returnproductInfo->reply) ? $returnproductInfo->reply : ''; ?></textarea>
                                    </div>
                                </div>

                                <!--  <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="returnAttachment">Attachment</label>
                                        <input type="file" class="form-control" id="file2" name="file2" />
                                    </div>
                                </div> -->
                                <!--   <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="AcInvoicenumDesp">Attachment</label>
                                            <?php //if (!empty($despatchInfo->acattachmentInvoiceS3File)) { 
                                            ?>
                                             
                                                <a href="<?php //echo $despatchInfo->acattachmentInvoiceS3File; 
                                                            ?>" target="_blank">
                                                    <button class="btn">
                                                        <img src="<?php echo $despatchInfo->acattachmentInvoiceS3File; ?>" style="height: 50px !important; width: 50px;">
                                                        A/C - View
                                                    </button>
                                                </a>
                                            <?php //} else { 
                                            ?>
                                              
                                                <input type="file" name="file" class="form-control" id="AcInvoicenumDesp">
                                            <?php //} 
                                            ?>
                                        </div>
                                    </div> -->

                                <?php if ($role == 35): ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="received_date">Received Date</label>
                                            <input type="date" class="form-control" name="receivedOndate" id="receivedOndate" value="<?php echo isset($returnproductInfo->receivedOndate) ? $returnproductInfo->receivedOndate : ''; ?>">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="receivedQty">Quantity</label>
                                            <input type="number" class="form-control" name="receivedQty" id="receivedQty" min="1" value="<?php echo isset($returnproductInfo->receivedQty) ? $returnproductInfo->receivedQty : ''; ?>">
                                        </div>
                                    </div>

                                    <!--  <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="product">Product </label>
                                            <input type="text" class="form-control" name="product" id="product" value="<?php echo isset($returnproductInfo->product) ? $returnproductInfo->product : ''; ?>">
                                        </div>
                                    </div> -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="productCode">Product Code</label>
                                            <select class="form-control required" id="product_code" name="receivedProduct" required>
                                                <?php foreach ($codes as $code): ?>
                                                    <option value="<?php echo $code['productCode']; ?>"
                                                        <?php echo ($returnproductInfo->receivedProduct == $code['productCode']) ? 'selected' : ''; ?>>
                                                        <?php echo $code['productCode']; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="receivedProductVerification">Product Verification</label>
                                            <select class="form-control" name="receivedProductVerification" id="receivedProductVerification">
                                                <option value="">-- Select --</option>
                                                <option value="Accepted" <?php echo (isset($returnproductInfo->receivedProductVerification) && $returnproductInfo->receivedProductVerification == 'Accepted') ? 'selected' : ''; ?>>Accepted</option>
                                                <option value="Damaged" <?php echo (isset($returnproductInfo->receivedProductVerification) && $returnproductInfo->receivedProductVerification == 'Damaged') ? 'selected' : ''; ?>>Damaged</option>
                                            </select>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>

                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for reply (if needed) -->
<script src="https://cdn.ckeditor.com/4.20.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('replyMessage');
</script>
<script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        readOnly: true
    });
</script>