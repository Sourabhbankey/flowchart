<?php
$taskId = $taskInfo->taskId;
$taskTitle = $taskInfo->taskTitle;
$description = $taskInfo->description;
$taskStatus = $taskInfo->status;
$assignedTo = $taskInfo->assignedTo;
$assignedTo = $taskInfo->assignedTo;
$collabrators = $taskInfo->collabrators;

// print_r($taskInfo);
$selectUserId = "";
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Task Management
            <small>Add / Edit Task</small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Task Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->

                    <form role="form" action="<?php echo base_url(); ?>task/editTask" method="post" id="editTask" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="taskTitle">Task Title</label>
                                        <input type="text" class="form-control required ed-task" value="<?php echo $taskTitle; ?>" id="taskTitle" name="taskTitle" maxlength="256" />
                                        <div class="tsk-title"><?php echo $taskTitle; ?></div>
                                        <input type="hidden" value="<?php echo $taskId; ?>" name="taskId" id="taskId" />
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Assigned To</label>
                                        <select class="form-control required disaction1" id="assignedTo" name="assignedTo">
                                            <option value="0">Select User</option>
                                            <?php if (!empty($users)) {
                                                foreach ($users as $rl) {
                                                    $userText = $rl->name; ?>
                                                    <option value="<?php echo $rl->userId; ?>" <?php if (
    $rl->userId == $assignedTo
) {
    echo "selected=selected";
} ?>><?= $userText ?></option>
                                            <?php
                                                }
                                            } ?>
                                        </select>

                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="taskStatus" name="taskStatus">
                                <option  class="clsopen" value="<?= "Open" ?>" <?php if (
                                    $taskStatus == "Open") { echo "selected=selected";
                                } ?>>Open</option>
                                <option class="clsclose" value="<?= "Closed" ?>" <?php if ($taskStatus == "Closed") {
                                    echo "selected=selected";
                                } ?>>Closed</option>
                                 </select>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                <div class="form-group">
                                    <label for="collaborators">Collaborators <span class="re-mend-field"></span></label>
                                    <input type="hidden" name="existing_collaborators" value="<?php echo $collabrators; ?>">
                                    <select class="form-control required selectpicker" id="collabrators" name="collabrators[]" multiple data-live-search="true">
                                        <option value="0" disabled>Select User</option>
                                        <?php if (!empty($users)) {
                                            // Assuming $collabrators is a comma-separated string of userIds
                                            $selectedCollaborators = explode(
                                                ",",
                                                $collabrators
                                            );

                                            foreach ($users as $rl) {

                                                $userText = $rl->name;
                                                $isCollaborator = in_array(
                                                    $rl->userId,
                                                    $selectedCollaborators
                                                );

                                                $selected = $isCollaborator
                                                    ? "selected"
                                                    : "";
                                                ?>
                                                <option value="<?= $rl->userId ?>" <?= $selected ?>>
                                                    <?= $userText ?>
                                                </option>

                                        <?php
                                            }
                                        } ?>
                                    </select>
                                </div>
                            </div>


                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <!-- <textarea class="form-control required ed-task" id="description" readonly="readonly" name="description"><?php
//echo $description;
?></textarea> -->
                                    <div class="tsk-title"><?php echo $description; ?></div>
                                </div>
                            </div>
                        </div>
                </div><!-- /.box-body -->

                <div class="box-footer">
                    <input type="submit" class="btn btn-primary" value="Submit" />
                   
                </div>
                </form>
            </div>
        </div>
        <div class="col-md-4">
            <?php
            $this->load->helper("form");
            $error = $this->session->flashdata("error");
            if ($error) { ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata("error"); ?>
                </div>
            <?php }
            ?>
            <?php
            $success = $this->session->flashdata("success");
            if ($success) { ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata("success"); ?>
                </div>
            <?php }
            ?>

            <div class="row">
                <div class="col-md-12">
                    <?php echo validation_errors(
                        '<div class="alert alert-danger alert-dismissable">',
                        ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'
                    ); ?>
                </div>
            </div>
        </div>
</div>
</section>
<style type="text/css">
    .ed-task {
        display: none;
    }

    .disaction1 {
        pointer-events: none;
    }
</style>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        filebrowserUploadUrl: "<?= base_url("task/upload") ?>",
        filebrowserUploadMethod: 'form'
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const collaboratorsDropdown = document.getElementById('collaborators');
        const selectedUsersDiv = document.getElementById('selected-users');

        function updateSelectedUsers() {
            const selectedOptions = [...collaboratorsDropdown.selectedOptions];
            selectedUsersDiv.innerHTML = selectedOptions
                .filter(option => option.value !== '0')
                .map(option => `<span class="badge bg-primary me-1">${option.text}</span>`)
                .join(' ');
        }

        // Update selected users on change
        collaboratorsDropdown.addEventListener('change', updateSelectedUsers);

        // Initialize selected users on page load
        updateSelectedUsers();
    });
</script>
</div>