<?php
// $taskId = $taskInfo->taskId;
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Task Management
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <div class="status-filter" style="margin-top: 10px;">
                        <button class="btn btn-info btn-sm filter-btn" data-status="Open">Open</button>
                        <button class="btn btn-success btn-sm filter-btn" data-status="Closed">Closed</button>
                        <button class="btn btn-default btn-sm filter-btn" data-status="All">Show All</button>

                        <div style="margin-top: 10px;float: left;">
                            <form action="<?php echo base_url() ?>task/taskListing" method="POST" id="searchUser">
                                <div class="tsk-filter">
                                    <label for="fromDate">From Date</label>
                                    <input type="date" name="fromDate" value="<?php echo $fromDate; ?>" class="form-control-old input-sm" />
                                </div>
                                <div class="tsk-filter">
                                    <label for="toDate">To Date</label>
                                    <input type="date" name="toDate" value="<?php echo $toDate; ?>" class="form-control-old input-sm" />
                                </div>
                                <div class="tsk-filter">
                                    <label for="statusFilter">Status</label>
                                    <select name="statusFilter" class="form-control-old input-sm">
                                        <option value="All" <?= ($statusFilter == 'All') ? 'selected' : '' ?>>All</option>
                                        <option value="Open" <?= ($statusFilter == 'Open') ? 'selected' : '' ?>>Open</option>
                                        <option value="Closed" <?= ($statusFilter == 'Closed') ? 'selected' : '' ?>>Closed</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary" style="margin-left: 10px;">Apply</button>
                                <a href="<?= base_url('task/taskListing?resetFilter=1') ?>" class="btn btn-sm btn-default" style="margin-left: 5px;">Clear</a>
                            </form>
                        </div>
                        <a class="btn btn-primary" href="<?php echo base_url(); ?>task/add"><i class="fa fa-plus"></i> Add New task</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if (!empty($notifications)) { ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4>Notifications</h4>
                        <ul>
                            <?php foreach ($notifications as $notification) { ?>
                                <li>
                                    <?php echo htmlspecialchars($notification->message); ?>
                                    <?php if ($notification->taskId) { ?>
                                        <a href="<?php echo base_url('task/reply/' . $notification->taskId); ?>">View Task</a>
                                    <?php } ?>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <!-- <h3 class="box-title">To Do List</h3> -->
                        <div class="box-tools"></div>
                    </div><!-- /.box-header -->
                    <div class="box-body table-responsive no-padding1">
                        <div class="card-container">
                            <?php
                            $serial_no = $serial_no;
                            foreach ($records as $record) :
                            ?>
                                <div class="task-card dtfilter" data-created="<?= htmlspecialchars($record->createdDtm) ?>">
                                    <h5><strong>#<?= $serial_no++ ?> - <?= htmlspecialchars($record->taskTitle) ?></strong></h5>

                                    <p><strong>Status:</strong>
                                        <span class="badge-status" style="background-color: <?= $record->status == 'Open' ? 'red' : ($record->status == 'Closed' ? 'green' : '#999') ?>;">
                                            <?= ucfirst($record->status) ?>
                                        </span>
                                        <?php if ($record->status == 'Closed' && $record->updatedBy == 0) : ?>
                                            <span class="badge badge-secondary">Auto-Closed</span>
                                        <?php endif; ?>
                                    </p>

                                    <!-- <p><strong>Assigned By:</strong> <?= htmlspecialchars($this->db->query("SELECT name FROM tbl_users WHERE userId = ?", [$record->assignedBy])->row()->name) ?></p>
                                    <p><strong>Assigned To:</strong> <?= htmlspecialchars($this->db->query("SELECT name FROM tbl_users WHERE userId = ?", [$record->assignedTo])->row()->name) ?></p> -->
                                    <?php
$assignedByUser = $this->db->query("SELECT name FROM tbl_users WHERE userId = ?", [$record->assignedBy])->row();
$assignedToUser = $this->db->query("SELECT name FROM tbl_users WHERE userId = ?", [$record->assignedTo])->row();
?>

<p><strong>Assigned By:</strong>
    <span style="<?= $record->assignedBy == $vendorId ? 'background-color: #5235ad; color: #fff; padding: 2px 6px; border-radius: 3px;' : '' ?>">
        <?= htmlspecialchars($assignedByUser->name) ?>
    </span>
</p>

<p><strong>Assigned To:</strong>
    <span style="<?= $record->assignedTo == $vendorId ? 'background-color: #8b078d; color: #fff; padding: 2px 6px; border-radius: 3px;' : '' ?>">
        <?= htmlspecialchars($assignedToUser->name) ?>
    </span>
</p>


                                    <p><strong>Collaborators:</strong>
                                        <?php
                                        $collaborator_names_str = 'No Collaborators';
                                        if (!empty($record->collabrators)) {
                                            $collaborator_ids = explode(',', $record->collabrators);
                                            if (!empty($collaborator_ids)) {
                                                $placeholders = implode(',', array_fill(0, count($collaborator_ids), '?'));
                                                $query = $this->db->query("SELECT name FROM tbl_users WHERE userId IN ($placeholders)", $collaborator_ids);
                                                $names = array_map(fn ($row) => htmlspecialchars($row->name), $query->result());
                                                $collaborator_names_str = implode(', ', $names);
                                            }
                                        }
                                        echo $collaborator_names_str;
                                        ?>
                                    </p>

                                    <p><strong>Created:</strong> <?= htmlspecialchars($record->createdDtm) ?></p>
                                    <p><strong>Updated:</strong> <?= htmlspecialchars($record->updatedDtm) ?></p>

                                    <div class="card-actions">
                                        <?php
                                        $countQuery = $this->db->query(
                                            "SELECT COUNT(*) as unread_count FROM tbl_task_reply WHERE taskId = ? AND msgRead = 0 AND repliedBy != ?",
                                            [$record->taskId, $vendorId]
                                        );
                                        $unreadCount = $countQuery->row()->unread_count;
                                        ?>
                                      <a href="<?= base_url('task/reply/' . $record->taskId) ?>" 
   class="btn btn-sm btn-info task-reply-link" 
   data-taskid="<?= $record->taskId ?>">
    <i class="fa fa-eye"></i> View
    <span id="unread_count_<?= $record->taskId ?>" class="badge" <?= $unreadCount > 0 ? '' : 'style="display:none;"' ?>>
        <?= $unreadCount ?>
    </span>
</a>
                                        <?php if ($record->assignedBy == $vendorId || $is_admin == 1) : ?>
                                            <a href="<?= base_url() . 'task/edit/' . $record->taskId ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i> Edit</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div><!-- /.box-body -->
                    <div class="box-footer clearfix">
                        <div class="br-pagi">
                            <p>Showing <?= $start ?> to <?= $end ?> of <?= $total_records ?> records</p>
                            <?php echo $links; ?>
                        </div>
                    </div>
                </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>

<style type="text/css">
    .notification {
        position: relative;
        display: inline-block;
    }

    .notification .badge {
        position: absolute;
        top: -12px;
        right: -12px;
        padding: 3px 6px;
        font-size: 12px;
        line-height: 1;
        border-radius: 50%;
        background-color: red;
        color: white;
        z-index: 10;
    }

    .date-picker {
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 4px;
        width: 150px;
        margin-right: 10px;
        font-size: 14px;
    }

    /*My-Card-View-CSS*/
    .card-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: flex-start;
    }

    .task-card {
        background: #fff;
        border: 1px solid #ccc;
        padding: 15px;
        width: calc(25% - 20px);
        /* 4 cards per row with 20px gap */
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        border-radius: 5px;
    }

    .task-card h5 {
        margin-top: 0;
        font-size: 16px;
    }

    .task-card p {
        margin: 6px 0;
        font-size: 14px;
    }

    .badge-status {
        padding: 3px 8px;
        border-radius: 4px;
        color: #fff;
        font-size: 12px;
    }

    .card-actions {
        margin-top: 10px;
    }

    .card-actions .btn {
        margin-right: 5px;
    }
    .tsk-filter{display: contents;}

    @media screen and (max-width: 768px) {
        .task-card {
            width: calc(50% - 20px);
        }
    }

    @media screen and (max-width: 480px) {
        .task-card {
            width: 100%;
        }
    }

    .btn-info .badge {
        color: #fff;
        background-color: #d30707;
    }
    /*END-My-Card-View-CSS*/
</style>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#filterForm").attr("action", baseURL + "task/taskListing/" + value);
            jQuery("#filterForm").submit();
        });

        // Mark replies as read on clicking "View"
    });
$(document).ready(function () {
    $('.task-reply-link').on('click', function (e) {
        e.preventDefault();

        var taskId = $(this).data('taskid');
        var linkHref = $(this).attr('href');
        var badge = $('#unread_count_' + taskId);

        // Instantly hide the badge
        badge.text('0').hide();

        // Send AJAX to mark replies as read in DB
        $.ajax({
            url: '<?= base_url("task/markTaskRepliesRead") ?>',
            type: 'POST',
            data: { taskId: taskId },
            complete: function () {
                // Redirect after update
                window.location.href = linkHref;
            }
        });
    });
});



</script>

<!-- Custom-Card-view-flter-Script -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        const cards = document.querySelectorAll('.task-card');

        // Filter by status
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const status = this.getAttribute('data-status');
                cards.forEach(card => {
                    const cardStatus = card.querySelector('.badge-status')?.textContent.trim();
                    if (status === 'All' || cardStatus === status) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const applyButton = document.getElementById('applyDateFilter');
        const clearButton = document.getElementById('clearDateFilter');

        if (applyButton && clearButton) {
            applyButton.addEventListener('click', function() {
                const startVal = document.getElementById('startDate').value;
                const endVal = document.getElementById('endDate').value;

                const startDate = startVal ? new Date(startVal + 'T00:00:00') : null;
                const endDate = endVal ? new Date(endVal + 'T23:59:59') : null;

                document.querySelectorAll('.dtfilter').forEach(card => {
                    const createdAttr = card.getAttribute('data-created');

                    if (!createdAttr) {
                        card.style.display = 'none';
                        return;
                    }

                    const createdDate = new Date(createdAttr.replace(' ', 'T'));

                    let visible = true;
                    if (startDate && createdDate < startDate) visible = false;
                    if (endDate && createdDate > endDate) visible = false;

                    card.style.display = visible ? '' : 'none';
                });
            });

            clearButton.addEventListener('click', function() {
                document.getElementById('startDate').value = '';
                document.getElementById('endDate').value = '';
                document.querySelectorAll('.dtfilter').forEach(card => {
                    card.style.display = '';
                });
            });
        }
    });

    $('a[href*="task/reply"]').click(function(e) {
    e.preventDefault();
    $.ajax({
        url: $(this).attr('href'),
        success: function(response) {
            // Update counter in UI
            $('#notification-counter').text(response.unread_count || 0);
        }
    });
});
</script>
