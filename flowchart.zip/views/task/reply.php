<?php
$taskId = $taskInfo->taskId;
$taskTitle = $taskInfo->taskTitle;
$description = $taskInfo->description;
$status = $taskInfo->status;
//print_r($status);exit;
$taskattchS3File = $taskInfo->taskattchS3File;
$collabrators = $taskInfo->collabrators;
$selectUserId = '';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Task Management
            <small>Reply Task</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Task Reply</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="taskTitle">Task Title</label>
                                    <input type="text" class="form-control required" value="<?php echo $taskTitle; ?>" id="taskTitle" name="taskTitle" maxlength="256" readonly>
                                    <input type="hidden" value="<?php echo $taskId; ?>" name="taskId" id="taskId" />
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">

                                    <label for="collaborators">Collaborators <span class="re-mend-field"></span></label>
                                    <?php
                                    if (!empty($users)) {
                                        // Assuming $collabrators is a comma-separated string of userIds
                                        $selectedCollaborators = explode(',', $collabrators);

                                        $collaboratorNames = [];
                                        foreach ($users as $rl) {
                                            if (in_array($rl->userId, $selectedCollaborators)) {
                                                $collaboratorNames[] = htmlspecialchars($rl->name);
                                            }
                                        }

                                        // Join all collaborator names with a comma
                                        $collaboratorNamesText = implode(', ', $collaboratorNames);
                                    } else {
                                        $collaboratorNamesText = "No collaborators found.";
                                    }
                                    ?>
                                    <input type="text" class="form-control" id="collaborators-field" value="<?= $collaboratorNamesText ?>" readonly>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group reply-desc-cls">
                                        <label for="description">Description</label>
                                        <?php echo $description; ?><br>
                                    </div>
                                    <div class="form-group reply-desc-cls">
                                        <label for="created">Created At</label>
                                        <?php
                                        $query = $this->db->query("SELECT createdDtm FROM tbl_task WHERE taskId = " . $taskId);
                                        if ($query->num_rows() > 0) {
                                            $row = $query->row();
                                            echo $row->createdDtm;
                                        } else {
                                            echo "No record found";
                                        }
                                        ?><br>
                                    </div>

                                   <?php if (!empty($taskInfo->taskattchS3File)) : 
    $fileUrl = $taskInfo->taskattchS3File;
    $fileExt = strtolower(pathinfo($fileUrl, PATHINFO_EXTENSION));

    $pdfIcon = 'https://cdn-icons-png.flaticon.com/512/337/337946.png';     // PDF icon
    $docIcon = 'https://cdn-icons-png.flaticon.com/512/732/732221.png';     // Word icon
?>
    <div class="col-md-12">
        <div class="form-group">
            <label for="taskTitle">File Attachment</label>
            <a href="<?php echo $fileUrl; ?>" target="_blank">
                <button class="btn" style="border:none; background:none; padding:0;">
                    <?php 
                    if (in_array($fileExt, ['jpg', 'jpeg', 'png', 'gif', 'bmp'])) {
                        // Show the actual image file
                        echo '<img src="' . $fileUrl . '" style="height:50px; width:50px;">';
                    } elseif ($fileExt === 'pdf') {
                        // Show PDF icon
                        echo '<img src="' . $pdfIcon . '" style="height:50px; width:50px;">';
                    } elseif (in_array($fileExt, ['doc', 'docx'])) {
                        // Show DOC icon
                        echo '<img src="' . $docIcon . '" style="height:50px; width:50px;">';
                    } else {
                        // For other file types, show the original URL but this may not render correctly as image
                        echo '<img src="' . $fileUrl . '" style="height:50px; width:50px;">';
                    }
                    ?>
                </button>
            </a>
        </div>
    </div>
<?php endif; ?>


                                    <div class="col-md-12 chat-container" id="repliesList" style="overflow-y:auto; max-height:400px;margin-bottom: 24px;">
                                        <?php
                                        if (!empty($replyData)) {
                                            foreach ($replyData as $replyDat) {
                                                $Query          = "SELECT * FROM tbl_users WHERE userId='$replyDat->repliedBy'";
                                                $fetchAr        = $this->db->query($Query);
                                                $Details        = $fetchAr->row();
                                                $replyName      = $Details->name;
                                        ?>
                                                <span style="color: gray;font-size: 12px;"><i class="fa fa-user"></i> <?php echo $replyName ?> :-</span>
                                                <p><?php echo $replyDat->reply ?></p>
                                                <p> <?php echo $replyDat->createdDtm; ?></p>


                                        <?php
                                            }
                                        }
                                        ?>
                                    </div>

                                    <?php if ($status == 'Open') { ?>
                                        <div class="col-md-12">
                                            <button class="btn btn-sm btn-info" title="Reply" onclick="myFunction()">
                                                <i class="fa fa-reply"></i> Reply
                                            </button>
                                            <a href="<?php echo base_url() ?>task/taskListing" class="btn btn-sm btn-info">Back to List</a>
                                        </div>
                                    <?php } else { ?>
                                        <div class="col-md-12">
                                            <a href="<?php echo base_url() ?>task/taskListing" class="btn btn-sm btn-info">Back to List</a>
                                        </div>
                                    <?php } ?>


                                    <!-- Reply Form -->
                                    <form role="form" id="replyTaskForm" enctype="multipart/form-data">
                                        <input type="hidden" value="<?php echo $taskId; ?>" name="taskId" id="taskId" />
                                        <div class="col-md-12 shodiv" style="margin-top: 13px;">
                                            <div class="form-group">
                                                <textarea class="form-control required" id="taskReply" name="taskReply" placeholder="Type your reply here..."></textarea>
                                            </div>
                                            <div class="form-group">
                                                <label for="file">Upload File</label>
                                                <input type="file" name="file[]" id="file" multiple>
                                            </div>
                                            <input type="submit" class="btn btn-sm btn-primary" value="Submit" />
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
</div>
<style type="text/css">
    textarea.form-control {
        height: 250px;
    }

    .reply-desc-cls p {
        word-wrap: break-word;
    }

    .reply-desc-cls .table td {
        word-wrap: break-word;
    }
    /*New-Style*/
    .chat-container {
    background: #e5ddd5;
    padding: 15px;
    border-radius: 5px;
    max-height: 400px;
    overflow-y: auto;
    border: 2px solid #767676;
}

.chat-bubble {
    padding: 10px 15px;
    margin: 10px 0;
    border-radius: 10px;
    max-width: 75%;
    position: relative;
    clear: both;
    display: inline-block;
    word-wrap: break-word;
}

.chat-bubble.sent {
    background: #dcf8c6;
    float: right;
    border-top-right-radius: 0;
    text-align: left;
}

.chat-bubble.received {
    background: #fff;
    float: left;
    border-top-left-radius: 0;
    text-align: left;
}

.chat-meta {
    font-size: 11px;
    color: gray;
    margin-top: 5px;
    text-align: right;
}

.chat-username {
    font-size: 12px;
    font-weight: bold;
    color: #555;
    margin-bottom: 5px;
}
#repliesList {
    scroll-behavior: smooth;
}

    /*End-New-Style*/
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<!-- <script src="https://cdn.ckeditor.com/ckeditor5/39.0.0/classic/ckeditor.js"></script> -->
<script type="text/javascript">
    $('.shodiv').hide();

    function myFunction(params) {
        $('.shodiv').show();
    }
</script>
<script>
    ClassicEditor
        .create(document.querySelector("#taskReply"))
        .catch(error => {
            console.er
            ror(error);
        });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    if (typeof jQuery === 'undefined') {
        document.write('<script src="https://code.jquery.com/jquery-3.6.0.min.js"><\/script>');
    }
</script>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.0/classic/ckeditor.js"></script>
<script type="text/javascript">
let ckEditorInstance;
let uploadedFiles = []; // Array to store uploaded file URLs

// Initialize CKEditor
ClassicEditor.create(document.querySelector('#taskReply'))
    .then(editor => {
        ckEditorInstance = editor; // Save editor instance for future use
    })
    .catch(error => {
        console.error('Error initializing CKEditor:', error);
    });

// Handle form submission
$('#replyTaskForm').submit(function (e) {
    e.preventDefault();

    const replyText = ckEditorInstance.getData().trim();
    const fileInput = $('#file')[0].files;

    if (!replyText && fileInput.length === 0 && uploadedFiles.length === 0) {
        alert('Please provide a reply text or upload a file before submitting.');
        return;
    }

    let formData = new FormData(this);
    formData.set('taskReply', replyText);

    uploadedFiles.forEach((file, index) => {
        formData.append(`uploadedFiles[${index}]`, file);
    });

    $.ajax({
        url: '<?php echo base_url("task/replyTask") ?>',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            console.log('Raw Response:', response); // ✅ Debugging Response

            // Check if response is a valid JSON string
            if (typeof response === 'string') {
                try {
                    response = JSON.parse(response);
                } catch (e) {
                    console.error('JSON Parsing Error:', e, 'Server Response:', response);
                    alert('Error processing response from the server.');
                    return;
                }
            }

            if (response && response.success) {
                appendReply(response); 
                uploadedFiles = []; 
                saveRepliesToLocalStorage();
                clearInputs();
            } else {
                alert(response.message || 'Error submitting reply.');
            }
        },
        error: function (xhr, status, error) {
            console.error('AJAX Error:', xhr.responseText || error);
            alert('An error occurred while submitting the form.');
        }
    });

    return false;
});


// Fetch and render replies from server or localStorage on page load
$(document).ready(function () {
    const taskId = $('#taskId').val();
    fetchReplies(taskId);
});

// Fetch replies from the server or localStorage
function fetchReplies() {
    const taskId = $('#taskId').val();

    $.ajax({
        url: '<?php echo base_url("task/getReplies") ?>',
        type: 'GET',
        data: { taskId: taskId },
        success: function (response) {
            if (typeof response === 'string') {
                try {
                    response = JSON.parse(response);
                } catch (e) {
                    console.error('Invalid JSON:', e);
                    return;
                }
            }

            if (response.success && Array.isArray(response.replies)) {
                $('#repliesList').html('');

                // ✅ Reverse the array to show oldest at the top
                const orderedReplies = response.replies.reverse();

                orderedReplies.forEach(reply => appendReply(reply));

                // ✅ Scroll to bottom
                const repliesList = document.getElementById('repliesList');
                repliesList.scrollTop = repliesList.scrollHeight;
            }
        },
        error: function (xhr, status, error) {
            console.error('Fetch error:', error);
        }
    });
}


// Append a new reply to the list
function appendReply(reply) {
    const currentUserId = <?php echo json_encode($this->session->userdata('userId')); ?>;
    const isSender = reply.repliedBy == currentUserId;
    const bubbleClass = isSender ? 'sent' : 'received';

    let html = `
    <div class="chat-bubble ${bubbleClass}">
        <div class="chat-username">${reply.username}</div>
        <div class="chat-text">${reply.reply}</div>
        <div class="chat-meta">${reply.createdDtm}</div>
    `;

    if (reply.taskreplyattchS3File && Array.isArray(reply.taskreplyattchS3File)) {
        html += `<div class="attachments">`;
        reply.taskreplyattchS3File.forEach(function (file) {
            const ext = file.split('.').pop().toLowerCase();
            if (['jpg', 'jpeg', 'png'].includes(ext)) {
                html += `<a href="${file}" target="_blank">
                            <img src="${file}" style="width: 90px; height: auto; margin-top: 5px;">
                        </a>`;
            } else {
                html += `<div><a href="${file}" target="_blank">Download File</a></div>`;
            }
        });
        html += `</div>`;
    }

    html += `</div>`;

    $('#repliesList').append(html);

    // ✅ Auto-scroll to bottom
    const repliesList = document.getElementById('repliesList');
    repliesList.scrollTop = repliesList.scrollHeight;
}


// Save replies to localStorage
function saveRepliesToLocalStorage() {
    const taskId = $('#taskId').val();
    const repliesHtml = $('#repliesList').html();
    localStorage.setItem(`repliesList_${taskId}`, repliesHtml);
}

// Restore uploaded files from localStorage replies
function restoreUploadedFilesFromReplies() {
    $('#repliesList img').each(function () {
        const fileUrl = $(this).attr('src');
        if (!uploadedFiles.includes(fileUrl)) {
            uploadedFiles.push(fileUrl);
        }
    });
}

// Clear CKEditor content and file input
function clearInputs() {
    ckEditorInstance.setData(''); // Clear CKEditor content
    $('#file').val(''); // Clear file input (but retain uploaded files)
}
</script>



