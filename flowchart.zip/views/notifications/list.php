<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-user-circle-o" aria-hidden="true"></i> Notifications</h1>
    </section>

    <section class="content">
        <?php
            $this->load->helper('form');
            $error = $this->session->flashdata('error');
            if($error){
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error; ?>                    
        </div>
        <?php } ?>

        <?php
            $success = $this->session->flashdata('success');
            if($success){
        ?>
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $success; ?>
        </div>
        <?php } ?>

        <div class="row">
            <div class="col-md-12">
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Notification List</h3>
                        <div class="box-tools">
                            <select id="notificationFilter" class="form-control" style="width: 150px;">
                                <option value="unread" selected>Unread</option>
                                <option value="read">Read</option>
                                <option value="all">All</option>
                            </select>
                        </div>
                    </div>

                    <div class="box-body table-responsive no-padding1">
                        <table id="notificationTable" class="display responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Message</th>
                                    <th>Created At</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($notifications)) { 
                                    foreach ($notifications as $notify) { ?>
                                    <tr class="notification-row" 
                                        data-id="<?php echo $notify->id; ?>" 
                                        data-taskid="<?php echo $notify->taskId; ?>" 
                                        
                                        style="cursor: pointer; <?php echo $notify->is_read ? '' : 'font-weight: bold;'; ?>">
   <td>
    <?php
        $baseUrl = base_url();
        $targetUrl = "#";

        if (!empty($notify->taskId)) {
            $targetUrl = $baseUrl . 'task/reply/' . $notify->taskId;
        } elseif (!empty($notify->supportMeetingId)) {
            $targetUrl = $baseUrl . 'support/edit/' . $notify->supportMeetingId;
        } elseif (!empty($notify->branchesId)) {
            $targetUrl = $baseUrl . 'branches/view/' . $notify->branchesId;
        } elseif (!empty($notify->announcementId)) {
            $targetUrl = $baseUrl . 'announcement/view/' . $notify->announcementId;
        } elseif (!empty($notify->blogId)) {
            $targetUrl = $baseUrl . 'blog/edit/' . $notify->blogId;
        } elseif (!empty($notify->pdcId)) {
            $targetUrl = $baseUrl . 'pdc/edit/' . $notify->pdcId;
        } elseif (!empty($notify->customDesignId)) {
            $targetUrl = $baseUrl . 'customdesign/edit/' . $notify->customDesignId;
        } elseif (!empty($notify->despatchId)) {
            $targetUrl = $baseUrl . 'despatch/view/' . $notify->despatchId;
        } elseif (!empty($notify->acattachmentId)) {
            $targetUrl = $baseUrl . 'acattachment/edit/' . $notify->acattachmentId;
        } elseif (!empty($notify->lgattachmentId)) {
            $targetUrl = $baseUrl . 'lgattachment/edit/' . $notify->lgattachmentId;
        } elseif (!empty($notify->leaveId)) {
            $targetUrl = $baseUrl . 'leave/view/' . $notify->leaveId;
        } elseif (!empty($notify->faqId)) {
            $targetUrl = $baseUrl . 'faq/view/' . $notify->faqId;
        } elseif (!empty($notify->brsetupid)) {
            $targetUrl = $baseUrl . 'branchinstallation/edit/' . $notify->brsetupid;
        } elseif (!empty($notify->admid)) {
            $targetUrl = $baseUrl . 'admissiondetails/edit/' . $notify->admid;
        } elseif (!empty($notify->stockId)) {
            $targetUrl = $baseUrl . 'stock/edit/' . $notify->stockId;
        } elseif (!empty($notify->freegiftId)) {
            $targetUrl = $baseUrl . 'freegift/edit/' . $notify->freegiftId;
        } elseif (!empty($notify->socialId)) {
            $targetUrl = $baseUrl . 'socialmedia/socialmediaListing/' . $notify->socialId;
        } elseif (!empty($notify->staffId)) {
            $targetUrl = $baseUrl . 'staff/staffListing/';
        } elseif (!empty($notify->onboardfrmId)) {
            $targetUrl = $baseUrl . 'onboardingforms/onboardingformsListing/';
        } elseif (!empty($notify->amcId)) {
            $targetUrl = $baseUrl . 'amc/view/' . $notify->amcId;
        } elseif (!empty($notify->locationApprovalId)) {
            $targetUrl = $baseUrl . 'locationapproval/locationapprovalListing/';
        } elseif (!empty($notify->adminMeetingId)) {
            $targetUrl = $baseUrl . 'administrationtraining/administrationtrainingListing/';
        } elseif (!empty($notify->trainingId)) {
            $targetUrl = $baseUrl . 'training/view/' . $notify->trainingId;
        } elseif (!empty($notify->id)) {
            $targetUrl = $baseUrl . 'task/reply/' . $notify->id;
        }
    ?>
    <a href="<?php echo $targetUrl; ?>">
        <?php echo htmlspecialchars_decode($notify->message); ?>
    </a>
</td>


                                        <td><?php echo date('d-m-Y H:i:s', strtotime($notify->created_at)); ?></td>
                                        <td>
                                            <span class="status <?php echo $notify->is_read ? 'read' : 'unread'; ?>">
                                                <?php echo $notify->is_read ? 'Read' : 'Unread'; ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php } } ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="box-footer clearfix"></div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- JQuery and DataTables JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>

<!-- Initialize DataTable and Handle Filter/Click -->
<script type="text/javascript">
    $(document).ready(function() {
        var table = $('#notificationTable').DataTable({
            responsive: true
        });

        $('#notificationFilter').on('change', function() {
            var filter = $(this).val();
            window.location.href = '<?php echo base_url('Notification/all_notifications'); ?>?filter=' + filter;
        });

        $('#notificationTable tbody').on('click', '.notification-row', function () {
            var $row = $(this);
            var notificationId = $row.data('id');
            var taskId = $row.data('taskid');
            var module = $row.data('module');

            $.ajax({
                url: '<?php echo base_url('Notification/mark_as_read'); ?>',
                type: 'POST',
                data: {
                    id: notificationId,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function (response) {
                    if (response.status === 'success') {
                        $row.css('font-weight', 'normal');
                        $row.find('td:last span').removeClass('unread').addClass('read').text('Read');
                        table.row($row).invalidate().draw();

                        if (taskId && module) {
                            let redirectUrl = '';
                            switch (module) {
                                case 'task':
                                    redirectUrl = '<?php echo base_url('task/edit/'); ?>' + taskId;
                                    break;
                                case 'support':
                                    redirectUrl = '<?php echo base_url('support/edit/'); ?>' + taskId;
                                    break;
                                case 'branch':
                                    redirectUrl = '<?php echo base_url('branch/edit/'); ?>' + taskId;
                                    break;
                                case 'announcement':
                                    redirectUrl = '<?php echo base_url('announcement/edit/'); ?>' + taskId;
                                    break;
                                case 'blog':
                                    redirectUrl = '<?php echo base_url('blog/edit/'); ?>' + taskId;
                                    break;
                                case 'pdc':
                                    redirectUrl = '<?php echo base_url('pdc/edit/'); ?>' + taskId;
                                    break;
                                case 'design':
                                    redirectUrl = '<?php echo base_url('internaldesign/edit/'); ?>' + taskId;
                                    break;
                                case 'despatch':
                                    redirectUrl = '<?php echo base_url('despatch/edit/'); ?>' + taskId;
                                    break;
                                case 'stock':
                                    redirectUrl = '<?php echo base_url('stock/edit/'); ?>' + taskId;
                                    break;
                                // Add other modules here
                                default:
                                    redirectUrl = '';
                            }

                            if (redirectUrl) {
                                window.location.href = redirectUrl;
                            }
                        }
                    }
                },
                error: function () {
                    alert('Error occurred while marking notification as read.');
                }
            });
        });
    });
</script>

<!-- Custom CSS -->
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    .notification .badge {
        position: absolute;
        top: 91px;
        right: 50px;
        padding: 5px 8px;
        border-radius: 50%;
        background-color: red;
        color: white;
    }
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        min-width: 50%;
        font-weight: bold;
    }
    .notification-row:hover {
        background-color: #f0f0f0;
    }
    .status.read {
        color: green;
        font-weight: normal;
    }
    .status.unread {
        color: red;
        font-weight: bold;
    }
</style>
