<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Attendance Management
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>leave/add">
                        <i class="fa fa-plus"></i> Apply Leave
                    </a>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="remaining-leaves">
                    <p>Assigned Leaves for the Year: <?php echo $totalLeaves; ?></p>
                    <p>Total Applied Leave Days: <?php echo $totalAppliedDays; ?></p>
                    <p>Remaining Leaves for the Year: <?php echo max(0, $totalLeaves - $totalAppliedDays); ?></p>

                </div>
                 <div class="row">
                        <div class="col-md-12">
                            <form method="get" action="<?php echo base_url('leave/leaveListing'); ?>" class="form-inline">
                                <div class="form-group">
                                    <label for="start_date">Start Date:</label>
                                    <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo isset($_GET['start_date']) ? $_GET['start_date'] : ''; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="end_date">End Date:</label>
                                    <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo isset($_GET['end_date']) ? $_GET['end_date'] : ''; ?>">
                                </div>
                                <button type="submit" class="btn btn-primary">Filter</button>
                                <a href="<?php echo base_url('leave/leaveListing'); ?>" class="btn btn-default">Reset</a>
                            </form>
                        </div>
                    </div>
                <!--  <div class="atten-rec">
                   <p><strong>Casual Leaves:</strong> 5 (Remaining: <?= $remainingCasual ?>)</p>
<p><strong>Sick Leaves:</strong> 3 (Remaining: <?= $remainingSick ?>)</p>
<p><strong>Annual Leaves:</strong> 5 (Remaining: <?= $remainingAnnual ?>)</p>
                </div> -->
                <div class="box">
                    <div class="box-header">
                        <div class="box-tools"></div>
                    </div>
                    <!--Leaves Calculation-->
                    <!--end here -->
                   
                    <div class="box-body table-responsive no-padding1">
                        <table id="example" class="display responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Leave Type</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Status</th>
                                    <th>Applied On</th>
                                    <th>View</th>
                                    <th>Cancelled</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php $serial = $serial_no;
                                //   print_r($leaveData);exit;
                                ?>
                                <?php foreach ($leaveData as $leave): ?>


                                    <tr>

                                        <td><?php echo $serial++; ?></td>
                                        <td><?php echo $leave['leave_type']; ?></td>
                                        <td><?php echo $leave['start_date']; ?></td>
                                        <td><?php echo $leave['end_date']; ?></td>

                                        <td><?php echo $leave['status']; ?></td>
                                        <td><?php echo $leave['created_at']; ?></td>
                                        <td>
                                            <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'leave/view/' . $leave['leaveId']; ?>" title="View">
                                                <i class="fa fa-eye"></i>
                                        </td>
                                        <td>
                                            <?php if ($leave['status'] == 'pending'): ?>
                                                <form method="post" action="<?= base_url('leave/cancelLeave') ?>" style="display:inline;" onsubmit="return confirm('Are you sure you want to cancel this leave?');">
                                                    <input type="hidden" name="leaveId" value="<?= $leave['leaveId']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger">Cancel</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>


                                    </tr>


                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="box-footer clearfix">
                        <div class="br-pagi">
                            <?php echo $pagination; ?>
                            <p>Showing <?php echo $startRecord; ?> to <?php echo $endRecord; ?> of <?php echo $totalRecords; ?> records</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }

    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        min-width: 50%;
        font-weight: bold;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }

    div.dataTables_wrapper li {
        text-indent: 0;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
        content: "-";
        background-color: #d33333;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }

    .remaining-leaves {
        display: flex;
        flex-wrap: wrap;
        /* Makes it responsive on smaller screens */
        gap: 20px;
        /* Spacing between the items */
        justify-content: center;
        /* Center horizontally */
        align-items: center;
        /* Center vertically */
        padding: 10px;
        text-align: center;
    }

    .remaining-leaves p {
        margin: 0;
        padding: 10px 15px;
        background-color: #FF9800;
        border-radius: 8px;
        flex: 1 1 auto;
        min-width: 150px;
        color: #fff;
        font-weight: 600;
    }

    .atten-rec {
        display: flex;
        flex-wrap: wrap;
        /* Makes it responsive on smaller screens */
        gap: 20px;
        /* Spacing between the items */
        justify-content: center;
        /* Center horizontally */
        align-items: center;
        /* Center vertically */
        padding: 10px;
        text-align: center;
    }

    .atten-rec p {
        margin: 0;
        padding: 10px 15px;
        background-color: #FF9800;
        border-radius: 8px;
        flex: 1 1 auto;
        min-width: 150px;
        color: #fff;
        font-weight: 600;
    }
</style>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });
    $(document).ready(function() {
        $("#example_paginate").hide();
        $("#example_info").hide();
    });
</script>

<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>