<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Leave Management
            <small>Add / Edit Leave</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- Left column -->
            <div class="col-md-9">
                <!-- General form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Leave Details</h3>
                    </div><!-- /.box-header -->
                    
                    <!-- Form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>leave/addNewLeave" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- Start Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="start_date">Start Date</label>
                                        <input type="date" class="form-control required" id="start_date" name="start_date" maxlength="256">
                                    </div>
                                </div>
                                <!-- End Date -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="end_date">End Date</label>
                                        <input type="date" class="form-control required" id="end_date" name="end_date" maxlength="256">
                                    </div>
                                </div>
                                <!-- Leave Type -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="leave_type">Leave Type</label>
                                        <select class="form-control required" id="leave_type" name="leave_type">
                                            <option value="Sick Leave">Sick Leave</option>
                                            <option value="Casual Leave">Casual Leave</option>
                                            <option value="Annual Leave">Annual Leave</option>
                                            <option value="Half Day">Half Day</option>
                                            <option value="Early Departure">Early Departure</option>
                                            <option value="Late Arrival">Late Arrival</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Reporting Manager -->
                 <div class="col-md-3">
                <div class="form-group">
                   <label for="assignedTo">Reporting Manager</label>
                  <select class="form-control required" id="assignedTo" name="assignedTo" required>
    <option value="0">Select User</option>
    <?php if (!empty($users)) : ?>
        <?php foreach ($users as $rl): ?>
            <?php 
                // Skip users with role 25
                if ($rl->roleId == 25) {
                    continue;
                }
                $userText = $rl->name; 
            ?>
            <option value="<?php echo $rl->userId ?>" <?php if ($rl->userId == set_value('assignedTo')) echo "selected=selected"; ?>>
                <?= htmlspecialchars($userText); ?>
            </option>
        <?php endforeach; ?>
    <?php endif; ?>
</select>

                                    </div>
                                </div>
                                <!-- Reason -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="reason">Reason</label>
                                    <textarea class="form-control required" id="reason" name="reason" rows="15" cols="82"></textarea>
                                </div>
                            </div>

                            <!-- File attachment section -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="file">Attachment (optional)</label>
                                    <input type="file" class="form-control" id="file" name="file[]" multiple>
                                </div>
                            </div>
                            </div><!-- /.row -->

                            
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" id="submitBtn" value="Submit" name="submit">
                        </div>
                    </form>
                </div><!-- /.box -->
            </div><!-- /.col-md-9 -->

            <!-- Right column -->
            <div class="col-md-4">
                <?php $this->load->helper('form'); ?>
                <?php if ($this->session->flashdata('error')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('success')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', 
                            ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div><!-- /.col-md-4 -->
        </div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<!-- Set minimum date for start_date and end_date -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('start_date').setAttribute('min', today);
        document.getElementById('end_date').setAttribute('min', today);
    });
</script>

<!-- Disable submit button on form submission -->
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
