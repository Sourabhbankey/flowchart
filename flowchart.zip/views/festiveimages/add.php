
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Festiveimages Management
        <small>Add / Edit </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter festiveimages Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>festiveimages/addNewFestiveimages" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="blogTitle">Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('festiveimagesTitle'); ?>" id="festiveimagesTitle" name="festiveimagesTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                               
                           
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="blogS3Image">Upload Image <span class="re-mend-field">*</span></label>
                                        <input required type="file" class="form-control required" value="" id="file" name="file" maxlength="256">
                                    </div>   
                                </div>
                               
                               
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script>
    $(document).ready(function() {
        $('#publishedPlatform').select2();
    });
</script>
<script>
    jQuery(document).ready(function() {
    // Ensure jQuery is loaded
    if (typeof jQuery === 'undefined') {
        console.error('jQuery is not loaded.');
        return;
    }

    // Function to get CSRF token values
    var getCsrfToken = function() {
        var name = jQuery('#csrf_token_name').val();
        var hash = jQuery('#csrf_token_hash').val();
        if (!name || !hash) {
            console.error('CSRF token name or hash is missing.');
            return null;
        }
        return { name: name, hash: hash };
    };

    // Handle read-more button click
    jQuery(document).on('click', '.read-more', function(e) {
        var $button = jQuery(this);
        var blogId = $button.data('blogid');
        var csrf = getCsrfToken();

        // Validate blogId and CSRF token
        if (!blogId) {
            console.error('Blog ID is undefined.');
            alert('Error: Blog ID is missing.');
            return;
        }
        if (!csrf) {
            console.error('CSRF token is invalid or missing.');
            alert('Error: Security token is missing.');
            return;
        }

        // Send AJAX request to update opened count
        jQuery.ajax({
            url: '<?php echo base_url(); ?>blog/updateOpenedCount',
            type: 'POST',
            data: { 
                blogId: blogId,
                [csrf.name]: csrf.hash
            },
            dataType: 'json',
            success: function(response) {
                console.log('AJAX Success Response:', response);
                if (response.success) {
                    // Update the opened count in the UI
                    jQuery('#opened-count-' + blogId).text(response.newCount);
                    // Update CSRF token if provided in response
                    if (response.csrfHash) {
                        jQuery('#csrf_token_hash').val(response.csrfHash);
                        console.log('Updated CSRF token:', response.csrfHash);
                    }
                } else {
                    console.error('Failed to update opened count: ' + (response.message || 'Unknown error'));
                    alert('Failed to update count: ' + (response.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText,
                    statusCode: xhr.status
                });
                alert('Failed to update blog opened count. Please try again.');
            }
        });
    });
});
</script>
<script>
jQuery(document).ready(function() {
    // File input validation
    $('#file').on('change', function() {
        const file = this.files[0];
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/webm', 'video/mov'];

        if (file) {
            // Check file type
            if (!allowedTypes.includes(file.type)) {
                alert('Invalid file type. Please upload an image (JPEG, PNG, GIF) or video (MP4, WEBM, MOV).');
                this.value = ''; // Clear the input
                return;
            }

            // Optional: Preview the file
            const preview = document.createElement(file.type.startsWith('image') ? 'img' : 'video');
            preview.style.maxWidth = '200px';
            preview.style.marginTop = '10px';
            preview.src = URL.createObjectURL(file);
            if (file.type.startsWith('video')) {
                preview.controls = true;
            }
            $('#file').nextAll('img, video').remove(); // Remove any existing previews
            $('#file').after(preview);
        }
    });

    // Remove preview on reset
    $('input[type="reset"]').on('click', function() {
        $('#file').nextAll('img, video').remove();
    });
});
</script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>