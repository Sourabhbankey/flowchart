<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header -->
    <section class="content">
        <!-- CSRF Tokens -->
        <input type="hidden" id="csrf_token_name" value="<?php echo htmlspecialchars($this->security->get_csrf_token_name()); ?>">
        <input type="hidden" id="csrf_token_hash" value="<?php echo htmlspecialchars($this->security->get_csrf_hash()); ?>">

        <?php if ($is_admin == 1 || $role == 14 || $role == 19) { ?>
            <div class="row">
                <div class="col-xs-12 text-right">
                    <div class="form-group">
                        <a class="btn btn-primary" href="<?php echo base_url(); ?>festiveimages/add"><i class="fa fa-plus"></i> Add New Images</a>
                    </div>
                </div>
            </div>
        <?php } ?>

        <!-- Flash messages -->
        <div class="row">
            <div class="col-md-12">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($is_admin == 1 || $role == 14 || $role == 19) { ?>
            <div class="form-group text-right">
                <a class="btn btn-primary" href="<?php echo base_url(); ?>festiveimages/add"><i class="fa fa-plus"></i> Add New Images</a>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Festive Images List</h3>
                    </div>
                    <div class="box-body table-responsive no-padding">
                        <div class="container-old">
                            <div class="row">
                                <?php if ($role != 25) { ?>
                                    <!-- Single Row for Franchise, Address, Contact, and Font Size -->
                                    <div class="row mb-4 align-items-end">
                                        <div class="col-md-3 col-sm-6">
                                            <div class="form-group">
                                                <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                                <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchFranchiseData(this.value)">
                                                    <option value="">Select Franchise</option>
                                                    <?php
                                                    if (!empty($branchDetail)) {
                                                        $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                        foreach ($branchDetail as $bd) {
                                                            $selected = ($bd->franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?php echo htmlspecialchars($bd->franchiseNumber); ?>" <?php echo $selected; ?>>
                                                                <?php echo htmlspecialchars($bd->franchiseNumber); ?>
                                                            </option>
                                                    <?php
                                                        }
                                                    } else {
                                                        echo '<option value="">No franchises available</option>';
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-6">
                                            <div class="form-group">
                                                <label for="branchAddress">Branch Address <span class="re-mend-field">*</span></label>
                                                <input type="text" class="form-control required" id="branchAddress" name="branchAddress"
                                                    value="<?php echo htmlspecialchars($this->session->userdata('branchAddress') ?: ''); ?>"
                                                    maxlength="255" required readonly aria-describedby="brAddressLoading">
                                                <span id="brAddressLoading" class="help-block" style="display: none;">Loading...</span>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-6">
                                            <div class="form-group">
                                                <label for="mobile">Contact Number <span class="re-mend-field">*</span></label>
                                                <input type="text" class="form-control required" id="mobile" name="mobile"
                                                    value="<?php echo htmlspecialchars($this->session->userdata('branchContacNum') ?: ''); ?>"
                                                    maxlength="255" required readonly aria-describedby="branchContacNumLoading">
                                                <span id="branchContacNumLoading" class="help-block" style="display: none;">Loading...</span>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-6">
                                            <div class="form-group">
                                                <label for="fontSizeSelector">Change Font Size</label>
                                                <select id="fontSizeSelector" class="form-control">
                                                    <option value="10px">Small</option>
                                                    <option value="12px" selected>Default</option>
                                                    <option value="14px">Medium</option>
                                                    <option value="16px">Large</option>
                                                    <option value="18px">Extra Large</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                <?php } else { ?>
                                    <input type="hidden" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber') ?: ''); ?>">
                                <?php } ?>
                                <!-- Festive Images List -->
                                <?php
                                if (!empty($records)) {
                                    foreach ($records as $record) {
                                        $festiveTitle = htmlspecialchars($record->festiveimagesTitle);
                                        $franchiseNumber = htmlspecialchars($record->franchiseNumber);
                                        // Use session data for role 25, otherwise use pre-fetched franchise data
                                        if ($role == 25) {
                                            $mobile = htmlspecialchars($this->session->userdata('branchContacNum') ?: '1234567890');
                                            $address = htmlspecialchars($this->session->userdata('branchAddress') ?: 'N/A');
                                        } else {
                                            $mobile = htmlspecialchars($franchiseData[$franchiseNumber]['mobile'] ?? '1234567890');
                                            $address = htmlspecialchars($franchiseData[$franchiseNumber]['branchAddress'] ?? 'N/A');
                                        }
                                        $mediaUrl = htmlspecialchars($record->festiveimagesS3Image);
                                        $id = htmlspecialchars($record->festiveimagesId);
                                        $extension = strtolower(pathinfo($mediaUrl, PATHINFO_EXTENSION));
                                        $isVideo = in_array($extension, ['mp4', 'webm', 'mov']);
                                ?>
                                        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                                            <div class="card-wrapper text-center">
                                                <div class="card-title h5 mb-2"><?php echo $festiveTitle; ?></div>
                                                <div class="card position-relative" id="card_<?php echo $id; ?>" data-franchise-number="<?php echo $franchiseNumber; ?>">
                                                    <?php if ($isVideo) { ?>
                                                        <video controls class="w-100" style="object-fit: cover;" crossOrigin="Anonymous">
                                                            <source src="<?php echo $mediaUrl; ?>" type="video/<?php echo $extension; ?>">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php } else { ?>
                                                        <img src="<?php echo $mediaUrl; ?>" alt="Festive Image" class="img-fluid" >
                                                    <?php } ?>
                                                    <div class="watermark position-absolute">eduMETA</div>
                                                    <div class="overlay position-absolute">
                                                        <div class="address" aria-label="Address: <?php echo $address; ?>" id="card_address_<?php echo $id; ?>"><?php echo $address; ?></div>
                                                        <div class="mobile" aria-label="Mobile: <?php echo $mobile; ?>" id="card_mobile_<?php echo $id; ?>"><?php echo $mobile; ?></div>
                                                    </div>
                                                </div>
                                                <button class="btn btn-primary mt-2 save-btn" id="save_btn_<?php echo $id; ?>" onclick="saveCardAsImage(<?php echo $id; ?>, '<?php echo $isVideo ? 'video' : 'image'; ?>')">
                                                    Download <?php echo $isVideo ? 'Video' : 'Image'; ?>
                                                </button>
                                            </div>
                                        </div>
                                <?php
                                    }
                                } else {
                                    echo "<div class='col-12'><p>No data available.</p></div>";
                                }
                                ?>
                            </div>
                        </div>
                        <div class="box-footer clearfix">
                            <?php echo $this->pagination->create_links(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- CSS -->
<style type="text/css">
    .card {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 0px;
        margin-bottom: 7px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .card-img-top {
        width: 100%;
    }

    .card-title {
        font-size: 1.2em;
        font-weight: bold;
    }

    .card-text {
        font-size: 0.9em;
        color: #555;
    }

    .blogbtn {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 8px 16px;
        text-decoration: none;
        border-radius: 5px;
    }

    .blogbtn:hover {
        background-color: #0056b3;
    }

    .actions a {
        margin-right: 10px;
    }

    .actions.mt-2 {
        margin: 10px 0px 0px 0px;
    }

    .row {
        margin-right: -10px;
        margin-left: -10px;
    }

    .card-container {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        justify-content: center;
        max-width: 1050px;
        margin: 0 auto;
    }

    .card-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }

    .card {
        position: relative;
        width: 325px;
        height: 450px;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border: none;
    }

    .card-title {
        font-size: 1.1em;
        font-weight: bold;
        position: relative;
        overflow: hidden;
        z-index: 1;
    }

    .card img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .watermark {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) rotate(-45deg);
        color: rgba(255, 255, 255, 0.1);
        font-size: 2em;
        font-weight: bold;
        pointer-events: none;
    }

    .overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        color: black;
        padding: 8px 16px 29px 16px;
        box-sizing: border-box;
        background: none !important;
    }

    .overlay .address,
    .overlay .mobile {
        font-size: 0.75em;
        margin-top: 5px;
        font-weight: 600;
        color: black;
    }

    .save-btn {
        margin-bottom: 15px;
        padding: 10px 20px;
        background: linear-gradient(135deg, #ff9f43, #ee5253);
        color: white;
        border: none;
        border-radius: 25px;
        cursor: pointer;
        text-decoration: none;
        font-weight: 600;
        position: relative;
        overflow: hidden;
        transition: transform 0.3s ease;
    }

    .save-btn::after {
        content: '↓';
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        opacity: 0;
        transition: all 0.3s ease;
    }

    .save-btn:hover {
        background: linear-gradient(135deg, #ee5253, #ff9f43);
    }

    .save-btn:hover::after {
        opacity: 1;
        right: 15px;
    }

    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 30px;
        gap: 10px;
    }

    .pagination a {
        padding: 10px 15px;
        background-color: #ff6b6b;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .pagination a:hover {
        background-color: #4ecdc4;
    }

    .pagination a.active {
        background-color: #ee5253;
        cursor: default;
    }

    .pagination a.disabled {
        background-color: #ccc;
        cursor: not-allowed;
    }

    @keyframes shine {
        0% {
            transform: translateX(-100%) rotate(30deg);
        }

        50% {
            transform: translateX(100%) rotate(30deg);
        }

        100% {
            transform: translateX(-100%) rotate(30deg);
        }
    }

    @media (max-width: 1050px) {
        .card-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }

    @media (max-width: 700px) {
        .card-container {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script>
    function saveCardAsImage(id, mediaType) {
        const card = document.getElementById(`card_${id}`);
        if (!card) {
            console.error(`Card with ID card_${id} not found.`);
            alert('Error: Card not found.');
            return;
        }

        if (mediaType === 'video') {
            const video = card.querySelector('video');
            if (!video) {
                console.error(`No video found in card_${id}.`);
                alert('Error: Video not found.');
                return;
            }
            const source = video.querySelector('source');
            if (!source || !source.src) {
                console.error(`No source found in video for card_${id}.`);
                alert('Error: Video source not found.');
                return;
            }

            fetch(source.src, {
                    method: 'GET',
                    mode: 'cors',
                    headers: {
                        'Accept': source.type || 'video/mp4'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.blob();
                })
                .then(blob => {
                    const url = window.URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `festive_video_${id}.${source.src.split('.').pop()}`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                })
                .catch(error => {
                    console.error(`Failed to download video for card_${id}:`, error);
                    alert('Error: Failed to download video. Please check the video URL or try again later.');
                });
        } else {
            const img = card.querySelector('img');
            if (!img) {
                console.error(`No image found in card_${id}.`);
                alert('Error: Image not found.');
                return;
            }
            if (!img.complete || img.naturalWidth === 0) {
                console.error(`Image in card_${id} not loaded. Attempting to reload.`);
                img.crossOrigin = 'Anonymous';
                img.src = img.src + (img.src.includes('?') ? '&' : '?') + 't=' + new Date().getTime();
                img.onload = () => {
                    renderCanvas(id);
                };
                img.onerror = () => {
                    console.error(`Failed to load image in card_${id}. Check S3 URL or CORS.`);
                    alert('Error: Failed to load image. Please try again.');
                };
                return;
            }
            card.classList.add('no-border');
            renderCanvas(id);
        }
    }

    function renderCanvas(id) {
        const card = document.getElementById(`card_${id}`);
        html2canvas(card, {
            scale: 2,
            useCORS: true,
            logging: true,
            backgroundColor: null
        }).then(canvas => {
            const link = document.createElement('a');
            link.href = canvas.toDataURL('image/png');
            link.download = `festive_image_${id}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            card.classList.remove('no-border');
        }).catch(error => {
            console.error('Error rendering card:', error);
            alert('Error: Failed to download image. Please try again.');
            card.classList.remove('no-border');
        });
    }
</script>
<script>
    $(document).ready(function() {
        // Initialize Select2 for franchiseNumber
        $('#franchiseNumber').select2({
            placeholder: "Select Franchise",
            allowClear: true,
            width: '100%'
        });

        // Trigger fetchFranchiseData on page load if franchiseNumber has a value
        const franchiseInput = $('#franchiseNumber');
        if (franchiseInput.val()) {
            fetchFranchiseData(franchiseInput.val());
        }

        // Handle Select2 change event
        $('#franchiseNumber').on('change', function() {
            fetchFranchiseData($(this).val());
        });
    });

    function fetchFranchiseData(franchiseNumber) {
        const brAddressInput = $('#branchAddress'); // Correct ID
        const branchContacNumInput = $('#mobile'); // Correct ID
        const brAddressLoading = $('#brAddressLoading');
        const branchContacNumLoading = $('#branchContacNumLoading');

        brAddressLoading.show();
        branchContacNumLoading.show();

        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("festiveimages/fetchFranchiseData"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    console.log('AJAX Response:', response);
                    if (response.status === 'success' && response.franchiseData) {
                        brAddressInput.val(response.franchiseData.brAddress || '');
                        branchContacNumInput.val(response.franchiseData.branchContacNum || '');
                        // Update card overlays with new franchise data
                        updateCardOverlays(franchiseNumber, response.franchiseData.brAddress, response.franchiseData.branchContacNum);
                    } else {
                        brAddressInput.val('');
                        branchContacNumInput.val('');
                        if (response.franchiseMessage) {
                            alert(response.franchiseMessage);
                        } else {
                            alert('No franchise data available.');
                        }
                    }
                    brAddressLoading.hide();
                    branchContacNumLoading.hide();
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error, xhr.responseText);
                    brAddressInput.val('');
                    branchContacNumInput.val('');
                    brAddressLoading.hide();
                    branchContacNumLoading.hide();
                    alert('Failed to fetch franchise data. Please try again or contact support.');
                }
            });
        } else {
            brAddressInput.val('');
            branchContacNumInput.val('');
            brAddressLoading.hide();
            branchContacNumLoading.hide();
        }
    }

    function updateCardOverlays(franchiseNumber, address, mobile) {
        $('[id^="card_"]').each(function() {
            const cardId = $(this).attr('id').replace('card_', '');
            const recordFranchiseNumber = '<?php echo $record->franchiseNumber; ?>';
            $(`#card_address_${cardId}`).text(address || 'N/A');
            $(`#card_mobile_${cardId}`).text(mobile || '1234567890');
        });
    }

    


    $(document).ready(function() {
        $('#fontSizeSelector').on('change', function() {
            const selectedSize = $(this).val();
            $('.card .address, .card .mobile').css('font-size', selectedSize);
        });
    });
</script>

<script>
    $(document).ready(function() {
        // Force preload of all images with CORS on page load
        $('img').each(function() {
            const $img = $(this);
            const originalSrc = $img.attr('src');
            if (originalSrc) {
                // Set CORS attribute and add cache buster
                $img.attr('crossOrigin', 'anonymous');
                $img.attr('src', originalSrc + (originalSrc.includes('?') ? '&' : '?') + 't=' + new Date().getTime());
                $img.on('error', function() {
                    console.error(`Failed to load image: ${originalSrc}`);
                    alert('Error: Failed to load image for card ID ' + $img.closest('.card').attr('id').replace('card_', ''));
                });
                $img.on('load', function() {
                    console.log(`Image loaded successfully: ${originalSrc}`);
                });
            }
        });
    });
</script>