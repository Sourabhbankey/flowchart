<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Social Media Record Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        
        <div class="row">
            <?php if (in_array($userRole, [1, 2, 14])): ?> 
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>socialmedia/add"><i class="fa fa-plus"></i> Add New  Record</a>
                </div> 
            </div>
            <?php endif; ?>
        </div>
    
        <div class="row">
            <?php if (in_array($userRole, [1, 2, 14])): ?> 
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <label for="resultrecordlist">Search By Franchise</label>
                    <form method="GET" action="<?= base_url('socialmedia/socialmediaListing'); ?>">
                    <label for="franchiseNumber">Franchise No. <span class="re-mend-field">*</span></label>
                    <select id="franchiseNumber" name="franchiseNumber" data-live-search="true" required>
                        <option value="">Select Franchise</option>
                        <?php
                        if (!empty($branchDetail)) {
                            foreach ($branchDetail as $bd) {
                                $selected = ($bd->franchiseNumber == $franchiseFilter) ? 'selected' : '';
                                ?>
                                <option value="<?= $bd->franchiseNumber; ?>" <?= $selected; ?>><?= $bd->franchiseNumber; ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <button type="submit" class="btn btn-primary customreset-fil">Filter</button>
                    
                    <a href="<?= base_url('socialmedia/socialmediaListing?resetFilter=1'); ?>" class="btn btn-danger btn-secondary">Reset</a>
                </form>

                    </div>
            </div>
            <?php endif; ?>
        </div> 
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Record List</h3>

                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                  <table id="example" class="display responsive nowrap table table-hover">
                    <thead>
                    <tr>
                        <th>Sr. No.</th>
                        <th>Franchise Number</th>
                       <!--  <th>Franchise Assigned</th> -->
                        
                        <!-- <th> Branch Current Status</th> -->
                        <th> Branch city</th>
                        <th> Branch State</th>
                        <th> Official Email Id</th>
                        <th> Personal Email Id</th>
                        <th> Contact Number</th>
                        <th> Branch location address</th>
                        <th>Fbpage Name</th>
                        <th>Fb page Link</th>
                         <th>Facebook Account Link</th>
                        <th>Active Followers on fb</th>
                        <th>Account Status fb</th>
                         <th>Insta page Name</th>
                          <th>Insta page Link</th>
                           <th>Active Followers onInsta</th>
                          <th>Account Status Insta</th>
                           <th>Google Profile Link</th>
                            <th>LinkedIn</th>
                             <?php if ($userRole!=25): ?> 
                            <th>Name</th>
                            <th>Mobile No</th>
                            <th>Merged Status</th>
                             <?php endif; ?>
                             <th>Description</th>

                         <th class="text-center">Actions</th>

                        
                    </tr>
                    </thead>
                 <tbody>
                   <?php
                    if(!empty($records))
                    { $counter=1;
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                        <td><?php echo $counter++ ?></td>
                        <td><?php echo $record->franchiseNumber  ?></td>
                       
                        <td><?php echo $record->branchcityName ?></td>
                        <td><?php echo $record->branchState ?></td>
                        <td><?php echo $record->officialEmailID ?></td>
                        <td><?php echo $record->personalEmailId ?></td>
                        <td><?php echo $record->mobile ?></td>
                        <td><?php echo $this->session->userdata('branchLocAddressPremise'); ?></td>
                        <td><?php echo $record->fbpageName ?></td>
                        <td><?php echo $record->fbpageLink  ?></td>
                        <td><?php echo $record->fbpagesLink  ?></td>
                        <td><?php echo $record->activeFollowersonfb  ?></td>
                        
                        <td><?php echo $record->accountStatusfb ?></td>
                        <td><?php echo $record->instapageName ?></td>
                        <td><?php echo $record->instapageLink ?></td>
                        <td><?php echo $record->activeFollowersonInsta ?></td>
                      
                        <td><?php echo $record->accountStatusInsta ?></td>
                        <td><?php echo $record->googleprofileLink ?></td>
                        <td><?php echo $record->linkedin ?></td>
                         <?php if ($userRole!=25): ?> 
                          <td><?php echo $record->partyname ?></td>
                        <td><?php echo $record->mobileno ?></td>
                        <td><?php echo $record->status ?></td>
                        <?php endif; ?>
                        <td><?php echo $record->description ?></td>
                      <td class="text-center">
    <?php if (in_array($userRole, [1, 2, 14, 33])): ?> 
        <!-- Full access (Edit/Delete/View) -->
        <a class="btn btn-sm btn-info" href="<?php echo base_url().'socialmedia/edit/'.$record->socialId; ?>" title="Edit">
            <i class="fa fa-pencil"></i>
        </a>
        <a class="btn btn-sm btn-danger deleteStock" href="#" data-salesrecId="<?php echo $record->socialId; ?>" title="Delete">
            <i class="fa fa-trash"></i>
        </a>
        <a class="btn btn-sm btn-info" onclick="makeFieldsReadOnly()" href="<?php echo base_url().'socialmedia/view/'.$record->socialId; ?>" title="View">
            <i class="fa fa-eye"></i>
        </a>
    
    <?php elseif (in_array($userRole, [13, 24])): ?>
        <!-- View-only access -->
        <a class="btn btn-sm btn-info" onclick="makeFieldsReadOnly()" href="<?php echo base_url().'socialmedia/view/'.$record->socialId; ?>" title="View">
            <i class="fa fa-eye"></i>
        </a>
    <?php endif; ?>
</td>



                   
                    </tr>
                   <?php
                        }
                    }
                    ?>
                  </tbody>


                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <div class="br-pagi">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>

<style type="text/css">
tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

