<?php 
//print_r($socialmediarecordInfo);exit;
$socialId = $socialmediarecordInfo->socialId;
$fbpageName = $socialmediarecordInfo->fbpageName;
$brspFranchiseAssigned = $socialmediarecordInfo->brspFranchiseAssigned;
$franchiseNumberArray = explode(",", $socialmediarecordInfo->franchiseNumber);
$franchiseNumber = $socialmediarecordInfo->franchiseNumber;
$fbpageLink = $socialmediarecordInfo->fbpageLink;
$activeFollowersonfb = $socialmediarecordInfo->activeFollowersonfb;
$prismoMascotFb = $socialmediarecordInfo->prismoMascotFb;
$accountStatusfb = $socialmediarecordInfo->accountStatusfb;
$instapageName = $socialmediarecordInfo->instapageName;
$instapageLink = $socialmediarecordInfo->instapageLink;
$instaID = $socialmediarecordInfo->instaID ?? '';
$instaPassword = $socialmediarecordInfo->instaPassword ?? '';
$fbID = $socialmediarecordInfo->fbID ?? '';
$fbPassword = $socialmediarecordInfo->fbPassword ?? '';
$dateOfCreation = $socialmediarecordInfo->dateOfCreation;
$googleprofileLink = $socialmediarecordInfo->googleprofileLink;
$googleProfileID = $socialmediarecordInfo->googleProfileID ?? '';
$creationMail = $socialmediarecordInfo->creationMail ?? '';
$dateofCreationInsta = $socialmediarecordInfo->dateofCreationInsta ?? '';
$dateofCreationfb = $socialmediarecordInfo->dateofCreationfb ?? '';
$activeFollowersonInsta = $socialmediarecordInfo->activeFollowersonInsta;
$prismoMascotInsta = $socialmediarecordInfo->prismoMascotInsta;
$accountStatusInsta = $socialmediarecordInfo->accountStatusInsta;
$description = $socialmediarecordInfo->description;
$fbpagesLink = $socialmediarecordInfo->fbpagesLink;
$linkedin = $socialmediarecordInfo->linkedin ?? '';

$partyname = $socialmediarecordInfo->partyname ?? '';
$mobileno = $socialmediarecordInfo->mobileno ?? '';
$status = $socialmediarecordInfo->status ?? '';

?>

<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-user-circle-o"></i> Record Management <small>Add / Edit Social Media Record</small></h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Social Media Details</h3>
                    </div>

                    <form role="form" action="<?php echo base_url() ?>socialmedia/editsocialmediarecord" method="post" id="editsocialmediarecord">
                        <div class="box-body">
                            <input type="hidden" name="socialId" value="<?php echo $socialId; ?>">

                           
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise No. <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control" value="<?php echo implode(', ', $franchiseNumberArray); ?>" readonly>
                                        <?php foreach ($franchiseNumberArray as $selectedFranchise) { ?>
                                            <input type="hidden" name="franchiseNumber[]" value="<?php echo $selectedFranchise; ?>">
                                        <?php } ?>
                                    </div>
                                </div>
                           
                            <input type="hidden" name="brspFranchiseAssigned" value="<?php echo $brspFranchiseAssigned; ?>">

                            <!-- Instagram Section -->
                            <div class="col-md-12"><h4><strong>Instagram Info</strong></h4></div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Instagram Page Name</label>
                                    <input type="text" class="form-control" name="instapageName" value="<?php echo $instapageName; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Instagram Page Link</label>
                                    <input type="text" class="form-control" name="instapageLink" value="<?php echo $instapageLink; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Instagram ID</label>
                                    <input type="text" class="form-control" name="instaID" value="<?php echo $instaID; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Instagram Password</label>
                                    <input type="text" class="form-control" name="instaPassword" value="<?php echo $instaPassword; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Followers on Instagram</label>
                                    <input type="text" class="form-control" name="activeFollowersonInsta" value="<?php echo $activeFollowersonInsta; ?>">
                                </div>
                            </div>
                           
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Account Status (Instagram)</label>
                                    <select class="form-control" name="accountStatusInsta">
                                        <option value="">Select Status</option>
                                        <option value="Active" <?php echo ($accountStatusInsta == "Active") ? "selected" : ""; ?>>Active</option>
                                        <option value="Inactive" <?php echo ($accountStatusInsta == "Inactive") ? "selected" : ""; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Date of Sharing (Instagram)</label>
                                    <input type="date" class="form-control" name="dateofCreationInsta" value="<?php echo $dateofCreationInsta; ?>">
                                </div>
                            </div>

                            <!-- Facebook Section -->
                            <div class="col-md-12"><h4><strong>Facebook Info</strong></h4></div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook Page Name</label>
                                    <input type="text" class="form-control" name="fbpageName" value="<?php echo $fbpageName; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook Page Link</label>
                                    <input type="text" class="form-control" name="fbpageLink" value="<?php echo $fbpageLink; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook ID</label>
                                    <input type="text" class="form-control" name="fbID" value="<?php echo $fbID; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook Password</label>
                                    <input type="text" class="form-control" name="fbPassword" value="<?php echo $fbPassword; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Followers on Facebook</label>
                                    <input type="text" class="form-control" name="activeFollowersonfb" value="<?php echo $activeFollowersonfb; ?>">
                                </div>
                            </div>
                             <div class="col-md-6">
                                <div class="form-group">
                                    <label>Facebook Account Link</label>
                                    <input type="text" class="form-control" name="fbpagesLink" value="<?php echo $fbpagesLink; ?>">
                                </div>
                            </div>
                           <!--  <div class="col-md-6">
                                <div class="form-group">
                                    <label>Prismo Mascot FB</label>
                                    <input type="text" class="form-control" name="prismoMascotFb" value="<?php echo $prismoMascotFb; ?>">
                                </div>
                            </div> -->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Account Status (Facebook)</label>
                                    <select class="form-control" name="accountStatusfb">
                                        <option value="">Select Status</option>
                                        <option value="Active" <?php echo ($accountStatusfb == "Active") ? "selected" : ""; ?>>Active</option>
                                        <option value="Inactive" <?php echo ($accountStatusfb == "Inactive") ? "selected" : ""; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Date of Sharing (Facebook)</label>
                                    <input type="date" class="form-control" name="dateofCreationfb" value="<?php echo $dateofCreationfb; ?>">
                                </div>
                            </div>

                            <!-- Google Info -->
                            <div class="col-md-12"><h4><strong>Google Profile Info</strong></h4></div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Google Profile Link</label>
                                    <input type="text" class="form-control" name="googleprofileLink" value="<?php echo $googleprofileLink; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Google Profile ID</label>
                                    <input type="text" class="form-control" name="googleProfileID" value="<?php echo $googleProfileID; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Google Creation Mail</label>
                                    <input type="email" class="form-control" name="creationMail" value="<?php echo $creationMail; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Date of Creation</label>
                                    <input type="date" class="form-control" name="dateOfCreation" value="<?php echo $dateOfCreation; ?>">
                                </div>
                            </div>
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label>LinkedIn</label>
                                    <input type="text" class="form-control" name="linkedin" value="<?php echo $linkedin; ?>">
                                </div>
                            </div>
                            <!-- Description -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" name="description" rows="4"><?php echo $description; ?></textarea>
                                </div>
                            </div>
                            <!-- Third Party -->
                            <div class="col-md-12"><h4><strong>Third Party Access</strong></h4></div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="partyname" value="<?php echo $partyname; ?>">
                                </div>
                            </div>
                             <div class="col-md-12">
                                <div class="form-group">
                                    <label>Mobile Name</label>
                                    <input type="text" class="form-control" name="mobileno" value="<?php echo $mobileno; ?>">
                                </div>
                            </div>
                             <div class="col-md-12">
                                <div class="form-group">
                                    <label>Merged Status</label>
                                    <select class="form-control" name="status">
                                        <option value="">Select Status</option>
                                        <option value="Merged" <?php echo ($status == "Merged") ? "selected" : ""; ?>>Merged</option>
                                        <option value="Not Merged" <?php echo ($status == "Not Merged") ? "selected" : ""; ?>>Not Merged</option>
                                    </select>
                                </div>
                            </div>


                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <!-- Right Column: Flash messages and validation -->
            <div class="col-md-4">
                <?php $this->load->helper('form'); ?>
                <?php if ($error = $this->session->flashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissable"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if ($success = $this->session->flashdata('success')): ?>
                    <div class="alert alert-success alert-dismissable"><?php echo $success; ?></div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style>
.frselectdiv {
    pointer-events: none;
}
</style>
