<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Social Media Record
        <small>Add / Edit Social Media Record</small>
      </h1>
    </section>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Social Media Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>socialmedia/addNewsocialmediarecord" method="post" role="form">
                            <div class="box-body">
                                <div class="row">
        							<div class="col-md-6">
                                        <div class="form-group">
                                            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                                    <option value="">Select Franchise</option>
                                                                     <?php
                                                                    if (!empty($branchDetail)) {
                                                                        foreach ($branchDetail as $bd) {
                                                                      $franchiseNumber = $bd->franchiseNumber;
                                                                    ?>
                                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                              <?php
                                                                  }
                                                               }
                                                            ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                            <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                                <option value="0">Select Role</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="issuedon">Fb Page Name</label>
                                            <input  type="text" class="form-control required" value="" id="fbpageName" name="fbpageName" maxlength="256" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity"> fb page Link</label>
                                            <input  type="text" class="form-control required" value="" id="fbpageLink" name="fbpageLink" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Active Followers on fb  </label>
                                            <input  type="text" class="form-control required" value="" id="activeFollowersonfb" name="activeFollowersonfb" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Prismo Mascot Fb</label>
                                            <input  type="text" class="form-control required" value="" id="prismoMascotFb" name="prismoMascotFb" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6"> 
                                       <div class="form-group">
                                            <label for="accountStatusfb">Account Status FB</label>
                                            <select class="form-control required" id="accountStatusfb" name="accountStatusfb">
                                                <option value="">Select Status</option>
                                                <option value="Active" <?php echo (!empty($accountStatusfb) && $accountStatusfb == "Active") ? "selected" : ""; ?>>Active</option>
                                                <option value="Inactive" <?php echo (!empty($accountStatusfb) && $accountStatusfb == "Inactive") ? "selected" : ""; ?>>Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Insta page Name</label>
                                            <input  type="text" class="form-control required" value="" id="instapageName" name="instapageName" maxlength="256" />
                                        </div>
                                    </div>
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Insta page Link</label>
                                            <input  type="text" class="form-control required" value="" id="instapageLink" name="instapageLink" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Google Profile Link</label>
                                            <input  type="text" class="form-control required" value="" id="googleprofileLink" name="googleprofileLink" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Date Of Creation</label>
                                            <input  type="date" class="form-control required" value="" id="dateofcreation" name="dateofCreation" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Active Followers on Insta</label>
                                            <input  type="text" class="form-control required" value="" id="activeFollowersonInsta" name="activeFollowersonInsta" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Prismo Mascot Insta</label>
                                            <input  type="text" class="form-control required" value="" id="prismoMascotInsta" name="prismoMascotInsta" maxlength="256" />
                                        </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="accountStatusInsta">Account Status Insta</label>
                                            <select class="form-control required" id="accountStatusInsta" name="accountStatusInsta" required>
                                                <option value="">Select Status</option>
                                                <option value="Active" <?php echo (!empty($accountStatusInsta) && $accountStatusInsta == "Active") ? "selected" : ""; ?>>Active</option>
                                                <option value="Inactive" <?php echo (!empty($accountStatusInsta) && $accountStatusInsta == "Inactive") ? "selected" : ""; ?>>Inactive</option>
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="prodQuantity">Description</label>
                                            <textarea required class="form-control required" id="description" name="description" maxlength="256" rows="4"></textarea>

                                        </div>
                                    </div> 
                                </div> 
                            </div><!-- /.box-body -->
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>    
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>

<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber !== "") {
        $.ajax({
            url: "<?php echo base_url('socialmedia/fetchAssignedUsers'); ?>",
            type: "POST",
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $("#branchFranchiseAssigned").html(response);
                  $('#branchFranchiseAssigned option[value="0"]').remove();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: " + status + " - " + error);
            }
        });
    } else {
      $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
    }
}
</script>
