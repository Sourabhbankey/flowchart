<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee Relieving
            <!-- <small>Add / Edit</small> -->
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Relieving  Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addEmpReliev" action="<?php echo base_url() ?>emprelieving/addNewEmprelieving" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
            <!-- New-Code -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="empName">Name of Employee</label>
                    <input required type="text" class="form-control" id="empName" name="empName">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="resigTermidate">Resignation or Termination Date</label>
                    <input required type="date" class="form-control" id="resigTermidate" name="resigTermidate">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="empContactdetails">Employee Contact Details</label>
                    <input type="text" class="form-control" id="empContactdetails" name="empContactdetails">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="empEmailid">Employee Email ID</label>
                    <input type="email" class="form-control" id="empEmailid" name="empEmailid">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="reportmngName">Name of Reporting Manager</label>
                    <input type="text" class="form-control" id="reportmngName" name="reportmngName">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="department">Department</label>
                    <input type="text" class="form-control" id="department" name="department">
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="communireportmngName">Communication with Reporting Manager</label>
                    <textarea class="form-control" id="communireportmngName" name="communireportmngName" rows="3"></textarea>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="formal_resignation_or_termination_mail">Formal Resignation Or Termination Mail</label>
                    <select class="form-control" id="formal_resignation_or_termination_mail" name="formal_resignation_or_termination_mail">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="acceptance_by_reporting_manager">Acceptance By Reporting Manager</label>
                    <select class="form-control" id="acceptance_by_reporting_manager" name="acceptance_by_reporting_manager">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="notice_period_served">Notice Period Served</label>
                    <select class="form-control" id="notice_period_served" name="notice_period_served">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="surrender_of_sim_card">SURRENDER OF SIM CARD (If Issued)</label>
                    <select class="form-control" id="surrender_of_sim_card" name="surrender_of_sim_card">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="surrender_of_id_card">SURRENDER OF ID Card</label>
                    <select class="form-control" id="surrender_of_id_card" name="surrender_of_id_card">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="surrender_of_mobile_phones">Surrender Of Mobile Phones (If Issued)</label>
                    <select class="form-control" id="surrender_of_mobile_phones" name="surrender_of_mobile_phones">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="surrender_of_laptop">Surrender Of Laptop (If Issued)</label>
                    <select class="form-control" id="surrender_of_laptop" name="surrender_of_laptop">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="relieving_letter_issued">Relieving Letter Issued</label>
                    <select class="form-control" id="relieving_letter_issued" name="relieving_letter_issued">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="no_dues_certificate_issued">No Dues Certificate Issued</label>
                    <select class="form-control" id="no_dues_certificate_issued" name="no_dues_certificate_issued">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="closure_of_official_mail_id">Closure Of Official Mail Id</label>
                    <select class="form-control" id="closure_of_official_mail_id" name="closure_of_official_mail_id">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="surrender_of_all_official_id_and_credentials">Surrender Of All Official ID & Credentials</label>
                    <select class="form-control" id="surrender_of_all_official_id_and_credentials" name="surrender_of_all_official_id_and_credentials">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="removal_from_all_official_sheets">Removal From All Official Sheets</label>
                    <select class="form-control" id="removal_from_all_official_sheets" name="removal_from_all_official_sheets">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="handover_of_all_offline_data_or_sheets">Hand Over Of All Offline Data Or Sheets</label>
                    <select class="form-control" id="handover_of_all_offline_data_or_sheets" name="handover_of_all_offline_data_or_sheets">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="removal_from_all_whatsapp_groups">Removal From All Whatsapp Groups</label>
                    <select class="form-control" id="removal_from_all_whatsapp_groups" name="removal_from_all_whatsapp_groups">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="closure_of_employee_whatsapp_group">Closure Of Employee Whatsapp Group</label>
                    <select class="form-control" id="closure_of_employee_whatsapp_group" name="closure_of_employee_whatsapp_group">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="submission_of_signed_copy_of_relieving_and_other_documents">Submission Of Signed Copy Of Relieving And Other Documents</label>
                    <select class="form-control" id="submission_of_signed_copy_of_relieving_and_other_documents" name="submission_of_signed_copy_of_relieving_and_other_documents">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="clearance_form_reporting_manager">Clearance Form Reporting Manager</label>
                    <select class="form-control" id="clearance_form_reporting_manager" name="clearance_form_reporting_manager">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="exit_interview">Exit Interview</label>
                    <select class="form-control" id="exit_interview" name="exit_interview">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>

            
            <div class="col-md-4">
                <div class="form-group">
                    <label for="final_fnf_mail">Final F&F Mail</label>
                    <select class="form-control" id="final_fnf_mail" name="final_fnf_mail">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>

            
            <div class="col-md-4">
                <div class="form-group">
                    <label for="acknowledgment_on_fnf_mail_and_last_salary_issued">Acknowledgment On F&F Mail & Last Salary Issued</label>
                    <select class="form-control" id="acknowledgment_on_fnf_mail_and_last_salary_issued" name="acknowledgment_on_fnf_mail_and_last_salary_issued">
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                </div>
            </div>

<!-- New-Code -->



                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="6"><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-3">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $error; ?>
                        </div>
                <?php endif; ?>

                <?php
                    $success = $this->session->flashdata('success');
                    if($success): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $success; ?>
                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
    </body>
</html>



<?php