<?php
$emprelievingId = $emprelievingInfo->emprelievingId;
$empName = $emprelievingInfo->empName;
$empContactdetails = $emprelievingInfo->empContactdetails;
$empEmailid = $emprelievingInfo->empEmailid;
$reportmngName = $emprelievingInfo->reportmngName;
$department = $emprelievingInfo->department;
$resigTermidate = $emprelievingInfo->resigTermidate;
$communireportmngName = $emprelievingInfo->communireportmngName;
$formal_resignation_or_termination_mail =$emprelievingInfo->formal_resignation_or_termination_mail;
$acceptance_by_reporting_manager =$emprelievingInfo->acceptance_by_reporting_manager;
$notice_period_served =$emprelievingInfo->notice_period_served;
$surrender_of_sim_card =$emprelievingInfo->surrender_of_sim_card;
$surrender_of_id_card =$emprelievingInfo->surrender_of_id_card;
$surrender_of_mobile_phones =$emprelievingInfo->surrender_of_mobile_phones;
$surrender_of_laptop =$emprelievingInfo->surrender_of_laptop;
$relieving_letter_issued =$emprelievingInfo->relieving_letter_issued;
$no_dues_certificate_issued =$emprelievingInfo->no_dues_certificate_issued;
$closure_of_official_mail_id =$emprelievingInfo->closure_of_official_mail_id;
$surrender_of_all_official_id_and_credentials =$emprelievingInfo->surrender_of_all_official_id_and_credentials;
$removal_from_all_official_sheets =$emprelievingInfo->removal_from_all_official_sheets;
$handover_of_all_offline_data_or_sheets =$emprelievingInfo->handover_of_all_offline_data_or_sheets;
$removal_from_all_whatsapp_groups =$emprelievingInfo->removal_from_all_whatsapp_groups;
$closure_of_employee_whatsapp_group =$emprelievingInfo->closure_of_employee_whatsapp_group;
$submission_of_signed_copy_of_relieving_and_other_documents =$emprelievingInfo->submission_of_signed_copy_of_relieving_and_other_documents;
$clearance_form_reporting_manager =$emprelievingInfo->clearance_form_reporting_manager;
$exit_interview =$emprelievingInfo->exit_interview;
$final_fnf_mail =$emprelievingInfo->final_fnf_mail;
$acknowledgment_on_fnf_mail_and_last_salary_issued =$emprelievingInfo->acknowledgment_on_fnf_mail_and_last_salary_issued;
$description = $emprelievingInfo->description;
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee Relieving Management
        <!-- <small>Add / Edit Employee of month</small> -->
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Employee Relieving Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo base_url() ?>Emprelieving/editEmprelieving" method="post" id="editEmprelieving" role="form">
                        <div class="box-body">
                        <div class="row">
                                <!-- New-Code -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="empName">Name of Employee</label>
                                        <input required type="text" class="form-control" id="empName" value="<?php echo $empName; ?>" name="empName">
                                        <input type="hidden" value="<?php echo $emprelievingId; ?>" name="emprelievingId" id="emprelievingId" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="resigTermidate">Resignation or Termination Date</label>
                                        <input required type="date" class="form-control" id="resigTermidate" value="<?php echo $resigTermidate; ?>" name="resigTermidate">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="empContactdetails">Employee Contact Details</label>
                                        <input type="text" class="form-control" id="empContactdetails" value="<?php echo $empContactdetails; ?>" name="empContactdetails">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="empEmailid">Employee Email ID</label>
                                        <input type="email" class="form-control" id="empEmailid" value="<?php echo $empEmailid; ?>" name="empEmailid">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="reportmngName">Name of Reporting Manager</label>
                                        <input type="text" class="form-control" id="reportmngName" value="<?php echo $reportmngName; ?>" name="reportmngName">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="department">Department</label>
                                        <input type="text" class="form-control" id="department" value="<?php echo $department; ?>" name="department">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="communireportmngName">Communication with Reporting Manager</label>
                                        <textarea class="form-control" id="communireportmngName" name="communireportmngName" rows="3"><?php echo $communireportmngName; ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="formal_resignation_or_termination_mail">Formal Resignation Or Termination Mail</label>
                                        <!-- <select class="form-control" id="formal_resignation_or_termination_mail" name="formal_resignation_or_termination_mail">
                                            <option value="<?php //echo $formal_resignation_or_termination_mail; ?>" <?php //echo "selected=selected"; ?>><?php //echo $formal_resignation_or_termination_mail; ?></option>
                                            <option value="Yes">Yes</option>
                                            <option value="No">No</option>
                                        </select> -->
                                        <select class="form-control" id="formal_resignation_or_termination_mail" name="formal_resignation_or_termination_mail">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($formal_resignation_or_termination_mail == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($formal_resignation_or_termination_mail == 'No') echo 'selected'; ?>>No</option>
                                        </select>

                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="acceptance_by_reporting_manager">Acceptance By Reporting Manager</label>
                                        <select class="form-control" id="acceptance_by_reporting_manager" name="acceptance_by_reporting_manager">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($acceptance_by_reporting_manager == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($acceptance_by_reporting_manager == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="notice_period_served">Notice Period Served</label>
                                        <select class="form-control" id="notice_period_served" name="notice_period_served">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($notice_period_served == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($notice_period_served == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="surrender_of_sim_card">SURRENDER OF SIM CARD (If Issued)</label>
                                        <select class="form-control" id="surrender_of_sim_card" name="surrender_of_sim_card">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($surrender_of_sim_card == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($surrender_of_sim_card == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="surrender_of_id_card">SURRENDER OF ID Card</label>
                                        <select class="form-control" id="surrender_of_id_card" name="surrender_of_id_card">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($surrender_of_id_card == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($surrender_of_id_card == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="surrender_of_mobile_phones">Surrender Of Mobile Phones (If Issued)</label>
                                        <select class="form-control" id="surrender_of_mobile_phones" name="surrender_of_mobile_phones">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($surrender_of_mobile_phones == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($surrender_of_mobile_phones == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="surrender_of_laptop">Surrender Of Laptop (If Issued)</label>
                                        <select class="form-control" id="surrender_of_laptop" name="surrender_of_laptop">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($surrender_of_laptop == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($surrender_of_laptop == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="relieving_letter_issued">Relieving Letter Issued</label>
                                        <select class="form-control" id="relieving_letter_issued" name="relieving_letter_issued">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($relieving_letter_issued == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($relieving_letter_issued == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="no_dues_certificate_issued">No Dues Certificate Issued</label>
                                        <select class="form-control" id="no_dues_certificate_issued" name="no_dues_certificate_issued">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($no_dues_certificate_issued == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($no_dues_certificate_issued == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="closure_of_official_mail_id">Closure Of Official Mail Id</label>
                                        <select class="form-control" id="closure_of_official_mail_id" name="closure_of_official_mail_id">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($closure_of_official_mail_id == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($closure_of_official_mail_id == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="surrender_of_all_official_id_and_credentials">Surrender Of All Official ID & Credentials</label>
                                        <select class="form-control" id="surrender_of_all_official_id_and_credentials" name="surrender_of_all_official_id_and_credentials">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($surrender_of_all_official_id_and_credentials == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($surrender_of_all_official_id_and_credentials == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="removal_from_all_official_sheets">Removal From All Official Sheets</label>
                                        <select class="form-control" id="removal_from_all_official_sheets" name="removal_from_all_official_sheets">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($removal_from_all_official_sheets == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($removal_from_all_official_sheets == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="handover_of_all_offline_data_or_sheets">Hand Over Of All Offline Data Or Sheets</label>
                                        <select class="form-control" id="handover_of_all_offline_data_or_sheets" name="handover_of_all_offline_data_or_sheets">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($handover_of_all_offline_data_or_sheets == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($handover_of_all_offline_data_or_sheets == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="removal_from_all_whatsapp_groups">Removal From All Whatsapp Groups</label>
                                        <select class="form-control" id="removal_from_all_whatsapp_groups" name="removal_from_all_whatsapp_groups">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($removal_from_all_whatsapp_groups == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($removal_from_all_whatsapp_groups == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="closure_of_employee_whatsapp_group">Closure Of Employee Whatsapp Group</label>
                                        <select class="form-control" id="closure_of_employee_whatsapp_group" name="closure_of_employee_whatsapp_group">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($closure_of_employee_whatsapp_group == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($closure_of_employee_whatsapp_group == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="submission_of_signed_copy_of_relieving_and_other_documents">Submission Of Signed Copy Of Relieving And Other Documents</label>
                                        <select class="form-control" id="submission_of_signed_copy_of_relieving_and_other_documents" name="submission_of_signed_copy_of_relieving_and_other_documents">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($submission_of_signed_copy_of_relieving_and_other_documents == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($submission_of_signed_copy_of_relieving_and_other_documents == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="clearance_form_reporting_manager">Clearance Form Reporting Manager</label>
                                        <select class="form-control" id="clearance_form_reporting_manager" name="clearance_form_reporting_manager">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($clearance_form_reporting_manager == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($clearance_form_reporting_manager == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="exit_interview">Exit Interview</label>
                                        <select class="form-control" id="exit_interview" name="exit_interview">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($exit_interview == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($exit_interview == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>

                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="final_fnf_mail">Final F&F Mail</label>
                                        <select class="form-control" id="final_fnf_mail" name="final_fnf_mail">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($final_fnf_mail == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($final_fnf_mail == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>

                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="acknowledgment_on_fnf_mail_and_last_salary_issued">Acknowledgment On F&F Mail & Last Salary Issued</label>
                                        <select class="form-control" id="acknowledgment_on_fnf_mail_and_last_salary_issued" name="acknowledgment_on_fnf_mail_and_last_salary_issued">
                                            <option value="">-- Select --</option>
                                            <option value="Yes" <?php if ($acknowledgment_on_fnf_mail_and_last_salary_issued == 'Yes') echo 'selected'; ?>>Yes</option>
                                            <option value="No" <?php if ($acknowledgment_on_fnf_mail_and_last_salary_issued == 'No') echo 'selected'; ?>>No</option>
                                        </select>
                                    </div>
                                </div>

                    <!-- New-Code -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>