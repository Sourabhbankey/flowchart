<?php 
    $amtconfId = $amountconfirmationInfo->amtconfId; 
     $confirmationStatus = $amountconfirmationInfo->confirmationStatus; 

   
    
?>  

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Amount Management
            <small>Edit  </small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title"> Details</h3>
                    </div>

                    <form role="form" action="<?php echo base_url('amountconfirmation/editAmountconfirmation'); ?>" method="post" id="editReturnproduct" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                      
                                         
                                       

<input type="hidden" value="<?php echo $amtconfId; ?>" name="amtconfId" id="amtconfId" />

<label for="status">Status</label>
<select name="confirmationStatus" id="confirmationStatus" class="form-control" required>
    <option value="">-- Select Status --</option>
    <option value="Received">Received</option>
    <option value="Not Received">Not Received</option>
</select>
                                    </div>
                                </div>
                             
               
                              
                            </div>
                        </div>

                         <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                  



                </div>
            </div>

            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $error; ?>
                </div>
                <?php } ?>

                <?php 
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="https://cdn.ckeditor.com/4.20.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('replyMessage');
</script>
<script src="https://cdn.ckeditor.com/4.21.0/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        readOnly: true
    });
</script>