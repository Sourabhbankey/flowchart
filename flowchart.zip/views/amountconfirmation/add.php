<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Amount Confirmation Management
        <small>Add / Edit Amount Confirmation</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Amount Confirmation Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <!-- <h2>Return a Product</h2> -->
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>amountconfirmation/addNewAmountconfirmation" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                              <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise No (Optional) :</label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber"  data-live-search="true" required>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div> 
                                

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Name of Payee:</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('namePayee'); ?>" id="namePayee" name="namePayee" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amount'); ?>" id="amount" name="amount" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Date of Payment :</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('date_of_Payment'); ?>" id="date_of_Payment" name="date_of_Payment" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Amount paid for</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amount_Paid_for '); ?>" id="amount_Paid_for " name="amount_Paid_for " maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Amount paid for</label>
                                       <select class="form-control required" id="mode_of_Payment" name="mode_of_Payment">
                                <option value="">-- Select Payment Mode --</option>
                                <option value="Bank Transfer" <?php echo set_select('mode_of_Payment', 'Bank Transfer'); ?>>Bank Transfer</option>
                                <option value="Cheque" <?php echo set_select('mode_of_Payment', 'Cheque'); ?>>Cheque</option>
                                <option value="UPI" <?php echo set_select('mode_of_Payment', 'UPI'); ?>>UPI</option>
                                <option value="RazorPay" <?php echo set_select('mode_of_Payment', 'RazorPay'); ?>>RazorPay</option>
                            </select>
                                    </div>
                                    
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Upload SnapShot File <span class="re-mend-field">*</span></label>
                                        <input required type="file" name="file" multiple>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description (Optional) :</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div> 
                                 <div class="col-md-4">                                
                                    <div class="form-group">
                                     <label for="roomName">Confirmation Status</label>
                                       <select class="form-control required" id="confirmationStatus" name="confirmationStatus">
                                <option value="">-- Select Payment Mode --</option>
                                <option value="Received" <?php echo set_select('confirmationStatus', 'Received'); ?>>Received</option>
                                <option value="Not Received" <?php echo set_select('confirmationStatus', 'Not Received'); ?>>Not Received</option>
                             </select>
                                    </div>
                                    
                                </div>
             

                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('ticket/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>