<?php //print_r($socialmediarecordInfo);exit; 
$socialId = $socialmediarecordInfo->socialId;
$franchiseName  = $socialmediarecordInfo->franchiseName ;
 $brspFranchiseAssigned  = $socialmediarecordInfo->brspFranchiseAssigned ;
 $franchiseNumberArray = explode(",",$socialmediarecordInfo->franchiseNumber);
$currentStatus  = $socialmediarecordInfo->currentStatus ;
 $branchcityName = $socialmediarecordInfo->branchcityName;
 $branchState  = $socialmediarecordInfo->branchState ;
 $officialEmailID = $socialmediarecordInfo->officialEmailID;
 $personalEmailId = $socialmediarecordInfo->personalEmailId;
 $mobile  = $socialmediarecordInfo->mobile ;
 $branchLocAddressPremise = $socialmediarecordInfo->branchLocAddressPremise;
$fbpageName  = $socialmediarecordInfo->fbpageName ;
 $brspFranchiseAssigned  = $socialmediarecordInfo->brspFranchiseAssigned ;
 $franchiseNumberArray = explode(",",$socialmediarecordInfo->franchiseNumber);
 $franchiseNumber = $socialmediarecordInfo->franchiseNumber;
 $fbpageLink  = $socialmediarecordInfo->fbpageLink ;
 $activeFollowersonfb = $socialmediarecordInfo->activeFollowersonfb;

 $accountStatusfb = $socialmediarecordInfo->accountStatusfb;
 $instapageName = $socialmediarecordInfo->instapageName;
$instapageLink = $socialmediarecordInfo->instapageLink;
$dateOfCreation = $socialmediarecordInfo->dateOfCreation;
$googleprofileLink = $socialmediarecordInfo->googleprofileLink;
$activeFollowersonInsta = $socialmediarecordInfo->activeFollowersonInsta;

$accountStatusInsta = $socialmediarecordInfo->accountStatusInsta;
$description = $socialmediarecordInfo->description;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i>  Record Management
        <small>Add / Edit Daily Report Record</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Daily Report Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>socialmedia/editsocialmediarecord" method="post" id="editsocialmediarecord" role="form">
                        <div class="box-body">
                        <div class="row">
                                <input type="hidden" name="socialId" value="<?php echo $socialId; ?>">
                             
                                    
                            
                          <h2 style="text-align: center;font-weight: 800;">Basic Details</h2>
                          <!-- Basic Details -->
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label class="control-label">Franchise No.</label><input type="text" class="form-control check"  autocomplete="off" name="franchiseNumber" value="<?php echo $franchiseNumber; ?>" readonly ><span class="error"></span>
                                  </div>
                                </div>
                                 <!-- <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="applicantName">Name of Applicant</label>
                                        <input type="text" class="form-control check required" value="<?php //echo $applicantName; ?>" readonly id="applicantName" name="applicantName" maxlength="256" />
                                    </div>
                                  </div> -->
                                  <div class="col-md-6">
                                         <div class="form-group">
                                            <label for="applicantName">Franchise Name</label>
                                            <input type="text" class="form-control check required" value="<?php echo $franchiseName; ?>" readonly id="franchiseName" name="franchiseName" maxlength="256" />
                                        </div>
                                    </div>    
                                    <!-- <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="applicantName">Branch Location </label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchLocation; ?>" readonly id="branchLocation" name="branchLocation" maxlength="256" />
                                      </div>
                                    </div> -->
                                      <div class="col-md-6">
                                       <div class="form-group">
                                        <label for="applicantName">Branch Current Status </label>
                                        <!-- <input type="text" class="form-control check required" value="<?php //echo $currentStatus; ?>" readonly id="currentStatus" name="currentStatus" maxlength="256" />  -->
                                        <input type="text" class="form-control check required" value="<?php echo $currentStatus; ?>" readonly id="currentStatus" name="currentStatus" maxlength="256" />
                                      </div>
                                    </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                        <label for="applicantName">Branch city </label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchcityName; ?>" readonly id="branchcityName" name="branchcityName" maxlength="256" />
                                      </div>
                                    </div>
                                      <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="applicantName">Branch State </label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchState; ?>" readonly id="branchState" name="branchState" maxlength="256" />
                                      </div>
                                    </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="applicantName">Official Email Id </label>
                                          <input type="text" class="form-control check required" value="<?php echo $officialEmailID; ?>" readonly id="officialEmailID" name="officialEmailID" maxlength="256" />
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="applicantName">Personal Email Id </label>
                                          <input type="text" class="form-control check required" value="<?php echo $personalEmailId; ?>" readonly id="personalEmailId" name="personalEmailId" maxlength="256" />
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="applicantName">Contact Number </label>
                                          <input type="text" class="form-control check required" value="<?php echo $mobile; ?>" readonly id="mobile" name="mobile" maxlength="256" />
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-12 mb-sm">
                                        <div class="form-group"><label class="control-label">Branch location address(Premise) <span class="required">*</span></label><textarea type="textarea" class="form-control check" readonly name="branchLocAddressPremise"><?php echo $branchLocAddressPremise; ?></textarea><span class="error"></span>
                                        </div>
                                    </div>
                                            </div>
                                      
                                            <!-- Hidden Input to store the selected value -->
                                            <input type="hidden" name="brspFranchiseAssigned" value="<?php echo $brspFranchiseAssigned; ?>">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="issuedon">fb page Name</label>
                                        <input  type="text" readonly class="form-control required" value="<?php echo $fbpageName; ?>" id="fbpageName" name="fbpageName" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity"> fb page Link</label>
                                        <input required type="text" class="form-control required" readonly value="<?php echo $fbpageLink; ?>" id="fbpageLink" name="fbpageLink" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">activeFollowersonfb </label>
                                        <input  type="text" class="form-control required" readonly value="<?php echo $activeFollowersonfb; ?>" id="activeFollowersonfb" name="activeFollowersonfb" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Google Profile Link</label>
                                        <input  type="text" class="form-control required" readonly value="<?php echo $googleprofileLink; ?>" id="googleprofileLink" name="googleprogileLink" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Date Of Creation</label>
                                        <input  type="date" class="form-control required" readonly value="<?php echo $dateOfCreation; ?>" id="dateOfCreation" name="dateofCreation" maxlength="256" />
                                    </div>
                                </div> 
                               

                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                    <label for="accountStatusfb">Account Status FB</label>
                                    <input type="text" class="form-control" value="<?php echo $accountStatusfb; ?>" readonly>
                                </div> 
                            </div>
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Insta page Name</label>
                                        <input required type="text" readonly class="form-control required" value="<?php echo $instapageName; ?>" id="instapageName" name="instapageName" maxlength="256" />

                                    </div>
                                  </div>  
                                    <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Insta pageLink</label>
                                        <input required type="text" readonly class="form-control required" value="<?php echo $instapageLink; ?>" id="instapageLink" name="instapageLink" maxlength="256" />
                                    </div>
                                </div> 
                                    <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Active Followers on Insta</label>
                                        <input required type="text" readonly class="form-control required" value="<?php echo $activeFollowersonInsta; ?>" id="activeFollowersonInsta" name="activeFollowersonInsta" maxlength="256" />
                                    </div>
                                </div> 
                                
                              
                                <div class="col-md-6">                                
                                   <div class="form-group">
                                    <label for="accountStatusInsta">Account Status Insta</label>
                                    <input type="text" class="form-control" value="<?php echo $accountStatusInsta; ?>" readonly>
                                </div>
                                </div> 
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Description</label>
                                        <textarea required readonly class="form-control required" id="description" name="description" maxlength="256" rows="4"><?php echo $description; ?></textarea>
                                    </div>
                                </div>  
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    .frselectdiv{
    pointer-events: none;
    }
</style>
<script>
    
    </script>
