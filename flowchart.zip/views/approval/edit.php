<?php
$approvalId = $approvalInfo->approvalId;
$userID = $approvalInfo->userID ?? '';
$approvalTitle = $approvalInfo->approvalTitle ?? '';
$approvalStatus = $approvalInfo->approvalStatus ?? '';
$description = $approvalInfo->description ?? '';
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-user-circle-o"></i> Record Management <small>Edit Approval</small></h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Approval Details</h3>
                    </div>

                    <!-- Edit Approval Form -->
                    <form role="form" action="<?php echo base_url('approval/editapproval'); ?>" method="post" id="editapproval">
                        <div class="box-body">
                            <input type="hidden" name="approvalId" value="<?php echo $approvalId; ?>">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Approval Title <span class="re-mend-field">*</span></label>
                                    <input type="text" class="form-control" readonly name="approvalTitle" value="<?php echo htmlspecialchars($approvalTitle); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="userID">Approving Authority</label>
                                    <select class="form-control check required" id="userID" disabled name="userID">
                                        <option value="0">Select User</option>
                                        <?php
                                        if (!empty($users)) {
                                            foreach ($users as $rl) {
                                                $userText = $rl->name;
                                        ?>
                                                <option value="<?php echo $rl->userId ?>" <?php if ($rl->userId == set_value('userID', $userID)) {
                                                                                                echo "selected=selected";
                                                                                            } ?>><?php echo htmlspecialchars($userText); ?></option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Approval Status <span class="re-mend-field">*</span></label>
                                    <select class="form-control" name="approvalStatus" required>
                                        <option value="">Select Status</option>
                                        <option value="Approve" <?php echo ($approvalStatus == "Approve") ? "selected" : ""; ?>>Approve</option>
                                        <option value="Reject" <?php echo ($approvalStatus == "Reject") ? "selected" : ""; ?>>Reject</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Description -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Description <span class="re-mend-field">*</span></label>
                                    <textarea class="form-control" id="description" name="description" rows="4"><?php echo htmlspecialchars($description); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>

                    <!-- Reply Form -->
                    <form role="form" action="<?php echo base_url('approval/addReply'); ?>" method="post" id="approvalReplyForm" enctype="multipart/form-data">
                        <div class="box-footer">
                            
 
                            <div class="form-group">
                                <label for="replyMessage">Reply <span class="re-mend-field">*</span></label>
                                <textarea required class="form-control" name="replyMessage" id="replyMessage" rows="5" placeholder="Write your reply here..."></textarea>
                            </div>

                            <div class="form-group">
                                <label for="attachment">Attachment (Optional)</label>
                                <input type="file" class="form-control" name="file1" id="file1" />
                            </div>

                            <input type="hidden" name="approvalId" value="<?php echo $approvalId; ?>" />
                            <button type="submit" class="btn btn-success">Submit Reply</button>
                        </div>
                    </form>

                    <!-- Chat Styles -->
                    <style>
                        .chat-container {
                            max-width: 90%;
                            margin: auto;
                            font-family: Arial, sans-serif;
                            display: flex;
                            flex-direction: column;
                        }

                        .chat-message {
                            margin: 10px 0;
                            max-width: 75%;
                            padding: 10px 15px;
                            border-radius: 10px;
                            position: relative;
                            word-wrap: break-word;
                            clear: both;
                        }

                        .sender {
                            align-self: flex-end;
                            background-color: #dcf8c6;
                            border-bottom-right-radius: 0;
                            text-align: left;
                            width: 90%;
                        }

                        .receiver {
                            align-self: flex-start;
                            background-color: #ffffff;
                            border: 1px solid #ddd;
                            border-bottom-left-radius: 0;
                            text-align: left;
                            width: 90%;
                        }

                        .chat-meta {
                            font-size: 12px;
                            color: #777;
                            margin-top: 5px;
                        }

                        .chat-header {
                            font-weight: bold;
                            font-size: 14px;
                            margin-bottom: 4px;
                        }

                        .box-footer h4 {
                            text-align: center;
                            margin-top: 20px;
                            color: #444;
                            border-bottom: 1px solid #ccc;
                            padding-bottom: 5px;
                        }

                        .re-mend-field {
                            color: red;
                        }
                    </style>

                    <!-- Tick Styles -->
                    <style>
                        .tick {
                            font-size: 14px;
                            margin-left: 5px;
                        }

                        .tick.single::after {
                            content: "\2713";
                            color: #555;
                        }

                        .tick.double::after {
                            content: "\2713\2713";
                            color: #555;
                        }

                        .tick.read::after {
                            content: "\2713\2713";
                            color: #4fc3f7;
                        }
                    </style>

                    <!-- Previous Replies -->
                    <?php if (!empty($replies)) { ?>
                        <div class="box-footer mt-4">
                            <h4>Previous Replies</h4>
                            <div class="chat-container">
                                <?php foreach ($replies as $reply) {
                                    $currentUserName = $this->session->userdata('name');
                                    $isSender = strtolower($reply->repliedByName) === strtolower($currentUserName);
                                ?>
                                    <div class="chat-message <?php echo $isSender ? 'sender' : 'receiver'; ?>">
                                        <div class="chat-header"><?php echo htmlspecialchars($reply->repliedByName); ?></div>
                                        <?php echo html_entity_decode($reply->message); ?>

                                        <?php if (!empty($reply->attachment)): ?>
                                            <div style="margin-top: 10px;">
                                                <a href="<?php echo $reply->attachment ?>" target="_blank">
                                                    <button class="btn">
                                                        <img src="<?php echo $reply->attachment ?>" style="height: 24px;width: 24px;"> View
                                                    </button>
                                                </a>
                                            </div>
                                        <?php endif; ?>

                                        <div class="chat-meta">
                                            (<?php echo date('d M Y h:i A', strtotime($reply->createdDtm)); ?>)
                                            <?php if ($isSender): ?>
                                                <?php
                                                $tickClass = !empty($reply->read_at) ? 'tick read' : ($reply->status === 'delivered' ? 'tick double' : 'tick single');
                                                ?>
                                                <span class="<?php echo $tickClass; ?>"></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>

            <!-- Flash Messages and Validation -->
            <div class="col-md-2">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>

                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for Description and Reply -->
<script src="https://cdn.ckeditor.com/4.20.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        readOnly: true
    });
    CKEDITOR.replace('replyMessage');
</script>

<style>
    .frselectdiv {
        pointer-events: none;
    }
</style>