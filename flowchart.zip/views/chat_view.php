<!DOCTYPE html>
<html>
<head>
    <title>Internal Chat</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<h3>Chat with User ID: <?php echo $friendId; ?></h3>

<div id="chat-box" style="border:1px solid #ccc; height:300px; overflow-y:scroll; padding:10px;"></div>

<form id="chat-form">
    <input type="hidden" name="receiver_id" value="<?php echo $friendId; ?>">
    <input type="text" name="message" id="message" required autocomplete="off">
    <button type="submit">Send</button>
</form>

<script>
function loadMessages() {
    $.post('<?php echo base_url("chat/fetch_messages"); ?>', {
        friendId: <?php echo $friendId; ?>
    }, function(data) {
        var messages = JSON.parse(data);
        var html = '';
        messages.forEach(function(msg) {
            html += '<p><strong>' + (msg.senderId == <?php echo $this->session->userdata('userId'); ?> ? 'Me' : 'Friend') + ':</strong> ' + msg.message + '</p>';
        });
        $('#chat-box').html(html);
    });
}

$('#chat-form').on('submit', function(e) {
    e.preventDefault();
    $.post('<?php echo base_url("chat/send_message"); ?>', $(this).serialize(), function() {
        $('#message').val('');
        loadMessages();
    });
});

setInterval(loadMessages, 3000);
loadMessages();
</script>
</body>
</html>
