<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Despatch Management
        <small>Add / Edit Despatch</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Despatch Details</h3>
                         <div class="pull-right">
            <a href="<?php echo base_url() ?>despatch/despatchListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>despatch/addNewDespatch" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                                <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                    <option value="">Select Franchise</option>
                                                    <?php
                                                    if (!empty($branchDetail)) {
                                                        foreach ($branchDetail as $bd) {
                                                            $franchiseNumber = $bd->franchiseNumber;
                                                            ?>
                                                            <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                                 
                                            </div>
                                        </div>
<div class="col-md-4">
    <div class="form-group">
        <label for="franchiseName">Franchise Name</label>
        <input type="text" class="form-control" id="franchiseName" name="despatchTitle" readonly>
    </div>
</div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                                <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                                    <option value="0">Select Role</option>
                                                </select>
                                            </div>
                                        </div>



                                <div class="col-md-4">                                
                                    <div class="form-group">
        <label for="orderId">Order ID</label>
       <select id="orderId" name="orderNumber" class="form-control" required>
            <option value="">Select Order</option>
        </select>
    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateoford">Date Of Order <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateoford'); ?>" id="dateoford" name="dateoford" maxlength="256" />
                                    </div>  
                                </div>
                             
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="delStatus">Delivery Status <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo set_value('class'); ?>" id="class" name="class" maxlength="256"> -->
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="delStatus" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option>
                                            <option value="<?= INACTIVE ?>"> In Process</option>     
                                            <option value="<?= ACTIVE ?>">Delivered</option>
                                        </select>
                                    </div>   
                                </div>
                              
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="productDescription">Product Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="productDescription" name="productDescription" readonly></textarea>
                                    </div>
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="productDescription">Franchise <span class="re-mend-field">*</span></label>
                                      
                                         <input required type="text" class="form-control required" value="" id="franchisename" name="franchisename" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Note <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
      

<script>
$(document).ready(function () {
    // Load all order numbers with their IDs as data attribute
    $.ajax({
        url: '<?= base_url("OrderController/get_orders_dropdown") ?>',
        method: 'GET',
        dataType: 'json',
        success: function (res) {
            $.each(res, function (i, order) {
                $('#orderId').append(
                    '<option value="' + order.number + '" data-id="' + order.id + '">' + order.number + '</option>'
                );
            });
        }
    });

    // On change, fetch order details using the data-id (real order ID)
    $('#orderId').on('change', function () {
        var orderNumber = $(this).val(); // for form submission
        var orderId = $(this).find('option:selected').data('id'); // for WooCommerce API

        if (orderId) {
            // Order Description
            $.ajax({
                url: '<?= base_url("OrderController/get_order_description") ?>',
                method: 'POST',
                data: { order_id: orderId },
                dataType: 'json',
                success: function (res) {
                    $('#productDescription').val(res.description);
                }
            });

            // Franchise Name
            $.ajax({
                url: '<?= base_url("OrderController/get_franchise_description") ?>',
                method: 'POST',
                data: { order_id: orderId },
                dataType: 'json',
                success: function (res) {
                    $('#franchisename').val(res.franchisename);
                }
            });
        } else {
            $('#productDescription').val('');
            $('#franchisename').val('');
        }
    });
});
</script>

                            
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field{color: red;}
    </style> 
</div>



<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("despatch/fetchAssignedUsers"); ?>',
            type: 'POST',
            dataType: 'json',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                // Populate the manager dropdown
                $('#branchFranchiseAssigned').html(response.managerOptions);
                 $('#branchFranchiseAssigned option[value="0"]').remove();
                // Set franchise name in text input
                $('#franchiseName').val(response.franchiseName);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                console.error("Response Text:", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
      $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
        $('#franchiseName').val('');
    }
}

</script>


<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>