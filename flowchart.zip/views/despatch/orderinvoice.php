<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-eye"></i> Order #<?php echo $order['number']; ?> Details</h1>

    </section>

    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h4 class="text-center mb-4" style="font-weight: 800;">Proforma Invoice</h4>
                    </div><!-- /.box-header -->
                    <!-- Start-form start -->
                    <div class="container-old border p-4" style="padding: 10px;">
                          <div class="row mb-3">
                            <div class="col-md-6">
                              <strong>Edumeta Edutech India Pvt. Ltd.</strong><br>
                              FY 2024-25-26<br>
                              First Floor 71, Panchal Compound, Behind Betala Force,<br>
                              Lasudiya Mori, Dewas Naka A.B. Road, Indore 452010<br>
                              GSTIN/UIN: 23AAFCE2177C1Z3<br>
                              State: Madhya Pradesh (Code: 23)<br>
                              Contact: +91-7470314920<br>
                              Email: accounts@edumeta.in
                            </div>
                            <div class="col-md-6 text-end">
                              <strong>Invoice No:</strong> EEIPL/25-26/283<br>
                              <strong>Date:</strong> 19-May-25<br>
                              <strong>Buyer's Order No:</strong> #<?php echo $order['number']; ?><br>
                              <strong>Delivery Note:</strong> Post / other<br>
                              <strong>Mode of Payment:</strong> HDFC Bank 19.05.25
                            </div>
                          </div>
                          <div class="row mb-3">
                            <div class="col-md-6">
                            <strong>Buyer (Bill to):</strong><br>
                            <p><?php echo $order['billing']['company']; ?></p>
                            <p><?php echo $order['billing']['first_name'] . ' ' . $order['billing']['last_name']; ?></p>
                            <p><?php echo $order['billing']['address_1']; ?><br>
                            <?php echo $order['billing']['city']; ?>,
                            <?php echo $order['billing']['state']; ?><br>
                            <?php echo $order['billing']['postcode']; ?></p>
                            <p>Email: <?php echo $order['billing']['email']; ?><br>
                            Phone: <?php echo $order['billing']['phone']; ?></p>
                          </div>
                            <div class="col-md-6">
                            <strong>Consignee (Ship to):</strong><br>
                            <!-- <p><?php //echo $order['billing']['company']; ?></p>
                            <p><?php //echo $order['billing']['first_name'] . ' ' . $order['billing']['last_name']; ?></p>
                            <p><?php //echo $order['billing']['address_1']; ?><br>
                            <?php //echo $order['billing']['city']; ?>,
                            <?php //echo $order['billing']['state']; ?><br>
                            <?php //echo $order['billing']['postcode']; ?></p>
                            <p>Email: <?php //echo $order['billing']['email']; ?><br>
                            Phone: <?php //echo $order['billing']['phone']; ?></p> -->
                            <!-- Shop TO -->
                            <p><?php echo $order['shipping']['company']; ?></p>
                            <p><?php echo $order['shipping']['first_name'] . ' ' . $order['shipping']['last_name']; ?></p>
                            <p><?php echo $order['shipping']['address_1']; ?><br>
                            <?php echo $order['shipping']['city']; ?>,
                            <?php echo $order['shipping']['state']; ?><br>
                            <?php echo $order['shipping']['postcode']; ?></p>
                          </div>
                          
                      </div>

                          <table class="table table-bordered">
                            <thead class="table-secondary">
                              <tr>
                                <th>Sl No.</th>
                                <th>Description of Goods</th>
                                <th>HSN/SAC</th>
                                <th>Cost Per Item</th>
                                <th>Quantity</th>
                                <th>Amount</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order['line_items'] as $item): ?>
                              <tr>
                                <td>1</td>
                                <td>
                                    <?php echo $item['name']; ?>
                                            <?php if (!empty($item['variation_id']) && $item['variation_id'] > 0): ?>
                                                <p><b>Variation ID:</b> <?php echo htmlspecialchars($item['variation_id']); ?></p>
                                            <?php endif; ?>
                                            <?php if (!empty($item['meta_data'])): ?>
                                                <?php foreach ($item['meta_data'] as $meta): ?>
                                                    <?php
                                                    $skipKeys = ['_WCPA_order_meta_data'];
                                                    $metaKey = $meta['key'] ?? $meta['display_key'] ?? '';

                                                    if (in_array($metaKey, $skipKeys)) {
                                                        continue;
                                                    }

                                                    $displayKey = is_array($meta['display_key']) ? json_encode($meta['display_key']) : $meta['display_key'];
                                                    $displayValue = is_array($meta['display_value']) ? json_encode($meta['display_value']) : $meta['display_value'];
                                                    ?>
                                                    <p><strong><?php echo htmlspecialchars($displayKey); ?>:</strong> <?php echo htmlspecialchars($displayValue); ?></p>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                            <!-- Addon Fields Section -->
                                            <!-- <?php if (!empty($item['meta_data'])): ?>
                                                <div class="border p-2 bg-light mt-2">
                                                    <strong>Addon fields</strong>
                                                    <table class="table table-sm mb-0 mt-1">
                                                        <thead>
                                                            <tr>
                                                                <th>Options</th>
                                                                <th>Values</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($item['meta_data'] as $meta): ?>
                                                                <?php
                                                                $metaKey = $meta['key'] ?? $meta['display_key'] ?? '';
                                                                if (in_array($metaKey, $skipKeys)) continue;

                                                                $optionKey = $metaKey;
                                                                $optionVal = $meta['value'] ?? $meta['display_value'] ?? '';

                                                                if (is_array($optionVal)) {
                                                                    $formattedValue = implode(', ', array_map(function ($v) {
                                                                        return is_scalar($v) ? htmlspecialchars($v) : json_encode($v);
                                                                    }, $optionVal));
                                                                } elseif (is_object($optionVal)) {
                                                                    $formattedValue = htmlspecialchars(json_encode($optionVal));
                                                                } else {
                                                                    $formattedValue = htmlspecialchars((string)$optionVal);
                                                                }
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo htmlspecialchars($optionKey); ?></td>
                                                                    <td><?php echo $formattedValue; ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div> -->
                                            <?php endif; ?>
                                </td>
                                <td>490110</td>
                                <td>₹ <?php echo number_format($item['price'], 2); ?></td>
                                <td>× <?php echo $item['quantity']; ?></td>
                                <td>₹ <?php echo number_format($item['total'], 2); ?></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                          </table>

                            <?php
                                $subtotal = 0;
                                foreach ($order['line_items'] as $item) {
                                    $subtotal += $item['total'];
                                }

                                $shipping_cost = isset($order['shipping_total']) ? $order['shipping_total'] : 0;

                                // Initialize coupon variables
                                $coupon_discount = 0;
                                $coupons = [];

                                // Check if coupon_lines exist and are valid
                                if (isset($order['coupon_lines']) && is_array($order['coupon_lines']) && count($order['coupon_lines']) > 0) {
                                    foreach ($order['coupon_lines'] as $coupon) {
                                        if (!empty($coupon['discount'])) {
                                            $coupon_discount += floatval($coupon['discount']);
                                        }
                                        if (!empty($coupon['code'])) {
                                            $coupons[] = $coupon['code'];
                                        }
                                    }
                                }

                                $order_total = ($subtotal - $coupon_discount) + $shipping_cost;
                                ?>
                            
                          <div class="row mb-2">
                            <div class="col-md-6"><strong>Total Kits:</strong> 70</div>
                            <div class="col-md-6 text-end"><strong>Subtotal:</strong> <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($subtotal, 2); ?></bdi></span></div>
                          </div>
                          <div class="row mb-2">
                            <div class="col-md-6"><strong>Transport Charges:</strong></div>
                            <div class="col-md-6 text-end"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($shipping_cost, 2); ?></bdi></span></div>
                          </div>
                          <!-- <div class="row mb-2">
                            <div class="col-md-6"><strong>Round Off:</strong></div>
                            <div class="col-md-6 text-end">₹0.40</div>
                          </div> -->
                          <div class="row mb-4">
                            <div class="col-md-6"><strong>Total:</strong></div>
                            <div class="col-md-6 text-end"><strong><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($order_total, 2); ?></bdi></span></strong></div>
                          </div>

                          <!-- <p><strong>Amount in Words:</strong> INR One Lakh Forty Four Thousand Six Hundred Ninety Only</p> -->

                          <h5 class="mt-5">Taxable IGST Summary</h5>
                          <table class="table table-bordered">
                            <thead class="table-secondary">
                              <tr>
                                <th>HSN/SAC</th>
                                <th>Taxable Value</th>
                                <th>IGST Rate</th>
                                <th>IGST Amount</th>
                                <th>Total</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>490110</td>
                                <td>₹1,14,999.85</td>
                                <td>5%</td>
                                <td>₹5,749.99</td>
                                <td>₹5,749.99</td>
                              </tr>
                              <tr>
                                <td>420222</td>
                                <td>₹13,347.25</td>
                                <td>18%</td>
                                <td>₹2,402.51</td>
                                <td>₹2,402.51</td>
                              </tr>
                            </tbody>
                            <tfoot class="table-light">
                              <tr>
                                <th colspan="3">Total</th>
                                <th>₹8,152.50</th>
                                <th>₹8,152.50</th>
                              </tr>
                            </tfoot>
                          </table>

                          <p><strong>Tax Amount (in words):</strong> INR Eight Thousand One Hundred Fifty Two and Fifty Paise Only</p>
                          <div class="row">
                          <div class="col-md-6 mt-5">
                            <strong>Declaration:</strong>
                            <ol>
                              <li>Material, content, quality & rates are subject to change without prior notice.</li>
                              <li>Material once delivered cannot be returned or exchanged.</li>
                              <li>No duplication with or without permission.</li>
                              <li>HO decision is final in case of any dispute.</li>
                              <li>Save all receipts related to eduMETA The i-SCHOOL.</li>
                              <li>Payments are non-refundable & non-adjustable.</li>
                              <li>Cheques are subject to realization.</li>
                              <li>Advance includes GST.</li>
                              <li>Disputes subject to Indore jurisdiction.</li>
                            </ol>
                          </div>

                            <div class="col-md-6 text-end mt-5">
                                        <p><strong>Company’s Bank Details</strong><br>
                                  A/c Holder’s Name : Edumeta Edutech India Pvt. Ltd.<br>
                                  Bank Name : Hdfc Bank<br>
                                  A/c No. : 50200105633731<br>
                                  Branch & IFS Code : Commerce House ,Indore & HDFC0001240</p> 
                                        <p><strong>Authorised Signatory</strong><br></p>
                              </div>
                              <div class="col-md-12">
                                  <p class="note-cls">This is a computer-generated <strong>Proforma Invoice</strong>.</p>
                              </div>
                          </div>
                        </div>
                    <!-- End-New-Form--->
                    <button onclick="window.print()" class="btn btn-primary pull-right">Print</button>
                </div>
            </div>
        </div>
        
    </section>


    <section class="content" style="padding-bottom: 0px;">
        <?php
        $subtotal = 0;
        foreach ($order['line_items'] as $item) {
            $subtotal += $item['total'];
        }

        $shipping_cost = isset($order['shipping_total']) ? $order['shipping_total'] : 0;

        // Initialize coupon variables
        $coupon_discount = 0;
        $coupons = [];

        // Check if coupon_lines exist and are valid
        if (isset($order['coupon_lines']) && is_array($order['coupon_lines']) && count($order['coupon_lines']) > 0) {
            foreach ($order['coupon_lines'] as $coupon) {
                if (!empty($coupon['discount'])) {
                    $coupon_discount += floatval($coupon['discount']);
                }
                if (!empty($coupon['code'])) {
                    $coupons[] = $coupon['code'];
                }
            }
        }

        $order_total = ($subtotal - $coupon_discount) + $shipping_cost;
        ?>

        <div class="box mt-4">
            <div class="box-body">
                <div class="row border p-3 align-items-start">
                    <!-- Left Column (col-8) -->
                    <table>
                        <tbody id="order_shipping_line_items">
                            <tr class="shipping ">
                                <td class="thumb"><i class="fas fa-truck fa-2x mr-3 text-secondary"></i></td>
                                <td class="name">
                                    <strong>Shipping and handling charges</strong>
                                    <strong>Items:</strong><br>
                                    <?php foreach ($order['line_items'] as $item): ?>
                                        <?php echo $item['name']; ?> × <?php echo $item['quantity']; ?><br>
                                    <?php endforeach; ?>
                                </td>
                                <td class="item_cost" width="1%"> </td>
                                <td class="quantity" width="1%"> </td>
                                <td class="line_cost" width="10%">
                                    <p class="text-right">₹ <?php echo number_format($shipping_cost, 2); ?></p>
                                </td>
                                <td class="wc-order-edit-line-item"></td>
                             
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <section class="content" style="padding-top: 0px;margin-top: -15px;">
        <div class="wc-order-data-row wc-order-totals-items wc-order-items-editable">
            <div class="wc-used-coupons">
                <ul class="wc_coupon_list">
                    <li><strong>Coupon(s)</strong></li>
                    <li class="code">
                        <?php if (!empty($coupons)): ?>
                            <div class="mt-3">
                                <?php foreach ($coupons as $code): ?>
                                    <?php echo htmlspecialchars($code); ?>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="mt-3 text-muted">No coupons applied.</div>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
            <table class="wc-order-totals">
                <tbody>
                    <tr>
                        <td class="label">Items Subtotal:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($subtotal, 2); ?></bdi></span>
                        </td>
                    </tr>
                    <?php if ($coupon_discount > 0): ?>
                        <tr>
                            <td class="label">Coupon(s):</td>
                            <td width="1%"></td>
                            <td class="total coupon-totl">-
                                <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($coupon_discount, 2); ?></bdi></span>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td class="label">Shipping:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($shipping_cost, 2); ?></bdi></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="label">Order Total:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($order_total, 2); ?></bdi></span>
                        </td>
                    </tr>
                </tbody>
            </table>
            <p class="text-muted mb-1"><i class="fas fa-info-circle"></i> This order is no longer editable.</p>
        </div>
    </section>
    <?php if (!empty($order['customer_note'])): ?>
        <section class="content">
            <div class="box mt-4">
                <div class="box-body">
                    <h4><strong>Customer Note</strong></h4>
                    <p><?php echo nl2br(htmlspecialchars($order['customer_note'])); ?></p>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>

<style type="text/css">
    .shipping td {
        padding: 1.5em 1em 1em;
        text-align: left;
        line-height: 1.5em;
        vertical-align: top;
        border-bottom: 1px solid #f8f8f8–
    }

    td.thumb {
        text-align: left;
        width: 38px;
        padding-bottom: 1.5em;
    }

    ul.wc_coupon_list li.code {
        display: inline-block;
        position: relative;
        padding: 0 .5em;
        background-color: #fff;
        border: 1px solid #aaa;
        box-shadow: 0 1px 0 #dfdfdf;
        border-radius: 4px;
        margin-right: 5px;
        margin-top: 5px;
    }

    .wc-used-coupons {
        float: left;
        width: 50%;
        text-align: left;
    }

    .wc-order-totals {
        float: right;
        width: 50%;
        margin: 0;
        padding: 0;
        text-align: right;
    }

    .wc-order-data-row {
        border-bottom: 1px solid #dfdfdf;
        padding: 1.5em 2em;
        background: #f8f8f8;
        line-height: 2em;
        text-align: right;
    }

    table.wc-order-totals td {
        color: #3c434a;
        font-weight: 400;
        font-size: 14px;
    }

    .coupon-totl span.woocommerce-Price-amount.amount {
        color: #ff521b;
    }

    section.content {
        padding-top: 10px;
        padding-bottom: 0px;
        min-height: auto;
    }

    .tbhed .item-tbhead th {
        text-align: left;
        padding: 1em;
        font-weight: 400;
        color: #999;
        background: #f8f8f8;
        -webkit-touch-callout: none;
        user-select: none;
    }

    .ord-item-list {
        border-bottom: 4px solid #f4f4f4;
    }

    ul.wc_coupon_list {
        list-style: none;
    }

    .wc-order-item-thumbnail {
        padding-top: 16px;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        padding: 8px 16px;
        font-size: 14px;
        border-radius: 4px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
    }

    .pull-right {
        float: right;
    }

    @media print {
        .btn-primary {
            display: none;
        }

        .content-wrapper {
            width: 100%;
            margin: 0;
            padding: 0;
        }

        .content-header {
            margin-bottom: 10px;
        }

        .box {
            border: none;
            box-shadow: none;
        }

        .border {
            border: 1px solid #000 !important;
        }

        a {
            text-decoration: none;
            color: #000;
        }

        .row {
            display: block;
        }

        .col-md-4,
        .col-md-12 {
            width: 100%;
            display: block;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 5px;
        }

        .wc-order-edit-line-item {
            display: none;
        }
    }
</style>
<style type="text/css">
    .note-cls{
        text-align: center;
        padding: 32px;
    }
</style>