<?php 
$orderId = isset($order) && isset($order->id) ? $order->id : null;
$brspFranchiseAssigned = isset($order->billing->company) ? $order->billing->company : '';

$AcInvoicenumDesp = isset($despatchInfo->AcInvoicenumDesp) ? $despatchInfo->AcInvoicenumDesp : '';
$AcInvoiceTitle = isset($despatchInfo->AcInvoiceTitle) ? $despatchInfo->AcInvoiceTitle : '';
$AcInvoiceAmount = isset($despatchInfo->AcInvoiceAmount) ? $despatchInfo->AcInvoiceAmount : '';
$AcDescription = isset($despatchInfo->AcDescription) ? $despatchInfo->AcDescription : '';
$despatchTitle = isset($despatchInfo->despatchTitle) ? $despatchInfo->despatchTitle : '';

$despatchId = $despatchInfo->despatchId;


$ordamtConfirmationStatus = $despatchInfo->ordamtConfirmationStatus;

$despatchTitle = $despatchInfo->despatchTitle;
$franchiseNumber = $despatchInfo->franchiseNumber;
$orderNumber = $despatchInfo->orderNumber;
/*New-field-Added-23-May-2023*/
$dateoford = $despatchInfo->dateoford;
$prodQtyDespatch = $despatchInfo->prodQtyDespatch;
$prodListdespatch = $despatchInfo->prodListdespatch;
$dateofdespatch = $despatchInfo->dateofdespatch;
/*New-field-Added-23-May-2023*/
$modeOforder = $despatchInfo->modeOforder;
$transportCourior = $despatchInfo->transportCourior;
$emailconfirmDispatchPOD = $despatchInfo->emailconfirmDispatchPOD;
$podNumber = $despatchInfo->podNumber;
$delStatus = $despatchInfo->delStatus;
$delDate = $despatchInfo->delDate;
$description = $despatchInfo->description;
$productDescription = $despatchInfo->productDescription;
$acattachmentInvoiceS3File = $despatchInfo->acattachmentInvoiceS3File;
$others = $despatchInfo->others;

//$selectUserId ='';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Despatch Management
        <small>Add / Edit Despatch</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Despatch Details</h3>
                         <div class="pull-right">
            <a href="<?php echo base_url() ?>despatch/despatchListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>despatch/editDespatch" enctype="multipart/form-data" method="post" id="editDespatch" role="form">
                        <div class="box-body">
                         
                          <input type="hidden" value="<?php echo $despatchId; ?>" name="despatchId" id="despatchId" /> 
                            <div class="row">    
                              <?php  if($is_admin == 1 || $role==23 || $role==16) { ?>  
                              <div class="col-md-4">
    <div class="form-group">
        <label>Franchise No</label>
        <input type="text" class="form-control" value="<?php echo isset($franchiseNumber) ? $franchiseNumber : ''; ?>" readonly>
    </div>
</div>
                            <?php } ?>
                            <input type="hidden" class="form-control" id="brspFranchiseAssigned" name="brspFranchiseAssigned" 
               value="<?php echo isset($despatchInfo->brspFranchiseAssigned) ? $despatchInfo->brspFranchiseAssigned : ''; ?>" 
               readonly>
                             <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="orderNumber">Order No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" 
                                               value="<?php echo set_value('orderNumber', isset($orderNumber) ? $orderNumber : ''); ?>" 
                                               id="orderNumber" name="orderNumber" maxlength="256" readonly />
                                    </div>
                                </div>
                                
                                                    <div class="col-md-4">                                
    <div class="form-group">
        <label for="ordamtConfirmationStatus">Amount Confirmation Status <span class="re-mend-field">*</span></label>
        <select class="form-control required" id="ordamtConfirmationStatus" name="ordamtConfirmationStatus" >
            <option value="">Select Mode</option>
            <option value="Received" <?php if ($ordamtConfirmationStatus == 'Received') echo 'selected'; ?>>Received</option>
            <option value="Not Received" <?php if ($ordamtConfirmationStatus == 'Not Received') echo 'selected'; ?>>Not Received</option>
           
        </select>
    </div>
</div>
                               <!--  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="AcInvoiceAmount">Invoice Amount <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $AcInvoiceAmount; ?>" id="AcInvoiceAmount" name="AcInvoiceAmount" maxlength="256" />
                                    </div>
                                </div> -->
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="AcDescription">Account Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required clsp" id="AcDescription" name="AcDescription"><?php echo $AcDescription; ?></textarea>
                                    </div>
                                </div>
                               
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="AcInvoicenumDesp">A/C Upload File</label>
                                            <?php if (!empty($despatchInfo->acattachmentInvoiceS3File)) { ?>
                                                <!-- If file exists, display the image and "AC - View" button -->
                                                <a href="<?php echo $despatchInfo->acattachmentInvoiceS3File; ?>" target="_blank">
                                                    <button class="btn">
                                                        <img src="<?php echo $despatchInfo->acattachmentInvoiceS3File; ?>" style="height: 50px !important; width: 50px;">
                                                        A/C - View
                                                    </button>
                                                </a>
                                            <?php } else { ?>
                                                <!-- If no file exists, display the file upload option -->
                                                <input type="file" name="file" class="form-control" id="AcInvoicenumDesp">
                                            <?php } ?>
                                        </div>
                                    </div>


                        <!-- End Ac-Section -->      
                        <?php  if($is_admin == 1 || $role==23) { ?>
                                       
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateoford">Date of Order <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateoford; ?>" id="dateoford" name="dateoford"  />
                                    </div>
                                </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                    <label for="despatchTitle">Despatch Title <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" 
                                           value="<?php echo set_value('despatchTitle', isset($despatchTitle) ? $despatchTitle : ''); ?>" 
                                           id="despatchTitle" name="despatchTitle" maxlength="256" />
                                    <input type="hidden" value="<?php echo isset($despatchId) ? $despatchId : ''; ?>" name="despatchId" id="despatchId" />
                                </div>
                            </div>
                             
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateofdespatch">Date of Despatch <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateofdespatch; ?>" id="dateofdespatch" name="dateofdespatch" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
    <div class="form-group">
        <label for="modeOforder">Mode Of Order <span class="re-mend-field">*</span></label>
        <select class="form-control required" id="modeOforder" name="modeOforder" >
            <option value="">Select Mode</option>
            <option value="VRL" <?php if ($modeOforder == 'VRL') echo 'selected'; ?>>VRL</option>
            <option value="Safexpress" <?php if ($modeOforder == 'Safexpress') echo 'selected'; ?>>Safexpress</option>
            <option value="Easyport" <?php if ($modeOforder == 'Easyport') echo 'selected'; ?>>Easyport</option>
            <option value="IndianPost" <?php if ($modeOforder == 'IndianPost') echo 'selected'; ?>>IndianPost</option>
            <option value="Others" <?php if ($modeOforder == 'Others') echo 'selected'; ?>>Others</option>
        </select>
    </div>
</div>
<div class="col-md-4" id="othersField" style="display: <?php echo ($modeOforder == 'Others') ? 'block' : 'none'; ?>;">
    <div class="form-group">
        <label for="otherMode">Other Mode of Order <span class="re-mend-field">*</span></label>
        <input type="text" class="form-control" id="otherMode" name="otherMode" value="<?php echo ($modeOforder == 'Others') ? $despatchInfo->otherMode : ''; ?>" maxlength="256" <?php echo ($modeOforder == 'Others') ? 'required' : ''; ?> />
    </div>
</div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="transportCourior">Tracking Link <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $transportCourior; ?>" id="transportCourior" name="transportCourior" maxlength="256" />
                                        
                                    </div>
                                    
                                </div>
                                <div class="col-md-8">                                
                                    <div class="form-group">
                                        <label for="emailconfirmDispatchPOD">Email Confirmation With Dispatch POD </label>
                                        <input  type="date" class="form-control required" value="<?php echo $emailconfirmDispatchPOD; ?>" id="emailconfirmDispatchPOD" name="emailconfirmDispatchPOD" maxlength="256" />
                                        
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="podNumber">Tracking No. <span class="re-mend-field">*</span></label>
                                        <input  type="text" class="form-control required" value="<?php echo $podNumber; ?>" id="podNumber" name="podNumber" maxlength="256" />
                                        
                                    </div>
                                    
                                </div>
                                
                                <!-- <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="VRLInvoicenumDesp">VRL Upload File </label>
                                        <input type="file" name="vrlfile" multiple>
                                    </div>

                                </div>
 -->

 <div class="col-md-6">
    <div class="form-group">
        <label for="AcInvoicenumDesp">Despatch Receipt</label>
        <?php if (!empty($despatchInfo->acattachmentVRLS3File)) { ?>
            <!-- If file exists, display the image and "AC - View" button -->
            <a href="<?php echo $despatchInfo->acattachmentVRLS3File; ?>" target="_blank">
                <button class="btn">
                    <img src="<?php echo $despatchInfo->acattachmentVRLS3File; ?>" style="height: 50px !important; width: 50px;">
                    AC - View
                </button>
            </a>
        <?php } else { ?>
            <!-- If no file exists, display the file upload option -->
            <input type="file" name="vrlfile" class="form-control" id="AcInvoicenumDesp">
        <?php } ?>
    </div>
</div>



                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="class">Delivery Status <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo $class; ?>" id="class" name="class" maxlength="256"> -->
                                         <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="delStatus" tabindex="-1" aria-hidden="true">
                                            <option value="<?= INACTIVE ?>" <?php if($delStatus == INACTIVE) {echo "selected=selected";} ?> >In Process</option> 
                                            <option value="<?= ACTIVE ?>" <?php if($delStatus == ACTIVE) {echo "selected=selected";} ?>>Delivered</option>
                                        
                                           
                                        </select>
                                    </div>  
                                </div>    
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="delDate">Date of Delivery</label>
                                        <input  type="date" class="form-control required" value="<?php echo $delDate; ?>" id="delDate" name="delDate" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Special Note <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="productDescription">Product Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="productDescription" name="productDescription"disabled><?php echo $productDescription; ?></textarea>
                                    </div>
                                </div>
                                
                            </div>
                        <?php } ?>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field{color: red;}
        /*.clsp{pointer-events:none;}*/
    </style>
    <script>
document.getElementById('modeOforder').addEventListener('change', function() {
    var othersField = document.getElementById('othersField');
    var otherModeInput = document.getElementById('otherMode');
    if (this.value === 'Others') {
        othersField.style.display = 'block';
        otherModeInput.setAttribute('required', 'required');
    } else {
        othersField.style.display = 'none';
        otherModeInput.removeAttribute('required');
    }
});
</script>
</div>