<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-eye"></i> Order #<?php echo $order['number']; ?> Details</h1>
 <div class="pull-right">
            <a href="<?php echo base_url() ?>despatch/despatchListing" class="btn btn-info">Back to Listing</a>
        </div>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-body">
                <div class="border p-3 mb-3">
                    <h4><strong>Order #<?php echo $order['number']; ?> Details</strong></h4>
                    <p>Payment via <?php echo $order['payment_method_title']; ?> .Paid On <?php echo $order['date_paid']; ?> <?php echo $order['transaction_id']; ?>
                        Customer IP: <?php echo $order['customer_ip_address']; ?></p>
                </div>

                <div class="row">
                    <!-- General -->
                    <div class="col-md-4 border p-3">
                        <h4><strong>General</strong></h4>
                        <p><strong>Date:</strong> <?php echo date('Y-m-d', strtotime($order['date_created'])); ?></p>
                        <p><strong>Time:</strong> <?php echo date('H:i', strtotime($order['date_created'])); ?></p>
                        <p><strong>Status:</strong> <?php echo ucfirst($order['status']); ?></p>
                        <p><strong>Customer:</strong><br>
                            <?php echo $order['billing']['first_name'] . ' ' . $order['billing']['last_name']; ?><br>
                            (<?php echo $order['billing']['email']; ?>)
                        </p>
                    </div>

                    <!-- Billing -->
                    <div class="col-md-4 border p-3">
                        <h4><strong>Billing</strong></h4>
                        <p><?php echo $order['billing']['company']; ?></p>
                        <p><?php echo $order['billing']['first_name'] . ' ' . $order['billing']['last_name']; ?></p>
                        <p><?php echo $order['billing']['address_1']; ?><br>
                            <?php echo $order['billing']['city']; ?>,
                            <?php echo $order['billing']['state']; ?><br>
                            <?php echo $order['billing']['postcode']; ?></p>
                        <p>Email: <?php echo $order['billing']['email']; ?><br>
                            Phone: <?php echo $order['billing']['phone']; ?></p>
                    </div>

                    <!-- Shipping -->
                    <div class="col-md-4 border p-3">
                        <h4><strong>Shipping</strong></h4>
                        <p><?php echo $order['shipping']['company']; ?></p>
                        <p><?php echo $order['shipping']['first_name'] . ' ' . $order['shipping']['last_name']; ?></p>
                        <p><?php echo $order['shipping']['address_1']; ?><br>
                            <?php echo $order['shipping']['city']; ?>,
                            <?php echo $order['shipping']['state']; ?><br>
                            <?php echo $order['shipping']['postcode']; ?></p>
                    </div>
                    <?php
                    $meta = [];
                    if (!empty($order['meta_data'])) {
                        foreach ($order['meta_data'] as $item) {
                            $meta[$item['key']] = $item['value'];
                        }
                    }
                    ?>
                    <div class="col-md-12">
                        <p><strong>Payment Transaction ID (Meta):</strong> <?php echo isset($meta['_billing_payment_transaction_id']) ? $meta['_billing_payment_transaction_id'] : 'N/A'; ?></p>

                        <p><strong>Application Slip:</strong>
                            <?php if (!empty($meta['_application'])): ?>
                                <a href="<?php echo $meta['_application']; ?>" target="_blank">View Attachment</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <h4><strong>Order Items</strong></h4>
        <div class="box mt-4">
            <div class="box-body">
                <div class="inside">
                    <div class="tbhed woocommerce_order_items_wrapper wc-order-items-editable">
                        <table cellpadding="0" cellspacing="0" class="woocommerce_order_items">
                            <thead class="item-tbhead">
                                <tr>
                                    <th class="item sortable" colspan="2" data-sort="string-ins">Item</th>
                                    <th class="item_cost sortable" data-sort="float">Cost</th>
                                    <th class="quantity sortable" data-sort="int">Qty</th>
                                    <th class="line_cost sortable" data-sort="float">Total</th>
                                    <th class="wc-order-edit-line-item" width="1%"> </th>
                                </tr>
                            </thead>

                            <tbody id="order_line_items">
                                <?php foreach ($order['line_items'] as $item): ?>
                                    <tr class="item ord-item-list" data-order_item_id="13663">
                                        <td class="thumb">
                                            <div class="wc-order-item-thumbnail">
                                                <img src="<?php echo $item['image']['src']; ?>" alt="" class="mr-3" width="64" height="64">
                                            </div>
                                        </td>
                                        <td class="name" data-sort-value="" style="padding: 10px;">
                                            <?php echo $item['name']; ?>
                                            <?php if (!empty($item['variation_id']) && $item['variation_id'] > 0): ?>
                                                <p><b>Variation ID:</b> <?php echo htmlspecialchars($item['variation_id']); ?></p>
                                            <?php endif; ?>
                                            <?php if (!empty($item['meta_data'])): ?>
                                                <?php foreach ($item['meta_data'] as $meta): ?>
                                                    <?php
                                                    $skipKeys = ['_WCPA_order_meta_data'];
                                                    $metaKey = $meta['key'] ?? $meta['display_key'] ?? '';

                                                    if (in_array($metaKey, $skipKeys)) {
                                                        continue;
                                                    }

                                                    $displayKey = is_array($meta['display_key']) ? json_encode($meta['display_key']) : $meta['display_key'];
                                                    $displayValue = is_array($meta['display_value']) ? json_encode($meta['display_value']) : $meta['display_value'];
                                                    ?>
                                                    <p><strong><?php echo htmlspecialchars($displayKey); ?>:</strong> <?php echo htmlspecialchars($displayValue); ?></p>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                            <!-- Addon Fields Section -->
                                            <?php if (!empty($item['meta_data'])): ?>
                                                <div class="border p-2 bg-light mt-2">
                                                    <strong>Addon fields</strong>
                                                    <table class="table table-sm mb-0 mt-1">
                                                        <thead>
                                                            <tr>
                                                                <th>Options</th>
                                                                <th>Values</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach ($item['meta_data'] as $meta): ?>
                                                                <?php
                                                                $metaKey = $meta['key'] ?? $meta['display_key'] ?? '';
                                                                if (in_array($metaKey, $skipKeys)) continue;

                                                                $optionKey = $metaKey;
                                                                $optionVal = $meta['value'] ?? $meta['display_value'] ?? '';

                                                                if (is_array($optionVal)) {
                                                                    $formattedValue = implode(', ', array_map(function ($v) {
                                                                        return is_scalar($v) ? htmlspecialchars($v) : json_encode($v);
                                                                    }, $optionVal));
                                                                } elseif (is_object($optionVal)) {
                                                                    $formattedValue = htmlspecialchars(json_encode($optionVal));
                                                                } else {
                                                                    $formattedValue = htmlspecialchars((string)$optionVal);
                                                                }
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo htmlspecialchars($optionKey); ?></td>
                                                                    <td><?php echo $formattedValue; ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="item_cost" width="10%" data-sort-value="">
                                            ₹ <?php echo number_format($item['price'], 2); ?>
                                        </td>
                                        <td class="quantity" width="5%">
                                            × <?php echo $item['quantity']; ?>
                                        </td>
                                        <td class="line_cost" width="10%" data-sort-value="">
                                            ₹ <?php echo number_format($item['total'], 2); ?>
                                        </td>
                                        <td class="wc-order-edit-line-item" width="1%">
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <button onclick="window.print()" class="btn btn-primary pull-right">Print Order</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content" style="padding-bottom: 0px;">
        <?php
        $subtotal = 0;
        foreach ($order['line_items'] as $item) {
            $subtotal += $item['total'];
        }

        $shipping_cost = isset($order['shipping_total']) ? $order['shipping_total'] : 0;

        // Initialize coupon variables
        $coupon_discount = 0;
        $coupons = [];

        // Check if coupon_lines exist and are valid
        if (isset($order['coupon_lines']) && is_array($order['coupon_lines']) && count($order['coupon_lines']) > 0) {
            foreach ($order['coupon_lines'] as $coupon) {
                if (!empty($coupon['discount'])) {
                    $coupon_discount += floatval($coupon['discount']);
                }
                if (!empty($coupon['code'])) {
                    $coupons[] = $coupon['code'];
                }
            }
        }

        $order_total = ($subtotal - $coupon_discount) + $shipping_cost;
        ?>

        <div class="box mt-4">
            <div class="box-body">
                <div class="row border p-3 align-items-start">
                    <!-- Left Column (col-8) -->
                    <table>
                        <tbody id="order_shipping_line_items">
                            <tr class="shipping ">
                                <td class="thumb"><i class="fas fa-truck fa-2x mr-3 text-secondary"></i></td>
                                <td class="name">
                                    <strong>Shipping and handling charges</strong>
                                    <strong>Items:</strong><br>
                                    <?php foreach ($order['line_items'] as $item): ?>
                                        <?php echo $item['name']; ?> × <?php echo $item['quantity']; ?><br>
                                    <?php endforeach; ?>
                                </td>
                                <td class="item_cost" width="1%"> </td>
                                <td class="quantity" width="1%"> </td>
                                <td class="line_cost" width="10%">
                                    <p class="text-right">₹ <?php echo number_format($shipping_cost, 2); ?></p>
                                </td>
                                <td class="wc-order-edit-line-item"></td>
                             
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
    <section class="content" style="padding-top: 0px;margin-top: -15px;">
        <div class="wc-order-data-row wc-order-totals-items wc-order-items-editable">
            <div class="wc-used-coupons">
                <ul class="wc_coupon_list">
                    <li><strong>Coupon(s)</strong></li>
                    <li class="code">
                        <?php if (!empty($coupons)): ?>
                            <div class="mt-3">
                                <?php foreach ($coupons as $code): ?>
                                    <?php echo htmlspecialchars($code); ?>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="mt-3 text-muted">No coupons applied.</div>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
            <table class="wc-order-totals">
                <tbody>
                    <tr>
                        <td class="label">Items Subtotal:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($subtotal, 2); ?></bdi></span>
                        </td>
                    </tr>
                    <?php if ($coupon_discount > 0): ?>
                        <tr>
                            <td class="label">Coupon(s):</td>
                            <td width="1%"></td>
                            <td class="total coupon-totl">-
                                <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($coupon_discount, 2); ?></bdi></span>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td class="label">Shipping:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($shipping_cost, 2); ?></bdi></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="label">Order Total:</td>
                        <td width="1%"></td>
                        <td class="total">
                            <span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">₹</span> <?php echo number_format($order_total, 2); ?></bdi></span>
                        </td>
                    </tr>
                </tbody>
            </table>
            <p class="text-muted mb-1"><i class="fas fa-info-circle"></i> This order is no longer editable.</p>
        </div>
    </section>
    <?php if (!empty($order['customer_note'])): ?>
        <section class="content">
            <div class="box mt-4">
                <div class="box-body">
                    <h4><strong>Customer Note</strong></h4>
                    <p><?php echo nl2br(htmlspecialchars($order['customer_note'])); ?></p>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>

<style type="text/css">
    .shipping td {
        padding: 1.5em 1em 1em;
        text-align: left;
        line-height: 1.5em;
        vertical-align: top;
        border-bottom: 1px solid #f8f8f8–
    }

    td.thumb {
        text-align: left;
        width: 38px;
        padding-bottom: 1.5em;
    }

    ul.wc_coupon_list li.code {
        display: inline-block;
        position: relative;
        padding: 0 .5em;
        background-color: #fff;
        border: 1px solid #aaa;
        box-shadow: 0 1px 0 #dfdfdf;
        border-radius: 4px;
        margin-right: 5px;
        margin-top: 5px;
    }

    .wc-used-coupons {
        float: left;
        width: 50%;
        text-align: left;
    }

    .wc-order-totals {
        float: right;
        width: 50%;
        margin: 0;
        padding: 0;
        text-align: right;
    }

    .wc-order-data-row {
        border-bottom: 1px solid #dfdfdf;
        padding: 1.5em 2em;
        background: #f8f8f8;
        line-height: 2em;
        text-align: right;
    }

    table.wc-order-totals td {
        color: #3c434a;
        font-weight: 400;
        font-size: 14px;
    }

    .coupon-totl span.woocommerce-Price-amount.amount {
        color: #ff521b;
    }

    section.content {
        padding-top: 10px;
        padding-bottom: 0px;
        min-height: auto;
    }

    .tbhed .item-tbhead th {
        text-align: left;
        padding: 1em;
        font-weight: 400;
        color: #999;
        background: #f8f8f8;
        -webkit-touch-callout: none;
        user-select: none;
    }

    .ord-item-list {
        border-bottom: 4px solid #f4f4f4;
    }

    ul.wc_coupon_list {
        list-style: none;
    }

    .wc-order-item-thumbnail {
        padding-top: 16px;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        padding: 8px 16px;
        font-size: 14px;
        border-radius: 4px;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
    }

    .pull-right {
        float: right;
    }

    @media print {
        .btn-primary {
            display: none;
        }

        .content-wrapper {
            width: 100%;
            margin: 0;
            padding: 0;
        }

        .content-header {
            margin-bottom: 10px;
        }

        .box {
            border: none;
            box-shadow: none;
        }

        .border {
            border: 1px solid #000 !important;
        }

        a {
            text-decoration: none;
            color: #000;
        }

        .row {
            display: block;
        }

        .col-md-4,
        .col-md-12 {
            width: 100%;
            display: block;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 5px;
        }

        .wc-order-edit-line-item {
            display: none;
        }
    }
</style>