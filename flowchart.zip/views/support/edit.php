<?php 
//print_r($supportInfo);exit;
$supportMeetingId = $supportInfo->supportMeetingId;
$meetingTitle = $supportInfo->meetingTitle;
$attendedByfranchise = $supportInfo->attendedByfranchise;
$dateMeeting = $supportInfo->dateMeeting;
$timeMeeting = $supportInfo->timeMeeting;
$durationMeeting = $supportInfo->durationMeeting;
$trypeofMeeting = $supportInfo->trypeofMeeting; // Fixed typo from trypeofMeeting
$franchiseNumberArray = explode(",", $supportInfo->franchiseNumber);
$description = $supportInfo->description;
$meetingLink = $supportInfo->meetingLink;
$minutesofmeeting = $supportInfo->minutesofmeeting;
$attendeesHO = $supportInfo->attendeesHO;

$status = $supportInfo->status;
$selectUserId = '';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Support Meeting Management
            <small>Add / Edit Support Meeting</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Support Meeting Details</h3>
                         <div class="pull-right">
            <a href="<?php echo base_url() ?>support/supportListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo base_url() ?>support/editSupport" method="post" id="editSupport" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="meetingTitle">Meeting Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $meetingTitle; ?>" id="meetingTitle" name="meetingTitle" maxlength="256" />
                                        <input type="hidden" value="<?php echo $supportMeetingId; ?>" name="supportMeetingId" id="supportMeetingId" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="attendedByfranchise">Attended By Franchise <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo $attendedByfranchise; ?>" id="attendedByfranchise" name="attendedByfranchise" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateMeeting">Date Of Meeting <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateMeeting; ?>" id="dateMeeting" name="dateMeeting" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="meetingLink">Meeting Link <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo $meetingLink; ?>" id="meetingLink" name="meetingLink" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="timeMeeting">Time of Meeting <span class="re-mend-field">*</span></label>
                                        <input required type="time" class="form-control required" value="<?php echo $timeMeeting; ?>" id="timeMeeting" name="timeMeeting" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="durationMeeting">Duration Of Meeting <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $durationMeeting; ?>" id="durationMeeting" name="durationMeeting" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="trypeofMeeting">Type of Meeting <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="trypeofMeeting" name="trypeofMeeting" required>
                                            <option value="Common-All" <?= $trypeofMeeting == "Common-All" ? 'selected' : '' ?>>Common (All)</option>
                                            <option value="Group" <?= $trypeofMeeting == "Group" ? 'selected' : '' ?>>Group</option>
                                            <option value="Individual" <?= $trypeofMeeting == "Individual" ? 'selected' : '' ?>>Individual</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" multiple data-live-search="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                    <option value="<?php echo $franchiseNumber; ?>" <?php if (in_array($franchiseNumber, $franchiseNumberArray)) {
                                                                                                        echo "selected=selected";
                                                                                                    } ?>><?php echo $franchiseNumber; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                              

        <input type="hidden" class="form-control" id="brspFranchiseAssigned" name="brspFranchiseAssigned" 
               value="<?php echo isset($supportInfo->brspFranchiseAssigned) ? $supportInfo->brspFranchiseAssigned : ''; ?>" 
               readonly>
                       <div class="col-md-4">
    <div class="form-group">
        <label for="attendeesHO">Attendees (HO) <span class="re-mend-field">*</span></label>
       <select class="form-control required" id="attendeesHO" name="attendeesHO[]" multiple>
    <option value="">Select User</option>
    <?php
    if (!empty($users)) {
        foreach ($users as $rl) {
            $userText = $rl->name;
            $isSelected = in_array($userText, (array)$selectedAttendeesHO) ? 'selected="selected"' : '';
            ?>
            <option value="<?= $userText ?>" <?= $isSelected ?>>
                <?= $userText ?>
            </option>
            <?php
        }
    }
    ?>
</select>
    </div>
</div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="minutesofmeeting">Minutes Of Meeting</label>
                                        <textarea class="form-control" id="minutesofmeeting" name="minutesofmeeting"><?php echo $minutesofmeeting; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="status">Status <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="status" name="status" required>
                                            <option value="" disabled>Select Status</option>
                                            <option value="Rescheduled" <?= (isset($status) && $status == "Rescheduled") ? 'selected' : '' ?>>Rescheduled</option>
                                            <option value="Completed" <?= (isset($status) && $status == "Completed") ? 'selected' : '' ?>>Completed</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('support/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
        $(document).ready(function() {
            $('#editSupport').on('submit', function(e) {
                if ($('#status').val() === '') {
                    e.preventDefault();
                    alert('Please select a status.');
                    return false;
                }
            });
        });
    </script>
</div>