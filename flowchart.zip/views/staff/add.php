<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Staff Management
            <small>Add / Edit Staff</small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Staff Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addStaff" action="<?php echo base_url() ?>staff/addNewStaff" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true" required>
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                     <option value="<?php echo $franchiseNumber; ?>" ><?php echo $franchiseNumber; ?></option>
                                                    <?php

                                                }
                                            }
                                                    ?>         
                                        </select>
                                    </div>
                                </div> -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <!-- Franchise users: Non-editable field -->
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: ''; // Use session franchise number or empty
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php if ($role == 14) { ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                            <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                                <span>Select a franchise to assign</span>
                                            </div>
                                            <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                              <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">Staff Employee Id<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('staff_EmpId'); ?>" id="staff_EmpId" name="staff_EmpId" maxlength="256" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">Name<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('name'); ?>" id="name" name="name" maxlength="256" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="dateOfJoin">Date Of Joining <span class="re-mend-field">*</span></label>
                                    <input required type="date" class="form-control required" value="<?php echo set_value('dateOfJoin'); ?>" id="dateOfJoin" name="dateOfJoin" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="birthday">Date Of Birth <span class="re-mend-field">*</span></label>
                                    <input required type="date" class="form-control required" value="<?php echo set_value('birthday'); ?>" id="birthday" name="birthday" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="staffMobileno">Staff Mobile No. <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('staffMobileno'); ?>" id="staffMobileno" name="staffMobileno" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="staffWhatsappno">Staff WhatsApp No. <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('staffWhatsappno'); ?>" id="staffWhatsappno" name="staffWhatsappno" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="staffemail">Staff E-mail <span class="re-mend-field">*</span></label>
                                    <input required type="email" class="form-control required" value="<?php echo set_value('staffemail'); ?>" id="staffemail" name="staffemail" maxlength="256">
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="emergencyMobileno">Emergency Mobile No. <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('emergencyMobileno'); ?>" id="emergencyMobileno" name="emergencyMobileno" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="highestQuali">Highest Qualification <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('highestQuali'); ?>" id="highestQuali" name="highestQuali" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="prevStaffexp">Previous Staff Experience <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('prevStaffexp'); ?>" id="prevStaffexp" name="prevStaffexp" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="prevStaffOrgname">Previous Organization Name <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required value=" <?php echo set_value('prevStaffOrgname'); ?>" id="prevStaffOrgname" name="prevStaffOrgname" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="classAssigned">Class Assign <span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('classAssigned'); ?>" id="classAssigned" name="classAssigned" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="addressResidencial">Residential Address<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('addressResidencial'); ?>" id="addressResidencial" name="addressResidencial" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="designationDropdown">Designation <span class="re-mend-field">*</span></label>
                                    <select class="form-control required" name="designation" id="designation" required>
                                        <option value="">Select Designation</option>
                                        <option value="admin">Admin</option>
                                        <option value="teacher">Teacher</option>
                                        <option value="supporting staff">Supporting Staff</option>
                                        <option value="maid">Maid</option>
                                        <option value="guard">Guard</option>
                                        <option value="driver">Driver</option>
                                        <option value="marketing manager">Marketing Manager</option>
                                        <option value="counsellor">Counsellor</option>
                                        <option value="branch owner">Branch Owner</option>
                                    </select>
                                </div>
                            </div>


                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="addressPerma">Permanent Address<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('addressPerma'); ?>" id="addressPerma" name="addressPerma" maxlength="256">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="remark">Description <span class="re-mend-field">*</span></label>
                                    <textarea required class="form-control required" id="remark" name="remark"></textarea>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <label>Relation Type <span class="re-mend-field">*</span></label><br />
                                <label class="radio-inline">
                                    <input type="radio" name="relationType" value="father" onclick="toggleRelationFields(this.value)" checked> Father
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="relationType" value="spouse" onclick="toggleRelationFields(this.value)"> Spouse
                                </label>
                            </div>
                            <div class="col-md-6" id="fatherFields">
                                <div class="form-group">
                                    <label for="fathername">Father's Name <span class="re-mend-field">*</span></label>
                                    <input type="text" class="form-control" id="fathername" name="fathername" value="<?php echo set_value('fathername'); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="fatherContact">Father's Contact Number <span class="re-mend-field">*</span></label>
                                    <input type="text" class="form-control" id="fatherContact" name="fatherContact" value="<?php echo set_value('fatherContact'); ?>">
                                </div>
                            </div>

                            <div class="col-md-6" id="spouseFields" style="display: none;">
                                <div class="form-group">
                                    <label for="spouseName">Spouse Name <span class="re-mend-field">*</span></label>
                                    <input type="text" class="form-control" id="spouseName" name="spouseName" value="<?php echo set_value('spouseName'); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="spouseContact">Spouse Contact Number <span class="re-mend-field">*</span></label>
                                    <input type="text" class="form-control" id="spouseContact" name="spouseContact" value="<?php echo set_value('spouseContact'); ?>">
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="staffStatus">Staff Status <span class="re-mend-field">*</span></label>
                                    <select class="form-control required" name="staffStatus" id="staffStatus" onchange="toggleLastWorking(this.value)" required>
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">Inactive</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4" id="lastWorkingDiv" style="display:none;">
                                <div class="form-group">
                                    <label for="lastWorkingDay">Last Working Day</label>
                                    <input type="date" class="form-control" id="lastWorkingDay" name="lastWorkingDay" />
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="socialMediaLink">Social Media Link</label>
                                    <input type="url" class="form-control" id="socialMediaLink" name="socialMediaLink" />
                                </div>
                            </div>

                            <!-- Attachments -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Attachments <span class="re-mend-field">*</span></label><br>
                                    <label>PAN Card</label>
                                    <input type="file" name="file" class="form-control" /><br>
                                    <label>Aadhaar Card</label>
                                    <input type="file" name="file2" class="form-control" /><br>
                                    <label>UG Degree</label>
                                    <input type="file" name="file3" class="form-control" /><br>
                                    <label>PG Degree</label>
                                    <input type="file" name="file4" class="form-control" /><br>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" id="policeVerificationCheck" onclick="togglePoliceVerification()"> Police Verification Declaration
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-12" id="policeVerificationField" style="display: none;">
                                <div class="form-group">
                                    <label for="policeVerificationText">Declaration Statement</label>
                                    <textarea readonly class="form-control" name="policeVerificationText" id="policeVerificationText" rows="3">
I, the undersigned, confirm that the police verification for the mentioned staff has been completed and documented appropriately.
        </textarea>
                                </div>
                            </div>
                            <div class="col-md-12" id="bankDetails">
                                <h3>BANK DETAILS</h3>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">Bank Name<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('bankname'); ?>" id="bankname" name="bankname" maxlength="256" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">Account Number<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('accountnumber'); ?>" id="accountnumber" name="accountnumber" maxlength="256" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">IFSC Code<span class="re-mend-field">*</span></label>
                                    <input required type="text" class="form-control required" value="<?php echo set_value('ifsc'); ?>" id="ifsc" name="ifsc" maxlength="256" />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name">Cheque Attachment<span class="re-mend-field">*</span></label>
                                    <input type="file" name="file5" class="form-control" /><br>
                                </div>
                            </div>
                        </div>
                </div><!-- /.box-body -->

                <div class="box-footer">
                    <input type="submit" class="btn btn-primary" value="Submit" />
                    <input type="reset" class="btn btn-default" value="Reset" />
                </div>
                </form>
            </div>
        </div>
        <div class="col-md-4">
            <?php
            $this->load->helper('form');
            $error = $this->session->flashdata('error');
            if ($error) {
            ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
            <?php } ?>
            <?php
            $success = $this->session->flashdata('success');
            if ($success) {
            ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php } ?>

            <div class="row">
                <div class="col-md-12">
                    <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                </div>
            </div>
        </div>
</div>
</section>
<style type="text/css">
    .re-mend-field {
        color: red;
    }

    #bankDetails h3 {
        text-align: center;
        background: #e7e7e7;
        border-radius: 5px;
        margin-bottom: 20px;
        padding: 10px;
    }
</style>
</div>
<script type="text/javascript">
    function toggleLastWorking(status) {
        document.getElementById('lastWorkingDiv').style.display = (status === 'inactive') ? 'block' : 'none';
    }
</script>
<script>
    function toggleRelationFields(value) {
        if (value === 'father') {
            document.getElementById('fatherFields').style.display = 'block';
            document.getElementById('spouseFields').style.display = 'none';
        } else {
            document.getElementById('fatherFields').style.display = 'none';
            document.getElementById('spouseFields').style.display = 'block';
        }
    }
</script>
<script>
    function togglePoliceVerification() {
        var check = document.getElementById('policeVerificationCheck');
        var field = document.getElementById('policeVerificationField');
        field.style.display = check.checked ? 'block' : 'none';
    }
</script>

<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });

    // Updated fetchAssignedFranchise function to fetch Growth Manager's name
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue');

        // Set loading state
        assignedDiv.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Loading...';
        hiddenInput.value = '';

        if (!franchiseNumber) {
            assignedDiv.innerText = 'Select a franchise to assign';
            console.warn('No franchiseNumber provided');
            return;
        }

        console.log('Fetching Growth Manager for franchiseNumber:', franchiseNumber);

        $.ajax({
            url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                console.log('Server Response:', response);
                if (response.status === 'success' && response.html) {
                    assignedDiv.innerHTML = response.html; // Update with Growth Manager's name
                    hiddenInput.value = response.userIds || ''; // Update hidden input
                    console.log('Updated UI with:', response.html, 'and userIds:', response.userIds);
                } else {
                    assignedDiv.innerText = 'No Growth Manager assigned';
                    hiddenInput.value = '';
                    console.warn('No valid data in response:', response.message);
                    alert(response.message || 'No Growth Manager found for this franchise');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                console.error('Response Text:', xhr.responseText);
                assignedDiv.innerText = 'Error fetching Growth Manager';
                hiddenInput.value = '';
                alert('Failed to fetch Growth Manager data. Please try again.');
            }
        });
    }
    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        if (!franchiseInput) {
            console.error('Franchise input element not found');
            return;
        }

        // Handle dropdown (non-readonly, roles other than 25)
        if (franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            console.log('Initializing dropdown with value:', franchiseInput.value);
            fetchAssignedFranchise(franchiseInput.value);
        }

        // Handle readonly input (role 25)
        if (franchiseInput.readOnly && franchiseInput.value) {
            console.log('Initializing readonly input with value:', franchiseInput.value);
            fetchAssignedFranchise(franchiseInput.value);
        }
    });
</script>