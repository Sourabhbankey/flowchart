<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-eye"></i> Order #<?php echo $order['number']; ?> Details</h1>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-body">
                <div class="border p-3 mb-3">
                    <h4><strong>Order #<?php echo $order['number']; ?> Details</strong></h4>
                    <p>Payment via <?php echo $order['payment_method_title']; ?> .Paid On <?php echo $order['date_paid']; ?>  <?php echo $order['transaction_id']; ?>
                    Customer IP: <?php echo $order['customer_ip_address']; ?></p>
                </div>

                <div class="row">
                    <!-- General -->
                    <div class="col-md-4 border p-3">
                        <h4><strong>General</strong></h4>
                        <p><strong>Date:</strong> <?php echo date('Y-m-d', strtotime($order['date_created'])); ?></p>
                        <p><strong>Time:</strong> <?php echo date('H:i', strtotime($order['date_created'])); ?></p>
                        <p><strong>Status:</strong> <?php echo ucfirst($order['status']); ?></p>
                        <p><strong>Customer:</strong><br>
                            <?php echo $order['billing']['first_name'] . ' ' . $order['billing']['last_name']; ?><br>
                            (<?php echo $order['billing']['email']; ?>)
                        </p>
                    </div>

                    <!-- Billing -->
                    <div class="col-md-4 border p-3">
                        <h4><strong>Billing</strong></h4>
                        <p><?php echo $order['billing']['company']; ?></p>
                        <p><?php echo $order['billing']['first_name'] . ' ' . $order['billing']['last_name']; ?></p>
                        <p><?php echo $order['billing']['address_1']; ?><br>
                           <?php echo $order['billing']['city']; ?>,
                           <?php echo $order['billing']['state']; ?><br>
                           <?php echo $order['billing']['postcode']; ?></p>
                        <p>Email: <?php echo $order['billing']['email']; ?><br>
                           Phone: <?php echo $order['billing']['phone']; ?></p>
                        
                    </div>

                    <!-- Shipping -->
                    <div class="col-md-4 border p-3">
                        <h4><strong>Shipping</strong></h4>
                        <p><?php echo $order['shipping']['company']; ?></p>
                        <p><?php echo $order['shipping']['first_name'] . ' ' . $order['shipping']['last_name']; ?></p>
                        <p><?php echo $order['shipping']['address_1']; ?><br>
                           <?php echo $order['shipping']['city']; ?>,
                           <?php echo $order['shipping']['state']; ?><br>
                           <?php echo $order['shipping']['postcode']; ?></p>

                    </div>
                    <?php
$meta = [];
if (!empty($order['meta_data'])) {
    foreach ($order['meta_data'] as $item) {
        $meta[$item['key']] = $item['value'];
    }
}
?>
  <div class="col-md-12">
<p><strong>Payment Transaction ID (Meta):</strong> <?php echo isset($meta['_billing_payment_transaction_id']) ? $meta['_billing_payment_transaction_id'] : 'N/A'; ?></p>

<p><strong>Application Slip:</strong>
  <?php if (!empty($meta['_application'])): ?>
    <a href="<?php echo $meta['_application']; ?>" target="_blank">View Attachment</a>
  <?php else: ?>
    N/A
  <?php endif; ?>
</p>
</div>
                </div>
            </div>
        </div>
    </section>
    <section><div class="box mt-4">
    <div class="box-body">
        <h4><strong>Order Items</strong></h4>
        <div class="row font-weight-bold border-bottom pb-2 mb-2">
            <div class="col-md-6">Item</div>
            <div class="col-md-2">Cost</div>
            <div class="col-md-2">Qty</div>
            <div class="col-md-2">Total</div>
        </div>

        <?php foreach ($order['line_items'] as $item): ?>
            <div class="row border-bottom py-3 align-items-center">
                <!-- Item Column -->
                <div class="col-md-6">
                    <div class="media">
                        <img src="<?php echo $item['image']['src']; ?>" alt="" class="mr-3" width="64" height="64">
                        <div class="media-body">
                            <h5 class="mt-0 mb-1"><?php echo $item['name']; ?></h5>
                            <?php if (!empty($item['meta_data'])): ?>
                                <div class="border p-2 bg-light mt-2">
                                    <strong>Addon fields</strong>
                                    <table class="table table-sm mb-0 mt-1">
                                        <thead>
                                            <tr>
                                                <th>Options</th>
                                                <th>Values</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <?php if (!empty($item['meta_data'])): ?>
    <div class="border p-2 bg-light mt-2">
        <strong>Addon fields</strong>
        <table class="table table-sm mb-0 mt-1">
            <thead>
                <tr>
                    <th>Options</th>
                    <th>Values</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($item['meta_data'] as $meta): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($meta['key']); ?></td>
                        <td>
                            <?php
                            if (is_array($meta['value'])) {
                                echo implode(', ', $meta['value']);
                            } else {
                                echo htmlspecialchars($meta['value']);
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Cost -->
                <div class="col-md-2">
                    ₹ <?php echo number_format($item['price'], 2); ?>
                </div>

                <!-- Quantity -->
                <div class="col-md-2">
                    × <?php echo $item['quantity']; ?>
                </div>

                <!-- Total -->
                <div class="col-md-2">
                    ₹ <?php echo number_format($item['total'], 2); ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
</section>
</div>
