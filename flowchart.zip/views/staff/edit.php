<?php
$staffid = $staffInfo->staffid;
$name = $staffInfo->name;
$dateOfJoin = $staffInfo->dateOfJoin;
$birthday = $staffInfo->birthday;
$staffMobileno = $staffInfo->staffMobileno;
$staffWhatsappno = $staffInfo->staffWhatsappno;
$staffemail = $staffInfo->staffemail;
$fathername = $staffInfo->fathername;
$spouseName = $staffInfo->spouseName;
$emergencyMobileno = $staffInfo->emergencyMobileno;
$highestQuali = $staffInfo->highestQuali;
$designation = $staffInfo->designation;
$classAssigned = $staffInfo->classAssigned;
$addressResidencial = $staffInfo->addressResidencial;
$addressPerma = $staffInfo->addressPerma;
/*$fathername = $staffInfo->fathername;*/
$franchiseNumberArray = explode(",",$staffInfo->franchiseNumber);
$remark = $staffInfo->remark;
$dateOfreleieving = $staffInfo->dateOfreleieving;
$staffStatus = $staffInfo->staffStatus; 
$brspFranchiseAssigned = $staffInfo->brspFranchiseAssigned;

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Staff  Management
        <small>Add / Edit Staff </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Staff Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>staff/editStaff" method="post" id="editStaff" role="form">
                        <div class="box-body">
                        <div class="row">
                                <!--  -->
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="name">Name<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $name; ?>" id="name" name="name" maxlength="256" readonly />
                                        <input type="hidden" value="<?php echo $staffid; ?>" name="staffid" id="staffid" />
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                   <div class="form-group">
    <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>

    <!-- Disabled dropdown for display -->
    <select class="form-control required" id="franchiseNumber_display" name="franchiseNumber_display[]" data-live-search="true" disabled>
        <option value="0">Select Franchise</option>
        <?php
        if (!empty($branchDetail)) {
            foreach ($branchDetail as $bd) {
                $franchiseNumber = $bd->franchiseNumber;
                $selected = in_array($franchiseNumber, $franchiseNumberArray) ? 'selected=selected' : '';
                echo "<option value='{$franchiseNumber}' {$selected}>{$franchiseNumber}</option>";
            }
        }
        ?>
    </select>

    <!-- Hidden input(s) to actually submit data -->
    <?php
    if (!empty($franchiseNumberArray)) {
        foreach ($franchiseNumberArray as $franchiseVal) {
            echo '<input type="hidden" name="franchiseNumber[]" value="' . $franchiseVal . '">';
        }
    }
    ?>
</div>
 <input type="hidden" value="<?php echo $brspFranchiseAssigned; ?>" name="brspFranchiseAssigned" id="brspFranchiseAssigned" />

                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfJoin">Date Of Joining <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateOfJoin; ?>" id="dateOfJoin" name="dateOfJoin" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="birthday">Date Of Birth <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $birthday; ?>" id="birthday" name="birthday" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="staffMobileno">Staff Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $staffMobileno; ?>" id="staffMobileno" name="staffMobileno" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="staffWhatsappno">Staff WhatsApp No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $staffWhatsappno; ?>" id="staffWhatsappno" name="staffWhatsappno" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="staffemail">Staff E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo $staffemail; ?>" id="staffemail" name="staffemail" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fathername">Father's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $fathername; ?>" id="fathername" name="fathername" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="spouseName">Spouse Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $spouseName; ?>" id="spouseName" name="spouseName" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="emergencyMobileno">Staff E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $emergencyMobileno; ?>" id="emergencyMobileno" name="emergencyMobileno" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="highestQuali">Highest Qualification <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $highestQuali; ?>" id="highestQuali" name="highestQuali" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="designation">Designation <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $designation; ?>" id="designation" name="designation" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="classAssigned">Class Assigned<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $classAssigned; ?>" id="classAssigned" name="classAssigned" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="addressResidencial">Residential Address  <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $addressResidencial; ?>" id="addressResidencial" name="addressResidencial" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="addressPerma">Permanent Address  <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $addressPerma; ?>" id="addressPerma" name="addressPerma" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <!--  -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="remark">Remark <span class="re-mend-field">*</span></label>
                                        <textarea readonly class="form-control required" id="remark" name="remark"><?php echo $remark; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfreleieving">Date of Relieving <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateOfreleieving ?>" id="dateOfreleieving" name="dateOfreleieving" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <!-- Hidden Staff Status Field -->
                                        <input type="hidden" name="staffStatus" id="staffStatus" value="<?php echo $staffStatus; ?>">

                                    </div>
                                </div>

                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const relievingInput = document.getElementById("dateOfreleieving");
    const staffStatusInput = document.getElementById("staffStatus");

    relievingInput.addEventListener("change", function () {
        if (this.value) {
            staffStatusInput.value = "inactive";
        } else {
            staffStatusInput.value = "active";
        }
    });
});
</script>

