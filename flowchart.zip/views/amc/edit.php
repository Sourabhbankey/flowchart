<?php
$amcId = $amcInfo->amcId;
$franchiseName = $amcInfo->franchiseName;
$franchiseNumber = $amcInfo->franchiseNumber;
$branchcityName = $amcInfo->branchcityName;
$branchState = $amcInfo->branchState;
$amcAmount = $amcInfo->amcAmount;

$oldAMCdue = $amcInfo->oldAMCdue;
$totalAmc = $amcInfo->totalAmc;
$statusAmc = $amcInfo->statusAmc;
$branchFranchiseAssigned = $amcInfo->branchFranchiseAssigned;

//$brInstallationStatusAMC = $amcInfo->brInstallationStatusAMC;
$dueDateAmc = $amcInfo->dueDateAmc;
/*--New-Added---*/
$amcPaid1 = $amcInfo->amcPaid1;
$amcYear1 = $amcInfo->amcYear1;
$amcYear1dueAmount = $amcInfo->amcYear1dueAmount;
$amcYear1date = $amcInfo->amcYear1date;
$statusYear1Amc = $amcInfo->statusYear1Amc;
$amcYear1S3File = $amcInfo->amcYear1S3File;

$amcPaid2 = $amcInfo->amcPaid2;
$amcYear2 = $amcInfo->amcYear2;
$amcYear2dueAmount = $amcInfo->amcYear2dueAmount;
$amcYear2date = $amcInfo->amcYear2date;
$statusYear2Amc = $amcInfo->statusYear2Amc;
$amcYear2S3File = $amcInfo->amcYear2S3File;

$amcPaid3 = $amcInfo->amcPaid3;
$amcYear3 = $amcInfo->amcYear3;
$amcYear3dueAmount = $amcInfo->amcYear3dueAmount;
$amcYear3date = $amcInfo->amcYear3date;
$statusYear3Amc = $amcInfo->statusYear3Amc;
$amcYear3S3File = $amcInfo->amcYear3S3File;

$amcPaid4 = $amcInfo->amcPaid4;
$amcYear4 = $amcInfo->amcYear4;
$amcYear4dueAmount = $amcInfo->amcYear4dueAmount;
$amcYear4date = $amcInfo->amcYear4date;
$statusYear4Amc = $amcInfo->statusYear4Amc;
$amcYear4S3File = $amcInfo->amcYear4S3File;

$amcPaid5 = $amcInfo->amcPaid5;
$amcYear5 = $amcInfo->amcYear5;
$amcYear5dueAmount = $amcInfo->amcYear5dueAmount;
$amcYear5date = $amcInfo->amcYear5date;
$statusYear5Amc = $amcInfo->statusYear5Amc;
$amcYear5S3File = $amcInfo->amcYear5S3File;

$amcPaid6 = $amcInfo->amcPaid6;
$amcYear6 = $amcInfo->amcYear6;
$amcYear6dueAmount = $amcInfo->amcYear6dueAmount;
$amcYear6date = $amcInfo->amcYear6date;
$statusYear6Amc = $amcInfo->statusYear6Amc;
$amcYear6S3File = $amcInfo->amcYear6S3File;

$amcPaid7 = $amcInfo->amcPaid7;
$amcYear7 = $amcInfo->amcYear7;
$amcYear7dueAmount = $amcInfo->amcYear7dueAmount;
$amcYear7date = $amcInfo->amcYear7date;
$statusYear7Amc = $amcInfo->statusYear7Amc;
$amcYear7S3File = $amcInfo->amcYear7S3File;

$amcPaid8 = $amcInfo->amcPaid8;
$amcYear8 = $amcInfo->amcYear8;
$amcYear8dueAmount = $amcInfo->amcYear8dueAmount;
$amcYear8date = $amcInfo->amcYear8date;
$statusYear8Amc = $amcInfo->statusYear8Amc;
$amcYear8S3File = $amcInfo->amcYear8S3File;

$amcPaid9 = $amcInfo->amcPaid9;
$amcYear9 = $amcInfo->amcYear9;
$amcYear9dueAmount = $amcInfo->amcYear9dueAmount;
$amcYear9date = $amcInfo->amcYear9date;
$statusYear9Amc = $amcInfo->statusYear9Amc;
$amcYear9S3File = $amcInfo->amcYear9S3File;

$amcPaid10 = $amcInfo->amcPaid10;
$amcYear10 = $amcInfo->amcYear10;
$amcYear10dueAmount = $amcInfo->amcYear10dueAmount;
$amcYear10date = $amcInfo->amcYear10date;
$statusYear10Amc = $amcInfo->statusYear10Amc;
$amcYear10S3File = $amcInfo->amcYear10S3File;
/*$amcYears = [];

for ($i = 1; $i <= 10; $i++) {
    $amcYears[$i] = [
        'year' => $amcInfo->{'amcYear' . $i},
        'dueAmount' => $amcInfo->{'amcYear' . $i . 'dueAmount'},
        'date' => $amcInfo->{'amcYear' . $i . 'date'},
        'status' => $amcInfo->{'statusYear' . $i . 'Amc'},
        's3File' => $amcInfo->{'amcYear' . $i . 'S3File'}
    ];
}*/

$currentStatus = $amcInfo->currentStatus;

// New fields for penalty and other charges
$penaltyCharges = $amcInfo->penaltyCharges;
$penaltyAmount = $amcInfo->penaltyAmount;
$otherChargesTitle = $amcInfo->otherChargesTitle;
$otherChargesAmount = $amcInfo->otherChargesAmount;
$descAmc = $amcInfo->descAmc;
//print_r($currentStatus);exit;
//$selectUserId ='';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Amc Management
        <small>Add / Edit Amc</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Amc Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start --> 
                    <form role="form" action="<?php echo base_url() ?>amc/editAmc" method="post" id="editAmc" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                        <div class="row">
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise No.</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseNumber; ?>" id="franchiseNumber" name="franchiseNumber" maxlength="256"  readonly />
                                        <input type="hidden" value="<?php echo $amcId; ?>" name="amcId" id="amcId" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="franchiseName">Branch Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseName; ?>" id="franchiseName" name="franchiseName" maxlength="256" readonly />
                                        <input type="hidden" value="<?php echo $franchiseName; ?>" name="franchiseName" id="franchiseName"/>
                                    </div>  
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="branchLocation">Location</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchcityName; ?>" id="branchLocation" name="branchcityName" maxlength="256" readonly />                                 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="branchState">State</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchState; ?>" id="branchState" name="branchState" maxlength="256" readonly />
                                    </div>
                                </div>
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="oldAMCdue">Old AMC Due</label>
                                        <input type="text" class="form-control required" value="<?php //echo $oldAMCdue; ?>" id="oldAMCdue" name="oldAMCdue" maxlength="256" />
                                    </div>
                                </div> -->
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="curAmc">AMC (Including GST)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcAmount; ?>" id="curAmc" name="amcAmount" maxlength="256" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Total Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $totalAmc; ?>" id="totalAmc" name="totalAmc" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="statusAmc">Status Of AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusAmc" tabindex="-1" aria-hidden="true">

                                            <option value="Due" <?php if($statusAmc == 'Due') {echo "selected=selected";} ?> >Due</option>
                                            <option value="Paid" <?php if($statusAmc == 'Paid') {echo "selected=selected";} ?>>Paid</option>
                                            <option value="Partial Paid" <?php if($statusAmc == 'Partial Paid') {echo "selected=selected";} ?>>Partial Paid</option>      
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Current Status</label>
                                        <input type="text" class="form-control required" value="<?php echo $currentStatus; ?>" id="totalAmc" readonly name="currentStatus" maxlength="256" />
                                    </div>
                                </div>
                           
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="dueDateAmc">Due Date</label>
                                        <input type="date" class="form-control required" value="<?php echo $dueDateAmc; ?>" id="dueDateAmc" name="dueDateAmc" maxlength="256" /> 
                                    </div>
                                </div>
                                  <!-- New Fields for Penalty and Other Charges -->
                                <div id="amc-wrapper" class="row col-md-12">
                                    <!-- AMC Year blocks will be appended here -->
                                   <?php
                                        $displayedAmcYears = 0;
                                        for ($i = 1; $i <= 10; $i++) {
                                            $amcPaid = $amcInfo->{'amcPaid' . $i};
                                            $amcYear = $amcInfo->{'amcYear' . $i};
                                            $amcDue = $amcInfo->{'amcYear' . $i . 'dueAmount'};
                                            $amcDate = $amcInfo->{'amcYear' . $i . 'date'};
                                            $amcStatus = $amcInfo->{'statusYear' . $i . 'Amc'};
                                            $amcFile = $amcInfo->{'amcYear' . $i . 'S3File'};

                                            // Skip empty records
                                            if (
                                                (empty($amcPaid) || trim($amcPaid) === '') &&
                                                (empty($amcYear) || trim($amcYear) === '') &&
                                                (empty($amcDue) || trim($amcDue) === '') &&
                                                (empty($amcStatus) || trim($amcStatus) === '') &&
                                                (empty($amcFile) || trim($amcFile) === '') &&
                                                ($amcDate == '' || $amcDate == '0000-00-00' || $amcDate == null)
                                            ) {
                                                continue;
                                            }


                                            $displayedAmcYears++;
                                        ?>
                                    <!-- AMC Year block HTML here -->
                                            <div class="col-md-12"><h4>AMC Year <?= $i ?></h4></div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcPaid<?= $i ?>">AMC Paid (<?= $i ?>)</label>
                                                    <input type="text" class="form-control" id="amcPaid<?= $i ?>" name="amcPaid<?= $i ?>" value="<?= $amcPaid ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcYear<?= $i ?>">AMC (Year <?= $i ?>)</label>
                                                    <input type="text" class="form-control" id="amcYear<?= $i ?>" name="amcYear<?= $i ?>" value="<?= $amcYear ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcYear<?= $i ?>dueAmount">AMC Year <?= $i ?> Due Amount</label>
                                                    <input type="text" class="form-control" id="amcYear<?= $i ?>dueAmount" name="amcYear<?= $i ?>dueAmount" value="<?= $amcDue ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcYear<?= $i ?>date">AMC Year-<?= $i ?> Date</label>
                                                    <input type="date" class="form-control" id="amcYear<?= $i ?>date" name="amcYear<?= $i ?>date" value="<?= $amcDate ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="statusYear<?= $i ?>Amc">Status Of Year-<?= $i ?> AMC</label>
                                                    <select class="form-control" id="statusYear<?= $i ?>Amc" name="statusYear<?= $i ?>Amc">
                                                        <option value="">Select</option>
                                                        <option value="Due" <?= ($amcStatus == 'Due') ? 'selected' : '' ?>>Due</option>
                                                        <option value="Paid" <?= ($amcStatus == 'Paid') ? 'selected' : '' ?>>Paid</option>
                                                        <option value="Partial Paid" <?= ($amcStatus == 'Partial Paid') ? 'selected' : '' ?>>Partial Paid</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="file<?= $i ?>">Upload File AMC Year-<?= $i ?></label>
                                                    <input type="file" class="form-control" id="file<?= $i ?>" name="file<?= $i ?>" multiple>
                                                    <?php if (!empty($amcFile)): ?>
                                                        <a href="<?= $amcFile ?>" target="_blank">View Uploaded File</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <hr class="col-md-12">
                                        <?php } ?>
                                            <hr class="col-md-12">
                                </div>
                                <div class="col-md-12" style="text-align: right;">
                                  <button type="button" class="btn btn-primary" id="add-amc">Add New AMC Year</button>
                                </div>
                                <!-- End- New-Field - Added -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="descAmc">Description</label>
                                        <textarea class="form-control required" id="descAmc" name="descAmc"><?php echo $descAmc; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('descAmc', {
            filebrowserUploadUrl: "<?= base_url('amc/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
<script>
  /*let amcYearCount = 0;
  const maxAmcYears = 10;
  let amcYearCount = <?= $displayedAmcYears ?>;*/

  let amcYearCount = <?= $displayedAmcYears ?>;
  const maxAmcYears = 10;


  document.getElementById('add-amc').addEventListener('click', function () {
    if (amcYearCount >= maxAmcYears) {
      alert("Maximum 10 AMC Years allowed.");
      return;
    }

    amcYearCount++;

    const wrapper = document.getElementById('amc-wrapper');

    const html = `
      <div class="col-md-12"><h4>AMC Year ${amcYearCount}</h4></div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="amcPaid${amcYearCount}">AMC Paid (${amcYearCount})</label>
          <input type="text" class="form-control" id="amcPaid${amcYearCount}" name="amcPaid${amcYearCount}">
        </div>
      </div>
      <div class="col-md-4">
        <div class="form-group">
          <label for="amcYear${amcYearCount}">AMC (Year ${amcYearCount})</label>
          <input type="text" class="form-control" id="amcYear${amcYearCount}" name="amcYear${amcYearCount}">
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="amcYear${amcYearCount}dueAmount">AMC Year ${amcYearCount} Due Amount</label>
          <input type="text" class="form-control" id="amcYear${amcYearCount}dueAmount" name="amcYear${amcYearCount}dueAmount">
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="amcYear${amcYearCount}date">AMC Year-${amcYearCount} Date</label>
          <input type="date" class="form-control" id="amcYear${amcYearCount}date" name="amcYear${amcYearCount}date">
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="statusYear${amcYearCount}Amc">Status Of Year-${amcYearCount} AMC</label>
          <select class="form-control" id="statusYear${amcYearCount}Amc" name="statusYear${amcYearCount}Amc">
            <option value="">Select</option>
            <option value="Due">Due</option>
            <option value="Paid">Paid</option>
            <option value="Partial Paid">Partial Paid</option>
          </select>
        </div>
      </div>

      <div class="col-md-4">
        <div class="form-group">
          <label for="file${amcYearCount}">Upload File AMC Year-${amcYearCount}</label>
          <input type="file" class="form-control" id="file${amcYearCount}" name="file${amcYearCount}" multiple>
        </div>
      </div>

      <hr class="col-md-12">
    `;

    wrapper.insertAdjacentHTML('beforeend', html);
  });
</script>    