<?php
$amcId = $amcInfo->amcId;
/*$franchiseName = $amcInfo->franchiseName;*/
$franchiseName = $amcInfo->franchiseName;
$franchiseNumber = $amcInfo->franchiseNumber;
$branchcityName = $amcInfo->branchcityName;
$branchState = $amcInfo->branchState;
$amcAmount = $amcInfo->amcAmount;
$oldAMCdue = $amcInfo->oldAMCdue;
$totalAmc = $amcInfo->totalAmc;
$statusAmc = $amcInfo->statusAmc;
$branchFranchiseAssigned = $amcInfo->branchFranchiseAssigned;
$currentStatus = $amcInfo->currentStatus;
$dueDateAmc = $amcInfo->dueDateAmc;
/*--New-Added---*/
$amcPaid1 = $amcInfo->amcPaid1;
$amcYear1 = $amcInfo->amcYear1;
$amcYear1dueAmount = $amcInfo->amcYear1dueAmount;
$amcYear1date = $amcInfo->amcYear1date;
$statusYear1Amc = $amcInfo->statusYear1Amc;
$amcYear1S3File = $amcInfo->amcYear1S3File;

$amcPaid2 = $amcInfo->amcPaid2;
$amcYear2 = $amcInfo->amcYear2;
$amcYear2dueAmount = $amcInfo->amcYear2dueAmount;
$amcYear2date = $amcInfo->amcYear2date;
$statusYear2Amc = $amcInfo->statusYear2Amc;
$amcYear2S3File = $amcInfo->amcYear2S3File;

$amcPaid3 = $amcInfo->amcPaid3;
$amcYear3 = $amcInfo->amcYear3;
$amcYear3dueAmount = $amcInfo->amcYear3dueAmount;
$amcYear3date = $amcInfo->amcYear3date;
$statusYear3Amc = $amcInfo->statusYear3Amc;
$amcYear3S3File = $amcInfo->amcYear3S3File;

$amcPaid4 = $amcInfo->amcPaid4;
$amcYear4 = $amcInfo->amcYear4;
$amcYear4dueAmount = $amcInfo->amcYear4dueAmount;
$amcYear4date = $amcInfo->amcYear4date;
$statusYear4Amc = $amcInfo->statusYear4Amc;
$amcYear4S3File = $amcInfo->amcYear4S3File;

$amcPaid5 = $amcInfo->amcPaid5;
$amcYear5 = $amcInfo->amcYear5;
$amcYear5dueAmount = $amcInfo->amcYear5dueAmount;
$amcYear5date = $amcInfo->amcYear5date;
$statusYear5Amc = $amcInfo->statusYear5Amc;
$amcYear5S3File = $amcInfo->amcYear5S3File;

$amcPaid6 = $amcInfo->amcPaid6;
$amcYear6 = $amcInfo->amcYear6;
$amcYear6dueAmount = $amcInfo->amcYear6dueAmount;
$amcYear6date = $amcInfo->amcYear6date;
$statusYear6Amc = $amcInfo->statusYear6Amc;
$amcYear6S3File = $amcInfo->amcYear6S3File;

$amcPaid7 = $amcInfo->amcPaid7;
$amcYear7 = $amcInfo->amcYear7;
$amcYear7dueAmount = $amcInfo->amcYear7dueAmount;
$amcYear7date = $amcInfo->amcYear7date;
$statusYear7Amc = $amcInfo->statusYear7Amc;
$amcYear7S3File = $amcInfo->amcYear7S3File;

$amcPaid8 = $amcInfo->amcPaid8;
$amcYear8 = $amcInfo->amcYear8;
$amcYear8dueAmount = $amcInfo->amcYear8dueAmount;
$amcYear8date = $amcInfo->amcYear8date;
$statusYear8Amc = $amcInfo->statusYear8Amc;
$amcYear8S3File = $amcInfo->amcYear8S3File;

$amcPaid9 = $amcInfo->amcPaid9;
$amcYear9 = $amcInfo->amcYear9;
$amcYear9dueAmount = $amcInfo->amcYear9dueAmount;
$amcYear9date = $amcInfo->amcYear9date;
$statusYear9Amc = $amcInfo->statusYear9Amc;
$amcYear9S3File = $amcInfo->amcYear9S3File;

$amcPaid10 = $amcInfo->amcPaid10;
$amcYear10 = $amcInfo->amcYear10;
$amcYear10dueAmount = $amcInfo->amcYear10dueAmount;
$amcYear10date = $amcInfo->amcYear10date;
$statusYear10Amc = $amcInfo->statusYear10Amc;
$amcYear10S3File = $amcInfo->amcYear10S3File;
$descAmc = $amcInfo->descAmc;
//$selectUserId ='';
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> View Amc Management
        <!-- <small>View Amc</small> -->
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                <div class="box box-primary">
                    <!-- /.box-header -->
                    <!-- form start --> 
                    <form role="form" action="<?php echo base_url() ?>amc/viewAmc" method="post" id="viewAmc" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise No.</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseNumber; ?>" id="franchiseNumber" name="franchiseNumber" maxlength="256" />
                                        <input type="hidden" value="<?php echo $amcId; ?>" name="amcId" id="amcId" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="franchiseName">Branch Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseName; ?>" id="franchiseName" name="franchiseName" maxlength="256" />
                                        <input type="hidden" value="<?php echo $franchiseName; ?>" name="franchiseName" id="franchiseName" />
                                    </div>  
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="branchLocation">Location</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchcityName; ?>" id="branchLocation" name="branchcityName" maxlength="256" />                                 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="branchState">State</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchState; ?>" id="branchState" name="branchState" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="curAmc">AMC (Including GST)</label>
                                        <input type="text" class="form-control required" value="<?php echo $amcAmount; ?>" id="curAmc" name="amcAmount" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Total Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo $totalAmc; ?>" id="totalAmc" name="totalAmc" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="statusAmc">Status Of AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusAmc" tabindex="-1" aria-hidden="true">
                                        
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($statusAmc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusAmc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Support Manager</label>
                                        <select class="form-control check required" id="brspFranchiseAssigned" name="branchFranchiseAssigned">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $drl)
                                                {
                                                    $userText = $drl->name;
                                                    ?>
                                                    <option value="<?php echo $drl->userId ?>" <?php if($drl->userId == set_value('branchFranchiseAssigned', $brspFranchiseAssigned)) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>      
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group">
                                        <label for="totalAmc">Current Status</label>
                                        <input type="text" class="form-control required" value="<?php echo $currentStatus; ?>" id="totalAmc" name="currentStatus" maxlength="256" readonly />
                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="dueDateAmc">Due Date</label>
                                        <input type="text" class="form-control required" value="<?php echo $dueDateAmc; ?>" id="dueDateAmc" name="dueDateAmc" maxlength="256" /> 
                                    </div>
                                </div>
                                <!-- New-Field - Added -->
                                <div id="amc-wrapper" class="row col-md-12">
                                    <!-- AMC Year blocks will be appended here -->
                                   <?php
                                        $displayedAmcYears = 0;
                                        for ($i = 1; $i <= 10; $i++) {
                                            $amcPaid = $amcInfo->{'amcPaid' . $i};
                                            $amcYear = $amcInfo->{'amcYear' . $i};
                                            $amcDue = $amcInfo->{'amcYear' . $i . 'dueAmount'};
                                            $amcDate = $amcInfo->{'amcYear' . $i . 'date'};
                                            $amcStatus = $amcInfo->{'statusYear' . $i . 'Amc'};
                                            $amcFile = $amcInfo->{'amcYear' . $i . 'S3File'};

                                            // Skip empty records
                                            if (
                                                (empty($amcPaid) || trim($amcPaid) === '') &&
                                                (empty($amcYear) || trim($amcYear) === '') &&
                                                (empty($amcDue) || trim($amcDue) === '') &&
                                                (empty($amcStatus) || trim($amcStatus) === '') &&
                                                (empty($amcFile) || trim($amcFile) === '') &&
                                                ($amcDate == '' || $amcDate == '0000-00-00' || $amcDate == null)
                                            ) {
                                                continue;
                                            }


                                            $displayedAmcYears++;
                                        ?>
                                    <!-- AMC Year block HTML here -->
                                            <div class="col-md-12"><h4>AMC Year <?= $i ?></h4></div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcPaid<?= $i ?>">AMC Paid (<?= $i ?>)</label>
                                                    <input type="text" class="form-control" id="amcPaid<?= $i ?>" name="amcPaid<?= $i ?>" value="<?= $amcPaid ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcYear<?= $i ?>">AMC (Year <?= $i ?>)</label>
                                                    <input type="text" class="form-control" id="amcYear<?= $i ?>" name="amcYear<?= $i ?>" value="<?= $amcYear ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcYear<?= $i ?>dueAmount">AMC Year <?= $i ?> Due Amount</label>
                                                    <input type="text" class="form-control" id="amcYear<?= $i ?>dueAmount" name="amcYear<?= $i ?>dueAmount" value="<?= $amcDue ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="amcYear<?= $i ?>date">AMC Year-<?= $i ?> Date</label>
                                                    <input type="date" class="form-control" id="amcYear<?= $i ?>date" name="amcYear<?= $i ?>date" value="<?= $amcDate ?>">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="statusYear<?= $i ?>Amc">Status Of Year-<?= $i ?> AMC</label>
                                                    <select class="form-control" id="statusYear<?= $i ?>Amc" name="statusYear<?= $i ?>Amc">
                                                        <option value="">Select</option>
                                                        <option value="Due" <?= ($amcStatus == 'Due') ? 'selected' : '' ?>>Due</option>
                                                        <option value="Paid" <?= ($amcStatus == 'Paid') ? 'selected' : '' ?>>Paid</option>
                                                        <option value="Partial Paid" <?= ($amcStatus == 'Partial Paid') ? 'selected' : '' ?>>Partial Paid</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="file<?= $i ?>">Upload File AMC Year-<?= $i ?></label><br>
                                                    <?php if (!empty($amcFile)): ?>
                                                        <a href="<?= $amcFile ?>" target="_blank">
                                                            <img src="<?= $amcFile ?>" alt="AMC File" style="width:50px; height:50px; object-fit:cover;">
                                                        </a>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                            <hr class="col-md-12">
                                        <?php } ?>
                                <!-- End- New-Field - Added -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="descAmc">Description</label>
                                        <textarea class="form-control required" id="descAmc" name="descAmc" readonly><?php echo $descAmc; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                       
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('descAmc', {
            filebrowserUploadUrl: "<?= base_url('amc/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
    <script type="text/javascript">
        /*Read-oly*/
    $.each($('form').serializeArray(), function(index, value){
      $('[name="' + value.name + '"]').attr('readonly', 'readonly');
    }); 
    $("form :select").attr("disabled", true);
    /*End-Read-only*/
    </script>