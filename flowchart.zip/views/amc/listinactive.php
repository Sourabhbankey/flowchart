<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> AMC Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <?php  if($is_admin == 1) { ?>
        <div class="row">
            <div class="col-xs-12 text-right">
             <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>amc/add"><i class="fa fa-plus"></i> Add New AMC</a>
                </div> 
            </div>
        </div>
    <?php } ?>
     <?php  if($is_admin == 1 || $role==16 || $role==15) { ?>
	 <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
            	<form method="GET" action="<?= base_url('amc/amcInactiveListing'); ?>">
                    <label for="franchiseNumber">Franchise No. <span class="re-mend-field"></span></label>
                    <select class="form-control1 required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" >
                        <option value="">Select Franchise</option>
                        <?php
                        if (!empty($branchDetail)) {
                            foreach ($branchDetail as $bd) {
                                $selected = ($bd->franchiseNumber == $franchiseFilter) ? 'selected' : '';
                                ?>
                                <option value="<?= $bd->franchiseNumber; ?>" <?= $selected; ?>><?= $bd->franchiseNumber; ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                    <div class="form-group">
                    <label for="amcStatus">AMC Status</label>
<select class="form-control1" id="statusAmc" name="statusAmc">
    <option value="">All</option>
    <option value="1" <?= ($statusAmc == '1') ? 'selected' : '' ?>>Paid</option>
    <option value="2" <?= ($statusAmc == '2') ? 'selected' : '' ?>>Due</option>
</select>
</div>
                    <button type="submit" class="btn btn-primary customreset-fil">Filter</button>
		
                    <a href="<?= base_url('amc/amcInactiveListing?resetFilter=1'); ?>" class="btn btn-danger btn-secondary">Reset</a>
                </form>
            </div>
        </div>
    </div>   
    <?php } ?>  
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">AMC List</h3>
                    <div class="box-tools">
                        <!--<form action="<?php //echo base_url() ?>task/taskListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>-->
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                    <table id="example" class="display responsive nowrap" style="width:100%">
                    <thead>
                    <tr>
                        <?php if($role != 25) { ?>
    <th>Franchise No.</th>
    <th>Branch Name</th>
    <th>Location</th>
    <th>State</th>
    <th>Total Amc (Including GST)</th>
    <th>Due Date</th>
    <th>Growth manager</th>
    <th>Current Status</th>
<?php } ?>
                        <th>Old AMC Due</th>
                         <!-- <th>AMC</th> -->
                       
                           
                        <th>Status Of AMC</th>
                        
                       
                        <th>AMC Year 1</th>
                        <th>AMC Year 1 Due Amount</th>
                        <th>AMC Year-1 Date</th>
                        <th>Status Of Year-1 AMC</th>
                        <th>AMC Year 2</th>
                        <th>AMC Year 2 Due Amount</th>
                        <th>AMC Year-2 Date</th>
                        <th>Status Of Year-2 AMC</th>
                        <th>AMC Year 3</th>
                        <th>AMC Year 3 Due Amount</th>
                        <th>AMC Year-3 Date</th>
                        <th>Status Of Year-3 AMC</th>
                        <th>AMC Year 4</th>
                        <th>AMC Year 4 Due Amount</th>
                        <th>AMC Year-4 Date</th>
                        <th>Status Of Year-4 AMC</th>
                        <th>AMC Year 5</th>
                        <th>AMC Year 5 Due Amount</th>
                        <th>AMC Year-5 Date</th>
                        <th>Status Of Year-5 AMC</th>
                        <th>Description</th>
                        <th>Created On</th>
                        <th>Updated On</th>
                       
                            <th class="text-center">Actions</th>
                       
                    </tr>
                    </thead>
                <tbody>
                    <?php
                    if(!empty($records))
                    {
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                        <?php if($role != 25) { ?>
    <td><?php echo $record->franchiseNumber ?></td>
    <td><?php echo $record->franchiseName ?></td>
    <td><?php echo $record->branchcityName ?></td>
    <td><?php echo $record->branchState ?></td>
    <td><?php echo $record->totalAmc ?></td>
    <td><?php echo date("d F Y", strtotime($record->dueDateAmc)) ?></td>
   <td><?php echo !empty($record->franchise_name) ? $record->franchise_name : ''; ?></td>
    <td><?php echo $record->currentStatus ?></td>
<?php } ?>
                       <td><?php echo $record->oldAMCdue ?></td>
                        <!--  <td><?php echo $record->amcAmount ?></td> -->
                        
                        
                        <td>
                            <?php 
                            if($record->statusAmc == ACTIVE) {
                                ?> <span class="label label-success">Paid</span> <?php
                            } 
                            else {
                                ?> <span class="label label-warning">Due</span> <?php
                            }
                            ?>
                        </td>
                       
                        <td><?php echo $record->amcYear1 ?></td>
                        <td><?php echo $record->amcYear1dueAmount ?></td>
                        <td><?php echo date("d F Y", strtotime($record->amcYear1date)) ?></td>
                        <td>
                            <?php 
                            if($record->statusYear1Amc == ACTIVE) {
                                ?> <span class="label label-success">Paid</span> <?php
                            } 
                            else {
                                ?> <span class="label label-warning">Due</span> <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $record->amcYear2 ?></td>
                        <td><?php echo $record->amcYear2dueAmount ?></td>
                        <td><?php echo date("d F Y", strtotime($record->amcYear2date)) ?></td>
                        <td>
                            <?php 
                            if($record->statusYear2Amc == ACTIVE) {
                                ?> <span class="label label-success">Paid</span> <?php
                            } 
                            else {
                                ?> <span class="label label-warning">Due</span> <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $record->amcYear3 ?></td>
                        <td><?php echo $record->amcYear3dueAmount ?></td>
                        <td><?php echo date("d F Y", strtotime($record->amcYear3date)) ?></td>
                        <td>
                            <?php 
                            if($record->statusYear3Amc == ACTIVE) {
                                ?> <span class="label label-success">Paid</span> <?php
                            } 
                            else {
                                ?> <span class="label label-warning">Due</span> <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $record->amcYear4 ?></td>
                        <td><?php echo $record->amcYear4dueAmount ?></td>
                        <td><?php echo date("d F Y", strtotime($record->amcYear4date)) ?></td>
                        <td>
                            <?php 
                            if($record->statusYear4Amc == ACTIVE) {
                                ?> <span class="label label-success">Paid</span> <?php
                            } 
                            else {
                                ?> <span class="label label-warning">Due</span> <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $record->amcYear5 ?></td>
                        <td><?php echo $record->amcYear5dueAmount ?></td>
                        <td><?php echo date("d F Y", strtotime($record->amcYear5date)) ?></td>
                        <td>
                            <?php 
                            if($record->statusYear5Amc == ACTIVE) {
                                ?> <span class="label label-success">Paid</span> <?php
                            } 
                            else {
                                ?> <span class="label label-warning">Due</span> <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $record->descAmc ?></td>
                        <td><?php echo date("d F Y", strtotime($record->createdDtm)) ?></td>
                        <td><?php //echo date("d-m-Y", strtotime($record->updatedDtm)) ?></td>
                        <?php  if($is_admin == 1 || $role==16) { ?>
                        <td class="text-center">
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'amc/edit/'.$record->amcId; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                            <a class="btn btn-sm btn-danger deletedespatch" href="#" data-despatchid="<?php echo $record->amcId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'amc/view/'.$record->amcId; ?>" title="View"><i class="fa fa-eye"></i></a>
                        </td>
                        <?php }else{ ?>
                         <td class="text-center">
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'amc/view/'.$record->amcId; ?>" title="View"><i class="fa fa-eye"></i></a>
                            
                        </td>
                    <?php } ?>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                     </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
               <!-- <div class="box-footer clearfix">-->
                    <div class="br-pagi">
                    <p>Showing <?= $start ?> to <?= $end ?> of <?= $total_records ?> records</p>
                    <p><?php echo $links; ?></p>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "amc/amcListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
$(document).ready(function() {
        $("#example_paginate").hide();
        $("#example_info").hide();
    });    
</script>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
