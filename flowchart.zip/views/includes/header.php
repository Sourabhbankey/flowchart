<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>eduMETA - FlowChart<?php //echo $pageTitle; 
                            ?></title>
  <meta name="referrer" content="no-referrer">
  <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
  <!-- Bootstrap 3.3.4 -->
  <link href="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <!-- FontAwesome 4.3.0 -->
  <link href="<?php echo base_url(); ?>assets/bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <!-- Ionicons 2.0.0 -->
  <link href="<?php echo base_url(); ?>assets/bower_components/Ionicons/css/ionicons.min.css" rel="stylesheet" type="text/css" />
  <!-- Theme style -->
  <link href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
  <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
  <link href="<?php echo base_url(); ?>assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>assets/dist/css/bootstrap-select.css" rel="stylesheet" type="text/css" />
  <!-- Custm CSS -->
  <link href="<?php echo base_url(); ?>assets/dist/css/custom-css.css" rel="stylesheet" type="text/css" />
  <style>
    .error {
      color: red;
      font-weight: normal;
    }

    .skin-blue .wrapper,
    .skin-blue .main-sidebar,
    .skin-blue .left-side {
      background-color: #367fa9;
    }

    .skin-blue .sidebar a {
      color: #fff;
    }

    .skin-blue .sidebar-menu>li.header {
      color: #fff;
      background: #357DA7;
    }
  </style>
  <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
  <script type="text/javascript">
    var baseURL = "<?php echo base_url(); ?>";
  </script>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">

    <header class="main-header">
      <!-- Logo -->
      <a href="<?php echo base_url(); ?>dashboard" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>edu</b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>eduMETA</b></span>
      </a>
      <!-- Header Navbar: style can be found in header.less -->
      <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <li class="dropdown tasks-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                <i class="fa fa-history"></i>
              </a>
              <ul class="dropdown-menu">
                <!--  <li class="header"> Last Login : <i class="fa fa-clock-o"></i> <?= empty($last_login) ? "First Time Login" : $last_login; ?></li> -->
                <li class="header"> Last Login : <i class="fa fa-clock-o"></i>
                  <?php
                  if (empty($last_login)) {
                    echo "First Time Login";
                  } else {
                    // Check the raw value of $last_login
                    // echo "<!-- Raw Last Login: $last_login -->"; // Debugging line (can be removed later)

                    // If $last_login is in UTC, create a DateTime object with UTC time zone
                    try {
                      // Assuming the $last_login time is in UTC
                      $date = new DateTime($last_login, new DateTimeZone('UTC'));

                      // Now convert to Asia/Kolkata timezone
                      $date->setTimezone(new DateTimeZone('Asia/Kolkata'));

                      // Output the formatted date and time
                      echo $date->format('Y-m-d h:i:A');
                    } catch (Exception $e) {
                      // Handle any errors in DateTime creation
                      echo "Error: " . $e->getMessage();
                    }
                  }
                  // Display both UTC and converted times for debugging
                  echo "UTC Time: " . (new DateTime($last_login, new DateTimeZone('Asia/Kolkata')))->format('Y-m-d h:i:A') . "<br>";
                  //echo "Converted Time: " . $date->format('Y-m-d H:i:s') . "<br>";

                  echo "Last Login (Raw): " . $last_login . "<br>";

                  // Check the original time zone offset for debugging
                  $dt = new DateTime($last_login);
                  echo "Original Time Zone: " . $dt->getTimezone()->getName() . "<br>";

                  ?>

                </li>
                <li class="header"> Last Login : <i class="fa fa-clock-o"></i>
                  <?php
                  if (empty($last_login)) {
                    echo "First Time Login";
                  } else {
                    try {
                      // Assuming $last_login is stored in UTC
                      $date = new DateTime($last_login, new DateTimeZone('UTC'));

                      // Convert to Asia/Kolkata timezone (or your desired timezone)
                      $date->setTimezone(new DateTimeZone('Asia/Kolkata'));

                      // Output formatted date and time
                      echo $date->format('Y-m-d h:i A');
                    } catch (Exception $e) {
                      echo "Error: " . $e->getMessage();
                    }
                  }
                  ?>
                </li>
              </ul>
            </li>
            <li class="user-header">
              <div class="notification-wrapper">
                <button id="notification-bell">
                  <i class="fa fa-bell"></i>
                  <span id="notification-count" class="badge">0</span>
                </button>

                <div id="notification-dropdown" class="dropdown-menu" style="width: 300px;">
                  <!--  <span class="caret cfehs94"></span> -->

                  <ul id="notification-list">
                    <!-- Notifications will come here -->
                  </ul>

                  <div id="view-all-wrapper" style="display: none; text-align: center; padding: 10px;">
                    <a href="<?= base_url('Notification/all_notifications') ?>" class="btn btn-primary btn-sm">View All</a>
                  </div>
                </div>
              </div>
            </li>

            <script>
              document.addEventListener("DOMContentLoaded", function() {
                const notifications = [{
                    message: "Notification 1"
                  }, {
                    message: "Notification 2"
                  },
                  {
                    message: "Notification 3"
                  }, {
                    message: "Notification 4"
                  },
                  {
                    message: "Notification 5"
                  }, {
                    message: "Notification 6"
                  },
                  {
                    message: "Notification 7"
                  }, {
                    message: "Notification 8"
                  },
                  {
                    message: "Notification 9"
                  }, {
                    message: "Notification 10"
                  },
                  {
                    message: "Notification 11"
                  }, {
                    message: "Notification 12"
                  }
                ];
                const listEl = document.getElementById('notification-list');
                const viewAllWrap = document.getElementById('view-all-wrapper');
                const viewAllLink = document.getElementById('view-all-link');
                const MAX_DISPLAY = 10;

                function render(count) {
                  // clear any previous items
                  listEl.innerHTML = '';
                  // add exactly `count` items (capped by notifications.length)
                  notifications.slice(0, count).forEach(n => {
                    const li = document.createElement('li');
                    li.textContent = n.message;
                    listEl.appendChild(li);
                  });
                }

                // show first 10 on load
                render(MAX_DISPLAY);

                // only show the “View All” link if there really are more than 10
                if (notifications.length > MAX_DISPLAY) {
                  viewAllWrap.style.display = 'block';
                }

                // clicking “View All” will expand to show everything
                viewAllLink.addEventListener('click', function(e) {
                  e.preventDefault();
                  render(notifications.length);
                  viewAllWrap.style.display = 'none';
                });
              });
            </script>

            <!-- User Account: style can be found in dropdown.less -->
            <li class="dropdown user user-menu">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <?php
                $userId = $this->session->userdata('userId');

                $query = $this->db->query('SELECT * FROM tbl_users WHERE userId = ?', array($userId));
                $user = $query->row();

                $profileImg = $user->upattachmentS3File;
                ?>
                <img src="<?php echo base_url($profileImg ?? ''); ?>" class="user-image" alt="User Image" />
                <span class="hidden-xs"><?php echo $name; ?></span>
              </a>
              <ul class="dropdown-menu">
                <!-- User image -->
                <li class="user-header">

                  <img src="<?php echo base_url($profileImg ?? ''); ?>" class="user-image" alt="User Image" />
                  <p>
                    <?php echo $name; ?>
                    <small><?php echo $role_text; ?></small>
                  </p>

                </li>

                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

                <script>
                  $(document).ready(function() {
                    function fetchNotifications() {
                      $.ajax({
                        url: "<?= base_url('notification/fetch_notifications'); ?>",
                        type: "GET",
                        dataType: "json",
                        success: function(data) {
                          $("#notification-count").text(data.length);
                          let list = "";

                          if (data.length > 0) {
                            data.forEach(notif => {
                              let targetUrl = "#";

                              if (notif.taskId && notif.taskId > 0) {
                                targetUrl = `<?= base_url('task/reply/'); ?>${notif.taskId}`;
                              } else if (notif.supportMeetingId && notif.supportMeetingId > 0) {
                                targetUrl = `<?= base_url('/support/edit/'); ?>${notif.supportMeetingId}`;
                              } else if (notif.branchesId && notif.branchesId > 0) {
                                targetUrl = `<?= base_url('branches/view/'); ?>${notif.branchesId}`;
                              } else if (notif.announcementId && notif.announcementId > 0) {
                                targetUrl = `<?= base_url('announcement/view/'); ?>${notif.announcementId}`;
                              } else if (notif.blogId && notif.blogId > 0) {
                                targetUrl = `<?= base_url('blog/blogListing/'); ?>`;
                              } else if (notif.pdcId && notif.pdcId > 0) {
                                targetUrl = `<?= base_url('pdc/pdcListing/'); ?>`;
                              } else if (notif.customDesignId && notif.customDesignId > 0) {
                                targetUrl = `<?= base_url('customdesign/edit/'); ?>${notif.customDesignId}`;
                              } else if (notif.despatchId && notif.despatchId > 0) {
                                targetUrl = `<?= base_url('despatch/view/'); ?>${notif.despatchId}`;
                              } else if (notif.acattachmentId && notif.acattachmentId > 0) {
                                targetUrl = `<?= base_url('acattachment/edit/'); ?>${notif.acattachmentId}`;
                              } else if (notif.lgattachmentId && notif.lgattachmentId > 0) {
                                targetUrl = `<?= base_url('lgattachment/edit/'); ?>${notif.lgattachmentId}`;
                              } else if (notif.leaveId && notif.leaveId > 0) {
                                targetUrl = `<?= base_url('leave/view/'); ?>${notif.leaveId}`;
                              } else if (notif.faqId && notif.faqId > 0) {
                                targetUrl = `<?= base_url('faq/view/'); ?>${notif.faqId}`;
                              } else if (notif.brsetupid && notif.brsetupid > 0) {
                                targetUrl = `<?= base_url('branchinstallation/edit/'); ?>${notif.brsetupid}`;
                              } else if (notif.admid && notif.admid > 0) {
                                targetUrl = `<?= base_url('admissiondetailsnew/edit/'); ?>${notif.admid}`;
                              } else if (notif.stockId && notif.stockId > 0) {
                                targetUrl = `<?= base_url('stock/edit/'); ?>${notif.stockId}`;
                              } else if (notif.freegiftId && notif.freegiftId > 0) {
                                targetUrl = `<?= base_url('freegift/edit/'); ?>${notif.freegiftId}`;
                              } else if (notif.socialId && notif.socialId > 0) {
                                targetUrl = `<?= base_url('socialmedia/socialmediaListing/'); ?>${notif.socialId}`;
                              } else if (notif.staffId && notif.staffId > 0) {
                                targetUrl = `<?= base_url('staff/staffListing/'); ?>`;
                              } else if (notif.onboardfrmId && notif.onboardfrmId > 0) {
                                targetUrl = `<?= base_url('onboardingforms/onboardingformsListing/'); ?>`;
                              } else if (notif.amcId && notif.amcId > 0) {
                                targetUrl = `<?= base_url('amc/view/'); ?>${notif.amcId}`;
                              } else if (notif.locationApprovalId && notif.locationApprovalId > 0) {
                                targetUrl = `<?= base_url('locationapproval/locationapprovalListing/'); ?>`;
                              } else if (notif.adminMeetingId && notif.adminMeetingId > 0) {
                                targetUrl = `<?= base_url('administrationtraining/administrationtrainingListing/'); ?>`;
                              } else if (notif.trainingId && notif.trainingId > 0) {
                                targetUrl = `<?= base_url('training/view/'); ?>${notif.trainingId}`;
                              } else if (notif.coupnsId && notif.coupnsId > 0) {
                                targetUrl = `<?= base_url('coupons/edit/'); ?>${notif.coupnsId}`;
                              } else if (notif.approvalId && notif.approvalId > 0) {
                                targetUrl = `<?= base_url('approval/edit/'); ?>${notif.approvalId}`;
                              } else if (notif.amtconfId && notif.amtconfId > 0) {
                                targetUrl = `<?= base_url('amountconfirmation/edit/'); ?>${notif.amtconfId  }`;
                              } else if (notif.dmfranchseId && notif.dmfranchseId > 0) {
                                targetUrl = `<?= base_url('dmfranchse/edit/'); ?>${notif.dmfranchseId }`;
                              } else if (notif.dmfranchsehoId && notif.dmfranchsehoId > 0) {
                                targetUrl = `<?= base_url('dmfranchseho/edit/'); ?>${notif.dmfranchsehoId  }`;
                              } else if (notif.dailyreportId && notif.dailyreportId > 0) {
                                targetUrl = `<?= base_url('dailyreport/dailyreportListing/'); ?>`;
                              } else if (notif.festiveimagesId && notif.festiveimagesId > 0) {
                                targetUrl = `<?= base_url('Festiveimages/festiveimagesListing/'); ?>`;
                              } else if (notif.brimgvideoId && notif.brimgvideoId > 0) {
                                targetUrl = `<?= base_url('Branchinstallationimg/edit/'); ?>${notif.brimgvideoId  }`;
                              } else if (notif.clientId && notif.clientId > 0) {
                                targetUrl = `<?= base_url('/clients/edit/'); ?>${notif.clientId  }`;
                              } else if (notif.assetsId && notif.assetsId > 0) {
                                targetUrl = `<?= base_url('/assetassignment/edit/'); ?>${notif.assetsId  }`;
                              } else if (notif.classfeeId && notif.classfeeId > 0) {
                                targetUrl = `<?= base_url('/classesfeetemplate/view/'); ?>${notif.classfeeId  }`;
                              } else if (notif.standId && notif.standId > 0) {
                                targetUrl = `<?= base_url('/standardformat/standardformatListing/'); ?>${notif.standId  }`;
                              } else if (notif.internaldesignId && notif.internaldesignId > 0) {
                                targetUrl = `<?= base_url('internaldesign/internaldesignListing/'); ?>${notif.internaldesignId  }`;
                              } else if (notif.studentkitId && notif.studentkitId > 0) {
                                targetUrl = `<?= base_url('studentkit/studentkitListing'); ?>${notif.studentkitId  }`;
                              } else if (notif.proddefectiveId && notif.proddefectiveId > 0) {
                                targetUrl = `<?= base_url('/defectiveproduct/defectiveproductListing'); ?>`;
                              } else if (notif.dcfeetempId && notif.dcfeetempId > 0) {
                                targetUrl = `<?= base_url('daycarefeetemplate/viewdaycarefeetemplate/'); ?>${notif.dcfeetempId}`;
                              } else if (notif.attachmentId && notif.attachmentId > 0) {
                                targetUrl = `<?= base_url('attachment/edit/'); ?>${notif.attachmentId    }`;
                              } else if (notif.transId && notif.transId > 0) {
                                targetUrl = `<?= base_url('transfer/view/'); ?>${notif.transId }`;
                              } else if (notif.standardimagesId && notif.standardimagesId > 0) {
                                targetUrl = `<?= base_url('/Standardimages/StandardimagesListing'); ?>`;
                              } else if (notif.empofmonthsId && notif.empofmonthsId > 0) {
                                targetUrl = `<?= base_url('employeeofmonth/employeeofmonthListing'); ?>`;
                              } else if (notif.assmentId && notif.assmentId > 0) {
                                targetUrl = `<?= base_url('trainingassessment/view/'); ?>${notif.assmentId }`;

                              } else if (notif.credId && notif.credId > 0) {
                                targetUrl = `<?= base_url('credentials/edit/'); ?>${notif.credId }`;

                              } else if (notif.qcId && notif.qcId > 0) {
                                targetUrl = `<?= base_url('qcdetails/edit/'); ?>${notif.qcId }`;

                              } else if (notif.id && notif.id > 0) {
                                targetUrl = `<?= base_url('/Notification/all_notifications'); ?>`;
                              }
                              list += `<li class="notification-item">
                                <a href="${targetUrl}" class="notification-link" data-id="${notif.id}">
                                    ${notif.message}
                                </a>
                            </li>`;
                            });
                          } else {
                            list = "<li>No new notifications</li>";
                          }

                          $("#notification-list").html(list);
                        }
                      });
                    }

                    function markNotificationAsRead(notificationId, targetUrl) {
                      $.ajax({
                        url: "<?= base_url('notification/mark_as_read'); ?>",
                        type: "POST",
                        data: {
                          id: notificationId
                        },
                        success: function() {
                          console.log("Notification marked as read:", notificationId);

                          $(`.notification-link[data-id="${notificationId}"]`).closest(".notification-item").remove();
                          let currentCount = parseInt($("#notification-count").text(), 10);
                          if (currentCount > 0) {
                            $("#notification-count").text(currentCount - 1);
                          }

                          setTimeout(() => {
                            window.location.href = targetUrl;
                          }, 300);
                        },
                        error: function() {
                          console.error("Error marking notification as read.");
                          window.location.href = targetUrl;
                        }
                      });
                    }

                    $(document).on("click", ".notification-link", function(e) {
                      e.preventDefault();
                      let notificationId = $(this).data("id");
                      let targetUrl = $(this).attr("href");

                      if (!notificationId) {
                        window.location.href = targetUrl;
                        return;
                      }

                      markNotificationAsRead(notificationId, targetUrl);
                    });

                    $("#notification-bell").on("click", function() {
                      $("#notification-dropdown").toggle();

                      if ($("#notification-count").text() !== "0") {
                        $.ajax({
                          url: "<?= base_url('notification/mark_all_read'); ?>",
                          type: "POST",
                          success: function() {
                            $("#notification-count").text("0");
                          }
                        });
                      }
                    });

                    // Fetch notifications on page load
                    fetchNotifications();

                    // Auto-refresh every 1 minute (60,000ms)
                    setInterval(fetchNotifications, 60000);

                    console.log("Auto-refresh enabled.");
                  });
                </script>


                <style>
                  .notification-wrapper {
                    position: relative;
                    display: inline-block;
                  }

                  #notification-bell {
                    background: none;
                    border: none;
                    font-size: 20px;
                    cursor: pointer;
                  }

                  #notification-count {
                    background: #EE0000;
                    color: white;
                    border-radius: 50%;
                    padding: 2px 5px;
                    font-size: 12px;
                    position: absolute;
                    top: -5px;
                    right: -5px;
                  }

                  #notification-dropdown {
                    display: none;
                    position: absolute;
                    right: 0;
                    background: white;
                    border: 1px solid #ccc;
                    width: 200px;
                    max-height: 200px;
                    overflow-y: auto;
                  }

                  #notification-list {
                    list-style: none;
                    padding: 10px;
                  }

                  #notification-dropdown {
                    position: absolute;
                    top: 100%;
                    left: 0;
                    z-index: 1000;
                    display: none;
                    float: left;
                    min-width: 10rem;
                    padding: 0.5rem 0;
                    margin: 0.125rem 0 0;
                    font-size: 1rem;
                    color: #343434;
                    text-align: left;
                    list-style: none;
                    background-color: #ffffff;
                    background-clip: padding-box;
                    border: 1px solid rgba(52, 52, 52, 0.15);
                    border-radius: 15px;
                    box-shadow: 0 3px 15px 0 rgba(0, 0, 0, 0.16);
                    right: 0 !important;
                    left: auto !important;
                    padding: 15px;
                    min-width: 325px;
                    transform: translate3d(0px, 54px, 0px) !important;
                    z-index: 511;
                    border: unset;
                    top: 0px;
                    transition: all 0.1s;
                    max-height: 400px;
                    overflow-y: auto;
                  }

                  a.notification-link:hover {
                    background-color: #e2e6ea;
                  }

                  .notification-link {
                    display: block;
                    text-decoration: none;
                    color: #006FE6;
                    padding: 5px 10px;
                    border-radius: 4px;
                    background-color: #f8f9fa;
                    transition: background-color 0.3sease;
                  }

                  li.notification-item {
                    margin-bottom: 10px;
                    font-size: 14px;
                  }

                  span.caret.cfehs94 {
                    background-color: var(--ux-cao06b, white);
                    border-top-left-radius: .25rem;
                    width: 1rem;
                    height: 1rem;
                    border-top: 1px solid var(--ux-97h3vl, lightgray);
                    border-left: 1px solid var(--ux-97h3vl, lightgray);
                    border-bottom-color: transparent;
                    -webkit-transform: rotateZ(45deg);
                    -webkit-transform: rotateZ(45deg);
                    -ms-transform: rotateZ(45deg);
                    -webkit-transform: rotateZ(45deg);
                    -ms-transform: rotateZ(45deg);
                    transform: rotateZ(45deg);
                    display: block;
                    left: 0.75rem;
                    top: 1.207rem;
                    position: relative;
                    margin-top: -1rem;
                    z-index: 1000 !important;
                  }
                </style>

                <!-- Menu Footer-->
                <li class="user-footer">
                  <div class="pull-left">
                    <a href="<?php echo base_url(); ?>profile" class="btn btn-warning btn-flat"><i class="fa fa-user-circle"></i> Profile</a>
                  </div>
                  <div class="pull-right">
                    <a href="<?php echo base_url(); ?>logout" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Sign out</a>
                  </div>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
          <li class="header">MAIN NAVIGATION</li>
          <?php if ($role == 25) { ?>
            <li>
              <a href="<?php echo base_url(); ?>dashboard">
                <i class="fa fa-dashboard"></i> <span>My Dashboard</span>
              </a>
            </li>
          <?php } else { ?>
            <li>
              <a href="<?php echo base_url(); ?>dashboard">
                <i class="fa fa-dashboard"></i> <span>My Dashboard</span>
              </a>
            </li>
          <?php } ?>
          <?php
          if ($is_admin == 1) {
          ?>
            <li>
              <a href="<?php echo base_url(); ?>userListing">
                <i class="fa fa-users"></i>
                <span>Users</span>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>roles/roleListing">
                <i class="fa fa-user-circle-o " aria-hidden="true"></i>
                <span>Roles</span>
              </a>
            </li>
          <?php
          }
          ?>
          <?php
          /*if($is_admin == 1 ||
                (array_key_exists('Booking', $access_info) 
                && ($access_info['Booking']['list'] == 1 || $access_info['Booking']['total_access'] == 1)))
            {
              ?>
            <li>
              <a href="<?php echo base_url(); ?>booking">
                <i class="fa fa-anchor"></i>
                <span>Booking</span>
              </a>
            </li>
              <?php
            }*/
          ?>
          <!--Investors--->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Investors', $access_info)
              && ($access_info['Investors']['list'] == 1 || $access_info['Investors']['total_access'] == 1))
          ) {
          ?>
            <li>
              <a href="<?php echo base_url(); ?>investors">
                <i class="fa fa-tasks"></i>
                <span>Investors</span>
              </a>
            </li>
          <?php
          }
          ?>
          <!--Branches--->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Branches', $access_info)
              && ($access_info['Branches']['list'] == 1 || $access_info['Branches']['total_access'] == 1))
          ) {
          ?>

            <?php if ($this->session->userdata('role') != 29 && $this->session->userdata('role') != 31) { ?>
              <li>
                <a href="<?php echo base_url(); ?>branches">
                  <i class="fa fa-anchor"></i>
                  <span>Branches</span>
                </a>
              </li>
            <?php } ?>


          <?php
          }
          ?>
          <!---New Branches---->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Task', $access_info)
              && ($access_info['Task']['list'] == 1 || $access_info['Task']['total_access'] == 1))
          ) {
          ?>
            <?php if ($this->session->userdata('role') != 25): ?>
              <li>
                <a href="<?php echo base_url(); ?>task">
                  <i class="fa fa-tasks"></i>
                  <span>Tasks</span>
                </a>
              </li>
            <?php endif; ?>

            <li>
              <a href="<?php echo base_url(); ?>ticket">
                <i class="fa fa-tasks"></i>
                <span>Branch Queries</span>
              </a>
            </li>

          <?php
          }
          ?>

          <li>
            <a href="<?php echo base_url(); ?>todo">
              <i class="fa fa-tasks"></i>
              <span>My Private To-Do List</span>
            </a>
          </li>

          <!--Attachment--->

          <!-- <li>
              <a href="<?php //echo base_url(); 
                        ?>attachment">
                <i class="fa fa-tasks"></i>
                <span>Attachment</span>
              </a>
            </li> -->
          <?php if (in_array($role, [1, 14, 15, 22, 25, 27, 19])) { ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>attachment" class="treeview-toggle">
                <i class="fa fa-share"></i>
                <span>Design Attachments</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: none;">
                <li>
                  <a href="<?php echo base_url(); ?>attachment">
                    <i class="fa fa-circle-o"></i> Design Attachments
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url(); ?>customdesign">
                    <i class="fa fa-circle-o"></i> Custom Designs - (On-Demand)
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url(); ?>festiveimages">
                    <i class="fa fa-circle-o"></i> Festival Images
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url(); ?>standardimages">
                    <i class="fa fa-circle-o"></i> Standard Image
                  </a>
                </li>
                <?php if ($role != 25) { ?>
                  <li>
                    <a href="<?php echo base_url('Internaldesign'); ?>">
                      <i class="fa fa-circle-o"></i> Internal Design
                    </a>
                  </li>
                <?php } ?>
              </ul>
            </li>
          <?php } ?>

          <!---New Attachment---->
          <!--Training--->

          <!-- <li>
              <a href="<?php //echo base_url(); 
                        ?>training">
                <i class="fa fa-tasks"></i>
                <span>Training</span>
              </a>
            </li> -->
          <?php if ($is_admin == 1 || $role == 2 ||  $role == 14 ||  $role == 13 ||  $role == 21 ||  $role == 20  || $role == 15 || $role == 24 || $role == 25) { ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>training">
                <i class="fa fa-tasks"></i>
                <span> Training</span> <i class="fa-solid fa-chevron-down"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>training">Schedule Training</a></li>
              
                <?php if ( $role != 25) { ?>
                <li><a href="<?php echo base_url(); ?>internaltraining"> Internal Library</a>
                  <?php
            }
            ?>
                <li><a href="<?php echo base_url(); ?>externallibrary"> External Library</a>
                </li>
              </ul>
            <?php
          }
            ?>

            <?php if ($is_admin == 1 || $role == 2 ||  $role == 14 ||  $role == 13 ||  $role == 21 ||  $role == 20  || $role == 15 || $role == 24 || $role == 25 || $role == 33) { ?>
            <li>
              <a href="<?php echo base_url(); ?>support">
                <i class="fa fa-tasks"></i>
                <span>Meeting</span>
              </a>
            </li>
          <?php
            }
          ?>

          <!---End-Training---->
          <!--Despatch--->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Despatch', $access_info)
              && ($access_info['Despatch']['list'] == 1 || $access_info['Despatch']['total_access'] == 1))
          ) {
          ?>
            <!-- <li>
              <a href="<?php echo base_url(); ?>despatch">
                <i class="fa fa-tasks"></i>
                <span>Despatch</span>
              </a>
            </li> -->
            <?php if ($is_admin == 1 || $role == 2 ||  $role == 14 ||  $role == 23 ||  $role == 15  || $role == 16 || $role == 35 || $role == 25) { ?>
              <li class="treeview">
                <a href="#">
                  <i class="fa fa-tasks"></i> <span>Dispatch</span>
                  <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="<?php echo base_url(); ?>despatch"><i class="fa fa-circle-o"></i> Dispatch</a></li>
                  <li><a href="<?php echo base_url(); ?>returnproduct"><i class="fa fa-circle-o"></i> Return / Exchange Product</a></li>

                   <?php if ($role != 25) { ?>
                  <li><a href="<?php echo base_url(); ?>defectiveproduct"><i class="fa fa-circle-o"></i> Defective Products</a></li>
                  <?php  
                }?>
                </ul>
              </li>
            <?php
            }
            ?>
          <?php
          }
          ?>

          <!-- <li>
              <a href="<?php echo base_url(); ?>despatch">
                <i class="fa fa-tasks"></i>
                <span>Despatch</span>
              </a>
            </li> -->
          <?php if ($is_admin == 1 || $role == 2 ||  $role == 14  ||  $role == 15  ||  $role == 25  ||  $role == 13 ||  $role == 21) { ?>
            <li class="treeview">
              <a href="#" class="treeview-toggle">
                <i class="fa fa-tasks"></i>
                <span>Fee Template</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: none;">
                <li>
                  <a href="<?php echo base_url(); ?>daycarefeetemplate">
                    <i class="fa fa-circle-o"></i> Day Care
                  </a>
                </li>
                <li>
                  <a href="<?php echo base_url(); ?>classesfeetemplate">
                    <i class="fa fa-circle-o"></i> Class Fee
                  </a>
                </li>
              </ul>
            </li>
          <?php
          }
          ?>


          <?php if ($is_admin == 1 ||  $role == 14 ||  $role == 15 ||  $role == 13 ||  $role == 24  || $role == 23 || $role == 24 || $role == 16) { ?>
            <li>
              <a href="<?php echo base_url(); ?>acattachment">
                <i class="fa fa-tasks"></i>
                <span>Account Attachment</span>
              </a>
            </li>
          <?php
          }
          ?>

          <!--Amc--->

          <?php
          $role = $this->session->userdata('role');
          // Define roles that should NOT see the AMC menu
          $excludedRoles = [19, 27, 29, 31, 33, 23, 21, 30, 39,40];
          // Define roles that see only AMC Inactive Listing
          $inactiveOnlyRoles = [1, 14, 15, 16, 24, 25];

          if (!in_array($role, $excludedRoles)) {
            // Show AMC menu for all roles except excluded ones
          ?>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-tasks"></i> <span>AMC</span>
                <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
              </a>
              <ul class="treeview-menu">
                <?php if (in_array($role, $inactiveOnlyRoles)) { ?>
                  <!-- Show only AMC Inactive Listing for specific roles -->
                  <li><a href="<?php echo base_url(); ?>amc/amcListing"><i class="fa fa-circle-o"></i> AMC Listing</a></li>
                <?php } else { ?>
                  <!-- Show both Active and Inactive Listings for other roles -->
                  <li><a href="<?php echo base_url(); ?>amc"><i class="fa fa-circle-o"></i> AMC Active Listing</a></li>
                  <li><a href="<?php echo base_url(); ?>amc/amcListing"><i class="fa fa-circle-o"></i> AMC Inactive Listing</a></li>
                <?php } ?>
              </ul>
            </li>
          <?php } ?>



          <!-- Support-Section -->

          <!-- End-Support -->

          <?php
          if ($role == 1 || $role == 14 || $role == 25 || $role == 24 || $role == 13 || $role == 16  ||  $role == 15) {
            //   if (
            //     $is_admin == 1 ||
            //     (array_key_exists('Lgattachment', $access_info)
            //       && ($access_info['Lgattachment']['list'] == 1 || $access_info['Lgattachment']['total_access'] == 1))
            //   ) {
            // 
          ?>

            <li>
              <a href="<?php echo base_url(); ?>lgattachment">
                <i class="fa fa-tasks"></i>
                <span>Legal Attachment</span>
              </a>
            </li>
          <?php
          }
          // }
          ?>
          <!---End-Despatch---->
          <!--Admissions--->

          <!-- <li>
              <a href="<?php //echo base_url(); 
                        ?>attachment">
                <i class="fa fa-tasks"></i>
                <span>Attachment</span>
              </a>
            </li> -->


          <?php
          if ($this->session->userdata('role') == 1 || $this->session->userdata('role') == 14 || $this->session->userdata('role') == 25 || $this->session->userdata('role') == 15 || $this->session->userdata('role') == 20) {
            if ($this->session->userdata('role') != 29 && $this->session->userdata('role') != 31) {
          ?>
              <li class="treeview">
                <a href="<?php echo base_url(); ?>admissiondetails">
                  <i class="fa fa-share">
                    <span class="pull-right-container"></i> Admission Details</span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="<?php echo base_url(); ?>admissiondetails"><i class="fa fa-circle-o"></i>Session 24-25</a></li>
                  <li><a href="<?php echo base_url(); ?>admissiondetailsnew"><i class="fa fa-circle-o"></i>Session 25-26</a></li>

                  <?php if ($this->session->userdata('role') != 33) { ?>
                    <li><a href="<?php echo base_url(); ?>admissiondetailsnew25"><i class="fa fa-circle-o"></i>Admission Listing 25-26</a></li>
                  <?php } ?>

                  <li><a href="<?php echo base_url(); ?>admenquiry"><i class="fa fa-circle-o"></i>Admission Enquiry</a></li>

                  <?php if ($this->session->userdata('role') == 25) { ?>
                    <li>
                      <a href="<?php echo base_url(); ?>admission">
                        <i class="fa fa-tasks"></i>
                        <span>Admissions</span>
                      </a>
                    </li>
                  <?php } ?>
                </ul>
              </li>
          <?php
            }
          }
          ?>

          <?php if (!in_array($this->session->userdata('role'), [33, 39])) { ?>
            <li><a href="<?php echo base_url(); ?>admissiondetailsnew25"><i class="fa fa-circle-o"></i>Listing 25-26</a></li>
          <?php } ?>

          <!---End-Admissions---->
          <!--Accounts--->
          <?php if ($role == 25) { ?>
            <li>
              <a href="<?php echo base_url(); ?>account">
                <i class="fa fa-tasks"></i>
                <span>Offer Plan</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if (
            $is_admin == 1 || $role == 1 || $role == 15 || $role == 24 || $role == 16 ||
            (array_key_exists('Pdc', $access_info) && ($access_info['Pdc']['list'] == 1 || $access_info['Pdc']['total_access'] == 1))
          ) {
          ?>
            <?php if ($this->session->userdata('role') != 29 && $this->session->userdata('role') != 31) { ?>
              <li>
                <a href="<?php echo base_url(); ?>pdc">
                  <i class="fa fa-tasks"></i>
                  <span>PDC</span>
                </a>
              </li>
            <?php } ?>
          <?php
          }
          ?>

          <!---End-Accounts---->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Blog', $access_info)
              && ($access_info['Blog']['list'] == 1 || $access_info['Blog']['total_access'] == 1))
          ) {
          ?>
            <li>
              <a href="<?php echo base_url(); ?>blog">
                <i class="fa fa-tasks"></i>
                <span>Blog</span>
              </a>
            </li>
          <?php
          }
          ?>
          <!---End-Accounts---->
          <?php
          if ($role == 1 || $role == 14 || $role == 25 || $role == 15 || $role == 18) {
            if (
              $is_admin == 1 ||
              (array_key_exists('Dmfranchse', $access_info)
                && ($access_info['Dmfranchse']['list'] == 1 || $access_info['Dmfranchse']['total_access'] == 1))
            ) {
          ?>
              <li>
                <a href="<?php echo base_url(); ?>dmfranchse">
                  <i class="fa fa-tasks"></i>
                  <span>Digital Marketing (Franchise)</span>
                </a>
              </li>
          <?php
            }
          }
          ?>
          <?php
          $excluded_roles = [25, 19, 27, 33, 16, 36];
          if (
            ($role == 1 || $role == 14 ||  $role == 15 || $role == 26 || $role == 18) &&
            !in_array($role, $excluded_roles)
          ) {
          ?>
            <li>
              <a href="<?php echo base_url(); ?>dmfranchseho">
                <i class="fa fa-tasks"></i>
                <span>Digital Marketing (HO)</span>
              </a>
            </li>
          <?php
          }
          ?>



          <?php if ($is_admin == 1 || $role == 2 ||  $role == 14 ||  $role == 13 ||  $role == 24 ||  $role == 25) { ?>
            <li>
              <a href="<?php echo base_url(); ?>locationapproval">
                <i class="fa fa-tasks"></i>
                <span>Location Approval</span>
              </a>
            </li>
          <?php
          }
          ?>
          <?php
          // if (
          //   $is_admin == 1 ||
          //   (array_key_exists('Administrationtraining', $access_info)
          //     && ($access_info['Administrationtraining']['list'] == 1 || $access_info['Administrationtraining']['total_access'] == 1))
          // ) {
          // 
          ?>
          <?php if (
            $role == 1 || $role == 14  || $role == 25  ||  $role == 13  ||  $role == 24   ||  $role == 15
          ) { ?>
            <li>
              <a href="<?php echo base_url(); ?>administrationtraining">
                <i class="fa fa-tasks"></i>
                <span>Administration Training</span>
              </a>
            </li>
          <?php } ?>
          <?php
          // }
          ?>
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Onboardingforms', $access_info)
              && ($access_info['Onboardingforms']['list'] == 1 || $access_info['Onboardingforms']['total_access'] == 1))
          ) {
          ?>
            <!-- <li>
              <a href="<?php echo base_url(); ?>onboardingforms">
                <i class="fa fa-tasks"></i>
                <span>Onboarding Forms</span>
              </a>
            </li> -->
            <?php if (
              $role == 1 || $role == 14 ||
              $role == 13 || $role == 24  ||  $role == 25
            ) { ?>
              <li class="treeview">
                <a href="<?php echo base_url(); ?>onboardingforms">
                  <i class="fa fa-tasks"></i>
                  <span>Onboarding Forms</span>
                </a>
                <ul class="treeview-menu">

                  <li><a href="<?php echo base_url(); ?>onboardingfirstform"><i class="fa fa-circle-o"></i> Franchise First Form</a></li>
                  <li><a href="<?php echo base_url(); ?>onboardapplication"><i class="fa fa-circle-o"></i> Franchise Enrollment Form</a></li>
                </ul>
              </li>

            <?php } elseif ($role == 25) { ?>
              <li class="treeview">
                <a href="#">
                  <i class="fa fa-tasks"></i>
                  <span>Onboarding Forms</span>
                </a>
                <ul class="treeview-menu">
                  <li><a href="<?php echo base_url(); ?>onboardingfirstform"><i class="fa fa-circle-o"></i> Franchise First Form</a></li>
                  <li><a href="<?php echo base_url(); ?>onboardapplication"><i class="fa fa-circle-o"></i> Franchise Enrollment Form</a></li>
                </ul>
              </li>
            <?php } ?>

          <?php
          }
          ?>
          <?php if (
            $role == 1 || $role == 14 ||
            $role == 13 || $role == 24
          ) { ?>
            <li><a href="<?php echo base_url(); ?>onboardingfirstform/onboardingfirstformListing"><i class="fa fa-circle-o"></i>Franchise FirstForm Listing</a></li>
            <li><a href="<?php echo base_url(); ?>onboardapplication/onboardapplicationListing"><i class="fa fa-circle-o"></i> OnboardApplication Listing</a></li>
          <?php } ?>
          <!-- Staff -->
          <?php
          if ($role == 1 || $role == 14 || $role == 25 || $role == 15 || $role == 21) {
            if (
              $is_admin == 1 ||
              (array_key_exists('Staff', $access_info)
                && ($access_info['Staff']['list'] == 1 || $access_info['Staff']['total_access'] == 1))
            ) {
          ?>
              <?php if ($this->session->userdata('role') != 29 && $this->session->userdata('role') != 31) { ?>
                <li>
                  <a href="<?php echo base_url(); ?>staff">
                    <i class="fa fa-tasks"></i>
                    <span>Staff Details</span>
                  </a>
                </li>
              <?php } ?>
          <?php
            }
          }
          ?>
          <!-- Admission Enquiry -->
          <!-- Branchinstallation -->

          <?php if ($role == 1 || $role == 14 || $role == 25 || $role == 13 || $role == 23  || $role == 16 || $role == 24) { ?>
            <li>
              <a href="<?php echo base_url(); ?>branchinstallation">
                <i class="fa fa-tasks"></i>
                <span>Branch Installation</span>
              </a>
            </li>
          <?php } ?>

          <!-- FreeGift -->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Freegift', $access_info)
              && ($access_info['Freegift']['list'] == 1 || $access_info['Freegift']['total_access'] == 1))
          ) {
          ?>
            <?php if ($role == 1 || $role == 14 || $role == 15 || $role == 23 || $role == 24 || $role == 26) { ?>
              <li>
                <a href="<?php echo base_url(); ?>freegift">
                  <i class="fa fa-tasks"></i>
                  <span>Free Gift From HO</span>
                </a>
              </li>
          <?php
            }
          }
          ?>
          <!-- Stock -->
          <!-- Stock -->
          <!--Attachment--->
          <!--  -->
          <!-- <li>
              <a href="<?php //echo base_url(); 
                        ?>attachment">
                <i class="fa fa-tasks"></i>
                <span>Attachment</span>
              </a>
            </li> -->
          <?php if ($role == 16 || $role == 1 || $role == 14) { ?>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-share"></i> <span>Stock</span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>stock"><i class="fa fa-circle-o"></i> Stock</a></li>
                <li><a href="<?php echo base_url(); ?>stockSampleListing"><i class="fa fa-circle-o"></i> Sample Kit</a></li>
                <li><a href="<?php echo base_url(); ?>salesrecord"><i class="fa fa-circle-o"></i> Sales Record</a></li>
                <li><a href="<?php echo base_url(); ?>purchaserecord"><i class="fa fa-circle-o"></i> Purchase Record</a></li>
                  <li><a href="<?php echo base_url(); ?>returnproductdispatch"><i class="fa fa-circle-o"></i>Return Received</a></li>
              </ul>
            </li>
          <?php } elseif ($role == 36 || $role == 37  || $role == 35) { ?>
            <li>
              <a href="<?php echo base_url(); ?>purchaserecord"><i class="fa fa-circle-o"></i> Purchase Record</a>
            </li>
          <?php } ?>


          <!---New Attachment---->

          <?php
          if (in_array($role, [1, 14, 24, 13])) {
          ?>
            <li>
              <a href="<?php echo base_url(); ?>scheduledinstallation">
                <i class="fa fa-tasks"></i>
                <span>Scheduled Installation</span>
              </a>
            </li>
          <?php } ?>

          <!---New Attachment---->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Announcement', $access_info)
              && ($access_info['Announcement']['list'] == 1 || $access_info['Announcement']['total_access'] == 1))
          ) {
          ?>
            <?php if ($role != 25 && $role != 29 && $role != 31) { ?> <!-- If role is NOT 29, show the menu item -->
              <li>
                <a href="<?php echo base_url(); ?>announcement">
                  <i class="fa fa-tasks"></i>
                  <span>Important Announcement</span>
                </a>
              </li>
            <?php } ?>
          <?php
          }
          ?>
          <!---FAQ's---->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Faq', $access_info)
              && ($access_info['Faq']['list'] == 1 || $access_info['Faq']['total_access'] == 1))
          ) {
          ?>

            <li>
              <a href="<?php echo base_url(); ?>faq">
                <i class="fa fa-tasks"></i>
                <span>FAQ's</span>
              </a>
            </li>
          <?php
          }
          ?>
          <!---Upcoming Branches---->
          <?php
          if (
            $is_admin == 1 ||
            (array_key_exists('Upcomingbranches', $access_info)
              && ($access_info['Upcomingbranches']['list'] == 1 || $access_info['Upcomingbranches']['total_access'] == 1))
          ) {
          ?>
            <?php if ($role == 1 || $role == 14 || $role == 13 || $role == 24) { ?>
              <li>
                <a href="<?php echo base_url(); ?>upcomingbranches">
                  <i class="fa fa-tasks"></i>
                  <span>Upcoming Branches</span>
                </a>
              </li>
            <?php } ?>
          <?php
          }
          ?>


          <!-- Sales -->


          <?php if ($role == 14 || $role == 1 || $role == 28 || $role == 29 || $role == 31 || $role == 2) { ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>sales">
                <i class="fa fa-share">
                  <span class="pull-right-container"></i> Sales</span>
              </a>
              <ul class="treeview-menu">

                <li><a href="<?php echo base_url(); ?>clients"><i class="fa fa-circle-o"></i> Leads</a></li>
                <li><a href="<?php echo base_url(); ?>followup"><i class="fa fa-circle-o"></i> My FollowUp</a></li>
                <li><a href="<?php echo base_url(); ?>results"><i class="fa fa-circle-o"></i> My Result</a></li>
                <li><a href="<?php echo base_url(); ?>performancereport"><i class="fa fa-circle-o"></i> Performance Report</a></li>
                <li><a href="<?php echo base_url(); ?>top10clients"><i class="fa fa-circle-o"></i> My Positive Clients</a></li>
                <li><a href="<?php echo base_url(); ?>dailyreport"><i class="fa fa-circle-o"></i> Daily Reports</a></li>
                <li><a href="<?php echo base_url(); ?>attendance"><i class="fa fa-circle-o"></i> Sales Attendance</a></li>

              </ul>
            </li>
          <?php
          }
          ?>



          <!-- Leave -->

          <!--  <li>
              <a href="<?php echo base_url(); ?>leave">
                <i class="fa fa-tasks"></i>
                <span>Leaves</span>
              </a>
            </li> -->
          <?php //if ($role == 14 || $role == 26 || $role == 15 || $role == 2|| $role == 1 || $role == 22 || $role == 29 || $role == 31) { 
          ?>
          <?php if ($role != 25 && $role != 39  && $role != 40) { ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>leave">
                <i class="fa fa-tasks"></i>
                <span>Human Resources</span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>leave"><i class="fa fa-circle-o"></i>Leave</a></li>
                <li><a href="<?php echo base_url(); ?>hr"><i class="fa fa-circle-o"></i> Applied Leave </a></li>
                <!-- <li><a href="<?php echo base_url(); ?>brholiday"><i class="fa fa-circle-o"></i> Branch Holiday </a></li> -->
                <li><a href="<?php echo base_url(); ?>brholiday/holiday"><i class="fa fa-circle-o"></i> Holiday </a></li>
                <li><a href="<?php echo base_url(); ?>employeeofmonth"><i class="fa fa-circle-o"></i> Employee Of Month </a></li>
                <li><a href="<?php echo base_url(); ?>hreventgallery"><i class="fa fa-circle-o"></i> Hr Event Gallery </a></li>

                <?php if ($role == 1  || $role == 2  ||  $role == 14 ||  $role == 26) { ?>
                  <li><a href="<?php echo base_url(); ?>hronboard/hronboardListing"><i class="fa fa-circle-o"></i> Hr Onboarding </a></li>

                  <!--  <li><a href="<?php //echo base_url(); 
                                      ?>employeeofmonth"><i class="fa fa-circle-o"></i> Employee Of Month </a></li>
                <li><a href="<?php //echo base_url(); 
                              ?>hreventgallery"><i class="fa fa-circle-o"></i> Hr Event Gallery </a></li> -->
                  <li><a href="<?php echo base_url(); ?>interview"><i class="fa fa-circle-o"></i> Interview Schedule </a></li>
                  <?php if ($role == 14 || $role == 1 || $role == 28 || $role == 29 || $role == 31 || $role == 26) { ?>
                    <li><a href="<?php echo base_url(); ?>emprelieving"><i class="fa fa-circle-o"></i> Employee Relieving </a></li>
                  <?php
                  }
                  ?>

                  <li><a href="<?php echo base_url(); ?>assetassignment"><i class="fa fa-circle-o"></i> Assets assignment </a></li>
                <?php
                }
                ?>

                <?php if ($role == 26) { ?>
                  <li>
                    <a href="<?php echo base_url(); ?>hronboard/add">
                      <i class="fa fa-tasks"></i>
                      <span>Employee Onboarding Form</span>
                    </a>
                  </li>
                  <li>
                    <a href="<?php echo base_url(); ?>hronboard/hronboardListing">
                      <i class="fa fa-tasks"></i>
                      <span>Employee Onboarding Listing</span>
                    </a>
                  </li>

                <?php } ?>
              </ul>
            </li>
          <?php } ?>
          <?php //} 
          ?>
          <?php if ($role == 14 || $role == 1 || $role == 26) { ?>
            <li><a href="<?php echo base_url(); ?>hr/userdeptListing"><i class="fa fa-circle-o"></i> User listing </a></li>
          <?php } ?>


          <?php if ($role == 1 ||  $role == 14 || $role == 26 || $role == 19) { ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>anniversarybirthdayrecord">
                <i class="fa fa-share">
                  <span class="pull-right-container"></i> Birthday & Anniversary</span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>branchanniversary/anniversarylisting"><i class="fa fa-circle-o"></i>Branch Anniversary</a></li>
                <li><a href="<?php echo base_url(); ?>branchanniversary/branchowneranniversarylisting"><i class="fa fa-circle-o"></i>Branch Owner Anniversary </a></li>
                <li><a href="<?php echo base_url(); ?>branchanniversary/branchempbirthlisting"><i class="fa fa-circle-o"></i>Branch Employee Birthday </a></li>
                <li><a href="<?php echo base_url(); ?>branchanniversary/empbirthlist"><i class="fa fa-circle-o"></i>Edumeta Employe Birthday</a></li>
                <li><a href="<?php echo base_url(); ?>branchanniversary/edumetaworkanniversarylisting"><i class="fa fa-circle-o"></i>Edumeta Employee Work Anniversary</a></li>
                <li><a href="<?php echo base_url(); ?>branchanniversary/studentbirthdaylisting"><i class="fa fa-circle-o"></i>Student Birthday</a></li>
                <li><a href="<?php echo base_url(); ?>branchanniversary/edumetamarriageanniversarylisting"><i class="fa fa-circle-o"></i>Edumeta Employee Marriage Anniversary </a></li>
              </ul>
            </li>
          <?php } ?>


          <?php if ($role == 14 || $role == 1 || $role == 15 || $role == 25 || $role == 23 || $role == 22) { ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>itwebrecords">
                <i class="fa fa-share">
                  <span class="pull-right-container"></i> IT</span>
              </a>
              <ul class="treeview-menu">
                <?php if ($role != 23) { ?>
                  <li><a href="<?php echo base_url(); ?>credentials"><i class="fa fa-circle-o"></i>Credentials</a></li>
                <?php } ?>
                <?php if ($role == 14 || $role == 1 || $role == 22 || $role == 25  || $role == 15 || $role == 23) { ?>
                  <li><a href="<?php echo base_url(); ?>coupons"><i class="fa fa-circle-o"></i> Coupons</a></li>
                  <!--  <li><a href="<?php echo base_url(); ?>itwebrecords"><i class="fa fa-circle-o"></i> It Details</a></li> -->
                <?php } ?>
              </ul>
            </li>
          <?php } ?>

          <?php if ($role == 14 || $role == 1 || $role == 13 || $role == 15 || $role == 33 || $role == 20 || $role == 19 || $role == 24) { ?>
            <li>
              <a href="<?php echo base_url(); ?>socialmedia">
                <i class="fa fa-tasks"></i>
                <span>Social Media</span>
              </a>
            </li>
          <?php } ?>
          <?php if ($role == 14 || $role == 1 || $role == 23 || $role == 2  ||  $role == 16) { ?>
            <li>
              <a href="<?php echo base_url(); ?>OrderController">
                <i class="fa fa-tasks"></i>
                <span> Shop Orders Listing</span>
              </a>
            </li>
            <?php if ($role == 14 || $role == 1 || $role == 23 || $role == 2) { ?>
              <li>
                <a href="<?php echo base_url(); ?>OrderController/user_list">
                  <i class="fa fa-tasks"></i>
                  <span>Shop Customers History</span>
                </a>
              </li>
            <?php } ?>
          <?php
          }
          ?>

          <?php
          if ($role == 1 || $role == 14 || $role == 13 || $role == 2 || $role == 25 || $role == 29  || $role == 28 || $role == 15  || $role == 13  || $role == 23 || $role == 16) { ?>
            <li>
              <a href="<?php echo base_url(); ?>amountconfirmation">
                <i class="fa fa-tasks"></i>
                <span>Amount confirmation</span>
              </a>
            </li>
          <?php
          }
          ?>



          <?php
          $allowed_roles = [1, 14, 25, 39];
          if (in_array($role, $allowed_roles)) { ?>
            <li>
              <a href="<?php echo base_url(); ?>brholiday">
                <i class="fa fa-tasks"></i>
                <span>Branch Holiday</span>
              </a>
            </li>
          <?php } ?>



          <?php
          $allowed_roles = [1, 2, 13, 14, 15, 19, 24, 33, 25];
          if (in_array($role, $allowed_roles)) { ?>
            <li>
              <a href="<?php echo base_url(); ?>branchinstallationimg">
                <i class="fa fa-tasks"></i>
                <span>Branch Installation Image</span>
              </a>
            </li>
          <?php } ?>

          <?php
          if ($role != 39  && $role != 40) { ?>
            <li>
              <a href="<?php echo base_url(); ?>Empdailyreport">
                <i class="fa fa-tasks"></i>
                <span>Employee Daily Report</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if ($role == 1 || $role == 14 ||  $role == 2 || $role == 15 || $role == 20  || $role == 24) { ?>
            <li>
              <a href="<?php echo base_url(); ?>qcdetails">
                <i class="fa fa-tasks"></i>
                <span>QC Details</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if ($role != 39 && $role != 25 && $role != 40) { ?>
            <li>
              <a href="<?php echo base_url(); ?>Approval">
                <i class="fa fa-tasks"></i>
                <span>Approval</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if ($role == 1 || $role == 14  || $role == 2 || $role == 15) { ?>
            <li>
              <a href="<?php echo base_url(); ?>standardformat">
                <i class="fa fa-tasks"></i>
                <span>Standard Format</span>
              </a>
            </li>
          <?php
          }
          ?>


          <?php
          if ($role == 1 || $role == 14  || $role == 2 || $role == 15) { ?>
            <li>
            <li>
              <a href="<?php echo base_url(); ?>guidelines">
                <i class="fa fa-tasks"></i>
                <span>Guidelines (Growth)</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if ($role == 1 || $role == 14  || $role == 25 || $role == 39 || $role == 40) { ?>
            <li>
            <li>
              <a href="<?php echo base_url(); ?>studentsfee/studentsfeeListing">
                <i class="fa fa-tasks"></i>
                <span>Fee Structure</span>
              </a>
            </li>
          <?php
          }
          ?>
          <?php
          if ($role == 1 || $role == 14 || $role == 39  || $role == 40) {
          ?>
            <li>
              <a href="<?php echo base_url(); ?>Homework/homeworkListing">
                <i class="fa fa-tasks"></i>
                <span>Home Work</span>
              </a>
            </li>
          <?php
          }
          ?>

       <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>PTM Dates</span>
              </a>
            </li>
          <?php
          }
          ?>

            <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Exam Schedule Dates</span>
              </a>
            </li>
          <?php
          }
          ?>

         <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Performance Sheet</span>
              </a>
            </li>
          <?php
          }
          ?>

<?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Report Card</span>
              </a>
            </li>
          <?php
          }
          ?>

<?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Referral Bonus</span>
              </a>
            </li>
          <?php
          }
          ?>


        <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Suggestion Curriculum</span>
              </a>
            </li>
          <?php
          }
          ?>


<?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Student Picture</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>School Announcement</span>
              </a>
            </li>
          <?php
          }
          ?>


<?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Notice Board</span>
              </a>
            </li>
          <?php
          }
          ?>


<?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Newsletter</span>
              </a>
            </li>
          <?php
          }
          ?>

          <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Advertisment</span>
              </a>
            </li>
          <?php
          }
          ?>


        <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href="#" class="ajax-link" data-url="<?php echo base_url(); ?>homework">
                <i class="fa fa-tasks"></i>
                <span>Awards Student</span>
              </a>
            </li>
          <?php
          }
          ?>


    

          <?php
          if ($role == 1 || $role == 14 || $role == 39 || $role == 40) {
          ?>
            <li>
              <a href=<?php echo base_url('studentdetails'); ?>>
                <i class="fa fa-tasks"></i>
                <span>Student Completed Details</span>
              </a>
            </li>
          <?php
          }
          ?>


          <?php
          if ($role == 1 || $role == 14  || $role == 39  || $role == 25 || $role == 15 || $role == 40) { ?>
            <li>
            <li>
              <a href="<?php echo base_url(); ?>studenteventgallery/listing">
                <i class="fa fa-tasks"></i>
                <span>Student Event Gallery</span>
              </a>
            </li>
          <?php
          }
          ?>


          <?php
          if ($role == 1 || $role == 14  || $role == 2 || $role == 15  || $role == 25) { ?>
            <li>
            <li>
              <a href="<?php echo base_url(); ?>transfer">
                <i class="fa fa-tasks"></i>
                <span>Transfer Certificate</span>
              </a>
            </li>
          <?php
          }
          ?>


          <?php
          if ($role == 1 || $role == 14  || $role == 2 || $role == 15) { ?>
            <li>
            <li>
              <a href="<?php echo base_url(); ?>emailtemplate">
                <i class="fa fa-tasks"></i>
                <span>Email Template</span>
              </a>
            </li>
          <?php
          }
          ?>

          <!--  <li>
              <a href="<?php echo base_url(); ?>brholiday">
                <i class="fa fa-tasks"></i>
                <span>Holiday List</span>
              </a>
            </li> -->
          <!-- HR DASHBOARD FOR LEAVE-->
          <?php if ($role == 14 || $role == 26 || $role == 15 || $role == 2) { ?>
            <!--  <li>
        <a href="<?php echo base_url(); ?>hr">
            <i class="fa fa-tasks"></i>
            <span>Applied Leave</span>
        </a>
    </li> -->

          <?php } ?>

        </ul>
      </section>
      <!-- /.sidebar -->
    </aside>

    <style>
      .treeview-menu {
        display: none;
        /* Ensure sub-menu is hidden by default */
      }

      .treeview.active .treeview-menu {
        display: block;
        /* Show sub-menu when parent is active */
      }

      .treeview.active>a {
        background-color: black;
        /* Highlight parent */
        color: #007bff;
        font-weight: bold;
      }

      .treeview-menu li.active a {
        background-color: black;
        /* Highlight sub-item */
        color: #007bff;
        font-weight: bold;
      }

      .treeview .pull-right-container .fa-angle-left {
        transition: transform 0.3s ease;
      }

      .treeview.active .pull-right-container .fa-angle-left {
        transform: rotate(-90deg);
        /* Rotate arrow when open */
      }
    </style>

    <script>
      document.addEventListener('DOMContentLoaded', function() {
        // Select all treeview toggle links
        const treeviewToggles = document.querySelectorAll('.treeview-toggle');
        const subMenuLinks = document.querySelectorAll('.treeview-menu li a');

        // Handle treeview toggle (open/close)
        treeviewToggles.forEach(toggle => {
          toggle.addEventListener('click', function(e) {
            e.preventDefault(); // Prevent default navigation
            const parentTreeview = this.parentElement;
            const isActive = parentTreeview.classList.contains('active');

            // Close all treeviews
            document.querySelectorAll('.treeview').forEach(treeview => {
              treeview.classList.remove('active');
            });

            // Toggle the clicked treeview
            if (!isActive) {
              parentTreeview.classList.add('active');
            }
          });
        });

        // Handle sub-menu item clicks
        subMenuLinks.forEach(link => {
          link.addEventListener('click', function(e) {
            // Remove active class from all sub-menu items
            document.querySelectorAll('.treeview-menu li').forEach(item => {
              item.classList.remove('active');
            });

            // Add active class to clicked sub-menu item
            this.parentElement.classList.add('active');

            // Ensure parent treeview is open and highlighted
            const parentTreeview = this.closest('.treeview');
            if (parentTreeview) {
              parentTreeview.classList.add('active');
            }
          });
        });
      });
    </script>

    <script>
      $(document).ready(function() {
        $('.ajax-link').on('click', function(e) {
          e.preventDefault(); // Prevent default link behavior
          const url = $(this).data('url'); // Get the URL from data attribute

          // Load content via AJAX
          $.ajax({
            url: url,
            type: 'GET',
            success: function(response) {
              $('#main-content').html(response); // Update content area
            },
            error: function(xhr, status, error) {
              console.error('Error loading content:', error);
              // alert('Failed to load Home Work content. Please try again.');
            }
          });
        });
      });
    </script>