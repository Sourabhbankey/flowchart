

    <footer class="main-footer">
        <!--Start of Tawk.to Script-->
        <script type="text/javascript">
            /*var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
            (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/664da12d9a809f19fb3394c4/1hufjr74k';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
            })();*/
            /*--Removed-Branding-from-footer--*/
            /*var removeBranding = function() {
                try {
                    var element = document.querySelector("iframe[title*=chat]:nth-child(2)").contentDocument.querySelector(`a[class*=tawk-branding]`)

                    if (element) {
                        element.remove()
                    }
                } catch (e) {}
            }

            var tick = 100

            setInterval(removeBranding, tick)*/
        /*--Removed-Branding-from-footer--*/
        </script>
<!--End of Tawk.to Script-->
        <div class="pull-right hidden-xs">
          <b>FlowChart</b> | Version 1.0
        </div>
        <strong>Copyright &copy; <script>document.write(new Date().getFullYear())</script> <a href="<?php echo base_url(); ?>">e<span><i>d</i></span>uMETA THE i-SCHOOL</a>.</strong> All rights reserved.
    </footer>
    
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js" type="text/javascript"></script>
    <!-- <script src="<?php echo base_url(); ?>assets/dist/js/pages/dashboard.js" type="text/javascript"></script> -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.validate.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/validation.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap-select.js" type="text/javascript"></script>
    <script type="text/javascript">
        var windowURL = window.location.href;
        pageURL = windowURL.substring(0, windowURL.lastIndexOf('/'));
        var x= $('a[href="'+pageURL+'"]');
            x.addClass('active');
            x.parent().addClass('active');
        var y= $('a[href="'+windowURL+'"]');
            y.addClass('active');
            y.parent().addClass('active');
            $('#franchiseNumber').selectpicker();
    </script>
    <script type="text/javascript">
    // Initialize Bootstrap tooltips
    // Initialize Bootstrap tooltips
    $(function () {
        $('[data-toggle="tooltip"]').tooltip({
            template: '<div class="tooltip custom-tooltip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>'
        });
    });
    /*document.getElementById('offerAmount').addEventListener('input', function (e) {
        // Remove any non-numeric characters (including "e")
        this.value = this.value.replace(/[^0-9]/g, '');
    });*/
    function validateNumericInput(inputId) {
        document.getElementById(inputId).addEventListener('input', function (e) {
            // Remove any non-numeric characters
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }

    // Validate both fields
    validateNumericInput('mobile');
    validateNumericInput('branchAmountReceived');
    validateNumericInput('finalAmount');
    validateNumericInput('offerAmount');
    validateNumericInput('discountAmount');
    validateNumericInput('legalChargesSales');
    validateNumericInput('brSetupinsChargSales');
    validateNumericInput('numInialKitSales');
    validateNumericInput('franchiseTenure');
    validateNumericInput('trainingAmount');
    validateNumericInput('societyServiceamount');
    validateNumericInput('totalAmount');
    validateNumericInput('gstAmount');
    validateNumericInput('amcAmount');
    validateNumericInput('totalfranchisegstFund');
    validateNumericInput('legalCharges');
    validateNumericInput('legalChargesdue');
    validateNumericInput('totalgstCharges');
    validateNumericInput('totalPaidamount');
    validateNumericInput('dueFranchiseamt');
    validateNumericInput('kitCharges');
    validateNumericInput('numinitialKit');
    validateNumericInput('totalKitsamt');
    validateNumericInput('kitamtReceived');
    validateNumericInput('dueKitamount');
    validateNumericInput('finaltotalamtDue');
    validateNumericInput('transporttravCharge');
    validateNumericInput('travelAmount');
    validateNumericInput('receivedtravelAmount');
    validateNumericInput('duetravelAmount');
    validateNumericInput('transportCharges');
    validateNumericInput('transportAmtreceived');
    validateNumericInput('duetransportCharges');
</script>
<script>
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const monthName = monthNames[date.getMonth()];
    const year = date.getFullYear();
    return `${day}-${monthName}-${year}`;
  }

  const input = document.getElementById("dob");

  input.addEventListener("click", () => {
    // Open browser-native date picker using a temporary input[type="date"]
    const tempInput = document.createElement("input");
    tempInput.type = "date";
    tempInput.style.position = "absolute";
    tempInput.style.opacity = 0;
    tempInput.style.pointerEvents = "none";
    document.body.appendChild(tempInput);

    tempInput.focus();
    tempInput.onchange = function () {
      if (this.value) {
        const selectedDate = new Date(this.value);
        input.value = formatDate(selectedDate);
      }
      document.body.removeChild(tempInput);
    };
  });
</script>

<style type="text/css">
    <style type="text/css">
        .cke_notifications_area {
            display: none;
        }
        /* Number Increment/Decrement icon - Hide spinner for Chrome, Safari, Edge */
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        /* Hide spinner for Firefox */
        input[type=number] {
            -moz-appearance: textfield;
        }
        .tooltip {
            display: none;
            position: absolute;
            background-color: #e90101;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 5px;
            z-index: 1;
            bottom: 60%; /* Position the tooltip above the input */
            left: 50%;
            transform: translateX(-50%);
            margin-bottom: 5px;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .form-group:hover .tooltip {
            display: block;
            opacity: 1;
        }
        /*Branch Tooltip with icon*/
        .custom-tooltip {
           /* width: 55%;*/
            word-break: break-all !important;
            height: fit-content;
            text-overflow: ellipsis; /* Add ellipsis for overflow text */
            background-color: #ff000c !important; /* Change to your desired background color */
                color: #fff; /* Change text color for better contrast */
        }
        .custom-tooltip .arrow {
                border-top-color: #007bff; /* Match arrow color to background */
        }
        .cke_notifications_area {
            display: none;
        }
    </style>
  </body>
</html>