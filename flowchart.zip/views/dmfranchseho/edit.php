<?php
$dmfranchsehoId = $dmfranchsehoInfo->dmfranchsehoId;
$dmfranchseTitle = $dmfranchsehoInfo->dmfranchseTitle;
$doneBy = $dmfranchsehoInfo->doneBy;
$numOfLeads = $dmfranchsehoInfo->numOfLeads;
$dateOfrequest = $dmfranchsehoInfo->dateOfrequest;
$CampaStartdate = $dmfranchsehoInfo->CampaStartdate;
$CampaEnddate = $dmfranchsehoInfo->CampaEnddate;
$platform = $dmfranchsehoInfo->platform;
$description = $dmfranchsehoInfo->description;
$dmattachmentS3file = $dmfranchsehoInfo->dmattachmentS3file;
$amount = $dmfranchsehoInfo->amount;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Digital Marketing Franchise Campaign Management
        <small>Add / Edit Digital Marketing Franchise Campaign</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Digital Marketing Franchise Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>dmfranchseho/editDmfranchseho" method="post" id="editDmfranchise" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dmfranchseTitle">Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $dmfranchseTitle; ?>" id="dmfranchseTitle" name="dmfranchseTitle" maxlength="256" />
                                        <input type="hidden" value="<?php echo $dmfranchsehoId; ?>" name="dmfranchsehoId" id="trainingId" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="doneBy">Done By <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="doneBy" name="doneBy" required>
                                            <option value="">Select</option>
                                            <option value="Franchise" <?= ($doneBy == 'Franchise') ? 'selected' : '' ?>>Franchise</option>
                                            <option value="HO" <?= ($doneBy == 'HO') ? 'selected' : '' ?>>H.O.</option>
                                        </select>   
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="numOfLeads">No. Of Leads Generated <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $numOfLeads; ?>" id="numOfLeads" name="numOfLeads" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amount">Amount <span class="re-mend-field">*</span></label>
                                        <input required type="number" step="0.01" class="form-control required" value="<?php echo $amount; ?>" id="amount" name="amount" min="0">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfrequest">Date Of Request <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateOfrequest; ?>" id="dateOfrequest" name="dateOfrequest" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="CampaStartdate">Campaign Start Date <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $CampaStartdate; ?>" id="CampaStartdate" name="CampaStartdate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="CampaEnddate">Campaign End Date <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required" value="<?php echo $CampaEnddate; ?>" id="CampaEnddate" name="CampaEnddate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="platform">Platform <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $platform; ?>" id="platform" name="platform" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4"></div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('dmfranchse/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>