<?php
$agingclsteacherId = $TeacherassignInfo->agingclsteacherId;
$techerId = $TeacherassignInfo->techerId;
$franchiseNumber = $TeacherassignInfo->franchiseNumber;
$className = $TeacherassignInfo->className;
$section = $TeacherassignInfo->section;
$status = $TeacherassignInfo->status;

?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Edit
            <small>Edit Teacher Assignment</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Update Details</h3>
                    </div>

                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>teacherassign/editTeacherassign" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">

                                <!-- Hidden ID -->
                                <input type="hidden" name="agingclsteacherId" value="<?php echo $agingclsteacherId; ?>">

                                <!-- Franchise -->
                                <div class="form-group">
                                        <label for="roomName">Franchise Number</label>
                                       <select class="form-control required" id="franchiseNumber" name="franchiseNumber">
    <option value="">Select Franchise</option>
    <?php foreach ($branchDetail as $branch): ?>
        <option value="<?php echo $branch->franchiseNumber; ?>" 
            <?php echo ($branch->franchiseNumber == $franchiseNumber) ? 'selected' : ''; ?>>
            <?php echo htmlspecialchars($branch->franchiseNumber); ?>
        </option>
    <?php endforeach; ?>
</select>

                                    </div>

                                <!-- Franchise Assigned To -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                        
                                        
                                        <input type="text" class="form-control required" readonly value="<?php echo !empty($brspFranchiseAssigned) ? $brspFranchiseAssigned : 'N/A'; ?>" id="brspFranchiseAssigned" name="brspFranchiseAssigned" maxlength="256" />
                                    </div>
                                </div>

                                <!-- Teacher Dropdown -->
                                 <div class="col-md-4">
                <div class="form-group">
                    <label for="teacherName">Assign Teacher Name <span class="re-mend-field">*</span></label>
                    <select class="form-control" id="teacherName" name="techerId" required>
                        <option value="">Select Teacher</option>
                        <?php foreach ($teacherList as $teacher): ?>
                            <option value="<?php echo $teacher->techerId; ?>" 
                                <?php echo ($teacher->techerId == $record->techerId) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher->teachername); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

                                <!-- Class -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="className">Class <span class="re-mend-field">*</span></label>
                                        <select class="form-control" id="className" name="className" required>
                                            <option value="">Select Class</option>
                                            <?php foreach ($classesList as $class): ?>
                                                <option value="<?php echo $class->classId; ?>" <?php echo ($record->className == $class->classId) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($class->className); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Section -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="sectionName">Section <span class="re-mend-field">*</span></label>
                                        <select class="form-control" id="sectionName" name="sectionName" required>
                                            <option value="">Select Section</option>
                                            <?php foreach ($sectionsList as $section): ?>
                                                <option value="<?php echo $section->sectionId; ?>" <?php echo ($record->section == $section->sectionId) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($section->sectionName); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="status">Status <span class="re-mend-field">*</span></label>
                                        <select class="form-control" name="status" required>
                                            <option value="">Select Status</option>
                                            <option value="Active" <?php echo ($record->status == 'Active') ? 'selected' : ''; ?>>Active</option>
                                            <option value="Inactive" <?php echo ($record->status == 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Update" />
                            <a href="<?php echo base_url('teacherassign/TeacherassignListing'); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <style>
        .re-mend-field { color: red; }
    </style>
</div>

<script>
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssignedDisplay');
        const hiddenInput = document.getElementById('brspFranchiseAssigned');
        assignedDiv.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Loading...';
        hiddenInput.value = '';

        $.post('<?php echo base_url("teacher/fetchAssignedUsers"); ?>', {
            franchiseNumber: franchiseNumber,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        }, function(response) {
            if (response.status === 'success') {
                assignedDiv.innerHTML = response.html;
                hiddenInput.value = response.userIds || '';
            } else {
                assignedDiv.innerHTML = 'No Growth Manager assigned';
            }
        }, 'json');
    }

    function fetchTeachersByFranchise(franchiseNumber, selectedId = '') {
        const dropdown = document.getElementById('teacherName');
        dropdown.innerHTML = '<option value="">Loading...</option>';

        $.post('<?php echo base_url("teacherassign/fetchTeachersByFranchise"); ?>', {
            franchiseNumber: franchiseNumber,
            '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
        }, function(response) {
            if (response.status === 'success') {
                dropdown.innerHTML = '<option value="">Select Teacher</option>';
                response.teachers.forEach(function(teacher) {
                    const option = document.createElement('option');
                    option.value = teacher.techerId;
                    option.text = teacher.teachername;
                    if (teacher.techerId == selectedId) {
                        option.selected = true;
                    }
                    dropdown.appendChild(option);
                });
            } else {
                dropdown.innerHTML = '<option value="">No teachers found</option>';
            }
        }, 'json');
    }
</script>
