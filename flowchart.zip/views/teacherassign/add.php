<div class="content-wrapper">
    <teacher class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Add
            <small>Add / Edit teacher</small>
        </h1>
    </teacher>

    <teacher class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div>

                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>teacherassign/addNewTeacherassign" enctype="multipart/form-data" method="post">
                        <div class="box-body">
                            <div class="row">

                                <!-- Franchise Field -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber"
                                                value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                            <script>
                                                document.addEventListener('DOMContentLoaded', function () {
                                                    const franchiseNumber = '<?php echo $this->session->userdata("franchiseNumber"); ?>';
                                                    fetchAssignedFranchise(franchiseNumber);
                                                    fetchTeachersByFranchise(franchiseNumber);
                                                });
                                            </script>
                                        <?php } else { ?>
                                            <select class="form-control" id="franchiseNumber" name="franchiseNumber" required onchange="fetchAssignedFranchise(this.value); fetchTeachersByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>">
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>

                                <!-- Franchise Assigned To -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                        <div id="brspFranchiseAssignedDisplay" class="form-control" style="height: auto; min-height: 34px;">
                                            <span>Select a franchise to assign</span>
                                        </div>
                                        <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssigned">
                                    </div>
                                </div>

                                <!-- Teacher Name Dropdown -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="teacherName">Assign Teacher Name <span class="re-mend-field">*</span></label>
                                        <select class="form-control" id="teacherName" name="techerId" required>
                                            <option value="">Select Teacher</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Class -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="className">Class <span class="re-mend-field">*</span></label>
                                        <select required class="form-control" id="className" name="className">
                                            <option value="">Select Class</option>
                                            <?php foreach ($classesList as $class): ?>
                                                <option value="<?php echo $class->classId; ?>" <?php echo set_select('className', $class->classId); ?>>
                                                    <?php echo htmlspecialchars($class->className); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Section -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="sectionName">Section <span class="re-mend-field">*</span></label>
                                        <select required class="form-control" id="sectionName" name="sectionName">
                                            <option value="">Select Section</option>
                                            <?php foreach ($sectionsList as $section): ?>
                                                <option value="<?php echo $section->sectionId; ?>" <?php echo set_select('sectionName', $section->sectionId); ?>>
                                                    <?php echo htmlspecialchars($section->sectionName); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- Status -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="teacherStatus">Status <span class="re-mend-field">*</span></label>
                                        <select required class="form-control" name="status" id="teacherStatus">
                                            <option value="">Select Status</option>
                                            <option value="Active" <?php echo set_select('status', 'Active'); ?>>Active</option>
                                            <option value="Inactive" <?php echo set_select('status', 'Inactive'); ?>>Inactive</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <!-- Flash Messages -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                    $success = $this->session->flashdata('success');
                    if($success) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </teacher>

    <style>
        .re-mend-field {
            color: red;
        }
    </style>
</div>

<!-- JS Scripts -->
<script>
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssignedDisplay');
        const hiddenInput = document.getElementById('brspFranchiseAssigned');
        assignedDiv.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Loading...';
        hiddenInput.value = '';

        if (!franchiseNumber) {
            assignedDiv.innerText = 'Select a franchise to assign';
            return;
        }

        $.ajax({
            url: '<?php echo base_url("teacher/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success' && response.html) {
                    assignedDiv.innerHTML = response.html;
                    hiddenInput.value = response.userIds || '';
                } else {
                    assignedDiv.innerText = 'No Growth Manager assigned';
                    hiddenInput.value = '';
                    alert(response.message || 'No Growth Manager found');
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                assignedDiv.innerText = 'Error fetching data';
                hiddenInput.value = '';
            }
        });
    }

    function fetchTeachersByFranchise(franchiseNumber) {
        const teacherDropdown = document.getElementById('teacherName');
        teacherDropdown.innerHTML = '<option value="">Loading...</option>';

        $.ajax({
            url: '<?php echo base_url("teacherassign/fetchTeachersByFranchise"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                teacherDropdown.innerHTML = '<option value="">Select Teacher</option>';
                if (response.status === 'success') {
                    response.teachers.forEach(function(teacher) {
                        const option = document.createElement('option');
                        option.value = teacher.techerId;
                        option.text = teacher.teachername;
                        teacherDropdown.appendChild(option);
                    });
                } else {
                    alert(response.message || 'No teachers found');
                }
            },
            error: function(xhr) {
                alert('Error fetching teachers');
                console.error(xhr.responseText);
            }
        });
    }

    // Prevent double submission
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');
    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault();
            return;
        }
        submitBtn.disabled = true;
        submitBtn.innerText = 'Submitting...';
    });
</script>
