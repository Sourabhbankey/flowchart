<?php //echo $this->session->userdata('franchiseNumber'); exit; 
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Legal Attachment Management
            <small>Add / Edit Attachment</small>
        </h1>
    </section>
    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Attachment / Upload File Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>lgattachment/addNewLgattachment" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="lgattachmentTitle">Attachment Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('lgattachmentitle'); ?>" id="lgattachmentTitle" name="lgattachmentTitle" maxlength="256" />
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="attachmentType">Attachment Type <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="attachmentType" name="attachmentType" required onchange="toggleOtherField()">
                                            <option value="">Select Attachment Type</option>
                                            <option value="Agreement Draft">Agreement Draft</option>
                                            <option value="Final Agreement">Final Agreement</option>
                                            <option value="Franchise License">Franchise License</option>
                                            <option value="Rent agreement">Rent agreement</option>
                                            <option value="Electricity bill">Electricity bill</option>
                                            <option value="Bank ac">Bank ac details(branch)</option>
                                            <option value="Property tax receipt">Property tax receipt</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="form-group" id="otherAttachmentTypeField" style="display: none;">
                                        <label for="otherAttachmentType">Specify Other Attachment Type <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control" id="otherAttachmentType" name="otherAttachmentType" maxlength="256" placeholder="Enter custom attachment type">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="acattachmentTitle">Upload File <span class="re-mend-field">*</span></label>
                                    <input required type="file" name="file" multiple>
                                </div>

                            </div>
                            <!--  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                     <option value="<?php echo $franchiseNumber; ?>" ><?php echo $franchiseNumber; ?></option>
                                                    <?php

                                                }
                                            }
                                                    ?>         
                                        </select>
                                    </div>
                                    
                                </div> -->
                            <?php if ($role != 25) { ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <!-- Franchise users: Non-editable field -->
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: ''; // Use session franchise number or empty
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                        <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                            <span>Select a franchise to assign</span>
                                        </div>
                                        <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                    </div>
                                </div>
                            <?php } else { ?>
                                <!-- Hidden input for role 25 to pass franchiseNumber -->
                                <input type="hidden" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>">
                            <?php } ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="description">Remark - Short Description <span class="re-mend-field">*</span></label>
                                    <textarea required class="form-control required" id="description" name="description"></textarea>
                                </div>
                            </div>
                        </div>
                </div><!-- /.box-body -->

                <div class="box-footer">
                    <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                    <input type="reset" class="btn btn-default" value="Reset" />
                </div>
                </form>
            </div>
        </div>
        <div class="col-md-4">
            <?php
            $this->load->helper('form');
            $error = $this->session->flashdata('error');
            if ($error) {
            ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
            <?php } ?>
            <?php
            $success = $this->session->flashdata('success');
            if ($success) {
            ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php } ?>

            <div class="row">
                <div class="col-md-12">
                    <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                </div>
            </div>
        </div>
</div>
</section>
<style type="text/css">
    .re-mend-field {
        color: red;
    }
</style>
</div>

<script>
    function fetchAssignedFranchise(franchiseNumber) {
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("admenquiry/fetchAssignedUsers"); ?>', // Update to match your controller and method
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber
                },
                success: function(response) {
                    $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    alert('Error fetching data');
                }
            });
        } else {
            $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
        }
    }
</script>


<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });

    // Updated fetchAssignedFranchise function to fetch Growth Manager's name
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue'); // Reference hidden input
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.html) {
                        assignedDiv.innerHTML = response.html; // Display Growth Manager's name(s)
                        hiddenInput.value = response.userIds || ''; // Set hidden input to userIds
                    } else {
                        assignedDiv.innerText = 'No Growth Manager assigned';
                        hiddenInput.value = ''; // Clear hidden input
                        alert(response.message || 'No Growth Manager found for this franchise');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    assignedDiv.innerText = 'Error fetching Growth Manager';
                    hiddenInput.value = ''; // Clear hidden input
                    alert('Error fetching Growth Manager data');
                }
            });
        } else {
            assignedDiv.innerText = 'Select a franchise to assign';
            hiddenInput.value = ''; // Clear hidden input
        }
    }

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        // For dropdown (non-readonly, roles other than 25)
        if (franchiseInput && franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }

        // For readonly input (role 25)
        if (franchiseInput && franchiseInput.readOnly) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        const dobInput = document.getElementById('birthday');
        const ageInput = document.getElementById('age');

        dobInput.addEventListener('change', function() {
            const dob = new Date(this.value);
            const today = new Date();

            if (isNaN(dob)) return;

            // If DOB is in the future, treat age as 0
            if (dob > today) {
                ageInput.value = "0 Year - 0 Months - 0 Days";
                return;
            }

            let years = today.getFullYear() - dob.getFullYear();
            let months = today.getMonth() - dob.getMonth();
            let days = today.getDate() - dob.getDate();

            if (days < 0) {
                months--;
                const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
                days += prevMonth.getDate();
            }

            if (months < 0) {
                years--;
                months += 12;
            }

            // Ensure no negative values even in edge cases
            years = Math.max(0, years);
            months = Math.max(0, months);
            days = Math.max(0, days);

            const ageStr = `${years} Year - ${months} Months - ${days} Days`;
            ageInput.value = ageStr;
        });
    });
</script>
<script>
    // Function to toggle the "Other" attachment type field
function toggleOtherField() {
    const attachmentType = document.getElementById('attachmentType').value;
    const otherField = document.getElementById('otherAttachmentTypeField');
    const otherInput = document.getElementById('otherAttachmentType');

    if (attachmentType === 'Other') {
        otherField.style.display = 'block';
        otherInput.setAttribute('required', 'required'); // Make the field required
    } else {
        otherField.style.display = 'none';
        otherInput.removeAttribute('required'); // Remove required attribute
        otherInput.value = ''; // Clear the input field
    }
}

// Form validation to ensure "Other" attachment type is filled
document.getElementById('yourForm').addEventListener('submit', function(e) {
    const attachmentType = document.getElementById('attachmentType').value;
    const otherInput = document.getElementById('otherAttachmentType');

    if (attachmentType === 'Other' && !otherInput.value.trim()) {
        e.preventDefault(); // Prevent form submission
        alert('Please specify the custom attachment type.');
        otherInput.focus();
        document.getElementById('submitBtn').disabled = false; // Re-enable submit button
        document.getElementById('submitBtn').innerText = 'Submit'; // Reset button text
    }
});
</script>