<?php
$lgattachmentId = $lgattachmentInfo->lgattachmentId;
$lgattachmentTitle = $lgattachmentInfo->lgattachmentTitle;
$attachmentType = $lgattachmentInfo->attachmentType;
$description = $lgattachmentInfo->description;

// Get current user role
$roleId = $this->session->userdata('role');
?>

<div class="content-wrapper">
    <!-- Content Header -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Legal Attachment Management
            <small>Add / Edit Attachment</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- Left column -->
            <div class="col-md-8">

                <?php if (in_array($roleId, [1, 14, 24])) { ?>
                    <!-- Edit form shown only for roles 1, 14, 24 -->
                    <div class="box box-primary">
                        <div class="box-header">
                            <h3 class="box-title">Attachment / Upload File Details</h3>
                        </div>

                        <form role="form" action="<?php echo base_url() ?>lgattachment/editLgattachment" method="post" id="editLgattachment">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">                                
                                        <div class="form-group">
                                            <label for="lgattachmentTitle">Attachment Title <span class="re-mend-field">*</span></label>
                                            <input required type="text" class="form-control" value="<?php echo $lgattachmentTitle; ?>" id="lgattachmentTitle" name="lgattachmentTitle" maxlength="256" />
                                            <input type="hidden" value="<?php echo $lgattachmentId; ?>" name="lgattachmentId" id="lgattachmentId" />
                                        </div>
                                    </div>

                                    <div class="col-md-6"> 
                                        <div class="form-group">
                                            <label for="attachmentType">Attachment Type <span class="re-mend-field">*</span></label>
                                            <select class="form-control" id="attachmentType" name="attachmentType" required>
                                                <option value="">Select Type</option>
                                                <option value="Agreement Draft" <?php echo ($attachmentType == 'Agreement Draft') ? 'selected' : ''; ?>>Agreement Draft</option>
                                                <option value="Final Agreement" <?php echo ($attachmentType == 'Final Agreement') ? 'selected' : ''; ?>>Final Agreement</option>
                                                <option value="Franchise License" <?php echo ($attachmentType == 'Franchise License') ? 'selected' : ''; ?>>Franchise License</option>
                                                <option value="Rent agreement" <?php echo ($attachmentType == 'Rent agreement') ? 'selected' : ''; ?>>Rent agreement</option>
                                                <option value="Electricity bill" <?php echo ($attachmentType == 'Electricity bill') ? 'selected' : ''; ?>>Electricity bill</option>
                                                <option value="Bank ac" <?php echo ($attachmentType == 'Bank ac') ? 'selected' : ''; ?>>Bank ac details(branch)</option>
                                                <option value="Property tax receipt" <?php echo ($attachmentType == 'Property tax receipt') ? 'selected' : ''; ?>>Property tax receipt</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="description">Description <span class="re-mend-field">*</span></label>
                                            <textarea required class="form-control" id="description" name="description" rows="4"><?php echo $description; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="box-footer">
                                <input type="submit" class="btn btn-primary" value="Submit" />
                                <input type="reset" class="btn btn-default" value="Reset" />
                            </div>
                        </form>
                    </div>
                <?php } ?>

                <!-- Reply Section (Always visible) -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Add Reply</h3>
                    </div>

                    <form role="form" action="<?php echo base_url(); ?>lgattachment/addReply" method="post" id="replyForm">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="replyText">Your Reply <span class="re-mend-field">*</span></label>
                                <textarea required class="form-control" id="replyText" name="replyText" rows="5" placeholder="Write your reply here..."></textarea>
                            </div>
                            <input type="hidden" name="lgattachmentId" value="<?php echo $lgattachmentId; ?>">
                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-success" value="Submit Reply" />
                        </div>
                    </form>
                </div>

                <!-- Previous Replies -->
                <div class="box box-info" style="margin-top:20px;">
                    <div class="box-header">
                        <h3 class="box-title">Previous Replies</h3>
                    </div>

                    <div class="box-body">
                        <?php if (!empty($replyList)) { ?>
                            <?php foreach ($replyList as $reply) { ?>
                                <div class="reply-item" style="border-bottom: 1px solid #eee; padding: 10px 0;">
                                    <p><strong><?php echo htmlspecialchars($reply->addedByName); ?></strong> 
                                    <small style="color: #888;"><?php echo date('d-m-Y H:i', strtotime($reply->createdDtm)); ?></small></p>
                                    <p><?php echo nl2br(htmlspecialchars($reply->replyText)); ?></p>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <p>No replies yet.</p>
                        <?php } ?>
                    </div>
                </div>

            </div>

            <!-- Right column -->
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>                    
                    </div>
                <?php } ?>

                <?php  
                    $success = $this->session->flashdata('success');
                    if($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
