
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <teacher class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Add 
        <small>Add / Edit teacher</small>
      </h1>
    </teacher>
    
    <teacher class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>teacher/addNewteacher" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <!-- Franchise users: Non-editable field -->
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: ''; // Use session franchise number or empty
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                            <div id="brspFranchiseAssignedDisplay" class="form-control" style="height: auto; min-height: 34px;">
                                                <span>Select a franchise to assign</span>
                                            </div>
                                           <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssigned">
                                        </div>
                                    </div>
                               
                            </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="giftTitle">teacher <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('teacherName'); ?>" id="teacherName" name="teacherName" maxlength="256" />
                                    </div>
                                </div>
                               
                        <div class="col-md-4">                                
    <div class="form-group">
        <label for="teacherStatus">Status <span class="re-mend-field">*</span></label>
        <select required class="form-control" name="status" id="teacherStatus">
            <option value="">Select Status</option>
            <option value="Active" <?php echo set_select('status', 'Active'); ?>>Active</option>
            <option value="Inactive" <?php echo set_select('status', 'Inactive'); ?>>Inactive</option>
        </select>
    </div>
</div>

                               
                                
                                
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </teacher>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>

<script>
  function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssignedDisplay');
        const hiddenInput = document.getElementById('brspFranchiseAssigned');

        // Set loading state
        assignedDiv.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Loading...';
        hiddenInput.value = '';

        if (!franchiseNumber) {
            assignedDiv.innerText = 'Select a franchise to assign';
            console.warn('No franchiseNumber provided');
            return;
        }

        console.log('Fetching Growth Manager for franchiseNumber:', franchiseNumber);

        $.ajax({
            url: '<?php echo base_url("teacher/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                console.log('Server Response:', response);
                if (response.status === 'success' && response.html) {
                    assignedDiv.innerHTML = response.html; // Update with Growth Manager's name
                    hiddenInput.value = response.userIds || ''; // Update hidden input
                    console.log('Updated UI with:', response.html, 'and userIds:', response.userIds);
                } else {
                    assignedDiv.innerText = 'No Growth Manager assigned';
                    hiddenInput.value = '';
                    console.warn('No valid data in response:', response.message);
                    alert(response.message || 'No Growth Manager found for this franchise');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                console.error('Response Text:', xhr.responseText);
                assignedDiv.innerText = 'Error fetching Growth Manager';
                hiddenInput.value = '';
                alert('Failed to fetch Growth Manager data. Please try again.');
            }
        });
    }
    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        if (!franchiseInput) {
            console.error('Franchise input element not found');
            return;
        }

        // Handle dropdown (non-readonly, roles other than 25)
        if (franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            console.log('Initializing dropdown with value:', franchiseInput.value);
            fetchAssignedFranchise(franchiseInput.value);
        }

        // Handle readonly input (role 25)
        if (franchiseInput.readOnly && franchiseInput.value) {
            console.log('Initializing readonly input with value:', franchiseInput.value);
            fetchAssignedFranchise(franchiseInput.value);
        }
    });
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>