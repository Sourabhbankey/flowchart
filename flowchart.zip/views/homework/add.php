
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <subject class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Add 
        <small>Add / Edit subject</small>
      </h1>
    </subject>
    
    <subject class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>homework/addNewHomework" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                       <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                                <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                    <option value="">Select Franchise</option>
                                                    <?php
                                                    if (!empty($branchDetail)) {
                                                        foreach ($branchDetail as $bd) {
                                                            $franchiseNumber = $bd->franchiseNumber;
                                                            ?>
                                                            <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                                 
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                                <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                                    <option value="0">Select Role</option>
                                                </select>
                                            </div>
                                        </div>

                              <div class="col-md-4">                                
    <div class="form-group">
        <label for="subjectName">Subject Name <span class="re-mend-field">*</span></label>
        <select required class="form-control" id="subjectName" name="subjectName">
            <option value="">Select Subject</option>
            <?php if (!empty($subjects)) {
                foreach ($subjects as $subject) { ?>
                    <option value="<?php echo $subject->subjectName; ?>" <?php echo set_select('subjectName', $subject->subjectName); ?>>
                        <?php echo $subject->subjectName; ?>
                    </option>
            <?php }} ?>
        </select>
    </div>
</div>
                                <div class="col-md-4">                                
    <div class="form-group">
        <label for="subjectName">Section Name <span class="re-mend-field">*</span></label>
        <select required class="form-control" id="sectionName" name="section_name">
            <option value="">Select Subject</option>
            <?php if (!empty($sections)) {
                foreach ($sections as $section) { ?>
                    <option value="<?php echo $section->sectionName; ?>" <?php echo set_select('sectionName', $section->sectionName); ?>>
                        <?php echo $section->sectionName; ?>
                    </option>
            <?php }} ?>
        </select>
    </div>
</div>
                               
                                <div class="col-md-4">                                
    <div class="form-group">
        <label for="subjectName">Class Name <span class="re-mend-field">*</span></label>
        <select required class="form-control" id="className" name="class_name">
            <option value="">Select Class</option>
            <?php if (!empty($classes)) {
                foreach ($classes as $classs) { ?>
                    <option value="<?php echo $classs->className; ?>" <?php echo set_select('className', $classs->className); ?>>
                        <?php echo $classs->className; ?>
                    </option>
            <?php }} ?>
        </select>
    </div>
</div>
                               
                  <!-- Homework Date -->
<div class="col-md-4">
    <div class="form-group">
        <label for="date_of_homework">Homework Date</label>
        <input type="date" class="form-control" name="date_of_homework" id="date_of_homework" value="<?php echo set_value('date_of_homework'); ?>">
    </div>
</div>

<!-- Submission Date -->
<div class="col-md-4">
    <div class="form-group">
        <label for="date_of_submission">Submission Date</label>
        <input type="date" class="form-control" name="date_of_submission" id="date_of_submission" value="<?php echo set_value('date_of_submission'); ?>">
    </div>
</div>

<!-- Schedule Date -->
<div class="col-md-4">
    <div class="form-group">
        <label for="schedule_date">Schedule Date</label>
        <input type="date" class="form-control" name="schedule_date" id="schedule_date" value="<?php echo set_value('schedule_date'); ?>">
    </div>
</div>

<!-- Homework Description -->
<div class="col-md-12">
    <div class="form-group">
        <label for="homework_description">Homework Description</label>
        <textarea class="form-control" name="homework_description" id="homework_description" rows="4"><?php echo set_value('homework_description'); ?></textarea>
    </div>
</div>

<!-- File Upload -->
<div class="col-md-6">
    <div class="form-group">
        <label for="homeS3attachment_file">Upload Attachment</label>
        <input type="file" class="form-control" name="homeS3attachment_file" id="homeS3attachment_file">
    </div>
</div>

<!-- SMS Notification -->
<div class="col-md-2">
    <div class="form-group">
        <label for="sms_notification">Send SMS?</label><br>
        <input type="checkbox" name="sms_notification" id="sms_notification" value="1" <?php echo set_checkbox('sms_notification', '1'); ?>>
    </div>
</div>

<!-- Evaluation Date -->
<div class="col-md-4">
    <div class="form-group">
        <label for="evaluation_date">Evaluation Date</label>
        <input type="date" class="form-control" name="evaluation_date" id="evaluation_date" value="<?php echo set_value('evaluation_date'); ?>">
    </div>
</div>

<!-- Evaluated By -->
<div class="col-md-4">
    <div class="form-group">
        <label for="evaluated_by">Evaluated By</label>
        <input type="text" class="form-control" name="evaluated_by" id="evaluated_by" value="<?php echo set_value('evaluated_by'); ?>">
    </div>
</div>
      

                               
                                
                                
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </subject>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>

<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("freegift/fetchAssignedUsers"); ?>', // Update to match your controller and method
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
        $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
    }
}
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("homework/fetchAssignedUsers"); ?>',
            type: 'POST',
            dataType: 'json',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                // Populate the manager dropdown
                $('#branchFranchiseAssigned').html(response.managerOptions);

                // Set franchise name in text input
                $('#franchiseName').val(response.franchiseName);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                console.error("Response Text:", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
        $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
        $('#franchiseName').val('');
    }
}

</script>