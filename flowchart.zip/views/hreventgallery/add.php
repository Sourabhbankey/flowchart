<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> HR Event Gallery
            <small>Add / Edit</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter HR Event Gallery Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addHreventgallery" action="<?php echo base_url() ?>hreventgallery/addNewHreventgallery" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="eventName">Event Name</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('eventName'); ?>" id="eventName" name="eventName" maxlength="255" required />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="eventDate">Event Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('eventDate'); ?>" id="eventDate" name="eventDate" required />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="venue">Venue</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('venue'); ?>" id="venue" name="venue" maxlength="255" required />
                                    </div>
                                </div>
                             <div class="col-md-6">                                
    <div class="form-group">
        <label for="eventS3attachment">Image Attachments (in ZIP Format)</label>
        <input type="file" name="files[]" class="form-control" multiple /> 
    </div>
</div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="eventvideoS3attachment">Video Attachments (in zip Format)</label>
                                        <input type="file" name="file2" class="form-control" multiple />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="6"><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-3">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $error; ?>
                        </div>
                <?php endif; ?>

                <?php
                    $success = $this->session->flashdata('success');
                    if($success): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $success; ?>
                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
    </body>
</html>



<?php