<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Blog Management
            <small>Add Blog</small>
        </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Blog Details</h3>
                    </div>
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>blog/addNewBlog" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="blogTitle">Blog Title <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('blogTitle'); ?>" id="blogTitle" name="blogTitle" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="publishedDate">Published Date <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('publishedDate'); ?>" id="publishedDate" name="publishedDate" required>
                                    </div>   
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="publishedPlatform">Published Platform <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="publishedPlatform" name="publishedPlatform[]" multiple required>
                                            <option value="Medium" <?php echo set_select('publishedPlatform', 'Medium'); ?>>Medium</option>
                                            <option value="Quora" <?php echo set_select('publishedPlatform', 'Quora'); ?>>Quora</option>
                                            <option value="Tumblr" <?php echo set_select('publishedPlatform', 'Tumblr'); ?>>Tumblr</option>
                                            <option value="FlipBoard" <?php echo set_select('publishedPlatform', 'FlipBoard'); ?>>FlipBoard</option>
                                            <option value="Blogger" <?php echo set_select('publishedPlatform', 'Blogger'); ?>>Blogger</option>
                                            <option value="LiveJournal" <?php echo set_select('publishedPlatform', 'LiveJournal'); ?>>LiveJournal</option>
                                            <option value="SubStack" <?php echo set_select('publishedPlatform', 'SubStack'); ?>>SubStack</option>
                                            <option value="Vocal" <?php echo set_select('publishedPlatform', 'Vocal'); ?>>Vocal</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="blogS3Image">Upload Thumbnail Image <span class="re-mend-field">*</span></label>
                                        <input type="file" class="form-control required" id="blogS3Image" name="file" required>
                                       
                                    </div>   
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="blogLink">Blog Link <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('blogLink'); ?>" id="blogLink" name="blogLink" maxlength="256" required>
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description" required><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" id="submitBtn" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>                    
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field { color: red; }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#publishedPlatform').select2();

            // Disable submit button on form submission
            const form = document.getElementById('yourForm');
            const submitBtn = document.getElementById('submitBtn');
            form.addEventListener('submit', function (e) {
                if (submitBtn.disabled) {
                    e.preventDefault();
                    return;
                }
                submitBtn.disabled = true;
                submitBtn.value = 'Submitting...';
            });

            // Image preview
            $('#blogS3Image').on('change', function(event) {
                const file = event.target.files[0];
                if (file && file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const preview = $('<img>', {
                            src: e.target.result,
                            class: 'img-preview',
                            style: 'max-width: 200px; margin-top: 10px;'
                        });
                        $('#blogS3Image').after(preview);
                        $('.img-preview').not(':last').remove();
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
    </script>
</div>