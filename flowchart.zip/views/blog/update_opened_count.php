<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['blogId']) && isset($_POST['openedCount'])) {
        $blogId = $_POST['blogId'];
        $openedCount = $_POST['openedCount'];

        // Assuming you have a database connection set up
        $query = "UPDATE blogs SET openedCount = ? WHERE blogId = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$openedCount, $blogId]);

        echo "Opened count updated successfully";
    }
}
?>
