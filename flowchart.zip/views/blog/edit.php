<?php
$blogId = $blogInfo->blogId;
$blogTitle = $blogInfo->blogTitle;
$blogLink = $blogInfo->blogLink;
$publishedDate = $blogInfo->publishedDate;
$publishedPlatform = $blogInfo->publishedPlatform;
$description = $blogInfo->description;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Blog Management
        <small>Add / Edit Blog</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Blog Details Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>blog/editBlog" method="post" id="editBlog" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="blogTitle">Blog Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $blogTitle; ?>" id="blogTitle" name="blogTitle" maxlength="256" />
                                        <input type="hidden" value="<?php echo $blogId; ?>" name="blogId" id="blogId" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="blogId">Blog Link <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo $blogLink; ?>" id="blogLink" name="blogLink" maxlength="256" />
                                        
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="publishedDate">Published Date <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $publishedDate; ?>" id="publishedDate" name="publishedDate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">                                
                                    <?php
                                          $selectedPlatforms = is_array($publishedPlatform) ? $publishedPlatform : explode(',', $publishedPlatform);
                                    ?>
                                    <div class="form-group">
                                        <label for="blogId">Published Platform <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="publishedPlatform" name="publishedPlatform[]" multiple required>
                                            <?php foreach(['Medium', 'Quora', 'Tumblr', 'FlipBoard', 'Blogger', 'LiveJournal', 'SubStack', 'Vocal'] as $platform): ?>
                                                <option value="<?php echo $platform; ?>" <?php echo in_array($platform, $selectedPlatforms) ? 'selected' : ''; ?>>
                                                    <?php echo $platform; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #e72f05 !important;
            border: 1px solid #8b8787 !important;
        }
        .select2-container--default .select2-selection--multiple .select2-selection__choice__remove{
            color: #fff !important;
        }
    </style>
</div>
<script>
    $(document).ready(function() {
        $('#publishedPlatform').select2();
    });
</script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>