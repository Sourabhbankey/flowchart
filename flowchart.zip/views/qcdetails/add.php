<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> QC Details
            <!-- <small>Add / Edit</small> -->
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter QC Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addEmpReliev" action="<?php echo base_url() ?>qcdetails/addNewQcdetails" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- New-Code -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseName">Franchise Name</label>
                                        <input type="text" class="form-control" id="franchiseName" name="franchiseName" readonly>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                        <select class="form-control required" id="branchFranchiseAssigned" name="branchFranchiseAssigned">
                                            <option value="0">Select Role</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseName">Franchise location</label>
                                        <input type="text" class="form-control" id="branchLocAddressPremise" name="branchLocation" readonly>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateOfInspection">Date of Inspection</label>
                                        <input type="date" class="form-control" id="date_of_inspection" name="date_of_inspection">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="date_of_installation">Date of Installation</label>
                                        <input type="date" class="form-control" id="date_of_installation" name="date_of_installation">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label>Attended by:</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="attended_by_owner" name="attended_by_owner" value="Owner">
                                        <label class="form-check-label" for="attended_by_owner">Owner</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" id="attended_by_admin" name="attended_by_admin" value="Admin">
                                        <label class="form-check-label" for="attended_by_admin">Admin</label>
                                    </div>
                                </div>

                                <hr>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="strength_playgroup">Playgroup</label>
                                        <input type="number" class="form-control" id="strength_playgroup" name="strength_playgroup" min="0">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="strength_nursery">Nursery</label>
                                        <input type="number" class="form-control" id="strength_nursery" name="strength_nursery" min="0">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="strength_kg1">KG 1</label>
                                        <input type="number" class="form-control" id="strength_kg1" name="strength_kg1" min="0">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="strength_kg2">KG 2</label>
                                        <input type="number" class="form-control" id="strength_kg2" name="strength_kg2" min="0">
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dayCare">Day Care</label>
                                        <input type="text" class="form-control" id="day_care" name="day_care">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="eveningClass">Evening Class</label>
                                        <input type="text" class="form-control" id="evening_class" name="evening_class">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="classes_running_till">Classes Running Till</label>
                                        <select class="form-control" id="classes_running_till" name="classes_running_till">
                                            <option value="">Select</option>
                                            <option value="Playgroup">Playgroup</option>
                                            <option value="Nursery">Nursery</option>
                                            <option value="KG 1">KG 1</option>
                                            <option value="KG 2">KG 2</option>
                                            <option value="Grade 1">Grade 1</option>
                                            <option value="2nd">2nd</option>
                                            <option value="3rd">3rd</option>
                                            <option value="4th">4th</option>
                                            <option value="5th">5th</option>
                                            <option value="6th">6th</option>
                                            <option value="7th">7th</option>
                                            <option value="8th">8th</option>
                                            <option value="9th">9th</option>
                                            <option value="10th">10th</option>
                                            <option value="11th">11th</option>
                                            <option value="12th">12th</option>
                                            <!-- Add more as needed -->
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label>Front Branding:</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="frontBrandingYes" name="front_branding" value="yes">
                                        <label class="form-check-label" for="frontBrandingYes">Yes</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="frontBrandingNo" name="front_branding" value="no">
                                        <label class="form-check-label" for="frontBrandingNo">No</label>
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <label>Uniform Condition OK?</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="uniformYes" name="uniform_condition_ok" value="yes">
                                        <label class="form-check-label" for="uniformYes">Yes</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="uniformNo" name="uniform_condition_ok" value="no">
                                        <label class="form-check-label" for="uniformNo">No</label>
                                    </div>
                                    <div class="form-group mt-2">
                                        <label for="uniformRemarks">If No, specify remarks</label>
                                        <textarea class="form-control" id="uniformRemarks" name="uniform_condition_remarks" rows="2"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label>Status:</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="statusNormal" name="status" value="Normal">
                                        <label class="form-check-label" for="statusNormal">Normal</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="statusSuspicious" name="status" value="Suspicious">
                                        <label class="form-check-label" for="statusSuspicious">Suspicious</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label>Books and Curriculum OK?</label><br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="booksYes" name="books_curriculum_ok" value="yes">
                                        <label class="form-check-label" for="booksYes">Yes</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" id="booksNo" name="books_curriculum_ok" value="no">
                                        <label class="form-check-label" for="booksNo">No</label>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="inappropriatePoints">Any Other Points Found Inappropriate</label>
                                        <textarea class="form-control" id="other_inappropriate_points" name="other_inappropriate_points" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="meetingMinutesClient">Meeting Completion / Minutes of the Meeting (for Client)</label>
                                        <textarea class="form-control" id="meeting_minutes_client" name="meeting_minutes_client" rows="4"></textarea>
                                    </div>
                                </div>
                                <!-- New-Code -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="6"><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File</label>
                                        <input type="file" name="file[]" multiple>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload ScreenShot</label>
                                        <input type="file" name="file1[]" multiple>
                                    </div>

                                </div>

                            </div>
                            <div class="box-footer">
                                <input type="submit" class="btn btn-primary" value="Submit" />
                                <input type="reset" class="btn btn-default" value="Reset" />
                            </div>
                    </form>
                </div>
            </div>

            <div class="col-md-3">
                <?php
                $error = $this->session->flashdata('error');
                if ($error): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <?php
                $success = $this->session->flashdata('success');
                if ($success): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
<script>
    function fetchAssignedFranchise(franchiseNumber) {
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("Qcdetails/fetchAssignedUsers"); ?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    franchiseNumber: franchiseNumber
                },
                success: function(response) {
                    // Populate the manager dropdown
                    $('#branchFranchiseAssigned').html(response.managerOptions);
                    $('#branchFranchiseAssigned option[value="0"]').remove();
                    // Set franchise name in text input
                    $('#franchiseName').val(response.franchiseName);
                    $('#branchLocAddressPremise').val(response.branchLocAddressPremise);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", status, error);
                    console.error("Response Text:", xhr.responseText);
                    alert('Error fetching data');
                }
            });
        } else {
            $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
            $('#franchiseName').val('');
            $('#branchLocAddressPremise').val('');
        }
    }
</script>
</body>

</html>