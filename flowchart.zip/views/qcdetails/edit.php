<?php
$qcId = $qcdetailsInfo->qcId;
$franchiseName = $qcdetailsInfo->franchiseName;
$franchiseNumber = $qcdetailsInfo->franchiseNumber;
$branchLocation = $qcdetailsInfo->branchLocation;

$date_of_inspection = $qcdetailsInfo->date_of_inspection;
$date_of_installation = $qcdetailsInfo->date_of_installation;
$attended_by_owner = $qcdetailsInfo->attended_by_owner;
$attended_by_admin = $qcdetailsInfo->attended_by_admin;
$strength_playgroup = $qcdetailsInfo->strength_playgroup;


$strength_nursery = $qcdetailsInfo->strength_nursery;
$strength_kg1 = $qcdetailsInfo->strength_kg1;
$strength_kg2 = $qcdetailsInfo->strength_kg2;
$day_care = $qcdetailsInfo->day_care;
$evening_class = $qcdetailsInfo->evening_class;

$classes_running_till = $qcdetailsInfo->classes_running_till;
$front_branding = $qcdetailsInfo->front_branding;
$status = $qcdetailsInfo->status;
$uniform_condition_ok = $qcdetailsInfo->uniform_condition_ok;
$uniform_condition_remarks = $qcdetailsInfo->uniform_condition_remarks;
$books_curriculum_ok = $qcdetailsInfo->books_curriculum_ok;
$meeting_minutes_client = $qcdetailsInfo->meeting_minutes_client;
$other_inappropriate_points = $qcdetailsInfo->other_inappropriate_points;
$qcattachmentS3File = $qcdetailsInfo->qcattachmentS3File;
$qcscrnshotattachmentS3File = $qcdetailsInfo->qcscrnshotattachmentS3File;
$branchFranchiseAssigned = $qcdetailsInfo->branchFranchiseAssigned;

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> QC details Management
        <!-- <small>Add / Edit Employee of month</small> -->
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter QC Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>Qcdetails/editQcdetails" method="post" id="editQcdetails" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="franchiseName">Franchise Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseName; ?>" readonly id="franchiseName" name="franchiseName" maxlength="256" />
                                        <input type="hidden" value="<?php echo $qcId; ?>" name="qcId" id="qcId" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Franchise Location</label>
                                        <input type="text" class="form-control required" value="<?php echo $branchLocation; ?>" id="branchLocation" readonly name="branchLocation" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="franchiseNumber">franchiseNumber</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseNumber; ?>" id="franchiseNumber" readonly name="franchiseNumber" maxlength="256" />
                                    </div>
                                </div>
                                <input type="text" value="<?php echo $branchFranchiseAssigned; ?>" name="branchFranchiseAssigned" id="branchFranchiseAssigned" />
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateOfInspection">Date of Inspection</label>
                                        <input type="date" class="form-control" id="date_of_inspection" value="<?php echo $date_of_inspection; ?>" name="date_of_inspection">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="date_of_installation">Date of Installation</label>
                                        <input type="date" class="form-control" id="date_of_installation" value="<?php echo $date_of_installation; ?>" name="date_of_installation">
                                    </div>
                                </div>
                               
                                  <div class="col-md-6">
    <label>Attended by:</label><br>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" id="attended_by_owner" name="attended_by_owner" value="Owner"
            <?php echo (!empty($inspectionData['attended_by_owner'])) ? 'checked' : ''; ?>>
        <label class="form-check-label" for="attended_by_owner">Owner</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="checkbox" id="attended_by_admin" name="attended_by_admin" value="Admin"
            <?php echo (!empty($inspectionData['attended_by_admin'])) ? 'checked' : ''; ?>>
        <label class="form-check-label" for="attended_by_admin">Admin</label>
    </div>
</div>

 <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="strength_playgroup">Playgroup</label>
                                                <input type="number" class="form-control" id="strength_playgroup" name="strength_playgroup" value="<?php echo $strength_playgroup; ?>" min="0">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="strength_nursery">Nursery</label>
                                                <input type="number" class="form-control" id="strength_nursery" name="strength_nursery" value="<?php echo $strength_nursery; ?>" min="0">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="strength_kg1">KG 1</label>
                                                <input type="number" class="form-control" id="strength_kg1" name="strength_kg1" value="<?php echo $strength_kg1; ?>" min="0">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="strength_kg2">KG 2</label>
                                                <input type="number" class="form-control" id="strength_kg2" name="strength_kg2" value="<?php echo $strength_kg2; ?>" min="0">
                                            </div>
                                        </div>
                                    
                                
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="dayCare">Day Care</label>
                                            <input type="text" class="form-control" id="day_care" value="<?php echo $day_care; ?>" name="day_care">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="eveningClass">Evening Class</label>
                                            <input type="text" class="form-control" id="evening_class"  value="<?php echo $evening_class; ?>" name="evening_class">
                                        </div>
                                    </div>

                                     <div class="col-md-4">
    <div class="form-group">
        <label for="classes_running_till">Classes Running Till</label>
        <select class="form-control" id="classes_running_till" name="classes_running_till">
            <option value="">Select</option>
            <option value="Playgroup" <?php echo ($selected_class == 'Playgroup') ? 'selected' : ''; ?>>Playgroup</option>
            <option value="Nursery" <?php echo ($selected_class == 'Nursery') ? 'selected' : ''; ?>>Nursery</option>
            <option value="KG 1" <?php echo ($selected_class == 'KG 1') ? 'selected' : ''; ?>>KG 1</option>
            <option value="KG 2" <?php echo ($selected_class == 'KG 2') ? 'selected' : ''; ?>>KG 2</option>
            <option value="Grade 1" <?php echo ($selected_class == 'Grade 1') ? 'selected' : ''; ?>>Grade 1</option>
             <option value="2nd" <?php echo ($selected_class == '2nd') ? 'selected' : ''; ?>>2nd</option>
              <option value="3rd" <?php echo ($selected_class == '3rd') ? 'selected' : ''; ?>>3rd</option>
               <option value="4th" <?php echo ($selected_class == '4th') ? 'selected' : ''; ?>>4th</option>
                <option value="5th" <?php echo ($selected_class == '5th') ? 'selected' : ''; ?>>5th</option>

                 <option value="6th" <?php echo ($selected_class == '6th') ? 'selected' : ''; ?>>6th</option>
                  <option value="7th" <?php echo ($selected_class == '7th') ? 'selected' : ''; ?>>7th</option>
                 <option value="8th" <?php echo ($selected_class == '8th') ? 'selected' : ''; ?>>8th</option>
                 <option value="9th" <?php echo ($selected_class == '9th') ? 'selected' : ''; ?>>9th</option>
                 <option value="10th" <?php echo ($selected_class == '10th') ? 'selected' : ''; ?>>10th</option>
                 <option value="11th" <?php echo ($selected_class == '11th') ? 'selected' : ''; ?>>11th</option>
                 <option value="12th" <?php echo ($selected_class == '12th') ? 'selected' : ''; ?>>12th</option>

            <!-- Add more as needed -->
        </select>
    </div>
</div>

<div class="col-md-4">
    <label>Front Branding:</label><br>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="frontBrandingYes" name="front_branding" value="yes"
            <?php echo ($front_branding == 'yes') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="frontBrandingYes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="frontBrandingNo" name="front_branding" value="no"
            <?php echo ($front_branding == 'no') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="frontBrandingNo">No</label>
    </div>
</div>


<div class="col-md-4">
    <label>Status:</label><br>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="statusNormal" name="status" value="Normal"
            <?php echo ($status == 'Normal') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="statusNormal">Normal</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="statusSuspicious" name="status" value="Suspicious"
            <?php echo ($status == 'Suspicious') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="statusSuspicious">Suspicious</label>
    </div>
</div>

<div class="col-md-12">
    <label>Uniform Condition OK?</label><br>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="uniformYes" name="uniform_condition_ok" value="1"
            <?php echo ($uniform_condition_ok == '1') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="uniformYes">Yes</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" id="uniformNo" name="uniform_condition_ok" value="0"
            <?php echo ($uniform_condition_ok == '0') ? 'checked' : ''; ?>>
        <label class="form-check-label" for="uniformNo">No</label>
    </div>

    <div class="form-group mt-2">
        <label for="uniformRemarks">If No, specify remarks</label>
        <textarea class="form-control" id="uniformRemarks" name="uniform_condition_remarks" rows="2"><?php echo $uniform_condition_remarks; ?></textarea>
    </div>

    <div class="col-md-6">
        <label>Books and Curriculum OK?</label><br>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" id="booksYes" name="books_curriculum_ok" value="1"
                <?php echo ($books_curriculum_ok == '1') ? 'checked' : ''; ?>>
            <label class="form-check-label" for="booksYes">Yes</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" id="booksNo" name="books_curriculum_ok" value="0"
                <?php echo ($books_curriculum_ok == '0') ? 'checked' : ''; ?>>
            <label class="form-check-label" for="booksNo">No</label>
        </div>
    </div>
</div>

 <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="inappropriatePoints">Any Other Points Found Inappropriate</label>
                                            <textarea class="form-control" id="other_inappropriate_points" name="other_inappropriate_points" rows="3"><?php echo $other_inappropriate_points; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="meetingMinutesClient">Meeting Completion / Minutes of the Meeting (for Client)</label>
                                            <textarea class="form-control" id="meeting_minutes_client" name="meeting_minutes_client" rows="4"><?php echo $meeting_minutes_client; ?></textarea>
                                        </div>
                                    </div>


                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>