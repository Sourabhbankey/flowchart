<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Staff (StaffController)
 * Staff Class to control Staff related operations.
 * @author : Ashish
 * @version : 1.0
 * @since : 13 June 2024
 */
class Hr extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Staff_model', 'stf');
        $this->load->model('Branches_model', 'bm');
        $this->isLoggedIn();
		$this->load->library('pagination');
        $this->module = 'Staff';
    }

    /**
     * This is default routing method
     * It routes to default listing page
     */
    public function index()
    {
        redirect('staff/staffListing');
    }
    
    /**
     * This function is used to load the Staff list
     */
  
//code done by yashi
 
public function staffListing() {
     $userId = $this->session->userdata('userId');
        $userRole = $this->session->userdata('role');
  
         $franchiseFilter = $this->input->get('franchiseNumber');
            if ($this->input->get('resetFilter') == '1') {
            $franchiseFilter = '';
        }
            $config = array();
            $config['base_url'] = base_url('staff/staffListing');
            $config['per_page'] = 10; 
            $config['uri_segment'] = 3;
            $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            if ($userRole == '14' || $userRole == '1'|| $userRole == '23'|| $userRole == '20' || $userRole == '21') { // Admin
                if ($franchiseFilter) {
                    $config['total_rows'] = $this->stf->getTotalTrainingRecordsCountByFranchise($franchiseFilter);
                    $data['records'] = $this->stf->getTrainingRecordsByFranchise($franchiseFilter, $config['per_page'], $page);
                } else {
                    $config['total_rows'] = $this->stf->getTotalTrainingRecordsCount();
                    
                    $data['records'] = $this->stf->getAllTrainingRecords($config['per_page'], $page);
                }
                 } else if ($userRole == '15' || $userRole == '13') { // Specific roles
                    $config['total_rows'] = $this->stf->getTotalTrainingRecordsCountByRole($userId);
                    $data['records'] = $this->stf->getTrainingRecordsByRole($userId, $config['per_page'], $page);
                    
                } else { 
                        $franchiseNumber = $this->stf->getFranchiseNumberByUserId($userId);
                        if ($franchiseNumber) {
                            if ($franchiseFilter && $franchiseFilter == $franchiseNumber) {
                                $config['total_rows'] = $this->stf->getTotalTrainingRecordsCountByFranchise($franchiseNumber);
                                $data['records'] = $this->stf->getTrainingRecordsByFranchise($franchiseNumber, $config['per_page'], $page);
                            } else {
                                $config['total_rows'] = $this->stf->getTotalTrainingRecordsCountByFranchise($franchiseNumber);
                                $data['records'] = $this->stf->getTrainingRecordsByFranchise($franchiseNumber, $config['per_page'], $page);
                            }
                        } else {
                            $data['records'] = []; // Handle the case where franchise number is not found
                        }
                    }

                        // Initialize pagination
                    $data["serial_no"] = $page + 1;
                    $this->pagination->initialize($config);
                    $data["links"] = $this->pagination->create_links();
                    $data["start"] = $page + 1;
                    $data["end"] = min($page + $config["per_page"], $config["total_rows"]);
                    $data["total_records"] = $config["total_rows"];
                    $data['pagination'] = $this->pagination->create_links();
                    $data["franchiseFilter"] = $franchiseFilter; // Pass the filter value to the view
                    $data['branchDetail'] = $this->bm->getBranchesFranchiseNumber();
    $this->loadViews("staff/list", $this->global, $data, NULL);
}

//ends here
    /**
     * This function is used to load the add new form
     */
    function add()
    {
        if(!$this->hasCreateAccess())
        {
            $this->loadThis();
        }
        else
        {
            //$data['users'] = $this->tm->getUser();
            $this->global['pageTitle'] = 'CodeInsect : Add New Staff';
            $data['branchDetail'] = $this->bm->getBranchesFranchiseNumber();
             $data['users'] = $this->stf->getUser();
            $this->loadViews("staff/add", $this->global, $data, NULL);
        }
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addNewStaff()
    {
        if(!$this->hasCreateAccess())
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('name','Meeting Title','trim|required|max_length[256]');
            $this->form_validation->set_rules('remark','Description','trim|required|max_length[1024]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->add();
            }
            else
            {    $brspFranchiseAssigned = $this->security->xss_clean($this->input->post('brspFranchiseAssigned'));
                $name = $this->security->xss_clean($this->input->post('name'));
                $franchiseNumberArray = $this->security->xss_clean($this->input->post('franchiseNumber'));
                /*-new-added-field-*/
                $dateOfJoin = $this->security->xss_clean($this->input->post('dateOfJoin'));
                $birthday = $this->security->xss_clean($this->input->post('birthday'));
                $staffMobileno = $this->security->xss_clean($this->input->post('staffMobileno'));
                $staffWhatsappno = $this->security->xss_clean($this->input->post('staffWhatsappno'));
                $staffemail = $this->security->xss_clean($this->input->post('staffemail'));
                $fathername = $this->security->xss_clean($this->input->post('fathername'));
                /*--Newfield--*/
                $spouseName = $this->security->xss_clean($this->input->post('spouseName'));
                $emergencyMobileno = $this->security->xss_clean($this->input->post('emergencyMobileno'));
                $highestQuali = $this->security->xss_clean($this->input->post('highestQuali'));
                $designation = $this->security->xss_clean($this->input->post('designation'));
                $classAssigned = $this->security->xss_clean($this->input->post('classAssigned'));
                $addressResidencial = $this->security->xss_clean($this->input->post('addressResidencial'));
                $addressPerma = $this->security->xss_clean($this->input->post('addressPerma'));
                /*-ENd-added-field-*/
                $remark = $this->security->xss_clean($this->input->post('remark'));
                $franchiseNumbers = implode(',',$franchiseNumberArray);
                $staffInfo = array('brspFranchiseAssigned'=>$brspFranchiseAssigned,'name'=>$name, 'dateOfJoin'=>$dateOfJoin, 'birthday'=>$birthday, 'staffMobileno'=>$staffMobileno, 'staffWhatsappno'=>$staffWhatsappno, 'staffemail'=>$staffemail, 'fathername'=>$fathername, 'spouseName'=>$spouseName, 'emergencyMobileno'=>$emergencyMobileno, 'highestQuali'=>$highestQuali, 'designation'=>$designation, 'classAssigned'=>$classAssigned, 'addressResidencial'=>$addressResidencial, 'addressPerma'=>$addressPerma, 'franchiseNumber'=>$franchiseNumbers, 'remark'=>$remark, 'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:s'));
                
                $result = $this->stf->addNewStaff($staffInfo);

                if($result > 0) {
                    if(!empty($franchiseNumberArray)){
                        foreach ($franchiseNumberArray as $franchiseNumber){
                        $branchDetail = $this->bm->getBranchesInfoByfranchiseNumber($franchiseNumber);
                            if(!empty($branchDetail)){
                                //$to = $branchDetail->branchEmail;
                                $to = $branchDetail->officialEmailID;
                                $subject = "Alert - eduMETA THE i-SCHOOL Assign New Staff Meeting";
                                $message = 'Dear '.$branchDetail->applicantName.' ';
                                //$message = ' '.$remark.' ';
                                $message .= 'You have been assigned a new meeting. BY- '.$this->session->userdata("name").' ';
                                $message .= 'Please visit the portal.';
                                //$message = ' '.$remark.' ';
                                $headers = "From: Edumeta  Team<noreply@theischool.com>" . "\r\n" . "BCC: dev.edumeta@gmail.com";
                                mail($to,$subject,$message,$headers);
                            }
                        }
                    }
                    $this->session->set_flashdata('success', 'New Staff Meeting created successfully');
                } else {
                    $this->session->set_flashdata('error', 'Staff Meeting creation failed');
                }
                
                redirect('staff/staffListing');
            }
        }
    }

    
    /**
     * This function is used load task edit information
     * @param number $taskId : Optional : This is task id
     */
    function edit($staffid = NULL)
    {
        if(!$this->hasUpdateAccess())
        {
            $this->loadThis();
        }
        else
        {
            if($staffid == null)
            {
                redirect('staff/staffListing');
            }
            
            $data['staffInfo'] = $this->stf->getStaffInfo($staffid);
            $data['branchDetail'] = $this->bm->getBranchesFranchiseNumber();
            //$data['users'] = $this->tm->getUser();
            $this->global['pageTitle'] = 'Meeting : Edit Staff';
            
            $this->loadViews("staff/edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function editStaff()
    {
        if(!$this->hasUpdateAccess())
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $staffid = $this->input->post('staffid');
            
            $this->form_validation->set_rules('name','Meeting Title','trim|required|max_length[256]');
            $this->form_validation->set_rules('remark','Description','trim|required|max_length[1024]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($staffid);
            }
            else
            {
                $name = $this->security->xss_clean($this->input->post('name'));
                $remark = $this->security->xss_clean($this->input->post('remark'));
                /*-new-added-field-*/
                $dateOfJoin = $this->security->xss_clean($this->input->post('dateOfJoin'));
                $birthday = $this->security->xss_clean($this->input->post('birthday'));
                $staffMobileno = $this->security->xss_clean($this->input->post('staffMobileno'));
                $staffWhatsappno = $this->security->xss_clean($this->input->post('staffWhatsappno'));
                $staffemail = $this->security->xss_clean($this->input->post('staffemail'));
                $fathername = $this->security->xss_clean($this->input->post('fathername'));
                /*-ENd-added-field-*/
                $spouseName = $this->security->xss_clean($this->input->post('spouseName'));
                $emergencyMobileno = $this->security->xss_clean($this->input->post('emergencyMobileno'));
                $highestQuali = $this->security->xss_clean($this->input->post('highestQuali'));
                $designation = $this->security->xss_clean($this->input->post('designation'));
                $classAssigned = $this->security->xss_clean($this->input->post('classAssigned'));
                $addressResidencial = $this->security->xss_clean($this->input->post('addressResidencial'));
                $addressPerma = $this->security->xss_clean($this->input->post('addressPerma'));
                $staffInfo = array('name'=>$name, 'dateOfJoin'=>$dateOfJoin, 'birthday'=>$birthday, 'staffMobileno'=>$staffMobileno, 'staffWhatsappno'=>$staffWhatsappno, 'staffemail'=>$staffemail, 'fathername'=>$fathername, 'spouseName'=>$spouseName, 'emergencyMobileno'=>$emergencyMobileno, 'highestQuali'=>$highestQuali, 'designation'=>$designation, 'classAssigned'=>$classAssigned, 'addressResidencial'=>$addressResidencial, 'addressPerma'=>$addressPerma, 'remark'=>$remark, 'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:s'));
                $result = $this->stf->editStaff($staffInfo, $staffid);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Staff Meeting updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Staff Meeting updation failed');
                }
                
                redirect('staff/staffListing');
            }
        }
    }
	/** Code for CK editor */
	  public function upload() {
        if (isset($_FILES['upload'])) {
            $file = $_FILES['upload'];
            $fileName = time() . '_' . $file['name'];
            $uploadPath = 'uploads/';

            if (move_uploaded_file($file['tmp_name'], $uploadPath . $fileName)) {
                $url = base_url($uploadPath . $fileName);
                $message = 'Image uploaded successfully';

                $callback = $_GET['CKEditorFuncNum'];
                echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($callback, '$url', '$message');</script>";
            } else {
                $message = 'Error while uploading file';
                echo "<script type='text/javascript'>alert('$message');</script>";
            }
        }
    }

     public function fetchAssignedUsers() {
    $franchiseNumber = $this->input->post('franchiseNumber');

    // Fetch the users based on the franchise number
    $users = $this->stf->getUsersByFranchise($franchiseNumber); // Adjust model method name if necessary

    // Generate HTML options for the response
    $options = '<option value="0">Select Role</option>';
    foreach ($users as $user) {
        $options .= '<option value="' . $user->userId . '">' . $user->name . '</option>';
    }

    echo $options; // Output the options as HTML
}
}

?>