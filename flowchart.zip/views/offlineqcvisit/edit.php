<?php
$offlineVisitQcId = $ofqcdetailsInfo->offlineVisitQcId;
$franchise_number = $ofqcdetailsInfo->franchise_number;
$franchise_name = $ofqcdetailsInfo->franchise_name;
$franchise_owner_name = $ofqcdetailsInfo->franchise_owner_name;
$location = $ofqcdetailsInfo->location;
$city = $ofqcdetailsInfo->city;
$state = $ofqcdetailsInfo->state;
$growth_manager = $ofqcdetailsInfo->growth_manager;
$date_of_inspection = $ofqcdetailsInfo->date_of_inspection;
$date_of_installation = $ofqcdetailsInfo->date_of_installation;
$qc_officer_1_name = $ofqcdetailsInfo->qc_officer_1_name;
$qc_officer_2_name = $ofqcdetailsInfo->qc_officer_2_name;
$presence_of_owner_admin = $ofqcdetailsInfo->presence_of_owner_admin;
$presence_of_owner_admin_status = $ofqcdetailsInfo->presence_of_owner_admin_status;
$date_of_qc = $ofqcdetailsInfo->date_of_qc;
$qc_rating = $ofqcdetailsInfo->qc_rating;
$total_strength = $ofqcdetailsInfo->total_strength;
$pg_strength = $ofqcdetailsInfo->pg_strength;
$nursery_strength = $ofqcdetailsInfo->nursery_strength;
$kg1_strength = $ofqcdetailsInfo->kg1_strength;
$kg2_strength = $ofqcdetailsInfo->kg2_strength;
$daycare_strength = $ofqcdetailsInfo->daycare_strength;
$upgrade_opted = $ofqcdetailsInfo->upgrade_opted;
$branding_at_premise = $ofqcdetailsInfo->branding_at_premise;
$school_branding_within_radius = $ofqcdetailsInfo->school_branding_within_radius;
$gesture_of_branch = $ofqcdetailsInfo->gesture_of_branch;
$live_cleanliness = $ofqcdetailsInfo->live_cleanliness;
$furniture_condition = $ofqcdetailsInfo->furniture_condition;
$classroom_decoration = $ofqcdetailsInfo->classroom_decoration;
$rabl_counter = $ofqcdetailsInfo->rabl_counter;
$safety_points = $ofqcdetailsInfo->safety_points;
$camera_status = $ofqcdetailsInfo->camera_status;
$inquiry_book = $ofqcdetailsInfo->inquiry_book;
$register_maintained = $ofqcdetailsInfo->register_maintained;
$branding_backdrop_present = $ofqcdetailsInfo->branding_backdrop_present;
$feedback_owner_admin = $ofqcdetailsInfo->feedback_owner_admin;
$feedback_parents = $ofqcdetailsInfo->feedback_parents;
$feedback_teachers = $ofqcdetailsInfo->feedback_teachers;
$feedback_students = $ofqcdetailsInfo->feedback_students;
$doctor_contact_present = $ofqcdetailsInfo->doctor_contact_present;
$uniform_discipline_staff = $ofqcdetailsInfo->uniform_discipline_staff;
$uniform_discipline_students = $ofqcdetailsInfo->uniform_discipline_students;
$books_copies_check = $ofqcdetailsInfo->books_copies_check;
$additional_books_reference = $ofqcdetailsInfo->additional_books_reference;
$additional_books_note = $ofqcdetailsInfo->additional_books_note;
$premise_overview = $ofqcdetailsInfo->premise_overview;
$additional_programs = $ofqcdetailsInfo->additional_programs;
$specific_concerns = $ofqcdetailsInfo->specific_concerns;
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Offline QC Visit Management
        <small>Edit  Offline QC Visit</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <!-- <div class="box-header">
                        <h3 class="box-title">Enter Offline QC Visit</h3>
                    </div> --><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>offlineqcvisit/editOfflineqcvisit" method="post" id="editOfflineqcvisit" role="form">

                        <input type="hidden" value="<?php echo $offlineVisitQcId; ?>" name="offlineVisitQcId" id="offlineVisitQcId" />
                        <div class="box-body">
                            
                        <!-- New-code -->
                        <!-- Section 1: Franchise Information -->
                        <h2 class="offlinevisith2">Section 1: Franchise Information</h2>
                      <div class="row">
    <?php
    $fields = [
        'franchise_number', 'franchise_name', 'franchise_owner_name', 'location', 'city', 'state',
        'growth_manager', 'date_of_inspection', 'date_of_installation',
        'qc_officer_1_name', 'qc_officer_2_name', 'date_of_qc', 'qc_rating'
    ];

    // Fields that should be readonly
    $readonly_fields = ['franchise_number', 'franchise_name', 'franchise_owner_name', 'location', 'city', 'state', 'growth_manager'];
foreach ($fields as $field) {
    $label = ucwords(str_replace("_", " ", $field));
    $type = in_array($field, ['date_of_inspection', 'date_of_installation', 'date_of_qc']) ? 'date' : 'text';
    if ($field == 'qc_rating') $type = 'number';

    // Use name instead of ID for growth_manager
    if ($field == 'growth_manager') {
        $value = isset($ofqcdetailsInfo->growthManagerName) ? $ofqcdetailsInfo->growthManagerName : '';
    } else {
        $value = isset($ofqcdetailsInfo->$field) ? $ofqcdetailsInfo->$field : '';
    }

    $readonly = in_array($field, $readonly_fields) ? 'readonly' : '';

    echo '<div class="col-md-4"><div class="form-group">
        <label>' . $label . '</label>
        <input type="' . $type . '" class="form-control" name="' . $field . '" value="' . set_value($field, $value) . '" ' . $readonly . '>
    </div></div>';
}

    ?>

    <!-- <div class="col-md-4"><div class="form-group">
        <label><input type="checkbox" name="presence_of_owner_admin" value="1"
            <?php //echo set_checkbox('presence_of_owner_admin', '1', !empty($ofqcdetailsInfo->presence_of_owner_admin)); ?>>
            In Presence of Franchise Owner/Admin</label>
    </div></div> -->
    <div class="col-md-4">
        <div class="form-group">
            <label>In Presence of Franchise</label>
            <select class="form-control" name="presence_of_owner_admin">
                <option value="Owner" <?php echo set_select('presence_of_owner_admin', 'Owner', $ofqcdetailsInfo->presence_of_owner_admin === 'Owner'); ?>>Owner</option>
                <option value="Admin" <?php echo set_select('presence_of_owner_admin', 'Admin', $ofqcdetailsInfo->presence_of_owner_admin === 'Admin'); ?>>Admin</option>
                <option value="Teacher" <?php echo set_select('presence_of_owner_admin', 'Teacher', $ofqcdetailsInfo->presence_of_owner_admin === 'Teacher'); ?>>Teacher</option>
            </select>
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label>Status</label>
            <select class="form-control" name="presence_of_owner_admin_status">
                <option value="Owner" <?php echo set_select('presence_of_owner_admin_status', 'Yes', $ofqcdetailsInfo->presence_of_owner_admin_status === 'Yes'); ?>>Yes</option>
                <option value="Admin" <?php echo set_select('presence_of_owner_admin_status', 'No', $ofqcdetailsInfo->presence_of_owner_admin_status === 'No'); ?>>No</option>
            </select>
        </div>
    </div>

</div>



                        <!-- Section 2: Student Strength -->
                        <h2 class="offlinevisith2">Section 2: Student Strength</h2>
                      <div class="row">
    <?php
    $student_fields = ['total_strength', 'pg_strength', 'nursery_strength', 'kg1_strength', 'kg2_strength', 'daycare_strength'];
    foreach ($student_fields as $field) {
        $label = ucwords(str_replace("_", " ", $field));
        $value = isset($ofqcdetailsInfo->$field) ? $ofqcdetailsInfo->$field : '';
        echo '<div class="col-md-4"><div class="form-group">
            <label>' . $label . '</label>
            <input type="number" class="form-control" name="' . $field . '" value="' . set_value($field, $value) . '">
        </div></div>';
    }
    ?>
    <?php
$upgrade_opted = set_value('upgrade_opted', !empty($ofqcdetailsInfo->upgrade_opted));
$upgrade_strength = set_value('upgrade_strength', isset($ofqcdetailsInfo->upgrade_strength) ? $ofqcdetailsInfo->upgrade_strength : '');
?>

    <!-- <div class="col-md-4"><div class="form-group">
        <label><input type="checkbox" name="upgrade_opted" value="1"
            <?php //echo set_checkbox('upgrade_opted', '1', !empty($ofqcdetailsInfo->upgrade_opted)); ?>>
            Upgrade (If Opted)</label>
    </div></div> -->
    <!-- Upgrade Opted Checkbox -->
<div class="col-md-4">
    <div class="form-group">
        <label>
            <input type="checkbox" id="upgrade_opted_checkbox" name="upgrade_opted" value="1"
                <?php echo set_checkbox('upgrade_opted', '1', $upgrade_opted); ?>>
            Upgrade (If Opted)
        </label>
    </div>
</div>

<!-- Upgrade Strength Field (Initially hidden if not opted) -->
<div class="col-md-4" id="upgrade_strength_group" style="display: <?php echo $upgrade_opted ? 'block' : 'none'; ?>;">
    <div class="form-group">
        <label>Upgrade</label>
        <input type="number" class="form-control" name="upgrade_strength"
               value="<?php echo $upgrade_strength; ?>">
    </div>
</div>

</div>

                        <!-- Section 3: Premise Evaluation -->
                        <h2 class="offlinevisith2">Section 3: Premise Evaluation</h2>
                        <div class="row">
                            <?php
                            $select_fields = [
                                'branding_at_premise' => ['Appropriate', 'Inappropriate'],
                                'school_branding_within_radius' => ['Appropriate', 'Inappropriate'],
                                'gesture_of_branch' => ['Good', 'Not Good'],
                                'live_cleanliness' => ['Clean & Hygienic', 'Dirty & Messy'],
                                'furniture_condition' => ['Appropriate', 'Inappropriate'],
                                'classroom_decoration' => ['Excellent', 'Good', 'Needs Improvement'],
                                'rabl_counter' => ['Available', 'Not Available'],
                                'safety_points' => ['Appropriate', 'Inappropriate'],
                                'camera_status' => ['Active', 'Not Active']
                            ];

                            foreach ($select_fields as $name => $options) {
                                echo '<div class="col-md-4"><div class="form-group"><label>' . ucwords(str_replace("_", " ", $name)) . '</label>';
                                echo '<select class="form-control" name="' . $name . '">';
                                foreach ($options as $opt) {
                                    $selected = set_select($name, $opt, $franchise[$name] == $opt);
                                    echo '<option value="' . $opt . '" ' . $selected . '>' . $opt . '</option>';
                                }
                                echo '</select></div></div>';
                            }
                            ?>
                        </div>

                        <!-- Section 4: Documentation Check -->
                        <h2 class="offlinevisith2">Section 4: Documentation Check</h2>
                      <div class="row">
    <div class="col-md-4"><div class="form-group">
        <label><input type="checkbox" name="inquiry_book" value="1"
            <?php echo set_checkbox('inquiry_book', '1', !empty($ofqcdetailsInfo->inquiry_book)); ?>>
            Inquiry Book</label>
    </div></div>

    <div class="col-md-4"><div class="form-group">
        <label><input type="checkbox" name="register_maintained" value="1"
            <?php echo set_checkbox('register_maintained', '1', !empty($ofqcdetailsInfo->register_maintained)); ?>>
            Register Maintained (Staff/Visitor/Record)</label>
    </div></div>
</div>


                        <!-- Section 5: Branding Backdrop -->
                        <h2 class="offlinevisith2">Section 5: Branding Backdrop</h2>
                      <div class="row">
    <div class="col-md-4"><div class="form-group">
        <label><input type="checkbox" name="branding_backdrop_present" value="1"
            <?php echo set_checkbox('branding_backdrop_present', '1', !empty($ofqcdetailsInfo->branding_backdrop_present)); ?>>
            Stage with Branding Backdrop Present</label>
    </div></div>
</div>

                       <!-- Section 6: Interaction Feedback -->
                       <h2 class="offlinevisith2">Section 6: Interaction Feedback</h2>
<div class="row">
    <?php
    $feedbacks = ['feedback_owner_admin', 'feedback_parents', 'feedback_teachers', 'feedback_students'];
    foreach ($feedbacks as $fb) {
        $value = isset($ofqcdetailsInfo->$fb) ? $ofqcdetailsInfo->$fb : '';
        echo '<div class="col-md-12"><div class="form-group">
            <label>' . ucwords(str_replace("_", " ", $fb)) . '</label>
            <textarea class="form-control" name="' . $fb . '">' . set_value($fb, $value) . '</textarea>
        </div></div>';
    }
    ?>
</div>

                        <!-- Section 7: Other Checks -->
                        <h2 class="offlinevisith2">Section 7: Other Checks</h2>
                    <div class="row">
   <?php
$checks = [
    'doctor_contact_present' => 'Doctor’s Contact at Premise',
    'uniform_discipline_staff' => 'Uniform Discipline - Staff',
    'uniform_discipline_students' => 'Uniform Discipline - Students',
    'books_copies_check' => 'Live Books & Copies Check',
    'additional_books_reference' => 'Additional Books for Reference'
];

foreach ($checks as $key => $label) {
    $checked = isset($ofqcdetailsInfo->$key) ? $ofqcdetailsInfo->$key : 0;
    $id_attr = ($key === 'additional_books_reference') ? 'id="additional_books_checkbox"' : '';
    echo '<div class="col-md-4"><div class="form-group">
        <label><input type="checkbox" name="' . $key . '" value="1" ' . $id_attr . ' ' . set_checkbox($key, '1', $checked) . '> ' . $label . '</label>
    </div></div>';
}
?>

<?php
$additional_books_checked = isset($ofqcdetailsInfo->additional_books_reference) && $ofqcdetailsInfo->additional_books_reference;
?>

<!-- Hidden by default unless checkbox is checked -->
<div class="col-md-12" id="additional_books_note_group" style="display: <?php echo $additional_books_checked ? 'block' : 'none'; ?>;">
    <div class="form-group">
        <label>Additional Books Note</label>
        <textarea class="form-control" name="additional_books_note"><?php echo set_value('additional_books_note', isset($ofqcdetailsInfo->additional_books_note) ? $ofqcdetailsInfo->additional_books_note : ''); ?></textarea>
    </div>
</div>


    <?php
    $paragraphs = ['premise_overview', 'additional_programs', 'specific_concerns'];
    foreach ($paragraphs as $p) {
        $val = isset($ofqcdetailsInfo->$p) ? $ofqcdetailsInfo->$p : '';
        echo '<div class="col-md-12"><div class="form-group">
            <label>' . ucwords(str_replace("_", " ", $p)) . '</label>
            <textarea class="form-control" name="' . $p . '">' . set_value($p, $val) . '</textarea>
        </div></div>';
    }
    ?>
</div>




                        <!--End- New-code -->
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>
    <script>
        $(document).ready(function () {
            // Toggle Upgrade Strength field
            $('#upgrade_opted_checkbox').change(function () {
                $('#upgrade_strength_group').toggle(this.checked);
            });

            // Toggle Additional Books Note field
            $('#additional_books_checkbox').change(function () {
                $('#additional_books_note_group').toggle(this.checked);
            });
        });
    </script>
    <style type="text/css">
        .offlinevisith2{
             text-align: center;
            background: #969494;
            padding: 5px;
            border-radius: 5px;
            color: #fff;
            font-weight: 700;
        }  
    </style>
</div>