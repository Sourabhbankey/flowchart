<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Offline QC Visit
            <!-- <small>Add / Edit</small> -->
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <!-- <div class="box-header">
                        <h3 class="box-title">Enter Offline QC Visit</h3>
                    </div> -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addNewOfflineqcvisit" action="<?php echo base_url() ?>offlineqcvisit/addNewOfflineqcvisit" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            
                                <!-- New-Code --> 
                                <h2 class="offlinevisith2">Section 1: Franchise Information</h2>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                            <select class="form-control required" id="franchiseNumber" name="franchise_number" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        ?>
                                                        <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group"><label>Franchise Name</label>
                                        <input type="text" readonly class="form-control required" id="branchSetupName" name="franchise_name" maxlength="256"></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group"><label>Franchise Owner Name</label>
                                        <input type="text" readonly class="form-control required" id="branchSetupName" name="franchise_owner_name" maxlength="256"></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group"><label>City</label> <input required type="text" class="form-control required" id="city" name="city" maxlength="256" readonly></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group"><label>State</label><input required type="text" class="form-control required" id="state" name="state" maxlength="256" readonly></div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                            <select class="form-control required" id="branchFranchiseAssigned" name="growth_manager">
                                                <option value="0">Select Role</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="brcompAddress">Branch Complete Address <span class="re-mend-field">*</span></label>
                                            <textarea required class="form-control required" id="brcompAddress" name="location" readonly></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-4"><div class="form-group"><label>Date of Inspection</label><input type="date" class="form-control" name="date_of_inspection"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Date of Installation</label><input type="date" class="form-control" name="date_of_installation"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Name of QC Officer 1</label><input type="text" class="form-control" name="qc_officer_1"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Name of QC Officer 2</label><input type="text" class="form-control" name="qc_officer_2"></div></div>
                                    <!-- <div class="col-md-4"><div class="form-group"><label><input type="checkbox" name="presence_of_owner_admin"> In Presence of Franchise Owner/Admin</label></div></div> -->
                                    <div class="col-md-4"><div class="form-group"><label>In Presence of Franchise</label><select class="form-control" name="presence_of_owner_admin"><option>Owner</option><option>Admin</option><option>Teacher</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Status</label><select class="form-control" name="presence_of_owner_admin_status"><option></option><option>Yes</option><option>No</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Date of QC</label><input type="date" class="form-control" name="date_of_qc"></div></div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Rating for Branch after QC</label>
                                            <div class="star-rating">
                                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                                    <input type="radio" id="star<?php echo $i; ?>" name="qc_rating" value="<?php echo $i; ?>"
                                                        <?php echo (isset($qc_rating) && $qc_rating == $i) ? 'checked' : ''; ?>>
                                                    <label for="star<?php echo $i; ?>" title="<?php echo $i; ?> stars">&#9733;</label>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                                <h2 class="offlinevisith2">Section 2: Student Strength</h2>
                                <div class="row">
                                    <div class="col-md-4"><div class="form-group"><label>Total Strength</label><input type="number" class="form-control" name="total_strength"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label for="pg_strength">PG</label><input type="number" class="form-control" name="pg_strength" id="pg_strength"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label for="nursery_strength">Nursery</label><input type="number" class="form-control" name="nursery_strength" id="nursery_strength"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label for="kg1_strength">KG1</label><input type="number" class="form-control" name="kg1_strength" id="kg1_strength"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label for="kg2_strength">KG2</label><input type="number" class="form-control" name="kg2_strength" id="kg2_strength"></div></div>
                                    <div class="col-md-4"><div class="form-group"><label for="daycare_strength">Day Care</label><input type="number" class="form-control" name="daycare_strength" id="daycare_strength"></div></div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="upgrade_opted" id="upgrade_opted"
                                                    <?php echo (isset($upgrade_opted) && $upgrade_opted) ? 'checked' : ''; ?>>
                                                Upgrade (If Opted)
                                            </label>
                                        </div>
                                    </div>
                                    <!-- Upgrade Strength Input (Initially hidden if not opted) -->
                                    <div class="col-md-4" id="upgrade_strength_group" style="display: <?php echo (isset($upgrade_opted) && $upgrade_opted) ? 'block' : 'none'; ?>;">
                                        <div class="form-group">
                                            <label>Upgrade</label>
                                            <input type="number" class="form-control" name="upgrade_strength"
                                                   value="<?php echo isset($upgrade_strength) ? $upgrade_strength : ''; ?>">
                                        </div>
                                    </div>
                                </div>

                                <h2 class="offlinevisith2">Section 3: Premise Evaluation</h2>
                                <div class="row">
                                    <div class="col-md-4"><div class="form-group"><label>Branding at Premise</label><select class="form-control" name="branding_premise"><option>Appropriate</option><option>Inappropriate</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>School Branding Within Radius</label><select class="form-control" name="school_branding"><option>Appropriate</option><option>Inappropriate</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Gesture of Branch</label><select class="form-control" name="gesture_branch"><option>Good</option><option>Not Good</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Live Cleanliness</label><select class="form-control" name="live_cleanliness"><option>Clean & Hygienic</option><option>Dirty & Messy</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Furniture/Equipment Condition</label><select class="form-control" name="furniture_condition"><option>Appropriate</option><option>Inappropriate</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Classroom Decoration</label><select class="form-control" name="classroom_decoration"><option>Excellent</option><option>Good</option><option>Needs Improvement</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>RABL Counter</label><select class="form-control" name="rabl_counter"><option>Available</option><option>Not Available</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Safety Points</label><select class="form-control" name="safety_points"><option>Appropriate</option><option>Inappropriate</option></select></div></div>
                                    <div class="col-md-4"><div class="form-group"><label>Camera</label><select class="form-control" name="camera"><option>Active</option><option>Not Active</option></select></div></div>
                                </div>

                                <h2 class="offlinevisith2">Section 4: Documentation Check</h2>
                                <div class="row">
                                    <div class="col-md-6"><div class="form-group"><label><input type="checkbox" name="inquiry_book"> Inquiry Book</label></div></div>
                                    <div class="col-md-6"><div class="form-group"><label><input type="checkbox" name="register_maintained"> Register Maintained (Staff/Visitor/Record)</label></div></div>
                                </div>

                                <h2 class="offlinevisith2">Section 5: Stage with Branding Backdrop</h2>
                                <div class="row">
                                    <div class="col-md-6"><div class="form-group"><label><input type="checkbox" name="branding_backdrop"> Stage with Branding Backdrop Present</label></div></div>
                                </div>

                                <h2 class="offlinevisith2">Section 6: Interaction Feedback</h2>
                                <div class="row">
                                    <div class="col-md-12"><div class="form-group"><label>Owner/Admin Feedback</label><textarea class="form-control" name="feedback_owner_admin"></textarea></div></div>
                                    <div class="col-md-12"><div class="form-group"><label>Parents Feedback</label><textarea class="form-control" name="feedback_parents"></textarea></div></div>
                                    <div class="col-md-12"><div class="form-group"><label>Teachers Feedback</label><textarea class="form-control" name="feedback_teachers"></textarea></div></div>
                                    <div class="col-md-12"><div class="form-group"><label>Students Feedback</label><textarea class="form-control" name="feedback_students"></textarea></div></div>
                                </div>

                                <h2  class="offlinevisith2">Section 7: Other Checks</h2>
                                <div class="row">
                                    <div class="col-md-4"><div class="form-group"><label><input type="checkbox" name="doctor_contact"> Doctor’s Contact at Premise</label></div></div>
                                    <div class="col-md-4"><div class="form-group"><label><input type="checkbox" name="uniform_discipline_staff"> Uniform Discipline - Staff</label></div></div>
                                    <div class="col-md-4"><div class="form-group"><label><input type="checkbox" name="uniform_discipline_students"> Uniform Discipline - Students</label></div></div>
                                    <div class="col-md-4"><div class="form-group"><label><input type="checkbox" name="live_books_check"> Live Books & Copies Check</label></div></div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>
                                                <input type="checkbox" name="additional_books" id="additional_books"
                                                    <?php echo (isset($additional_books) && $additional_books) ? 'checked' : ''; ?>>
                                                Additional Books for Reference
                                            </label>

                                            <div id="additional_books_note_wrapper" style="margin-top: 10px; display: <?php echo (isset($additional_books) && $additional_books) ? 'block' : 'none'; ?>;">
                                                <textarea class="form-control" name="additional_books_note" placeholder="If Yes, provide details"><?php echo isset($additional_books_note) ? $additional_books_note : ''; ?></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12"><div class="form-group"><label>Premise Overview</label><textarea class="form-control" name="premise_overview"></textarea></div></div>
                                    <div class="col-md-12"><div class="form-group"><label>Additional Programs</label><textarea class="form-control" name="additional_programs"></textarea></div></div>
                                    <div class="col-md-12"><div class="form-group"><label>Any Specific Concern</label><textarea class="form-control" name="specific_concerns"></textarea></div></div>
                                </div>
                                <!-- End-New-Code -->  
                               
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-3">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $error; ?>
                        </div>
                <?php endif; ?>

                <?php
                    $success = $this->session->flashdata('success');
                    if($success): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $success; ?>
                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("Qcdetails/fetchAssignedUsers"); ?>',
            type: 'POST',
            dataType: 'json',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                // Populate the manager dropdown
                $('#branchFranchiseAssigned').html(response.managerOptions);

                // Set franchise name in text input
                $('#franchiseName').val(response.franchiseName);
                 $('#branchLocAddressPremise').val(response.branchLocAddressPremise);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                console.error("Response Text:", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
        $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
        $('#franchiseName').val('');
        $('#branchLocAddressPremise').val('');
    }
}
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const checkbox = document.getElementById("upgrade_opted");
        const upgradeGroup = document.getElementById("upgrade_strength_group");

        checkbox.addEventListener("change", function () {
            upgradeGroup.style.display = this.checked ? "block" : "none";
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const checkbox = document.getElementById("additional_books");
        const textareaWrapper = document.getElementById("additional_books_note_wrapper");

        checkbox.addEventListener("change", function () {
            textareaWrapper.style.display = this.checked ? "block" : "none";
        });
    });
</script>

<style>
.star-rating {
    direction: rtl;
    display: flex;
    justify-content: flex-end;
}
.star-rating input[type="radio"] {
    display: none;
}
.star-rating label {
    font-size: 24px;
    color: #949494;
    cursor: pointer;
    padding: 0 2px;
}
.star-rating input[type="radio"]:checked ~ label,
.star-rating label:hover,
.star-rating label:hover ~ label {
    color: #f7d106;
}
.offlinevisith2{
     text-align: center;
    background: #969494;
    padding: 5px;
    border-radius: 5px;
    color: #fff;
    font-weight: 700;
}    
</style>

    </body>
</html>
<script>
$(document).ready(function () {
    $('#franchiseNumber').change(function () {
        let franchiseNumber = $(this).val();
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("offlineqcvisit/getBranchDetails"); ?>',
                type: 'POST',
                data: { franchiseNumber: franchiseNumber },
                dataType: 'json',
                success: function (response) {
                    if (response) {
                        $('#branchSetupName').val(response.branchSetupName);
                        $('#brcompAddress').val(response.brcompAddress);
                        $('#city').val(response.city);
                        $('#state').val(response.state);
                    } else {
                        alert("No data found for the selected franchise.");
                        $('#branchSetupName, #brcompAddress, #city, #state').val('');
                    }
                },
                error: function () {
                    alert("Error fetching branch details.");
                }
            });
        } else {
            $('#branchSetupName, #brcompAddress, #city, #state').val('');
        }
    });
});

function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("branchinstallation/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
        $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
    }
}

const form = document.getElementById('yourForm');
const submitBtn = document.getElementById('submitBtn');

form.addEventListener('submit', function (e) {
    if (submitBtn.disabled) {
        e.preventDefault();
        return;
    }
    submitBtn.disabled = true;
    submitBtn.innerText = 'Submitting...';
});
</script>