<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Offline QC Visit Management
        <!-- <small>Add, Edit, Delete</small> -->
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>offlineqcvisit/add"><i class="fa fa-plus"></i> Add New Offline QC visit</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <!-- <h3 class="box-title"></h3> -->
                    <!-- <div class="box-tools">
                        <form action="<?php //echo base_url() ?>offlineqcvisit/offlineqcvisitListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div> -->
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                  <table id="example" class="display responsive nowrap" style="width:100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Franchise Number</th>
                            <th>Franchise Name</th>
                            <th>Franchise Owner Name</th>
                            <th>Location</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Growth Manager</th>
                            <th>Date of Inspection</th>
                            <th>Date of Installation</th>
                            <th>QC Officer 1</th>
                            <th>QC Officer 2</th>
                            <th>Presence of Owner/Admin</th>
                            <th>Presence of Franchise Status</th>
                            <th>Date of QC</th>
                            <th>QC Rating</th>
                            <th>Total Strength</th>
                            <th>PG</th>
                            <th>Nursery</th>
                            <th>KG1</th>
                            <th>KG2</th>
                            <th>Day Care</th>
                            <th>Upgrade Opted</th>
                            <th>Branding at Premise</th>
                            <th>School Branding Within Radius</th>
                            <th>Gesture of Branch</th>
                            <th>Live Cleanliness</th>
                            <th>Furniture/Equipment Condition</th>
                            <th>Classroom Decoration</th>
                            <th>RABL Counter</th>
                            <th>Safety Points</th>
                            <th>Camera</th>
                            <th>Inquiry Book</th>
                            <th>Register Maintained</th>
                            <th>Stage Branding Backdrop</th>
                            <th>Owner/Admin Feedback</th>
                            <th>Parents Feedback</th>
                            <th>Teachers Feedback</th>
                            <th>Students Feedback</th>
                            <th>Doctor Contact</th>
                            <th>Uniform Discipline - Staff</th>
                            <th>Uniform Discipline - Students</th>
                            <th>Live Books Check</th>
                            <th>Additional Books</th>
                            <th>Additional Books Note</th>
                            <th>Premise Overview</th>
                            <th>Additional Programs</th>
                            <th>Specific Concerns</th>
                            <th>Created On</th>
                            <th>Updated On</th>
                        <th class="text-center">Actions</th>                       
                    </tr>
                    </thead>
                <tbody>
                    <?php
                    $counter = 1;

                    if(!empty($records))
                    {
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                        <td><?php echo $counter++; ?></td>
                        <td><?php echo $record->franchise_number; ?></td>
                        <td><?php echo $record->franchise_name; ?></td>
                        <td><?php echo $record->franchise_owner_name; ?></td>
                        <td><?php echo $record->location; ?></td>
                        <td><?php echo $record->city; ?></td>
                        <td><?php echo $record->state; ?></td>
                       <td><?php echo $record->growthManagerName; ?></td>
                        <td><?php echo $record->date_of_inspection; ?></td>
                        <td><?php echo $record->date_of_installation; ?></td>
                        <td><?php echo $record->qc_officer_1_name; ?></td>
                        <td><?php echo $record->qc_officer_2_name; ?></td>
                        <td><?php echo $record->presence_of_owner_admin; ?></td>
                        <td><?php echo $record->presence_of_owner_admin_status; ?></td>
                        <td><?php echo $record->date_of_qc; ?></td>
                        <td>
                            <div class="star-rating-display" style="display: contents;">
                                <?php
                                $rating = $record->qc_rating;
                                for ($i = 1; $i <= 5; $i++) {
                                    $class = ($i <= $rating) ? '' : 'empty';
                                    $title = $i . ' star' . ($i > 1 ? 's' : '');
                                    echo '<span class="star ' . $class . '" title="' . $title . '">' . ($i <= $rating ? '★' : '☆') . '</span>';
                                }
                                ?>
                            </div>

                        </td>
                        <td><?php echo $record->total_strength; ?></td>
                        <td><?php echo $record->pg_strength; ?></td>
                        <td><?php echo $record->nursery_strength; ?></td>
                        <td><?php echo $record->kg1_strength; ?></td>
                        <td><?php echo $record->kg2_strength; ?></td>
                        <td><?php echo $record->daycare_strength; ?></td>
                        <td><?php echo $record->upgrade_opted ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->branding_at_premise; ?></td>
                        <td><?php echo $record->school_branding_within_radius; ?></td>
                        <td><?php echo $record->gesture_of_branch; ?></td>
                        <td><?php echo $record->live_cleanliness; ?></td>
                        <td><?php echo $record->furniture_condition; ?></td>
                        <td><?php echo $record->classroom_decoration; ?></td>
                        <td><?php echo $record->rabl_counter; ?></td>
                        <td><?php echo $record->safety_points; ?></td>
                        <td><?php echo $record->camera_status; ?></td>
                        <td><?php echo $record->inquiry_book ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->register_maintained ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->branding_backdrop_present ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->feedback_owner_admin; ?></td>
                        <td><?php echo $record->feedback_parents; ?></td>
                        <td><?php echo $record->feedback_teachers; ?></td>
                        <td><?php echo $record->feedback_students; ?></td>
                        <td><?php echo $record->doctor_contact_present ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->uniform_discipline_staff ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->uniform_discipline_students ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->books_copies_check ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->additional_books_reference ? 'Yes' : 'No'; ?></td>
                        <td><?php echo $record->additional_books_note; ?></td>
                        <td><?php echo $record->premise_overview; ?></td>
                        <td><?php echo $record->additional_programs; ?></td>
                        <td><?php echo $record->specific_concerns; ?></td>
                        <td><?php echo date("d-m-Y", strtotime($record->createdDtm)) ?></td>
                        <td><?php echo date("d-m-Y", strtotime($record->updatedDtm)) ?></td>
                        <td class="text-center">
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'offlineqcvisit/edit/'.$record->offlineVisitQcId; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                            <a class="btn btn-sm btn-danger deleteofflineqcvisit" href="#" data-offlineVisitQcId="<?php echo $record->offlineVisitQcId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                           <!--  <a class="btn btn-sm btn-info" href="<?php //echo base_url().'offlineqcvisit/view/'.$record->offlineVisitQcId; ?>" title="View"><i class="fa fa-eye"></i></a> -->
                        </td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "offlineqcvisit/offlineqcvisitListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
.star-rating-display .star {
    font-size: 24px;
    color: #f7d106; 
}

.star-rating-display .star.empty {
    color: #363333; 
}

</style>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
                        
<script>
  async function downloadImage(url) {
    try {
      // Fetch the file as a blob
      const response = await fetch(url, { mode: 'cors' }); // Ensure the server allows CORS if the URL is cross-origin

      // Check if the response is OK
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const blob = await response.blob(); // Convert the response to a blob
      const urlObject = URL.createObjectURL(blob); // Create a temporary object URL for the blob

      // Create a temporary <a> element
      const a = document.createElement('a');
      const filename = url.substring(url.lastIndexOf('/') + 1); // Extract filename from URL
      a.href = urlObject;
      a.download = filename;

      // Append the <a> element to the document body
      document.body.appendChild(a);

      // Trigger a click programmatically
      a.click();

      // Cleanup: Remove the <a> element and revoke the object URL
      document.body.removeChild(a);
      URL.revokeObjectURL(urlObject);
    } catch (error) {
      console.error('Error downloading the file:', error);
      alert('Failed to download the file. Please try again later.');
    }
  }
</script>
