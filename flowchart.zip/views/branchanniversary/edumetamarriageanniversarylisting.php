<?php
date_default_timezone_set('Asia/Kolkata');

$query = $this->db->query("
    SELECT 
        hronboardId,
        dob,
        first_name
    FROM tbl_hrforms_onboard
    WHERE dob IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(dob) = MONTH(CURDATE())
    AND DAY(dob) >= DAY(CURDATE())
    ORDER BY DAY(dob) ASC;
");

$rows = $query->result();
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-birthday-cake" aria-hidden="true"></i> Edumeta Employee Marriage Anniversary Management
            <small>View Birthdays</small>
        </h1>
    </section>
    <section class="content">
        <?php if (in_array($this->session->userdata('role'), [1, 2, 14, 26, 19])) { ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Edumeta Employee Marriage Anniversary List</h3>
                        </div><!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                            <table id="example" class="display responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>S. No.</th>
                                        <th>DOB</th>
                                        <th>First Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($rows)) { ?>
                                        <tr>
                                            <td></td>
                                            <td>No Marriage Anniversary found for the current month.</td>
                                            <td></td>
                                        </tr>
                                    <?php } else {
                                        foreach ($rows as $row) { ?>
                                            <tr class="<?= (date('m-d', strtotime($row->dob)) == date('m-d')) ? 'table-warning' : '' ?>">
                                                <td></td> <!-- S. No. will be handled by DataTables -->
                                                <td><?= !empty($row->dob) ? htmlspecialchars(date('F j, Y', strtotime($row->dob))) : 'No Data' ?></td>
                                                <td><?= !empty($row->first_name) ? htmlspecialchars($row->first_name) : 'No Data' ?></td>
                                            </tr>
                                        <?php }
                                    } ?>
                                </tbody>
                            </table>
                        </div><!-- /.box-body -->
                    </div><!-- /.box -->
                </div>
            </div>
        <?php } else { ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                You do not have permission to view this page.
            </div>
        <?php } ?>
    </section>
</div>

<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    /* Table CSS */
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        min-width: 50%;
        font-weight: bold;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }
    div.dataTables_wrapper li {
        text-indent: 0;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
        content: "-";
        background-color: #d33333;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }
</style>

<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css" rel="stylesheet">

<!-- DataTables JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable({
            "paging": true,
            "responsive": true,
            "info": true,
            "searching": true,
            "columns": [
                { "data": null }, // S. No.
                { "data": "dob" },
                { "data": "first_name" }
            ],
            "columnDefs": [
                {
                    "targets": 0,
                    "render": function(data, type, row, meta) {
                        return meta.row + 1; // Auto-increment S. No.
                    }
                }
            ]
        });
    });
</script>