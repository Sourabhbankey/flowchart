<?php
date_default_timezone_set('Asia/Kolkata');

$query = $this->db->query("
    SELECT 
        hronboardId,
        dob,
        first_name
    FROM tbl_hrforms_onboard
    WHERE dob IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(dob) = MONTH(CURDATE())
    AND DAY(dob) >= DAY(CURDATE())
    ORDER BY DAY(dob) ASC
");

$rows = $query->result();
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-birthday-cake" style="color: #ff69b4;" aria-hidden="true"></i> Edumeta Employee Birthday Management
            <small>View Birthdays</small>
        </h1>
    </section>
    <section class="content">
        <?php if (in_array($this->session->userdata('role'), [1, 2, 14, 26, 19])) { ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Edumeta Employee Birthday List</h3>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table id="birthdayTable" class="table table-striped display responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>S. No.</th>
                                        <th>Birthday</th>
                                        <th>Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($rows)) { ?>
                                        <tr>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>No staff birthdays found for the current month.</td>
                                            <td>-</td>
                                        </tr>
                                    <?php } else { ?>
                                        <?php foreach ($rows as $index => $row) { ?>
                                            <tr class="<?= (date('m-d', strtotime($row->dob)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                                                <td><?= !empty($row->hronboardId) ? htmlspecialchars($row->hronboardId) : 'No Data' ?></td>
                                                <td><?= !empty($row->dob) ? htmlspecialchars(date('F j, Y', strtotime($row->dob))) : 'No Data' ?></td>
                                                <td><?= !empty($row->first_name) ? htmlspecialchars($row->first_name) : 'No Data' ?></td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php } else { ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                You do not have permission to view this page.
            </div>
        <?php } ?>
    </section>
</div>


<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css" rel="stylesheet">

<!-- DataTables JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#birthdayTable').DataTable({
            "paging": true,
            "responsive": true,
            "info": true,
            "searching": true
        });
    });
</script>