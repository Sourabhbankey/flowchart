<?php
date_default_timezone_set('Asia/Kolkata');

$query = $this->db->query("
    SELECT franchiseNumber, branchAnniversaryDate, applicantName
    FROM tbl_branches
    WHERE branchAnniversaryDate IS NOT NULL
    AND franchiseNumber IS NOT NULL
    AND applicantName IS NOT NULL
    AND MONTH(branchAnniversaryDate) = MONTH(CURDATE())
    AND DAY(branchAnniversaryDate) >= DAY(CURDATE())
    ORDER BY DAY(branchAnniversaryDate) ASC;
");

$rows = $query->result();
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-calendar" aria-hidden="true"></i> Branch Anniversary Management
            <small>View Anniversaries</small>
        </h1>
    </section>
    <section class="content">
        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole == '1' || $userRole == '2' || $userRole == '14' || $userRole == '26' || $userRole == '19') { ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Branch Anniversary List</h3>
                        </div><!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                            <table id="example" class="display responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Branch No.</th>
                                        <th>Branch Anniversary</th>
                                        <th>Branch Owner</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($rows)) { ?>
                                        <tr>
                                            <td colspan="3">No anniversaries found for the current month.</td>
                                        </tr>
                                    <?php } else {
                                        foreach ($rows as $row) { ?>
                                            <tr class="<?= (date('m-d', strtotime($row->branchAnniversaryDate)) == date('m-d')) ? 'table-warning' : '' ?>">
                                                <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                                                <td><?= !empty($row->branchAnniversaryDate) ? htmlspecialchars(date('F j, Y', strtotime($row->branchAnniversaryDate))) : 'No Data' ?></td>
                                                <td><?= !empty($row->applicantName) ? htmlspecialchars($row->applicantName) : 'No Data' ?></td>
                                            </tr>
                                        <?php }
                                    } ?>
                                </tbody>
                            </table>
                        </div><!-- /.box-body -->
                    </div><!-- /.box -->
                </div>
            </div>
        <?php } else { ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                You do not have permission to view this page.
            </div>
        <?php } ?>
    </section>
</div>

<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    /* Table CSS */
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        min-width: 50%;
        font-weight: bold;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }
    div.dataTables_wrapper li {
        text-indent: 0;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
        content: "-";
        background-color: #d33333;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }
</style>

<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css" rel="stylesheet">

<!-- DataTables JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable({
            "paging": true,
            "responsive": true,
            "info": true,
            "searching": true
        });
    });
</script>