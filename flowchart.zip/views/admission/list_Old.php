<?php 

/*$this->load->view('includes/header');
        $this->load->view('includes/footer');*/

        ?>

<?php //$this->load->view('includes/header'); ?>
<?php //$this->load->view('includes/footer'); ?>
        <section class="content-header">
<h1>Customer Details Card</h1>
<p>Customer ID : </p>
<p>First Name  : </p>
<h4>License Number : <?php echo $this->session->userdata('licenseNumber') ?></h4>
        <h4>Growth Manager Name : <?php echo $this->session->userdata('growthName') ?></h4>
        <h4>Mobile No : <?php echo $this->session->userdata('growthcontact') ?></h4>
        <h4>Valid From Date : <?php echo $this->session->userdata('growthvalidDate') ?></h4>
        <h4>Valid Till Date : <?php echo $this->session->userdata('growthvalidDateTill') ?></h4>
    </section>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
