<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Admission Details
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">      
        <div class="row">
            <div class="col-xs-12">
              <div class="box" style="padding-top: 20px;">   
                <div class="col-lg-6 col-xs-12">
                  <!-- small box -->
                  <div class="small-box bg-aqua" style="background-color: #ed5d24;">
                    <div class="inner">
                        <h4>Admissions PG : <span class="admnumdata"><?php echo $this->session->userdata('franAdmPGdetails') ?></span></h4>
                        <h4>Admissions NURSERY : <span class="admnumdata"><?php echo $this->session->userdata('franAdmNurdetails') ?></span></h4>
                        <h4>Admissions KG1 : <span class="admnumdata"><?php echo $this->session->userdata('franAdmKG1details') ?></span></h4>
                        <h4>Admissions KG2 : <span class="admnumdata"><?php echo $this->session->userdata('franAdmKG2details') ?></span></h4>
                        <h4>Admissions 1st : <span class="admnumdata"><?php echo $this->session->userdata('franAdm1stdetails') ?></span></h4>
                        <h4>Admissions 2nd : <span class="admnumdata"><?php echo $this->session->userdata('franAdm2nddetails') ?></span></h4>
                        <h4>Total Admissions : <span class="admnumdata"><?php echo $this->session->userdata('franAdmtotdetails') ?></span></h4>
                        <!-- <h4>Admission Counselor Name : <span class="admnumdata"><?php //echo $this->session->userdata('franAdmCondetails') ?></span></h4>
                        <h4>Last Discussion (Admissions) : <span class="admnumdata"><?php //echo $this->session->userdata('franAdmLDisdetails') ?></span></h4> -->
                    </div>
                  </div>
                </div>   <!-- End-small box --> 
                <div class="box-footer clearfix">
                    <?php //echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
/*table-css*/ 
span.admnumdata {
    font-weight: 800;
    padding: 25px;
    font-size: 20px;
}
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "despatch/despatchListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>


