<?php echo $this->session->userdata('offerName') ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Account Details
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">      
        <div class="row">
           <div class="col-lg-12 col-xs-12">
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><i class="fa fa-list-alt"></i> Franchise Offer Details</h3>
        </div>
        <div class="box-body">
            <table class="table table-bordered table-hover table-striped responsive nowrap">
                <thead>
                    <tr>
                        <th>Sr. No.</th>
                        <th>Detail</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $offerDetails = [
                            'Offer Plan' => $this->session->userdata('franofferPlanname'),
                            'Offer Amount' => '₹' . $this->session->userdata('franofferName'),
                            'Discount' => '₹' . $this->session->userdata('franACdiscountAmount'),
                            'Final Franchise Amount' => '₹' . $this->session->userdata('franACfinAmdetails'),
                            'GST Amount' => '₹' . $this->session->userdata('franACGSTAmdetails'),
                            'Total Paid Amount' => '₹' . $this->session->userdata('frantotalPaidamount'),
                            'Due Franchise Amount' => '₹' . $this->session->userdata('franACdueFranchiseamt'),
                            'Legal Charges' => '₹' . $this->session->userdata('franACLeChargAmsales'),
                            'Legal Charges Due' => '₹' . $this->session->userdata('franACLeDueAmdetails'),
                            'Branch Setup & Installation Charges' => '₹' . $this->session->userdata('franACbrSetupinsChargSales'),
                            'Branch Setup & Installation Charges (Due)' => '₹' . $this->session->userdata('franACTotGSTChargeAmdetails'),
                            'No. Of Initial Student KIT Offered' => $this->session->userdata('franACnumInialKitSales'),
                            'No. of Initial Kits' => $this->session->userdata('franACnuminitialKit'),
                            'KIT Charges' => '₹' . $this->session->userdata('franACkitCharges'),
                            'Total Kits Amount' => '₹' . $this->session->userdata('franACtotalKitsamt'),
                            'Kit Amount Received' => '₹' . $this->session->userdata('franACkitamtReceived')
                        ];
                        $sr = 1;
                        foreach ($offerDetails as $label => $value) {
                            echo "<tr>
                                    <td>{$sr}</td>
                                    <td>{$label}</td>
                                    <td>{$value}</td>
                                  </tr>";
                            $sr++;
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



                </div>   <!-- End-small box --> 
                <div class="box-footer clearfix">
                    <?php //echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
/*table-css*/ 
span.admnumdata {
    font-weight: 800;
    padding: 25px;
    font-size: 20px;
}
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "despatch/despatchListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>


