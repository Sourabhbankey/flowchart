<?php
$taskId = $taskInfo->taskId;
$taskTitle = $taskInfo->taskTitle;
$description = $taskInfo->description;
$status = $taskInfo->status;
$taskattchS3File = $taskInfo->taskattchS3File;

$selectUserId = '';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Task Management
            <small>Reply Task</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Task Reply</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="taskTitle">Task Title</label>
                                    <input type="text" class="form-control required" value="<?php echo $taskTitle; ?>" id="taskTitle" name="taskTitle" maxlength="256" readonly>
                                    <input type="hidden" value="<?php echo $taskId; ?>" name="taskId" id="taskId" />
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="taskTitle">Collaborators <span class="re-mend-field"></span></label>
                                    <select class="form-control required" id="collaborators" name="collaborators[]" multiple data-live-search="true">
                                        <option value="0">Select User</option>
                                        <?php
                                        if (!empty($users)) {
                                            foreach ($users as $rl) {
                                                $userText = $rl->name;
                                                if ($role == $rl->roleId || $is_admin == 1) {
                                        ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if ($rl->userId == set_value('assignedTo')) {
                                                                                                    echo "selected=selected";
                                                                                                } ?>><?= $userText ?></option>
                                        <?php
                                                }
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group reply-desc-cls">
                                    <label for="description">Description</label>
                                    <?php echo $description; ?><br>
                                </div>
                                <div class="form-group reply-desc-cls">
                                    <label for="created">Created At</label>
                                    <?php
                                    $query = $this->db->query("SELECT createdDtm FROM tbl_task WHERE taskId = " . $taskId);
                                    if ($query->num_rows() > 0) {
                                        $row = $query->row();
                                        echo $row->createdDtm;
                                    } else {
                                        echo "No record found";
                                    }
                                    ?><br>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="taskTitle">File Attachment</label>
                                        <a href="<?php echo $taskInfo->taskattchS3File ?>" target="_blank"><button class="btn"><img src="<?php echo $taskInfo->taskattchS3File ?>" style="height: 50px !important;width: 50px;"></a>
                                    </div>
                                </div>

                                <div class="col-md-12 reply-desc-cls" id="repliesList">
                                    <?php
                                    if (!empty($replyData)) {
                                        foreach ($replyData as $replyDat) {
                                            $Query          = "SELECT * FROM tbl_users WHERE userId='$replyDat->repliedBy'";
                                            $fetchAr        = $this->db->query($Query);
                                            $Details        = $fetchAr->row();
                                            $replyName      = $Details->name;
                                    ?>
                                            <span style="color: gray;font-size: 12px;"><i class="fa fa-user"></i> <?php echo $replyName ?> :-</span>
                                            <p><?php echo $replyDat->reply ?></p>
                                            <p> <?php echo $replyDat->createdDtm; ?></p>


                                    <?php
                                        }
                                    }
                                    ?>
                                </div>


                                <div class="col-md-12">
                                    <button class="btn btn-sm btn-info" title="Reply" onclick="myFunction()"><i class="fa fa-reply"></i> Reply</button>
                                    <a href="<?php echo base_url() ?>task/taskListing" class="btn btn-sm btn-info">Back to List</a>
                                </div>

                                <!-- Reply Form -->
                                <form role="form" id="replyTaskForm" enctype="multipart/form-data">
                                    <input type="hidden" value="<?php echo $taskId; ?>" name="taskId" id="taskId" />
                                    <div class="col-md-12 shodiv" style="margin-top: 13px;">
                                        <div class="form-group">
                                            <textarea class="form-control required" id="taskReply" name="taskReply" placeholder="Type your reply here..."></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="file">Upload File</label>
                                            <input type="file" name="file[]" id="file" multiple>
                                        </div>
                                        <input type="submit" class="btn btn-sm btn-primary" value="Submit" />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    textarea.form-control {
        height: 250px;
    }

    .reply-desc-cls p {
        word-wrap: break-word;
    }

    .reply-desc-cls .table td {
        word-wrap: break-word;
    }
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.0/classic/ckeditor.js"></script>
<script type="text/javascript">
    $('.shodiv').hide();

    function myFunction(params) {
        $('.shodiv').show();
    }
</script>
<script>
    ClassicEditor
        .create(document.querySelector("#taskReply"))
        .catch(error => {
            console.er
            ror(error);
        });
</script>
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script>
    if (typeof jQuery === 'undefined') {
        document.write('<script src="https://code.jquery.com/jquery-3.6.0.min.js"><\/script>');
    }
</script>
<script type="text/javascript">
    // Handle the form submission
    $('#replyTaskForm').submit(function (e) {
        e.preventDefault(); // Prevent default form submission

        // Get input values
        const replyText = $('#taskReply').val().trim(); // Trim whitespace
        const fileInput = $('#file').val(); // Get file input value

        // Validation: Ensure at least one field is filled
        if (!replyText && !fileInput) {
            alert('Please provide a reply text or upload a file before submitting.');
            return; // Stop further execution
        }

        let formData = new FormData(this); // Collect form data
        $.ajax({
            url: '<?php echo base_url("task/replyTask") ?>',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                console.log('Response:', response); // Debugging the response
                response = JSON.parse(response);

                if (response.success) {
                    // Build the new reply HTML structure
                    let newReply = `<div class="reply">
                        <strong>${response.username}:</strong> ${response.reply}
                        <small>${response.createdDtm}</small>
                        <div>`;

                    // Add attached images if they exist
                    if (response.taskreplyattchS3File && response.taskreplyattchS3File.length > 0) {
                        response.taskreplyattchS3File.forEach(function (file) {
                            newReply += `<a href="${file}" target="_blank">
                                <img src="${file}" alt="attachment" style="width: 90px; height: auto; margin-right: 10px;">
                            </a>`;
                        });
                    }

                    newReply += `</div></div>`;

                    // Append the new reply to the replies list
                    $('#repliesList').append(newReply);

                    // Save replies to local storage for persistence
                    localStorage.setItem('repliesList', $('#repliesList').html());

                    // Clear form fields
                    $('#taskReply').val('');
                    $('#file').val('');

                    // Refresh the page to show updated data
                    location.reload();
                } else {
                    alert('Error submitting reply.');
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', error); // Log error
                alert('An error occurred while submitting the form.');
            }
        });
    });

    // Restore replies from local storage on page load
    $(document).ready(function () {
        const savedReplies = localStorage.getItem('repliesList');
        if (savedReplies) {
            $('#repliesList').html(savedReplies);
        }
    });
</script>
