<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Record
        <small>Add / Edit  Record</small>
      </h1>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>Itwebrecords/addNewItwebrecords" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
							
                              <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="issuedon">Onboarding Manager</label>
                                  <input required type="text" class="form-control required" value="" id="brOnboardMgr" name="brOnboardMgr" maxlength="256" />
                                    </div>
                                </div>
                               
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity"> Growth Manager</label>
                                        <input required type="text" class="form-control required" value="" id="brGrowthMgr" name="brGrowthMgr" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Branch No. </label>
                                        <input required type="text" class="form-control required" value="" id="brNumbr" name="brNumbr" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Branch Name</label>
                                        <input required type="text" class="form-control required" value="" id="brName" name="brName" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">City</label>
                                        <input  required type="text" class="form-control required" value="" id="brCity" name="brCity" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">

State
                                        </label>
                                        <input required type="text" class="form-control required" value="" id="brStatus" name="brStatus" maxlength="256" />

                                    </div>
                                    </div> 
                                    <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Website Creation Status</label>
                                        <select class="form-control required" id="webCreationStatus" name="webCreationStatus" required>
    <option value="">Select Status</option>
    <option value="Active">Active</option>
    <option value="Inactive">Inactive</option>
</select>

                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Website Link</label>
                                        <input required type="text" class="form-control required" value="" id="websiteLink" name="websiteLink" maxlength="256" />
                                    </div>
                                </div> 
                                
<!--                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Description</label>
                                        <textarea required class="form-control required" id="description" name="description" maxlength="256" rows="4"></textarea>

                                    </div>
                                </div> -->
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="issuedon">Date Of Sharing (Website)</label>
                                  <input required type="date" class="form-control required" value="" id="websharingdate" name="websharingdate" maxlength="256" />
                                    </div>
                                </div>
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="issuedon">Date of Sharing(Edumeta App)</label>
                                  <input required type="date" class="form-control required" value="" id="edumetaAppdate" name="edumetaAppdate" maxlength="256" />
                                    </div>
                                </div> 
                                
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Description</label>
                                        <textarea required class="form-control required" id="description" name="description" maxlength="256" rows="4"></textarea>

                                    </div>
                                </div>  
                               
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>   
</div>