<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-image" aria-hidden="true"></i> View Attachment
            <small>Preview of the selected attachment</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <?php
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Attachment: <?php echo htmlspecialchars($attachmentInfo->attachmentTitle); ?></h3>
                        <div class="box-tools pull-right">
                            <a href="<?php echo base_url('attachment/attachmentListing'); ?>" class="btn btn-primary">
                                <i class="fa fa-arrow-left"></i> Back to List
                            </a>
                        </div>
                    </div>
                    <div class="box-body">
                        <?php if (!empty($attachmentInfo->attachmentS3File)) { ?>
                            <?php
                            $file_paths = explode(',', $attachmentInfo->attachmentS3File);
                            if (count($file_paths) > 0) {
                                echo '<div class="row">';
                                foreach ($file_paths as $index => $file_path) {
                                    if (!empty($file_path)) {
                                        // Determine file type based on extension
                                        $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
                                        $isImage = in_array($extension, ['png', 'jpg', 'jpeg']);
                                        $isVideo = in_array($extension, ['mp4', 'mpeg', 'mov']);
                            ?>
                                        <div class="col-md-4 col-sm-6 col-xs-12">
                                            <div class="card">
                                                <div class="card-media">
                                                    <?php if ($isImage) { ?>
                                                        <img src="<?php echo htmlspecialchars($file_path); ?>"
                                                             alt="<?php echo htmlspecialchars($attachmentInfo->attachmentTitle); ?> Image <?php echo $index + 1; ?>"
                                                             class="img-responsive">
                                                    <?php } elseif ($isVideo) { ?>
                                                        <video controls class="video-responsive">
                                                            <source src="<?php echo htmlspecialchars($file_path); ?>" type="video/<?php echo $extension; ?>">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php } else { ?>
                                                        <p>Unsupported file type: <?php echo $extension; ?></p>
                                                    <?php } ?>
                                                </div>
                                                <div class="card-body text-center">
                                                    <button class="btn btn-primary"
                                                            onclick="downloadFile('<?php echo $file_path; ?>', this, '<?= $attachmentInfo->attachmentId . '_' . $index; ?>', '<?php echo $isImage ? 'Image' : ($isVideo ? 'Video' : 'File'); ?>')">
                                                        <i class="fa fa-download"></i> Download <?php echo $isImage ? 'Image' : ($isVideo ? 'Video' : 'File'); ?> <?= $index + 1 ?>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                            <?php
                                    }
                                }
                                echo '</div>';
                            } else {
                            ?>
                                <p>No files available for this attachment.</p>
                            <?php
                            }
                            ?>
                        <?php } else { ?>
                            <p>No files available for this attachment.</p>
                        <?php } ?>
                    </div>
                    <div class="box-footer text-center">
                        <a href="<?php echo base_url('attachment/attachmentListing'); ?>" class="btn btn-default">
                            <i class="fa fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style type="text/css">
    .img-responsive, .video-responsive {
        display: block;
        max-width: 100%;
        height: 400px; /* Adjusted for uniformity */
        width: auto;
        border-radius: 5px;
        margin: 0 auto;
    }

    .box {
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .box-header {
        background-color: #f8f9fa;
        padding: 15px;
    }

    .box-body {
        padding: 20px;
    }

    .box-footer {
        padding: 15px;
        background-color: #f8f9fa;
    }

    .card {
        border: 1px solid #ddd;
        border-radius: 5px;
        margin-bottom: 20px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        background-color: #fff;
    }

    .card-media {
        padding: 10px;
        text-align: center;
    }

    .card-body {
        padding: 15px;
    }

    .download-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
</style>

<!-- Bootstrap CSS (assuming it's not already included in your template) -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        // Handle image load errors
        jQuery('img').on('error', function() {
            jQuery(this).hide();
            jQuery(this).parent().append('<p class="text-danger">Unable to load image. Please check the URL or try again later.</p>');
        });

        // Handle video load errors
        jQuery('video').on('error', function() {
            jQuery(this).hide();
            jQuery(this).parent().append('<p class="text-danger">Unable to load video. Please check the URL or try again later.</p>');
        });
    });

    function downloadFile(url, button, attachmentId, fileType) {
        const $button = jQuery(button);
        $button.prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Downloading...');

        fetch(url, {
                mode: 'cors' // needed for cross-origin URLs
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`${fileType} not available for download.`);
                }
                return response.blob();
            })
            .then(blob => {
                const blobUrl = URL.createObjectURL(blob);
                const link = document.createElement('a');
                const filename = url.split('/').pop() || `${fileType.toLowerCase()}_${attachmentId}.${fileType === 'Image' ? 'jpg' : 'mp4'}`;
                link.href = blobUrl;
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(blobUrl);
            })
            .catch(error => {
                jQuery(button).parent().append(`<p class="text-danger">Download failed: ${error.message}</p>`);
            })
            .finally(() => {
                const index = parseInt(attachmentId.split('_')[1]) + 1;
                $button.prop('disabled', false).html(`<i class="fa fa-download"></i> Download ${fileType} ${index}`);
            });
    }
</script>
<script type="text/javascript">
    function downloadFile(fileUrl, button, uniqueId, fileType, fileName) {
        // Disable the button to prevent multiple clicks
        $(button).prop('disabled', true).addClass('download-btn').text(`Downloading ${fileType}...`);

        // Create a temporary anchor element to trigger the download
        const link = document.createElement('a');
        link.href = fileUrl;
        link.download = `${fileName}.${fileUrl.split('.').pop()}`; // Set the file name for download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Re-enable the button after a short delay (optional, to ensure download starts)
        setTimeout(() => {
            $(button).prop('disabled', false).removeClass('download-btn').html(`<i class="fa fa-download"></i> Download ${fileType}`);
        }, 2000);
    }
</script>