<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Attachment Management
            <small>Add / Edit Attachment</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Attachment / Upload File Details</h3>
                          <div class="pull-right">
            <a href="<?php echo base_url() ?>attachment/attachmentListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div>
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>attachment/addNewAttachment" enctype="multipart/form-data" method="post">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="attachmentTitle">Attachment Title</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('attachmentTitle'); ?>" id="attachmentTitle" name="attachmentTitle" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="attachmentType">Attachment Type</label>
                                        <select class="form-control required" id="attachmentType" name="attachmentType">
                                            <option value="">Select Type</option>
                                            <option value="Image">Image</option>
                                            <option value="Video">Video</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise</label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" multiple data-live-search="true" required>
                                            <option value="selectAll">Select All</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="linkAttachment">Google Drive Link</label>
                                        <input type="url" class="form-control" id="linkAttachment" name="linkAttachment" placeholder="https://example.com" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="file">Upload Files <span class="text-danger">*</span></label>
                                      <input type="file" name="file[]" id="file" multiple required>

                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Remark - Short Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    var isSelectAll = false;

    $('#franchiseNumber').change(function() {
        var selectedValues = $(this).val();

        if (selectedValues && selectedValues.includes('selectAll')) {
            if (!isSelectAll) {
                $('#franchiseNumber option').prop('selected', true);
                isSelectAll = true;
            } else {
                $('#franchiseNumber option').prop('selected', false);
                isSelectAll = false;
            }
            $('#franchiseNumber option[value="selectAll"]').prop('selected', false);
            $('#franchiseNumber').selectpicker('refresh');
        }
    });

    $('#attachmentType').change(function() {
        const type = $(this).val();
        const fileInput = $('#file');
        if (type === 'Image') {
            fileInput.attr('accept', 'image/png,image/jpeg,image/jpg,image/cdr');
        } else if (type === 'Video') {
            fileInput.attr('accept', 'video/mp4,video/avi,video/quicktime');
        } else {
            fileInput.attr('accept', 'image/png,image/jpeg,image/cdr,image/jpg,video/mp4,video/avi,video/quicktime');
        }
    });

   $('#file').on('change', function () {
    const files = this.files;
    const attachmentType = $('#attachmentType').val();
    const allowedImageTypes = ['png', 'jpeg', 'jpg', 'cdr'];
    const allowedVideoTypes = ['mp4', 'avi', 'mov'];
    let errorMessage = '';

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileName = file.name.toLowerCase();
        const extension = fileName.substring(fileName.lastIndexOf('.') + 1);

        const isImage = allowedImageTypes.includes(extension);
        const isVideo = allowedVideoTypes.includes(extension);

        if (attachmentType === 'Image' && !isImage) {
            errorMessage += `${file.name} is not a valid image file (PNG, JPG, JPEG, CDR).\n`;
        } else if (attachmentType === 'Video' && !isVideo) {
            errorMessage += `${file.name} is not a valid video file (MP4, AVI, MOV).\n`;
        } else if (!isImage && !isVideo) {
            errorMessage += `${file.name} is not a valid file type.\n`;
        }
    }

    if (errorMessage) {
        alert(errorMessage);
        this.value = ''; // Clear the input
    }
});


    $('#yourForm').on('submit', function(e) {
        const submitBtn = $('#submitBtn');
        if (submitBtn.prop('disabled')) {
            e.preventDefault();
            return;
        }
        submitBtn.prop('disabled', true).text('Submitting...');
    });
});
</script>