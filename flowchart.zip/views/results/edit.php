<?php
$resultsId = $resultsrecordInfo->resultsId;
$finalfranchisecost = $resultsrecordInfo->finalfranchisecost;

$amountreceived = $resultsrecordInfo->amountreceived;
$initialkitsoffered =$resultsrecordInfo->initialkitsoffered;
$premisestatus = $resultsrecordInfo->premisestatus;
$expectedinstallationdate = $resultsrecordInfo->expectedinstallationdate;
$additionaloffer = $resultsrecordInfo->additionaloffer;

$incentivereceived = $resultsrecordInfo->incentivereceived;
$incentivereceivedSTL =$resultsrecordInfo->incentivereceivedSTL;
$offername =$resultsrecordInfo->offername;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Results Record Management
        <small>Add / Edit Clients Record</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Results Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>results/editResultsrecord" method="post" id="editResultsrecord" role="form">
                        <div class="box-body">
                        <div class="row">
                                
                            <input type="hidden" name="resultsId" value="<?php echo $resultsId; ?>" />

                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Final franchise cost</label>
                                        <input required type="text" class="form-control required" value="<?php echo $finalfranchisecost; ?>" id="finalfranchisecost" name="finalfranchisecost" maxlength="256" />
                                    </div>
                                </div>  
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Amount Resceived</label>
                                        <input required type="text" class="form-control required" value="<?php echo $amountreceived; ?>" id="amountreceived" name="amountreceived" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Initial kits offered</label>
                                        <input required type="text" class="form-control required" value="<?php echo $initialkitsoffered; ?>" id="initialkitsoffered" name="initialkitsoffered" maxlength="256" />
                                    </div>
                                </div> 
                              <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productCode">Premise Status</label>
                                      <select class="form-control required" id="premisestatus" name="premisestatus" required>
    <option value="ready" <?php echo (trim($premisestatus) == "ready") ? "selected" : ""; ?>>Ready</option>
<option value="underprocess" <?php echo (trim($premisestatus) == "underprocess") ? "selected" : ""; ?>>Underprocess</option>

</select>

                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Expected installation date</label>
                                        <input required type="date" class="form-control required" value="<?php echo $expectedinstallationdate; ?>" id="expectedinstallationdate" name="expectedinstallationdate" maxlength="256" />
                                    </div>
                                </div> 
                                   <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Additional offerings</label>
                                        <input required type="text" class="form-control required" value="<?php echo $additionaloffer; ?>" id="additionaloffer" name="additionaloffer" maxlength="256" />
                                    </div>
                                </div>
                               <?php if ($role == 2) : ?>
    <div class="col-md-6">                                
        <div class="form-group">
            <label for="incentivereceived">Incentive Received Sales AOM</label>
            <input required="" type="text" class="form-control required" 
       value="<?= isset($incentivereceived) ? htmlspecialchars($incentivereceived) : ''; ?>" 
       id="incentivereceived" name="incentivereceived" maxlength="256">
        </div>
    </div>
    <div class="col-md-6">                                
        <div class="form-group">
            <label for="incentivereceivedSTL">Incentive Received Sales TL</label>
            <input required type="text" class="form-control required" 
                   value="<?php echo $incentivereceivedSTL; ?>" 
                   id="incentivereceivedSTL" 
                   name="incentivereceivedSTL" 
                   maxlength="256" />
        </div>
    </div>
     <div class="col-md-6">                                
        <div class="form-group">
            <label for="offername">Offer Name</label>
            <input required type="text" class="form-control required" 
                   value="<?php echo $offername; ?>" 
                   id="offername" 
                   name="offername" 
                   maxlength="256" />
        </div>
    </div>
<?php endif; ?>

                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>