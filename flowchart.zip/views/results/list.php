<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Results Record Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <!-- <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>results/add"><i class="fa fa-plus"></i> Add New Results Record</a>
                </div> -->
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group filterfrmgroup">
                    <!-- <h3 class="box-title"></h3> -->
                    <label for="resultrecordlist">Results Record List</label>
                     <?php if ($userRole != 29) { ?>
                         <form action="<?php echo base_url() ?>results/resultsListing" method="GET" id="searchList">
    <select name="userFilter" class="form-control-old input-sm">
        <option value="">All Users</option>
        <?php foreach ($users as $user) { ?>
            <option value="<?php echo $user->userId; ?>" <?php echo ($user->userId == $userFilter) ? 'selected' : ''; ?>>
                <?php echo $user->name; ?>
            </option>
        <?php } ?>
    </select>

    <input type="date" name="fromDate" value="<?php echo $fromDate; ?>" class="form-control-old input-sm" placeholder="From Date"/>
    <input type="date" name="toDate" value="<?php echo $toDate; ?>" class="form-control-old input-sm" placeholder="To Date"/>

    <button type="submit" class="btn btn-primary btn-sm btn-default searchList" style="color: #fff;">
        <i class="fa fa-search"></i> Search
    </button>
    
        <a href="<?php echo base_url('results/resultsListing'); ?>" class="btn btn-secondary btn-sm">
   <i class="fa fa-refresh"></i> Reset
</a> 
</form>
<?php } ?>

                           
                               <a class="btn btn-sm btn-primary" href="<?php echo base_url().'results/viewincentive/1'; ?>" title="View">
                                    View Incentive
                                </a>
                           
                </div>
            </div>
        </div> 

        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <div class="box-tools">
                        <!-- <form action="<?php echo base_url() ?>results/resultsListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form> -->
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                  <table id="example" class="display responsive nowrap" style="width:100%">
                    <thead>
                    <tr>
                         <th>Sr. No.</th>
                         <th>Client Name</th>
                         
                        <th>Issued On</th>
                        <th>First Call</th>
                         <?php if ($userRole != 29) { ?>
                            <th>User Name</th>
                        <?php } ?>
                        <th>Contact No</th>
                        <th>Alter Contact No</th>
                        <th>Email Id</th>
                        <th>City</th>
                        <th>Location</th>
                        <th>Last Call</th>
                        <th>Next Followup</th>
                        <th>Status</th>
                        <th>Comment1</th>
                        <th>Comment2</th>
                         <th class="text-center">Actions</th>

                        
                    </tr>
                    </thead>
                 <tbody>
                    <?php  
                    if(!empty($records))
                        $counter = 1;
                    {
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                         <td><?php echo $counter++; ?></td>
                            <td><?php echo $record->clientname ?></td>
                         
                        <td><?php echo $record->issuedon ?></td>
                        <td><?php echo $record->firstcall ?></td>
                     <?php if ($userRole != 29) { ?>
                            <td><?php echo $record->userName; ?></td>
                        <?php } ?>
                        <td><?php echo $record->contactno ?></td>
                        <td><?php echo $record->altercontactno ?></td>
                        <td><?php echo $record->emailid ?></td>
                        <td><?php echo $record->city ?></td>
                        <td><?php echo $record->location ?></td>
                        <td><?php echo $record->lastcall ?></td>
                        <td><?php echo $record->nextfollowup ?></td>
                        <td><?php echo $record->status ?></td>
                        <td><?php echo $record->description ?></td>
                        <td><?php echo $record->description2 ?></td>
                         <td class="text-center">
    <?php if ($record->is_edited == 0 || $userRole == 2) { ?>
        <!-- Show Edit button if NOT edited -->
        <a class="btn btn-sm btn-info" href="<?php echo base_url().'results/edit/'.$record->resultsId; ?>" title="Edit">
            <i class="fa fa-pencil"></i>
        </a>
    <?php } ?>
    
    <!-- Always show View button -->
    <a class="btn btn-sm btn-primary" href="<?php echo base_url().'results/view/'.$record->resultsId; ?>" title="View">
        <i class="fa fa-eye"></i>
    </a>

    <!-- Keep Delete button -->
    <a class="btn btn-sm btn-danger deleteStock" href="#" data-salesrecId="<?php echo $record->resultsId; ?>" title="Delete">
        <i class="fa fa-trash"></i>
    </a>
 
</td>

                    </tr>
                   <?php
                        }
                    }
                    ?>
                    <?php //if (in_array($userRole, [2, 1, 14])) { ?>
                    <!-- <a class="btn btn-sm btn-primary" href="<?php echo base_url().'results/viewincentive/'.$record->resultsId; ?>" title="View">View Incentive</a> -->
                    <?php //} ?>  
                  </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <?php if ($totalRecords > 0) { ?>
    <p class="text-muted">
        Showing records <strong><?php echo $startRecord; ?></strong> to <strong><?php echo $endRecord; ?></strong> of <strong><?php echo $totalRecords; ?></strong>
    </p>
<?php } else { ?>
    <p class="text-muted">No records found.</p>
<?php } ?>
                <div class="box-footer clearfix">
                    <div class="br-pagi">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
    .filterfrmgroup {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
}
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "training/trainingListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
