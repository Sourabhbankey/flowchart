<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Record
        <small>Add / Edit  Record</small>
      </h1>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
 <!--  <form method="GET" action="">
    <label for="month">Filter by Month:</label>
    <input type="month" name="month" id="month" value="<?= htmlspecialchars($selectedMonth); ?>">
    <button type="submit" class="btn btn-primary">Filter</button>
</form> -->
<form method="GET" action="<?= base_url('results/viewincentive'); ?>">
    <label>Month:</label>
    <input type="month" name="month" value="<?= isset($_GET['month']) ? $_GET['month'] : ''; ?>">

    <label>User:</label>
    <select name="userId">
        <option value="">All Users</option>
        <?php foreach ($users as $user) : ?>
            <option value="<?= $user['userId']; ?>" 
                <?= (isset($_GET['userId']) && $_GET['userId'] == $user['userId']) ? 'selected' : ''; ?>>
                <?= $user['name']; ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Filter</button>
</form>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>User Name</th>
            <th>Team Leader Name</th>
            <th>Month</th>
           
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($monthly_incentives)) : ?>
            <?php foreach ($monthly_incentives as $incentive) : ?>
                <tr>
                    <td><?= htmlspecialchars($incentive['userName'] ?? 'Unknown'); ?></td>
                    
                    <td><?= htmlspecialchars($incentive['team_lead_name'] ?? 'Unknown'); ?></td>
                    <td><?= htmlspecialchars($incentive['incentive_month'] ?? '-'); ?></td>
                   
                    <td>
                        <button class="btn btn-primary btn-sm view-incentives" 
                            data-user-id="<?= htmlspecialchars($incentive['userId'] ?? ''); ?>">
                            View
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr>
                <td colspan="5" class="text-center">No incentive records found for this month.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Modal to show incentive details -->
<div class="modal fade" id="incentiveModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Incentive Details For Sales</h3>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Client Name</th>
                            <th>Month</th>
                            <th>Incentive Received By Sales AOM</th>
                            <?php if ($role != 29): ?>
                            <th>Incentive Received By TL</th>
                            <th>Total-(SAOM + TL)</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="incentiveDetails"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>









<!-- Summary Section -->


<a href="<?php echo base_url('results/resultsListing'); ?>" class="btn btn-secondary">Back</a>



                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>   
</div>
<script>
$(document).ready(function() {
    $(document).on("click", ".view-incentives", function() { 
        var userId = $(this).data("user-id");

        if (!userId) {
            alert("User ID not found!"); 
            return;
        }

        console.log("User ID:", userId); // Debugging

        $.ajax({
            url: "<?= base_url('results/fetchIncentives'); ?>",
            type: "POST",
            data: { userId: userId },
            dataType: "html",  // Ensure HTML response
            success: function(response) {
                console.log("Response received:", response); // Debugging
                $("#incentiveDetails").html(response);
                $("#incentiveModal").modal("show");
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error);
                console.log("Server Response:", xhr.responseText); // Log full response
                alert("Error fetching incentives! Check console for details.");
            }
        });
    });
});

</script>
<style>
    .incent-total {
    font-weight: bold;
    background-color: #1E88E5;
    color: #fff;
    font-size: 18px;
    border-top: 4px solid #000;
}
</style>

