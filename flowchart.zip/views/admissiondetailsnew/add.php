Details
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Admission 25-26 Details Management
            <small>Add / Edit Admission</small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Admission Details Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>admissiondetailsnew/addNewAdmissiondetails" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25  ) { ?>
                                            <!-- Franchise users: Non-editable field -->
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: ''; // Use session franchise number or empty
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php if ($role == 14) { ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                        <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                            <span>Select a franchise to assign</span>
                                        </div>
                                        <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="name">Student Name<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('name'); ?>" id="name" name="name" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="enrollNum">Enrollment Number<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('enrollNum'); ?>" id="enrollNum" name="enrollNum" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="className">Class Name <span class="re-mend-field">*</span></label>
                                        <select required class="form-control" id="className" name="class_name">
                                            <option value="">Select Class</option>
                                            <?php if (!empty($classes)) {
                                                foreach ($classes as $classs) { ?>
                                                    <option value="<?php echo $classs->className; ?>" <?php echo set_select('className', $classs->className); ?>>
                                                        <?php echo $classs->className; ?>
                                                    </option>
                                            <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="sectionName">Section Name <span class="re-mend-field">*</span></label>
                                        <select required class="form-control" id="sectionName" name="section_name">
                                            <option value="">Select Subject</option>
                                            <?php if (!empty($sections)) {
                                                foreach ($sections as $section) { ?>
                                                    <option value="<?php echo $section->sectionName; ?>" <?php echo set_select('sectionName', $section->sectionName); ?>>
                                                        <?php echo $section->sectionName; ?>
                                                    </option>
                                            <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                               
                                <!-- <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="staffType">Staff <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="staffType" name="staffType" required>
                                            <option value="">Select Staff</option> -->
                                <!-- Staff options will be populated dynamically via AJAX -->
                                <!-- </select>
                                    </div>
                                </div> -->
                               
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateOfAdmission">Date Of Admission <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateOfAdmission'); ?>" id="dateOfAdmission" name="dateOfAdmission" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="program">Program <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="program" name="program" required>
                                            <option value="">Select Program Type</option>
                                            <option value="Regular">Regular</option>
                                            <option value="Settler">Settler</option>
                                            <option value="Summer Camp">Summer Camp</option>
                                            <option value="Day Care">Day Care</option>
                                            <option value="Bridge Course">Bridge Course</option>
                                            <option value="Winter Camp">Winter Camp</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="birthday">Date Of Birth <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('birthday'); ?>" id="birthday" name="birthday" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="age">Age <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('age'); ?>" id="age" name="age" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="gender">Gender <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="gender" name="gender" required>
                                            <option value="">Select Gender Type</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fathername">Father's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('fathername'); ?>" id="fathername" name="fathername" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatheremail">Father's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo set_value('fatheremail'); ?>" id="fatheremail" name="fatheremail" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fatherMobile_no">Father's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('fatherMobile_no'); ?>" id="fatherMobile_no" name="fatherMobile_no" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="mothername">Mother's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('mothername'); ?>" id="mothername" name="mothername" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motheremail">Mother's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo set_value('motheremail'); ?>" id="motheremail" name="motheremail" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motherMobile_no">Mother's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('motherMobile_no'); ?>" id="motherMobile_no" name="motherMobile_no" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="bloodGroup">Blood Group <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('bloodGroup'); ?>" id="bloodGroup" name="bloodGroup" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="motherTongue">Mother Tongue <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('motherTongue'); ?>" id="motherTongue" name="motherTongue" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="religion">Religion <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('religion'); ?>" id="religion" name="religion" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="caste">Caste <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('caste'); ?>" id="caste" name="caste" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('city'); ?>" id="city" name="city" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="state">State <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('state'); ?>" id="state" name="state" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="address">Address<span class="re-mend-field">*</span></label>
                                       <textarea required class="form-control required" id="address" name="address" maxlength="256"><?php echo set_value('address'); ?></textarea>

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Total Fee <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('totalFee'); ?>" id="totalFee" name="totalFee" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="previousSchool">Previous School <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="previousSchool" name="previousSchool"></textarea>
                                    </div>
                                </div>
                                <!-- NEW FILEDS ADD -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Form Fee </label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('formFee'); ?>" id="formFee" name="formFee" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Admission Fee</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('admissionFee'); ?>" id="admissionFee" name="admissionFee" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Admission Fee received date </label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('admissionFeedate'); ?>" id="admissionFeedate" name="admissionFeedate" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Sibling Discount </label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('siblingDiscount'); ?>" id="siblingDiscount" name="siblingDiscount" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Lumpsum Discount </label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('lumpsumDiscount'); ?>" id="lumpsumDiscount" name="lumpsumDiscount" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Discount (If any other)</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('discountother'); ?>" id="discountother" name="discountother" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Annual charges</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('annualcharges'); ?>" id="annualcharges" name="annualcharges" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Annual fee payment date</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('annualfeepayment'); ?>" id="annualfeepayment" name="annualfeepayment" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Annual charges received</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('annualchargesreceived'); ?>" id="annualchargesreceived" name="annualchargesreceived" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Net Fee</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('netFee'); ?>" id="netFee" name="netFee" maxlength="256">
                                    </div>
                                </div>
                                
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">1st installment Due</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment1Due'); ?>" id="installment1Due" name="installment1Due" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">1st installment received</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment1received'); ?>" id="installment1received" name="installment1received" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">1st installment payment date</label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('installmentpayment1date'); ?>" id="installmentpayment1date" name="installmentpayment1date" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">2nd  installment due</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment2due'); ?>" id="installment2due" name="installment2due" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">2nd installment due on </label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('installment2dueon'); ?>" id="installment2dueon" name="installment2dueon" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">2nd  installment amount received</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment2amountreceived'); ?>" id="installment2amountreceived" name="installment2amountreceived" maxlength="256">
                                    </div>
                                </div>

                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">2nd installment paid on </label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('installment2paidon'); ?>" id="installment2paidon" name="installment2paidon" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">3rd installment </label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment3'); ?>" id="installment3" name="installment3" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">3rd installment amount received</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment3amountreceived'); ?>" id="installment3amountreceived" name="installment3amountreceived" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">3rd installment paid on </label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('installment3paidon'); ?>" id="installment3paidon" name="installment3paidon" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">4th installment</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment4'); ?>" id="installment4" name="installment4" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">4th instllment due date</label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('instllment4duedate'); ?>" id="instllment4duedate" name="instllment4duedate" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">4th installment amount received</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('installment4amountreceived'); ?>" id="installment4amountreceived" name="installment4amountreceived" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">4th installment paid on</label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('installment4paidon'); ?>" id="installment4paidon" name="installment4paidon" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Total amount</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('totalamount'); ?>" id="totalamount" name="totalamount" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Received Amt</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('receivedamt'); ?>" id="receivedamt" name="receivedamt" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Due Amt</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('dueamt'); ?>" id="dueamt" name="dueamt" maxlength="256">
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">School transport</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('schooltransport'); ?>" id="schooltransport" name="schooltransport" maxlength="256">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">kit given date</label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('kitgivendate'); ?>" id="kitgivendate" name="kitgivendate" maxlength="256">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Kit Given</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('kitgiven'); ?>" id="kitgiven" name="kitgiven" maxlength="256">
                                    </div>
                                </div>

                         

                            <div class="col-md-12">
                                <div class="form-group">
                                        <label for="remark">Any Comment<span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="comment" name="comment"></textarea>
                                    </div>
                                </div>
                             <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Reference name</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('referencename'); ?>" id="referencename" name="referencename" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">School</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('school'); ?>" id="school" name="school" maxlength="256">
                                    </div>
                                </div>
                            <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="totalFee">Day care</label>
                                        <input  type="text" class="form-control required" value="<?php echo set_value('daycare'); ?>" id="daycare" name="daycare" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                <div class="form-group">
                                        <label for="remark">Remark <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="remark" name="remark"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>


<!-- Existing HTML remains unchanged -->
<!-- Only the JavaScript section is updated -->

<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });

    // Updated fetchAssignedFranchise function to fetch Growth Manager's name
    function fetchAssignedFranchise(franchiseNumber) {
    const assignedDiv = document.getElementById('brspFranchiseAssigned');
    const hiddenInput = document.getElementById('brspFranchiseAssignedValue'); // Reference hidden input
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success' && response.html) {
                    assignedDiv.innerHTML = response.html; // Display Growth Manager's name(s)
                    hiddenInput.value = response.userIds || ''; // Set hidden input to userIds
                } else {
                    assignedDiv.innerText = 'No Growth Manager assigned';
                    hiddenInput.value = ''; // Clear hidden input
                    alert(response.message || 'No Growth Manager found for this franchise');
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                assignedDiv.innerText = 'Error fetching Growth Manager';
                hiddenInput.value = ''; // Clear hidden input
                alert('Error fetching Growth Manager data');
            }
        });
    } else {
        assignedDiv.innerText = 'Select a franchise to assign';
        hiddenInput.value = ''; // Clear hidden input
    }
}

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        // For dropdown (non-readonly, roles other than 25)
        if (franchiseInput && franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }

        // For readonly input (role 25)
        if (franchiseInput && franchiseInput.readOnly) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }
    });

    // Existing age calculation script
    document.addEventListener('DOMContentLoaded', function() {
        const dobInput = document.getElementById('birthday');
        const ageInput = document.getElementById('age');

        dobInput.addEventListener('change', function() {
            const dob = new Date(this.value);
            const today = new Date();

            if (isNaN(dob)) return;

            // If DOB is in the future, treat age as 0
            if (dob > today) {
                ageInput.value = "0 Year - 0 Months - 0 Days";
                return;
            }

            let years = today.getFullYear() - dob.getFullYear();
            let months = today.getMonth() - dob.getMonth();
            let days = today.getDate() - dob.getDate();

            if (days < 0) {
                months--;
                const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
                days += prevMonth.getDate();
            }

            if (months < 0) {
                years--;
                months += 12;
            }

            // Ensure no negative values even in edge cases
            years = Math.max(0, years);
            months = Math.max(0, months);
            days = Math.max(0, days);

            const ageStr = `${years} Year - ${months} Months - ${days} Days`;
            ageInput.value = ageStr;
        });
    });

    // Commented-out fetchStaffByFranchise function (unchanged)
    /*
    function fetchStaffByFranchise(franchiseNumber) {
        if (franchiseNumber) {
            console.log('Fetching staff for franchise: ', franchiseNumber);
            $.ajax({
                url: '<?php echo base_url("admissiondetailsnew/fetchStaffByFranchise"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    console.log('AJAX Response: ', response);
                    if (response.status === 'success') {
                        $('#staffType').html('<option value="">Select Staff</option>');
                        if (response.staff && response.staff.length > 0) {
                            $.each(response.staff, function(index, staff) {
                                console.log('Staff ID: ', staff.staffid, 'Name: ', staff.name);
                                $('#staffType').append(
                                    '<option value="' + staff.staffid + '">' + staff.name + '</option>'
                                );
                            });
                        } else {
                            console.log('No staff found in response');
                            $('#staffType').html('<option value="">No Staff Found</option>');
                        }
                    } else {
                        console.error('Error: ', response.message);
                        $('#staffType').html('<option value="">No Staff Found</option>');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error: ', status, error);
                    console.error('Response Text: ', xhr.responseText);
                    $('#staffType').html('<option value="">Error fetching staff</option>');
                }
            });
        } else {
            console.log('No franchise selected');
            $('#staffType').html('<option value="">Select Staff</option>');
        }
    }
    */
</script>
<!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->