<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> General Images
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <!-- CSRF Tokens -->
        <input type="hidden" id="csrf_token_name" value="<?php echo htmlspecialchars($this->security->get_csrf_token_name()); ?>">
        <input type="hidden" id="csrf_token_hash" value="<?php echo htmlspecialchars($this->security->get_csrf_hash()); ?>">

        <?php if ($is_admin == 1 || $role == 14 || $role == 19) { ?>
            <div class="row">
                <div class="col-xs-12 text-right">
                    <div class="form-group">
                        <a class="btn btn-primary" href="<?php echo base_url(); ?>Standardimages/add"><i class="fa fa-plus"></i> Add New Images</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-md-12">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Standard Images List</h3>
                    </div>
                    <div class="box-body table-responsive no-padding">
                        <div class="card-container">
                            <?php
                            if (!empty($records)) {
                                foreach ($records as $record) {
                                    $standardimagesTitle = htmlspecialchars($record->standardimagesTitle);
                                    $mobile = htmlspecialchars($userInfo->mobile ?? '1234567890');
                                    $address = htmlspecialchars($this->session->userdata('branchLocAddressPremise') ?? 'N/A');
                                    $mediaUrl = htmlspecialchars($record->standardimagesS3Image);
                                    $id = htmlspecialchars($record->standardimagesId);
                                    $extension = strtolower(pathinfo($mediaUrl, PATHINFO_EXTENSION));
                                    $isVideo = in_array($extension, ['mp4', 'webm', 'mov']);
                            ?>
                                    <div class="card-wrapper">
                                        <div class="card-title"><?php echo $standardimagesTitle; ?></div>
                                        <div class="card" id="card_<?php echo $id; ?>">
                                            <?php if ($isVideo) { ?>
                                                <video controls width="100%" height="100%" style="object-fit: cover;" crossOrigin="Anonymous">
                                                    <source src="<?php echo $mediaUrl; ?>" type="video/<?php echo $extension; ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php } else { ?>
                                                <img src="<?php echo $mediaUrl; ?>" alt="Festive Image" crossOrigin="Anonymous">
                                            <?php } ?>
                                            <div class="watermark">eduMETA</div>
                                            <div class="overlay">
                                                <div class="address" aria-label="Address: <?php echo $address; ?>"><?php echo $address; ?></div>
                                                <div class="mobile" aria-label="mobile: <?php echo $mobile; ?>"><?php echo $mobile; ?></div>
                                            </div>
                                        </div>
                                        <button class="save-btn" id="save_btn_<?php echo $id; ?>" onclick="saveCardAsImage(<?php echo $id; ?>, '<?php echo $isVideo ? 'video' : 'image'; ?>')">Download <?php echo $isVideo ? 'Video' : 'Image'; ?></button>
                                    </div>
                            <?php
                                }
                            } else {
                                echo "<p>No data available.</p>";
                            }
                            ?>
                        </div>
                        <div class="box-footer clearfix">
                            <?php echo $this->pagination->create_links(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- CSS -->
    <style type="text/css">
        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 7px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .card-img-top {
            width: 100%;
        }

        .card-title {
            font-size: 1.2em;
            font-weight: bold;
        }

        .card-text {
            font-size: 0.9em;
            color: #555;
        }

        .blogbtn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 5px;
        }

        .blogbtn:hover {
            background-color: #0056b3;
        }

        .actions a {
            margin-right: 10px;
        }

        .actions.mt-2 {
            margin: 10px 0px 0px 0px;
        }

        .row {
            margin-right: -10px;
            margin-left: -10px;
        }

        .card-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            justify-content: center;
            max-width: 1050px;
            margin: 0 auto;
        }

        .card-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .card {
            position: relative;
            width: 325px;
            height: 450px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
        }

        .card-title {
            font-size: 1.1em;
            font-weight: bold;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            color: rgba(255, 255, 255, 0.1);
            font-size: 2em;
            font-weight: bold;
            pointer-events: none;
        }

        .overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            color: black;
            padding: 8px 16px 29px 16px;
            box-sizing: border-box;
            background: none !important;
        }

        .overlay .address,
        .overlay .mobile {
            font-size: 0.75em;
            margin-top: 5px;
            font-weight: 600;
            color: black;
        }

        .save-btn {
            margin-bottom: 15px;
            padding: 10px 20px;
            background: linear-gradient(135deg, #ff9f43, #ee5253);
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .save-btn::after {
            content: '↓';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            opacity: 0;
            transition: all 0.3s ease;
        }

        .save-btn:hover {
            background: linear-gradient(135deg, #ee5253, #ff9f43);
        }

        .save-btn:hover::after {
            opacity: 1;
            right: 15px;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 30px;
            gap: 10px;
        }

        .pagination a {
            padding: 10px 15px;
            background-color: #ff6b6b;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .pagination a:hover {
            background-color: #4ecdc4;
        }

        .pagination a.active {
            background-color: #ee5253;
            cursor: default;
        }

        .pagination a.disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        @keyframes shine {
            0% {
                transform: translateX(-100%) rotate(30deg);
            }
            50% {
                transform: translateX(100%) rotate(30deg);
            }
            100% {
                transform: translateX(-100%) rotate(30deg);
            }
        }

        @media (max-width: 1050px) {
            .card-container {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max/max-width: 700px) {
            .card-container {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
    <script>
        function saveCardAsImage(id, mediaType) {
            const card = document.getElementById(`card_${id}`);
            if (!card) {
                console.error(`Card with ID card_${id} not found.`);
                alert('Error: Card not found.');
                return;
            }

            if (mediaType === 'video') {
                const video = card.querySelector('video');
                if (!video) {
                    console.error(`No video found in card_${id}.`);
                    alert('Error: Video not found.');
                    return;
                }
                const source = video.querySelector('source');
                if (!source || !source.src) {
                    console.error(`No source found in video for card_${id}.`);
                    alert('Error: Video source not found.');
                    return;
                }

                fetch(source.src, {
                    method: 'GET',
                    mode: 'cors',
                    headers: {
                        'Accept': source.type || 'video/mp4'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! Status: ${response.status}`);
                    }
                    return response.blob();
                })
                .then(blob => {
                    const url = window.URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.download = `festive_video_${id}.${source.src.split('.').pop()}`;
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                })
                .catch(error => {
                    console.error(`Failed to download video for card_${id}:`, error);
                    alert('Error: Failed to download video. Please check the video URL or try again later.');
                });
            } else {
                const img = card.querySelector('img');
                if (!img) {
                    console.error(`No image found in card_${id}.`);
                    alert('Error: Image not found.');
                    return;
                }
                if (!img.complete || img.naturalWidth === 0) {
                    console.error(`Image in card_${id} not loaded. Attempting to reload.`);
                    img.crossOrigin = 'Anonymous';
                    img.src = img.src + (img.src.includes('?') ? '&' : '?') + 't=' + new Date().getTime();
                    img.onload = () => {
                        renderCanvas(id);
                    };
                    img.onerror = () => {
                        console.error(`Failed to load image in card_${id}. Check S3 URL or CORS.`);
                        alert('Error: Failed to load image. Please try again.');
                    };
                    return;
                }
                card.classList.add('no-border');
                renderCanvas(id);
            }
        }

        function renderCanvas(id) {
            const card = document.getElementById(`card_${id}`);
            html2canvas(card, {
                scale: 2,
                useCORS: true,
                logging: true,
                backgroundColor: null
            }).then(canvas => {
                const link = document.createElement('a');
                link.href = canvas.toDataURL('image/png');
                link.download = `festive_image_${id}.png`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                card.classList.remove('no-border');
            }).catch(error => {
                console.error('Error rendering card:', error);
                alert('Error: Failed to download image. Please try again.');
                card.classList.remove('no-border');
            });
        }
    </script>