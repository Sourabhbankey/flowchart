<?php
$branchesId = $branchesInfo->branchesId;
$applicantName = $branchesInfo->applicantName;
//$address = $branchesInfo->address;
$mobile = $branchesInfo->mobile;
$branchcityName = $branchesInfo->branchcityName;
$branchState = $branchesInfo->branchState;
$branchSalesDoneby = $branchesInfo->branchSalesDoneby;
$branchAmountReceived = $branchesInfo->branchAmountReceived;
$branchFranchiseAssigned = $branchesInfo->branchFranchiseAssigned;
$branchFranchiseAssignedDesigning = $branchesInfo->branchFranchiseAssignedDesigning;
$branchFranchiseAssignedLegalDepartment = $branchesInfo->branchFranchiseAssignedLegalDepartment;
$branchFrAssignedAccountsDepartment = $branchesInfo->branchFrAssignedAccountsDepartment;
$branchFrAssignedDispatchDepartment = $branchesInfo->branchFrAssignedDispatchDepartment;
$branchFrAssignedAdmissionDepartment = $branchesInfo->branchFrAssignedAdmissionDepartment;
$branchFrAssignedMaterialDepartment = $branchesInfo->branchFrAssignedMaterialDepartment;
$branchFrAssignedDigitalDepartment = $branchesInfo->branchFrAssignedDigitalDepartment;
$branchFrAssignedTrainingDepartment = $branchesInfo->branchFrAssignedTrainingDepartment;
$branchFrAssignedSocialmediaDepartment = $branchesInfo->branchFrAssignedSocialmediaDepartment;
$branchAddress = $branchesInfo->branchAddress;
$permanentAddress = $branchesInfo->permanentAddress;
$branchEmail = $branchesInfo->branchEmail;
//New fields added for edit.....
$franchiseNumber = $branchesInfo->franchiseNumber; 
$franchiseName = $branchesInfo->franchiseName;
$typeBranch = $branchesInfo->typeBranch;
$currentStatus = $branchesInfo->currentStatus;
$bookingDate = $branchesInfo->bookingDate;
$licenseNumber = $branchesInfo->licenseNumber;
$licenseSharedon = $branchesInfo->licenseSharedon;
$validFromDate = $branchesInfo->validFromDate;
$validTillDate = $branchesInfo->validTillDate;
$branchLocation = $branchesInfo->branchLocation;
$adminName = $branchesInfo->adminName;
$adminContactNum = $branchesInfo->adminContactNum;
$additionalNumber = $branchesInfo->additionalNumber;
$officialEmailID = $branchesInfo->officialEmailID;
$personalEmailId = $branchesInfo->personalEmailId;
$facebookPageStatus = $branchesInfo->facebookPageStatus;
$facebookPageLink = $branchesInfo->facebookPageLink;
$facebookPageRemark = $branchesInfo->facebookPageRemark;
$googleMapLoc = $branchesInfo->googleMapLoc;
$googleMapLocLink = $branchesInfo->googleMapLocLink;
$googleMapLocRemark = $branchesInfo->googleMapLocRemark;
$instagramPageStatus = $branchesInfo->instagramPageStatus;
$instagramPageID = $branchesInfo->instagramPageID;
$instagramPageRemark = $branchesInfo->instagramPageRemark;
$uniformDisclipineemail = $branchesInfo->uniformDisclipineemail;
/*---New-Field-Digital--*/
$jdPageStatus = $branchesInfo->jdPageStatus;
$jdPageID = $branchesInfo->jdPageID;
$jdPageRemark = $branchesInfo->jdPageRemark;
$tweetPageStatus = $branchesInfo->tweetPageStatus;
$tweetPageID = $branchesInfo->tweetPageID;
$tweetPageRemark = $branchesInfo->tweetPageRemark;
$digiMarkCost = $branchesInfo->digiMarkCost;
$digiMarkStartDtm = $branchesInfo->digiMarkStartDtm;
$digiMarkEndDtm = $branchesInfo->digiMarkEndDtm;
$digiMarkReamrk = $branchesInfo->digiMarkReamrk;
$insfeedvideoUplodFB = $branchesInfo->insfeedvideoUplodFB;
$insfeedvideoUplodYoutube = $branchesInfo->insfeedvideoUplodYoutube;
$insfeedvideoUplodInsta = $branchesInfo->insfeedvideoUplodInsta;
$optOnlineMarketing = $branchesInfo->optOnlineMarketing;
/*---End-Field-Digital--*/
$branchLocAddressPremise = $branchesInfo->branchLocAddressPremise;
$addOfFranchise = $branchesInfo->addOfFranchise;
$gstNumber = $branchesInfo->gstNumber;
$undertakingCommitmentSupport = $branchesInfo->undertakingCommitmentSupport;
$amcAmount = $branchesInfo->amcAmount;
$invoiceNumber = $branchesInfo->invoiceNumber;
$agreementTenure = $branchesInfo->agreementTenure;
$salesExecutive = $branchesInfo->salesExecutive;
$salesTeamlead = $branchesInfo->salesTeamlead;
$Manual1 = $branchesInfo->Manual1;
$Manual2 = $branchesInfo->Manual2;
$Manual3 = $branchesInfo->Manual3;
$Reference = $branchesInfo->Reference;
$installationTentativeDate = $branchesInfo->installationTentativeDate;
$formsDocumentsCompleted = $branchesInfo->formsDocumentsCompleted;
$setUpInstallation = $branchesInfo->setUpInstallation;
$branchAnniversaryDate = $branchesInfo->branchAnniversaryDate;
$admissionCracked = $branchesInfo->admissionCracked;
$teacherRecruitment = $branchesInfo->teacherRecruitment;
$pgDecidedFee = $branchesInfo->pgDecidedFee;
$nurseryDecidedFee = $branchesInfo->nurseryDecidedFee;
$KG1DecidedFee = $branchesInfo->KG1DecidedFee;
$KG2DecidedFee = $branchesInfo->KG2DecidedFee;
$feeSharedStatus = $branchesInfo->feeSharedStatus;
$feesRemark = $branchesInfo->feesRemark;
$addmissionPG  = $branchesInfo->addmissionPG;
$addmissionNursary  = $branchesInfo->addmissionNursary;
$addmissionKg1  = $branchesInfo->addmissionKg1;
$addmissionKg2  = $branchesInfo->addmissionKg2;
$addmission1st  = $branchesInfo->addmission1st;
$addmission2nd  = $branchesInfo->addmission2nd;
$totalAddmission  = $branchesInfo->totalAddmission;
$addmissionCounselor  = $branchesInfo->addmissionCounselor;
$lastDiscussaddmission  = $branchesInfo->lastDiscussaddmission;
$addmissionSheetlink  = $branchesInfo->addmissionSheetlink;
$dateexlSheetshared = $branchesInfo->dateexlSheetshared;
$lastInteractiondate  = $branchesInfo->lastInteractiondate;
$lastDiscussionby  = $branchesInfo->lastDiscussionby;
$lastInteractioncomment  = $branchesInfo->lastInteractioncomment;
$agreementDraftdate  = $branchesInfo->agreementDraftdate;
$branchLandline  = $branchesInfo->branchLandline;
$additionalName  = $branchesInfo->additionalName;
$finalPaydeadline  = $branchesInfo->finalPaydeadline;
$completeFranchiseAmt  = $branchesInfo->completeFranchiseAmt;
$confirmationAmt33kGST  = $branchesInfo->confirmationAmt33kGST;
$happinessLevelbranch  = $branchesInfo->happinessLevelbranch;
/*-----Start-Design--*/
$DesignsPromotional = $branchesInfo->DesignsPromotional;
$DesignsPromotionalRemark = $branchesInfo->DesignsPromotionalRemark;
$BranchSpecialNote = $branchesInfo->BranchSpecialNote;
$biometricInstalled = $branchesInfo->biometricInstalled;
$biometricRemark = $branchesInfo->biometricRemark;
$biometricInstalledDate = $branchesInfo->biometricInstalledDate;
$camaraInstalled = $branchesInfo->camaraInstalled;
$camaraRemark = $branchesInfo->camaraRemark;
$camaraInstalledDate = $branchesInfo->camaraInstalledDate;
$eduMetaAppTraining = $branchesInfo->eduMetaAppTraining;
$AppTrainingRemark = $branchesInfo->AppTrainingRemark;
$AppTrainingRemarkDate = $branchesInfo->AppTrainingRemarkDate;
/*--new-field--*/
$congratulationsImg = $branchesInfo->congratulationsImg;
$brimguploadedFBStatus = $branchesInfo->brimguploadedFBStatus;
$brimguploadedFBDate = $branchesInfo->brimguploadedFBDate;
$brimguploadedInstaStatus = $branchesInfo->brimguploadedInstaStatus;
$brimguploadedInstaDate = $branchesInfo->brimguploadedInstaDate;
$admissionOpenimgStatus = $branchesInfo->admissionOpenimgStatus;
$staffHiringimgStatus = $branchesInfo->staffHiringimgStatus;
$newsletterMarch = $branchesInfo->newsletterMarch;
$newsletterJune = $branchesInfo->newsletterJune;
$newsletterSeptember = $branchesInfo->newsletterSeptember;
$newsletterDecember = $branchesInfo->newsletterDecember;
$OBirthDayImgStatus = $branchesInfo->OBirthDayImgStatus;
$OBirthDayImgSharedDtm = $branchesInfo->OBirthDayImgSharedDtm;
$OwnerAnnImgStatus = $branchesInfo->OwnerAnnImgStatus;
$OwnerAnnImgSharedDtm = $branchesInfo->OwnerAnnImgSharedDtm;
/*-----End-Design--*/
$OwnerAnniversery = $branchesInfo->OwnerAnniversery;
$welcomeCall = $branchesInfo->welcomeCall;
$welcomeMail = $branchesInfo->welcomeMail;
$whatsappGroup = $branchesInfo->whatsappGroup;
$whatsappGroupRemark = $branchesInfo->whatsappGroupRemark;
$whatsappGroupdate = $branchesInfo->whatsappGroupdate;
$interactionMeeting = $branchesInfo->interactionMeeting;
$interactionMeetingRemark = $branchesInfo->interactionMeetingRemark;
$undertakingCommitment = $branchesInfo->undertakingCommitment;
$onboardingForm = $branchesInfo->onboardingForm;
$onboardingFormReceived = $branchesInfo->onboardingFormReceived;
$onboardingFormRemark = $branchesInfo->onboardingFormRemark;
$installationRequirementmail = $branchesInfo->installationRequirementmail;
$installationRequirementmailRemark = $branchesInfo->installationRequirementmailRemark;
$officialemailshared = $branchesInfo->officialemailshared;
$finalAgreementShared = $branchesInfo->finalAgreementShared;
$inaugurationDate = $branchesInfo->inaugurationDate;
/*---Start-Trainging-*/
/*$adminTraining = $branchesInfo->adminTraining;
$classroomDecoration = $branchesInfo->classroomDecoration;
$movieClub = $branchesInfo->movieClub;
$referEarn = $branchesInfo->referEarn;
$teacherInteraction = $branchesInfo->teacherInteraction;
$teacherInterview = $branchesInfo->teacherInterview;
$pongalWorkshop = $branchesInfo->pongalWorkshop;
$sankrantiWorkshop = $branchesInfo->sankrantiWorkshop;
$republicDayWorkshop = $branchesInfo->republicDayWorkshop;
$bridgeCourseCounselling = $branchesInfo->bridgeCourseCounselling;
$bulletinBoard = $branchesInfo->bulletinBoard;
$bridgeCourse = $branchesInfo->bridgeCourse;
$settlersProgram = $branchesInfo->settlersProgram;
$jollyPhonic = $branchesInfo->jollyPhonic;
$academicsMeetings = $branchesInfo->academicsMeetings;

$curiculumnShared = $branchesInfo->curiculumnShared;
$holidaEventlisting = $branchesInfo->holidaEventlisting;
$sharingAssessmentpapers = $branchesInfo->sharingAssessmentpapers;
$assessmentSharingemail = $branchesInfo->assessmentSharingemail;
$PTMscheduledate = $branchesInfo->PTMscheduledate;
$shadowPuppet = $branchesInfo->shadowPuppet;
$monthlyEventtraining = $branchesInfo->monthlyEventtraining;
$summertCampdate = $branchesInfo->summertCampdate;
$winterCampdate = $branchesInfo->winterCampdate;*/

//yashi 
$timeDisclipineemail = $branchesInfo->timeDisclipineemail;
$IntroductionDate = $branchesInfo->IntroductionDate;
$Pre_marketingDate = $branchesInfo->Pre_marketingDate;
$Admin_OrientationDate = $branchesInfo->Admin_OrientationDate;
$Inauguration_Refer_and_EarnDate = $branchesInfo->Inauguration_Refer_and_EarnDate;
$Classroom_decorationDate = $branchesInfo->Classroom_decorationDate;
$Movie_clubDate = $branchesInfo->Movie_clubDate;
$Fee_structureDate = $branchesInfo->Fee_structureDate;
$Day_careDate = $branchesInfo->Day_careDate;
$ToddlerDate = $branchesInfo->ToddlerDate;
$pG_April_JuneDate = $branchesInfo->pG_April_JuneDate;
$pG_JulyDate = $branchesInfo->pG_JulyDate;
$pG_AugustDate = $branchesInfo->pG_AugustDate;
$pG_SeptemberDate = $branchesInfo->pG_SeptemberDate;
$pG_OctoberDate = $branchesInfo->pG_OctoberDate;
$pG_NovemberDate = $branchesInfo->pG_NovemberDate;
$pG_DecemberDate = $branchesInfo->pG_DecemberDate;
$pG_JanuaryDate = $branchesInfo->pG_JanuaryDate;
$pG_FebruaryDate = $branchesInfo->pG_FebruaryDate;
$pG_MarchDate = $branchesInfo->pG_MarchDate;


$NurseryBook_1_Date = $branchesInfo->NurseryBook_1_Date;
$NurseryBook_2_Date = $branchesInfo->NurseryBook_2_Date;
$NurseryBook_3_Date = $branchesInfo->NurseryBook_3_Date;
$NurseryBook_4_Date = $branchesInfo->NurseryBook_4_Date;
$NurseryBook_5_Date = $branchesInfo->NurseryBook_5_Date;
$NurseryBook_6_Date = $branchesInfo->NurseryBook_6_Date;
$NurseryBook_7_Date = $branchesInfo->NurseryBook_7_Date;
$NurseryBook_8_Date = $branchesInfo->NurseryBook_8_Date;
$NurseryBook_9_Date = $branchesInfo->NurseryBook_9_Date;


$KG1Book_1_Date = $branchesInfo->KG1Book_1_Date;
$KG1Book_2_Date = $branchesInfo->KG1Book_2_Date;
$KG1Book_3_Date = $branchesInfo->KG1Book_3_Date;
$KG1Book_4_Date = $branchesInfo->KG1Book_4_Date;
$KG1Book_5_Date = $branchesInfo->KG1Book_5_Date;
$KG1Book_6_Date = $branchesInfo->KG1Book_6_Date;
$KG1Book_7_Date = $branchesInfo->KG1Book_7_Date;
$KG1Book_8_Date = $branchesInfo->KG1Book_8_Date;
$KG1Book_9_Date = $branchesInfo->KG1Book_9_Date;

$KG2Book_1_Date = $branchesInfo->KG2Book_1_Date;
$KG2Book_2_Date = $branchesInfo->KG2Book_2_Date;
$KG2Book_3_Date = $branchesInfo->KG2Book_3_Date;
$KG2Book_4_Date = $branchesInfo->KG2Book_4_Date;
$KG2Book_5_Date = $branchesInfo->KG2Book_5_Date;
$KG2Book_6_Date = $branchesInfo->KG2Book_6_Date;
$KG2Book_7_Date = $branchesInfo->KG2Book_7_Date;
$KG2Book_8_Date = $branchesInfo->KG2Book_8_Date;
$KG2Book_9_Date = $branchesInfo->KG2Book_9_Date;

$eventCelebration_April_JuneDate = $branchesInfo->eventCelebration_April_JuneDate;
$eventCelebration_JulyDate = $branchesInfo->eventCelebration_JulyDate;
$eventCelebration_AugustDate = $branchesInfo->eventCelebration_AugustDate;
$eventCelebration_SeptemberDate = $branchesInfo->eventCelebration_SeptemberDate;
$eventCelebration_OctoberDate = $branchesInfo->eventCelebration_OctoberDate;
$eventCelebration_NovemberDate = $branchesInfo->eventCelebration_NovemberDate;
$eventCelebration_DecemberDate = $branchesInfo->eventCelebration_DecemberDate;
$eventCelebration_JanuaryDate = $branchesInfo->eventCelebration_JanuaryDate;
$eventCelebration_FebruaryDate = $branchesInfo->eventCelebration_FebruaryDate;
$eventCelebration_MarchDate = $branchesInfo->eventCelebration_MarchDate;

$Workshop_1Date = $branchesInfo->Workshop_1Date;
$Workshop_2Date = $branchesInfo->Workshop_2Date;
$Workshop_3Date = $branchesInfo->Workshop_3Date;
$Workshop_4Date = $branchesInfo->Workshop_4Date;
$Workshop_5Date = $branchesInfo->Workshop_5Date;
$Workshop_6Date = $branchesInfo->Workshop_6Date;
$Workshop_7Date = $branchesInfo->Workshop_7Date;

$others_Settlers_program_Date = $branchesInfo->others_Settlers_program_Date;
$others_Circle_time_Date = $branchesInfo->others_Circle_time_Date;
$others_Interview_Date = $branchesInfo->others_Interview_Date;
$others_Academic_Overview_Date = $branchesInfo->others_Academic_Overview_Date;
$others_Teacher_interaction_Date = $branchesInfo->others_Teacher_interaction_Date;
$others_Assessment_Date = $branchesInfo->others_Assessment_Date;
$others_PTM_Date = $branchesInfo->others_PTM_Date;
$others_Summer_camp_Date = $branchesInfo->others_Summer_camp_Date;
$others_Winter_Camp_Date = $branchesInfo->others_Winter_Camp_Date;
$others_Aayam_Date = $branchesInfo->others_Aayam_Date;
$others_Sports_day_Date = $branchesInfo->others_Sports_day_Date;
$others_midterm_session = $branchesInfo->others_midterm_session;
$others_bridgecourse = $branchesInfo->others_bridgecourse;

/*---End-Trainging--*/
$offerName = $branchesInfo->offerName;
$BranchSpecialNoteSales = $branchesInfo->BranchSpecialNoteSales;
$offerPlanname = $branchesInfo->offerPlanname;
$discountAmount = $branchesInfo->discountAmount;
$finalAmount = $branchesInfo->finalAmount;
/*Added-Additioanl-field in Sales-04-07-2024*/
$legalChargesSales = $branchesInfo->legalChargesSales;
$brSetupinsChargSales = $branchesInfo->brSetupinsChargSales;
$numInialKitSales = $branchesInfo->numInialKitSales;
$franchiseTenure = $branchesInfo->franchiseTenure;
/*ENd-Additioanl-field-04-07-2024*/
$welComeFolderStatus = $branchesInfo->welComeFolderStatus;
$welComeFolderDtm = $branchesInfo->welComeFolderDtm;
$trainingAmount = $branchesInfo->trainingAmount;
$societyServiceamount = $branchesInfo->societyServiceamount;
$totalAmount = $branchesInfo->totalAmount;
$gstAmount = $branchesInfo->gstAmount;
$totalfranchisegstFund = $branchesInfo->totalfranchisegstFund;
$legalCharges = $branchesInfo->legalCharges;
$legalChargesdue = $branchesInfo->legalChargesdue;
$totalgstCharges = $branchesInfo->totalgstCharges;
$totalPaidamount = $branchesInfo->totalPaidamount;
$dueFranchiseamt = $branchesInfo->dueFranchiseamt;
$kitCharges = $branchesInfo->kitCharges;
$numinitialKit = $branchesInfo->numinitialKit;
$totalKitsamt = $branchesInfo->totalKitsamt;
$kitamtReceived = $branchesInfo->kitamtReceived;
$dueKitamount = $branchesInfo->dueKitamount;
$installationDate = $branchesInfo->installationDate;
$finaltotalamtDue = $branchesInfo->finaltotalamtDue;
$specialRemark = $branchesInfo->specialRemark;
$transporttravCharge = $branchesInfo->transporttravCharge;
$brsetupinstachargReceived = $branchesInfo->brsetupinstachargReceived;
$brsetupinstachargDue = $branchesInfo->brsetupinstachargDue;
$travelAmount = $branchesInfo->travelAmount;
$receivedtravelAmount = $branchesInfo->receivedtravelAmount;
$duetravelAmount = $branchesInfo->duetravelAmount;
$transportCharges = $branchesInfo->transportCharges;
$transportAmtreceived = $branchesInfo->transportAmtreceived;
$duetransportCharges = $branchesInfo->duetransportCharges;
$upgradeUptoclass = $branchesInfo->upgradeUptoclass;
$branchStatus = $branchesInfo->branchStatus;
$brInstallationStatus = $branchesInfo->brInstallationStatus;
$undertakingAck = $branchesInfo->undertakingAck;
$agreementDraftReceiveddate = $branchesInfo->agreementDraftReceiveddate;
$compFileSubmit = $branchesInfo->compFileSubmit;
$fileCLoserDate = $branchesInfo->fileCLoserDate;
$branchStatusRemark = $branchesInfo->branchStatusRemark;
/*---Despatch--*/
$insmatDispatchdate = $branchesInfo->insmatDispatchdate; 
$DetailsReceiptmail = $branchesInfo->DetailsReceiptmail;
$ConfBrinsScheduledemail = $branchesInfo->ConfBrinsScheduledemail;
$Materialrecdate = $branchesInfo->Materialrecdate;
$BrinsScheduleddate = $branchesInfo->BrinsScheduleddate;
$BrinsScheduledemail = $branchesInfo->BrinsScheduledemail;
$brInstalationRemark = $branchesInfo->brInstalationRemark;
$videoFeedbackbr = $branchesInfo->videoFeedbackbr;
$writtenFeedbackbr = $branchesInfo->writtenFeedbackbr;
$ShoppinPortSharedDate = $branchesInfo->ShoppinPortSharedDate;
$ShoppinPortTraining = $branchesInfo->ShoppinPortTraining;
$ShoppinPortTrainingDate = $branchesInfo->ShoppinPortTrainingDate;
$ShoppinPortRemark = $branchesInfo->ShoppinPortRemark;
$returnItems = $branchesInfo->returnItems;
$modeOfDespatch = $branchesInfo->modeOfDespatch;
$NumOfBoxes = $branchesInfo->NumOfBoxes;
$PoDNum = $branchesInfo->PoDNum;
$SpecificGiftOffer = $branchesInfo->SpecificGiftOffer;
$ConfBrInsOverPhone = $branchesInfo->ConfBrInsOverPhone;
$shortComming = $branchesInfo->shortComming;
$solutionShortComming = $branchesInfo->solutionShortComming;
/*--End-Despatch--*/
/*--new-custom-Accounts--*/
/*$ledgerMarch = $branchesInfo->ledgerMarch;
$ledgerJune = $branchesInfo->ledgerJune;
$ledgerSeptember = $branchesInfo->ledgerSeptember;
$ledgerDecember = $branchesInfo->ledgerDecember;*/
$reminderAMCStatus1Dec = $branchesInfo->reminderAMCStatus1Dec;
$reminderAMCStatus10Dec = $branchesInfo->reminderAMCStatus10Dec;
$reminderAMCStatus15Dec = $branchesInfo->reminderAMCStatus15Dec;
$reminderAMCStatus19Dec = $branchesInfo->reminderAMCStatus19Dec;
$reminderAMCStatus20Dec = $branchesInfo->reminderAMCStatus20Dec;
$RemarkforAMCmail = $branchesInfo->RemarkforAMCmail;
$InvoiceAMCClearance = $branchesInfo->InvoiceAMCClearance;
$PenaltyMailnoncle = $branchesInfo->PenaltyMailnoncle;
$invoiceNumberAll = $branchesInfo->invoiceNumberAll;
/*$LgBeforeattachS3File = $branchesInfo->LgBeforeattachS3File;
$LgAfterattachS3File = $branchesInfo->LgAfterattachS3File;*/
$LedgerMonthDrop = $branchesInfo->LedgerMonthDrop;
$LedgerYear = $branchesInfo->LedgerYear;


/*--End-Accounts--*/
/*---it--*/
$customWebsiteLink = $branchesInfo->customWebsiteLink;
/*--it--*/
/*basic deatils */
$franchiseName = $branchesInfo->franchiseName;



?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Branches Management
        <small>Add / Edit Brances</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Branches Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="" method="post" id="" role="form" >
                        <div class="box-body">
                           <?php if ($is_admin != 1) {  ?>
                          <div class="basic-details-franch">
                            
                          <h2 style="text-align: center;font-weight: 800;">Basic Details</h2>
                          <!-- Basic Details -->
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label class="control-label">Franchise No.</label><input type="text" class="form-control check"  autocomplete="off" name="franchiseNumber" value="<?php echo $franchiseNumber; ?>" readonly ><span class="error"></span>
                                  </div>
                                </div>
                                 <!-- <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="applicantName">Name of Applicant</label>
                                        <input type="text" class="form-control check required" value="<?php //echo $applicantName; ?>" readonly id="applicantName" name="applicantName" maxlength="256" />
                                    </div>
                                  </div> -->
                                  <div class="col-md-6">
                                         <div class="form-group">
                                            <label for="applicantName">Franchise Name</label>
                                            <input type="text" class="form-control check required" value="<?php echo $franchiseName; ?>" readonly id="franchiseName" name="franchiseName" maxlength="256" />
                                        </div>
                                    </div>    
                                    <!-- <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="applicantName">Branch Location </label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchLocation; ?>" readonly id="branchLocation" name="branchLocation" maxlength="256" />
                                      </div>
                                    </div> -->
                                      <div class="col-md-6">
                                       <div class="form-group">
                                        <label for="applicantName">Branch Current Status </label>
                                        <!-- <input type="text" class="form-control check required" value="<?php //echo $currentStatus; ?>" readonly id="currentStatus" name="currentStatus" maxlength="256" />  -->
                                        <input type="text" class="form-control check required" value="<?php echo $currentStatus; ?>" readonly id="currentStatus" name="currentStatus" maxlength="256" />
                                      </div>
                                    </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                        <label for="applicantName">Branch city </label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchcityName; ?>" readonly id="branchcityName" name="branchcityName" maxlength="256" />
                                      </div>
                                    </div>
                                      <div class="col-md-6">
                                      <div class="form-group">
                                        <label for="applicantName">Branch State </label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchState; ?>" readonly id="branchState" name="branchState" maxlength="256" />
                                      </div>
                                    </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="applicantName">Official Email Id </label>
                                          <input type="text" class="form-control check required" value="<?php echo $officialEmailID; ?>" readonly id="officialEmailID" name="officialEmailID" maxlength="256" />
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="applicantName">Personal Email Id </label>
                                          <input type="text" class="form-control check required" value="<?php echo $personalEmailId; ?>" readonly id="personalEmailId" name="personalEmailId" maxlength="256" />
                                        </div>
                                      </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                          <label for="applicantName">Contact Number </label>
                                          <input type="text" class="form-control check required" value="<?php echo $mobile; ?>" readonly id="mobile" name="mobile" maxlength="256" />
                                        </div>
                                      </div>
                                      
                                      <div class="col-md-6 mb-sm">
                                        <div class="form-group"><label class="control-label">Branch location address(Premise) <span class="required">*</span></label><textarea type="textarea" class="form-control check" readonly name="branchLocAddressPremise"><?php echo $branchLocAddressPremise; ?></textarea><span class="error"></span>
                                        </div>
                                    </div>
                                  
                                      <hr>
                          <!-- End-Basic-Details -->
                          </div>
                        </div>
                        <?php } ?>
                            <div class="row">
                                   <input type="hidden" value="<?php echo $branchesId; ?>" name="branchesId" id="branchesId"  />
                                   <?php
                                   if ($is_admin != 1 || $role!=2) {
                                      ?>
                                       <input type="hidden" value="<?php echo $applicantName; ?>" name="applicantName" id="applicantName" />
                                       <input type="hidden" value="<?php echo $branchAddress; ?>" name="branchAddress" id="branchAddress" />
                                      <?php
                                   }
                                    ?>
                                <?php  if($is_admin == 1 || $role==2 || $role==15) { ?>

                                <div class="col-md-6">   
                                <div class="form-group"><label class="control-label">Franchise No.</label><input type="text" class="form-control check"  autocomplete="off" name="franchiseNumber" value="<?php echo $franchiseNumber; ?>" readonly ><span class="error"></span></div>                             
                                    <div class="form-group">
                                        <label for="applicantName">Name of Applicant</label>
                                        <input type="text" class="form-control check required" value="<?php echo $applicantName; ?>" readonly id="applicantName" name="applicantName" maxlength="256" />
                                       
                                        
                                    </div>
                                   <!--  code added By Yashi 22-11 -->
                                         <div class="form-group">
                                        <label for="applicantName">Franchise Name</label>
                                        <input type="text" class="form-control check required" value="<?php echo $franchiseName; ?>" readonly id="franchiseName" name="franchiseName" maxlength="256" />
                                       
                                        
                                    </div>


                                    <div class="form-group">
                                        <label for="mobile">Mobile Number</label>
                                        <input type="text" class="form-control check required digits" id="mobile" value="<?php echo $mobile; ?>" readonly name="mobile" maxlength="10">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Sales T.L. <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="salesTeamlead" readonly value="<?php echo $salesTeamlead; ?>"><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <label for="stateName">State</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchState; ?>" readonly id="branchState" name="branchState" maxlength="256" />
                                    </div>
                                    <div class="form-group">
                                        <label for="branchAmountReceived">Amount Received</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchAmountReceived; ?>" readonly id="branchAmountReceived" name="branchAmountReceived" maxlength="256" />
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="branchAddress">Address</label>
                                        <textarea class="form-control check required" id="branchAddress" name="branchAddress" readonly value="<?php echo $branchAddress; ?>"><?php echo $branchAddress; ?></textarea>
                                    </div>
                                    

                                    <div class="form-group">
                                        <label class="control-label">Undertaking And Commitment - Sales</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="undertakingCommitment" readonly value="<?php echo $undertakingCommitment; ?>"><span class="error"></span>
                                    </div>
                                    <!----->
                                    <div class="form-group">
                                        <label for="branchFrAssignedAdmissionDepartment">Franchise Assigned to Admission Department</label>
                                        <select class="form-control check required" id="branchFrAssignedAdmissionDepartment" readonly name="branchFrAssignedAdmissionDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ADMusers))
                                            {
                                                foreach ($ADMusers as $ADMbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $ADMbranchFranchiseAssignedDesigninguserText = $ADMbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $ADMbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($ADMbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedAdmissionDepartment', $branchFrAssignedAdmissionDepartment)) {echo "selected=selected";} ?>><?= $ADMbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?> 
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedDispatchDepartment">Franchise Assigned to Dispatch Department</label>
                                        <select class="form-control check required" id="branchFrAssignedDispatchDepartment" readonly name="branchFrAssignedDispatchDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($DISusers))
                                            {
                                                foreach ($DISusers as $DISbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $DISbranchFranchiseAssignedDesigninguserText = $DISbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $DISbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($DISbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedDispatchDepartment', $branchFrAssignedDispatchDepartment)) {echo "selected=selected";} ?>><?= $DISbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>    
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedMaterialDepartment">Franchise Assigned to Material Department</label>
                                        <select class="form-control check required" id="branchFrAssignedMaterialDepartment" readonly name="branchFrAssignedMaterialDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($MATusers))
                                            {
                                                foreach ($MATusers as $MATbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $MATbranchFranchiseAssignedDesigninguserText = $MATbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $MATbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($MATbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedMaterialDepartment', $branchFrAssignedMaterialDepartment)) {echo "selected=selected";} ?>><?= $MATbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>              
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedDigitalDepartment">Franchise Assigned to Digital Department</label>
                                        <select class="form-control check required" id="branchFrAssignedDigitalDepartment" readonly name="branchFrAssignedDigitalDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($DMusers))
                                            {
                                                foreach ($DMusers as $DMbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $DMbranchFranchiseAssignedDesigninguserText = $DMbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $DMbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($DMbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedDigitalDepartment', $branchFrAssignedDigitalDepartment)) {echo "selected=selected";} ?>><?= $DMbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedTrainingDepartment">Franchise Assigned to Training Department</label>
                                        <select class="form-control check required" id="branchFrAssignedTrainingDepartment" readonly name="branchFrAssignedTrainingDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($TRMusers))
                                            {
                                                foreach ($TRMusers as $TRMbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $TRMbranchFranchiseAssignedDesigninguserText = $TRMbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $TRMbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($TRMbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedTrainingDepartment', $branchFrAssignedTrainingDepartment)) {echo "selected=selected";} ?>><?= $TRMbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedSocialmediaDepartment">Franchise Assigned to Social Media Department</label>
                                        <select class="form-control check required" id="branchFrAssignedSocialmediaDepartment" readonly name="branchFrAssignedSocialmediaDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($SMDusers))
                                            {
                                                foreach ($SMDusers as $SMDbranchFranchiseAssignedSocialmedial)
                                                {
                                                    $SMDbranchFranchiseAssignedSocialmediaText = $SMDbranchFranchiseAssignedSocialmedial->name;
                                                    ?>
                                                    <option value="<?php echo $SMDbranchFranchiseAssignedSocialmedial->userId ?>" <?php if($SMDbranchFranchiseAssignedSocialmedial->userId == set_value('branchFrAssignedSocialmediaDepartment', $branchFrAssignedSocialmediaDepartment)) {echo "selected=selected";} ?>><?= $SMDbranchFranchiseAssignedSocialmediaText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>   
                                        </select>
                                    </div>
                                    <!------>
                                  
                                    <div class="form-group">
                                      <div class="form-group"><label class="control-label">Special Note for the Sales</label>
                                        <textarea class="form-control check required" id="branchAddress" name="BranchSpecialNoteSales" readonly value="<?php echo $branchAddress; ?>"><?php echo $BranchSpecialNoteSales; ?></textarea>
                                      </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <!-- <label class="control-label">Complete Franchise amount Date (within 3 months from confirmation amount )</label> Replaced by-vikramsir-->
                                        <label class="control-label">Complete franchise amount due date given</label><input type="date" class="form-control check" autocomplete="off" name="completeFranchiseAmt" readonly value="<?php echo $completeFranchiseAmt; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                <div class="form-group">
                                        <label for="email">Email address</label>
                                        <input type="text" class="form-control check required email" id="email" value="<?php echo $branchEmail; ?>" readonly name="branchEmail" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="cityName">City</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchcityName; ?>" id="branchcityName" readonly name="branchcityName" maxlength="256" />
                                    </div>
                                    
                                   <!--  <div class="form-group">
                                        <label for="branchSalesDoneby">Sales Done By</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchSalesDoneby; ?>"  readonly id="branchSalesDoneby" name="branchSalesDoneby" maxlength="256" />
                                    </div> -->
                               <!-- <div class="form-group">
    <label for="branchSalesDoneby">Sales Done By</label>
    <input 
        type="text" 
        class="form-control" 
        id="branchSalesDoneby" 
        name="branchSalesDoneby" 
        value="<?php
            $salesDoneByText = 'Select User'; // Default text if no value is set
            if (!empty($user)) {
                foreach ($user as $rl) {
                    if ($rl->userId == $branchSalesDoneby) {
                        $salesDoneByText = $rl->name; // Match found, set user name
                        break;
                    }
                }
            }
            // If no match is found, treat it as "Other"
            if ($salesDoneByText === 'Select User' && !empty($branchSalesDoneby)) {
                $salesDoneByText = htmlspecialchars($branchSalesDoneby); // Display "Other" value
            }
            echo $salesDoneByText;
        ?>" 
        readonly
    />
</div>
 -->
  <div class="form-group">
                                    <label for="branchSalesDoneby">Sales Done By</label>
                                    <div style="display: flex; align-items: center;">
                                        <select class="form-control required" id="assignedTo" name="branchSalesDonebyDropdown" style="width: 50%;">
                                            <option value="0">Select User</option>
                                            <?php
                                            $isOtherSelected = true; // Assume "Other" is selected until a match is found
                                            if (!empty($user)) {
                                                foreach ($user as $rl) {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId; ?>" 
                                                        <?php 
                                                        if ($rl->userId == $branchSalesDoneby) {
                                                            echo 'selected';
                                                            $isOtherSelected = false; // Match found, not "Other"
                                                        }
                                                        ?>>
                                                        <?= $userText ?>
                                                    </option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                            <option value="other" <?php echo $isOtherSelected ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                        <input 
                                            type="text" 
                                            class="form-control required" 
                                            id="branchSalesDonebyOther" 
                                            name="branchSalesDoneby" 
                                            maxlength="256" 
                                            placeholder="Enter other sales person" 
                                            style="display: <?php echo $isOtherSelected ? 'block' : 'none'; ?>; margin-left: 10px; width: 50%;" 
                                            value="<?php echo $isOtherSelected ? htmlspecialchars($branchSalesDoneby) : ''; ?>" 
                                        />
                                    </div>
                                </div>

                                    
                                    <div class="form-group"><label class="control-label">Booking Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="bookingDate" readonly value="<?php echo $bookingDate; ?>"><span class="error"></span>
                                    </div>
                                    <!-- <div class="form-group">
                                        <label class="control-label">Confirmation Amount Date (33k + GST) (within 30days)</label><input type="date" class="form-control check" autocomplete="off" name="confirmationAmt33kGST" value="<?php //echo $confirmationAmt33kGST; ?>"><span class="error"></span>
                                    </div> Removed by-vikramsir-->
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                        <select class="form-control check required" readonly id="branchFranchiseAssigned" name="branchFranchiseAssigned">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('branchFranchiseAssigned', $branchFranchiseAssigned)) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedDesigning">Franchise Assigned to Designing</label>
                                        <select class="form-control check required" readonly id="branchFranchiseAssignedDesigning" name="branchFranchiseAssignedDesigning">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($dusers))
                                            {
                                                foreach ($dusers as $drl)
                                                {
                                                    $duserText = $drl->name;
                                                    ?>
                                                    <option value="<?php echo $drl->userId ?>" <?php if($drl->userId == set_value('branchFranchiseAssignedDesigning', $branchFranchiseAssignedDesigning)) {echo "selected=selected";} ?>><?= $duserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedLegalDepartment">Franchise Assigned to LegalDepartment</label>
                                        <select class="form-control check required" id="branchFranchiseAssignedLegalDepartment" readonly name="branchFranchiseAssignedLegalDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($LDusers))
                                            {
                                                foreach ($LDusers as $LDbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $LDbranchFranchiseAssignedDesigninguserText = $LDbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $LDbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($LDbranchFranchiseAssignedDesigningrl->userId == set_value('branchFranchiseAssignedLegalDepartment', $branchFranchiseAssignedLegalDepartment)) {echo "selected=selected";} ?>><?= $LDbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <!------->
                                    <div class="form-group">
                                        <label for="branchFrAssignedAccountsDepartment">Franchise Assigned to Accounts Department</label>
                                        <select class="form-control check required" id="branchFrAssignedAccountsDepartment" readonly name="branchFrAssignedAccountsDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ACusers))
                                            {
                                                foreach ($ACusers as $ACbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $ACbranchFranchiseAssignedDesigninguserText = $ACbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $ACbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($ACbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedAccountsDepartment', $branchFrAssignedAccountsDepartment)) {echo "selected=selected";} ?>><?= $ACbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    
                                    <!--------->
                                    <div class="form-group">
                                        <label class="control-label">Offer Plan Name </label><input type="text" class="form-control check" autocomplete="off" readonly name="offerPlanname" value="<?php echo $offerPlanname; ?>"><span class="error"></span>
                                    </div>
                                      <div class="form-group">
                                        <label class="control-label">Offer Amount </label><input type="text" class="form-control check" readonly autocomplete="off" name="offerName" value="<?php echo $offerName; ?>"><span class="error"></span>
                                    </div>
                                     <div class="form-group">
                                        <label class="control-label">Discount </label><input type="text" class="form-control check" autocomplete="off" readonly name="discountAmount" value="<?php echo $discountAmount; ?>"><span class="error"></span>
                                    </div>
                                   <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Final Franchise Amount </label><input type="text" class="form-control check" autocomplete="off" name="finalAmount" value="<?php echo $finalAmount; ?>"><span class="error"></span></div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                  <?php //@$gstAmount = $totalAmount * 0.18 ?>
                                    <div class="form-group"><label class="control-label">GST Amount</label><input type="text" class="form-control check" autocomplete="off" name="gstAmount" value="<?php echo $gstAmount; ?>"><span class="error"></span></div>
                                </div>  

                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Total Paid Amount</label><input type="text" class="form-control check" autocomplete="off" name="totalPaidamount" value="<?php echo $totalPaidamount; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                  <?php  //@$dueFranchiseamt = $totalfranchisegstFund - $totalPaidamount  ?>
                                    <div class="form-group"><label class="control-label">Due Franchise Amount</label><input type="text" class="form-control check" autocomplete="off" name="dueFranchiseamt" value="<?php echo $dueFranchiseamt; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges  </label><input type="text" class="form-control" autocomplete="off" name="legalChargesSales" readonly value="<?php echo $legalChargesSales; ?>"><span class="error"></span></div>
                                </div>
                                
                                 <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges Due</label><input type="text" class="form-control check" autocomplete="off" name="legalChargesdue" value="<?php echo $legalChargesdue; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Setup & Installation Charges </label><input type="text" class="form-control" autocomplete="off" name="brSetupinsChargSales" readonly value="<?php echo $brSetupinsChargSales; ?>"><span class="error"></span></div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                  <?php  //@$totalgstCharges = $totalfranchisegstFund + $legalCharges  ?>
                                    <div class="form-group"><label class="control-label">Total ( with GST)+Legal Charges</label><input type="text" class="form-control check" autocomplete="off" name="totalgstCharges" value="<?php echo $totalgstCharges; ?>"><span class="error"></span></div>
                                </div>
                                   <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">No. Of Initial Student KIT Offered </label><input type="text" class="form-control" autocomplete="off" name="numInialKitSales" readonly value="<?php echo $numInialKitSales; ?>"><span class="error"></span></div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">No. of Initial kits</label><input type="text" class="form-control check" autocomplete="off" name="numinitialKit" value="<?php echo $numinitialKit; ?>"><span class="error"></span></div>
                                </div>
                                  <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">KIT Charges</label><input type="text" class="form-control check" autocomplete="off" name="kitCharges" value="<?php echo $kitCharges; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                  <?php  //@$totalKitsamt = $kitCharges * $numinitialKit  ?>
                                    <div class="form-group"><label class="control-label">Total Kits amount</label><input type="text" class="form-control check" autocomplete="off" name="totalKitsamt" value="<?php echo $totalKitsamt; ?>"><span class="error"></span></div>
                                </div>

                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Kit amount Received</label><input type="text" class="form-control check" autocomplete="off" name="kitamtReceived" value="<?php echo $kitamtReceived; ?>"><span class="error"></span></div>
                                </div>
                                  

                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Franchise Tenure </label><input type="text" class="form-control" readonly autocomplete="off" name="franchiseTenure" value="<?php echo $franchiseTenure; ?>"><span class="error"></span></div>
                                </div>
                                    
                                    
                                </div>
                            <?php }else{
                            ?>
                            <!--<input type="hidden" value="<?php //echo $applicantName; ?>" id="applicantName" name="applicantName" />
                            <input type="hidden" value="<?php //echo $branchAddress; ?>" id="branchAddress" name="branchAddress" />-->
                            
                            <!----Start-Legal-Section------>
                                <?php
                                    }if ($is_admin == 1 || $role==24 || $role==15) {
                                     ?>
                                  <div class="row">
                                     <?php if ($role==24) { ?>
                                     <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">LICENSE DETAIL</h4>
                                      </div>
                                    </div>
                                    <?php } ?>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">License number</label><input type="text" class="form-control check" readonly autocomplete="off" name="licenseNumber" value="<?php echo $licenseNumber; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">License Shared on</label><input type="text" class="form-control check" readonly autocomplete="off" name="licenseSharedon" value="<?php echo $licenseSharedon; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Valid from Date <span class="required">*</span></label><input type="date" class="form-control check" data-plugin-datepicker="" readonly autocomplete="off" name="validFromDate" value="<?php echo $validFromDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Valid  TIll Date <span class="required">*</span></label><input type="date" class="form-control check" data-plugin-datepicker="" readonly autocomplete="off" name="validTillDate" value="<?php echo $validTillDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                </div>
                               <div class="row">
                                <?php if ($role==24 ) { ?>
                                <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">FORMS</h4>
                                      </div>
                                    </div>
                                <?php } ?>    
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Forms and Documents completed <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" readonly name="formsDocumentsCompleted" value="<?php echo $formsDocumentsCompleted; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="onboardingForm" readonly value="<?php echo $onboardingForm; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                    <!-- <div class="form-group"><label class="control-label">Onboarding Form Received</label><input type="date" class="form-control check" autocomplete="off" name="onboardingFormReceived" value=""><span class="error"></span>
                                    </div> -->
                                    <label class="control-label">Onboarding Form Received</label>
                                    <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" readonly name="onboardingFormReceived" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($onboardingFormReceived == ACTIVE) {echo "selected=selected";} ?>> Yes </option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($onboardingFormReceived == INACTIVE) {echo "selected=selected";} ?> > No </option>
                                        </select>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form - Remark</label><input type="text" class="form-control check" autocomplete="off" name="onboardingFormRemark" readonly value="<?php echo $onboardingFormRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">AGREEMENT DETAIL</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Tenure <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="agreementTenure" value="<?php echo $agreementTenure; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Final Agreement pdf shared <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="finalAgreementShared" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Draft</label><input type="date" class="form-control check" autocomplete="off" name="agreementDraftdate" value="<?php echo $agreementDraftdate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Draft Received On</label><input type="date" class="form-control check" autocomplete="off" name="agreementDraftReceiveddate" value="<?php echo $agreementDraftReceiveddate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                             </div>
                             <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">FILE DETAIL</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Complete File Subbmitted On</label><input type="date" class="form-control check" autocomplete="off" name="compFileSubmit" value="<?php echo $compFileSubmit; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">File Closer Date</label><input type="date" class="form-control check" autocomplete="off" name="fileCLoserDate" value="<?php echo $fileCLoserDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Udertaking Acknowledgement Received <span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="undertakingAck" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($undertakingAck == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($undertakingAck == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Status <span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="branchStatus" tabindex="-1" aria-hidden="true">
                                        <option value="<?php echo $branchStatus; ?>" <?php echo "selected=selected"; ?>><?php echo $branchStatus; ?></option>
                                          <option value="Installed-Active">Installed Active</option>
                                          <option value="Installed-Closed"> Installed Closed</option>
                                          <option value="UnInstalled-Active"> UnInstalled Active</option>
                                          <option value="UnInstalled-Closed"> UnInstalled Closed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Status<span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brInstallationStatus" tabindex="-1" aria-hidden="true">
                                            
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($brInstallationStatus == ACTIVE) {echo "selected=selected";} ?>>Installed</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brInstallationStatus == INACTIVE) {echo "selected=selected";} ?> >Not Installed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Status Remark</label><input type="text" class="form-control check" autocomplete="off" name="branchStatusRemark" value="<?php echo $branchStatusRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">BRANCH DOCUMENT - IDENTITY PROOF</h4>
                                        <h6 style="text-align: center;font-weight: bold;font-size: 14px;">INDIVIDUAL DOCUMENT</h6>
                                      </div>
                                    </div>
                                <?php } ?>
                                <!---Check-List--->
                                <!---Check-List--->
                                <?php
                                    if (!empty($legalDocumentsIndividual)) {
                                        foreach ($legalDocumentsIndividual as $record) {
                                            $module = $record['module'];
                                            ?>
                                            <?php
                                            foreach ($record as $key => $value) {
                                                ?>
                                                <?php
                                                if ($key !== 'module') {
                                                    ?>
                                                    <div class="col-md-4 mb-sm">
                                                        <div class="form-group">
                                                            <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                            <?php $fieldName = key($record); ?>
                                                            
                                                            <input type="checkbox" name="accesslegalDocumentsIndividual[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                            
                                                            <?php if ($record['module'] == 'Passport_Size_Photo') { ?>
                                                                <p class="float-left" style="margin-left: -530px;font-weight: bold;text-decoration: underline;">ADDRESS PROOF:-</p>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                <?php
                                                }
                                                ?>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                        }
                                    }
                                ?>
                              </div>  
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">PROPRIETORSHIP FIRM DOCUMEN</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                                <!---Check-List--->
                                <!-- check list  -->
                                <?php
                                    if(!empty($legalDocumentsProprietorship))
                                    {
                                        
                                        foreach($legalDocumentsProprietorship as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsProprietorship[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            
                                        <?php 
                                        }
                                        ?>
                                        
                                            <?php
                                        }
                                    }
                                ?>
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">HUF - DOCUMENT</h4>
                                      </div>
                                      <?php
								
									
                                    if(!empty($legalDocumentsHUF))
                                    {
                                        
                                        foreach($legalDocumentsHUF as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsHUF[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            
                                        <?php 
                                        }
                                        ?>
                                        
                                            <?php
                                        }
                                    }
                                ?>
                                    </div>
                                <?php } ?>
                              </div>
                             <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">PARTNERSHIP FIRM DOCUMENT</h4>
                                      </div>
                                      <?php
                                    if(!empty($legalDocumentsPartnership))
                                    {
                                        
                                        foreach($legalDocumentsPartnership as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsPartnership[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            
                                        <?php 
                                        }
                                        ?>
                                        
                                            <?php
                                        }
                                    }
                                ?>
                                    </div>
                                <?php } ?>
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                             
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">TRUST DOCUMENT</h4>
                                      </div>
                                      <?php
                                    if(!empty($legalDocumentsTrust))
                                    {
                                        
                                        foreach($legalDocumentsTrust as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsTrust[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            
                                        <?php 
                                        }
                                        ?>
                                        
                                            <?php
                                        }
                                    }
                                ?>
                                    </div>
                                <?php } ?>
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">SOCIETY DOCUMENT</h4>
                                      </div>
                                      <?php
                                    if(!empty($legalDocumentsSociety))
                                    {
                                        
                                        foreach($legalDocumentsSociety as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsSociety[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            
                                        <?php 
                                        }
                                        ?>
                                        
                                            <?php
                                        }
                                    }
                                ?>
                                    </div>
                                <?php } ?>
                              </div>
                              
                            <!--   <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">OFFER TO BRANCH FREE OF CHARGE</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                              </div> -->
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                     <div class="col-md-12">
    <h4 class="legal-hed-title">PREMISE PICTURE</h4>
    
    <!-- BEFORE INSTALLATION -->
    <h6 style="text-align: center;font-weight: bold;font-size: 14px;">BEFORE INSTALLATION -:</h6><br>
    
    <!-- <?php if(!empty($LgBeforeattachS3File)): ?>
        <div style="text-align: center;">
            <img src="<?= $LgBeforeattachS3File ?>" alt="Before Installation">
        </div>
    <?php else: ?>
        <p style="text-align: center;">No image uploaded for before installation.</p>
    <?php endif; ?> -->

    <br>

    <!-- AFTER INSTALLATION -->
    <h6 style="text-align: center;font-weight: bold;font-size: 14px;">AFTER INSTALLATION -:</h6><br>
    
    <!-- <?php if(!empty($LgAfterattachS3File)): ?>
        <div style="text-align: center;">
            <img src="<?= $LgAfterattachS3File ?>" alt="After Installation" >
        </div>
    <?php else: ?>
        <p style="text-align: center;">No image uploaded for after installation.</p>
    <?php endif; ?> -->
</div>

                                <?php } ?>
                              </div>
                            <!----End-Legal-Section------>                                
                            <!---Start-Digital-Marketing-Section---->
                                <?php
                                    }if ($is_admin == 1 || $role==18 || $role==15) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Opted For Online Marketing <span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="optOnlineMarketing" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($optOnlineMarketing == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($optOnlineMarketing == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Digital Marketing Cost With GST <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="digiMarkCost" value="<?php echo $digiMarkCost; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Digital Marketing Start Date <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="digiMarkStartDtm" value="<?php echo $digiMarkStartDtm; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Digital Marketing End Date <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="digiMarkEndDtm" value="<?php echo $digiMarkEndDtm; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Online Marketing Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="digiMarkReamrk" value="<?php echo $digiMarkReamrk; ?>"><span class="error"></span>
                                    </div>
                                </div>
                            <!---End--Digital-<arketing-Section---->
                            <!---Start-Social-Media-Department-Section---->
                            <?php
                                    }if ($is_admin == 1 || $role==33 || $role==15) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group">
                                        <label class="control-label">Facebook Page Status <span class="required">*</span></label>
                                        <select class="form-control check required" id="facebookPageStatus" name="facebookPageStatus" required>
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($facebookPageStatus == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($facebookPageStatus == INACTIVE) {echo "selected=selected";} ?> >InActive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Facebook Page  Link</label><input type="text" class="form-control check" autocomplete="off" name="facebookPageLink" value="<?php echo $facebookPageLink; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Facebook Page Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="facebookPageRemark" value="<?php echo $facebookPageRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Google Map Location Status <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="googleMapLoc" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($googleMapLoc == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($googleMapLoc == INACTIVE) {echo "selected=selected";} ?> >InActive</option>
                                    </select>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Google Map Location Link</label><input type="text" class="form-control check" autocomplete="off" name="googleMapLocLink" value="<?php echo $googleMapLocLink; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Google Map Location - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="googleMapLocRemark" value="<?php echo $googleMapLocRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Instagram Page Status <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="instagramPageStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($instagramPageStatus == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($instagramPageStatus == INACTIVE) {echo "selected=selected";} ?> >InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Instagram Page ID</label><input type="text" class="form-control check" autocomplete="off" name="instagramPageID" value="<?php echo $instagramPageID; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Instagram Page - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="instagramPageRemark" value="<?php echo $instagramPageRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <!---New-custom--->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Just Dial Page Status <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="jdPageStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($jdPageStatus == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($jdPageStatus == INACTIVE) {echo "selected=selected";} ?> >InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Just Dial Page ID</label><input type="text" class="form-control check" autocomplete="off" name="jdPageID" value="<?php echo $jdPageID; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Just Dial Page - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="jdPageRemark" value="<?php echo $jdPageRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">LinkedIn Page Status <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="tweetPageStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($tweetPageStatus == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($tweetPageStatus == INACTIVE) {echo "selected=selected";} ?> >InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">LinkedIn Page ID</label><input type="text" class="form-control check" autocomplete="off" name="tweetPageID" value="<?php echo $tweetPageID; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">LinkedIn Page - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="tweetPageRemark" value="<?php echo $tweetPageRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>     
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation feedback video uploaded on FB <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="insfeedvideoUplodFB" value="<?php echo $insfeedvideoUplodFB; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation feedback video uploaded on Youtube <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="insfeedvideoUplodYoutube" value="<?php echo $insfeedvideoUplodYoutube; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation feedback video uploaded on Insta <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="insfeedvideoUplodInsta" value="<?php echo $insfeedvideoUplodInsta; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Custom Website Link<span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="customWebsiteLink" value="<?php echo $customWebsiteLink; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on FB<span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brimguploadedFBStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($brimguploadedFBStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brimguploadedFBStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on FB Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="brimguploadedFBDate" value="<?php echo $brimguploadedFBDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on Instagram<span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brimguploadedInstaStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($brimguploadedInstaStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brimguploadedInstaStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on Instagram Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="brimguploadedInstaDate" value="<?php echo $brimguploadedInstaDate; ?>"><span class="error"></span>
                                    </div>
                                </div>        
                            <!---End-Social-Media-Department-Section---->

                            <!---Start-Support-Section---->                 
                            <?php
                            }
                            if ($is_admin == 1 || $role==15 || $role==13) {
                                 ?>
                                <!---Custom-Fields-Start-->
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch location address(Premise) <span class="required">*</span></label><textarea type="textarea" class="form-control check" name="branchLocAddressPremise"><?php echo $branchLocAddressPremise; ?></textarea><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Add of franchisee (person/company/society/partnership) <span class="required">*</span></label><textarea type="textarea" class="form-control check" name="addOfFranchise"><?php echo $addOfFranchise; ?></textarea><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-6 mb-sm">
                                <div class="form-group">
                                        <label class="control-label">Permanent Address</label>
                                        <textarea class="form-control check" rows="1" name="permanentAddress" placeholder="Permanent Address"><?php echo $permanentAddress; ?></textarea>
                                    </div>
                                </div>  
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group">
                                        <label class="control-label">Franchise Name</label><input type="text" class="form-control check" autocomplete="off" name="franchiseName" value="<?php echo $franchiseName; ?>"><span class="error"></span>
                                    </div>
                                </div>    
                                <div class="col-md-6 mb-sm">
                                <div class="form-group">
                                        <label class="control-label">Current Status</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="currentStatus" tabindex="-1" aria-hidden="true">
                                            <option value="<?php echo $currentStatus; ?>" <?php echo "selected=selected"; ?>><?php echo $currentStatus; ?></option>
                                          <option value="Installed-Active">Installed Active</option>
                                          <option value="Installed-Closed"> Installed Closed</option>
                                          <option value="UnInstalled-Active"> UnInstalled Active</option>
                                          <option value="UnInstalled-Closed"> UnInstalled Closed</option>
                                        </select>
                                    </div>
                                </div> 
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group">
                                        <label class="control-label">Type of branch</label><input type="text" class="form-control check" autocomplete="off" name="typeBranch" value="<?php echo $typeBranch; ?>"><span class="error"></span>
                                    </div>
                                </div>                                         
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Location</label><input type="text" class="form-control check" autocomplete="off" name="branchLocation" value="<?php echo $branchLocation; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admin's  Name <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="adminName" value="<?php echo $adminName; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admin's  Contact Number <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="adminContactNum" value="<?php echo $adminContactNum; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Additional number</label><input type="tel" class="form-control check" autocomplete="off" name="additionalNumber" value="<?php echo $additionalNumber; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Edumeta Official email ID</label><input type="email" class="form-control check" autocomplete="off" name="officialEmailID" value="<?php echo $officialEmailID; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Personal Email ID</label><input type="email" class="form-control check" autocomplete="off" name="personalEmailId" value="<?php echo $personalEmailId; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">GST number</label><input type="text" class="form-control check" autocomplete="off" name="gstNumber" value="<?php echo $gstNumber; ?>"><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-6 mb-sm"><!--new-field--->
                                    <div class="form-group"><label class="control-label">Undertaking And Commitment - Support</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="undertakingCommitmentSupport" value="<?php echo $undertakingCommitmentSupport; ?>"><span class="error"></span>
                                    </div>
                                </div><!--end-new-field--->
                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Manuals-1 <span class="required"></span></label><input type="date" class="form-control check" autocomplete="off" name="Manual1" value="<?php echo $Manual1; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Manuals-2 <span class="required"></span></label><input type="date" class="form-control check" autocomplete="off" name="Manual2" value="<?php echo $Manual2; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Manuals-3 <span class="required"></span></label><input type="date" class="form-control check" autocomplete="off" name="Manual3" value="<?php echo $Manual3; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Reference</label><input type="text" class="form-control check" autocomplete="off" name="Reference" value="<?php echo $Reference; ?>"><span class="error"></span></div>
                                </div>                              
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Tentative Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="installationTentativeDate" value="<?php echo $installationTentativeDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Date</label><input type="date" class="form-control check" autocomplete="off" name="installationDate" value="<?php echo $installationDate; ?>"><span class="error"></span></div>
                                </div>
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Set Up/Installation completed <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="setUpInstallation" value="<?php //echo $setUpInstallation; ?>"><span class="error"></span></div>
                                </div>-->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Anniversary Date/ start date <span class="required">*</span></label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="branchAnniversaryDate" value="<?php echo $branchAnniversaryDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Teacher Recruitment Done</label><input type="text" class="form-control check" autocomplete="off" name="teacherRecruitment" value="<?php echo $teacherRecruitment; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Anniversery</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="OwnerAnniversery" value="<?php echo $OwnerAnniversery; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Welcome CALL <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="welcomeCall" value="<?php echo $welcomeCall; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Welcome MAIL <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="welcomeMail" value="<?php echo $welcomeMail; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Whatsapp Group <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="whatsappGroup" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($whatsappGroup == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($whatsappGroup == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Whatsapp Group - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="whatsappGroupRemark" value="<?php echo $whatsappGroupRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Whatsapp Group Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="whatsappGroupdate" value="<?php echo $whatsappGroupdate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Requirement mail</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="installationRequirementmail" value="<?php echo $installationRequirementmail; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-5 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Requirement mail - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="installationRequirementmailRemark" value="<?php echo $installationRequirementmailRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Official email id shared <span class="required">*</span></label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="officialemailshared" value="<?php echo $officialemailshared; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">1st Interaction Meeting</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="interactionMeeting" value="<?php echo $interactionMeeting; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-5 mb-sm">
                                    <div class="form-group"><label class="control-label">1st Interaction Meeting - Remark</label><input type="text" class="form-control check" autocomplete="off" name="interactionMeetingRemark" value="<?php echo $interactionMeetingRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                               
                                <!---End-New-field-Support-18-May-2023---> 
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Inauguration</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="inaugurationDate" value="<?php //echo $inaugurationDate; ?>"><span class="error"></span>
                                    </div>
                                </div>-->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Interaction Date (Support)</label><input type="date" class="form-control check" autocomplete="off" name="lastInteractiondate" value="<?php echo $lastInteractiondate; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Discussion by</label><input type="text" class="form-control check" autocomplete="off" name="lastDiscussionby" value="<?php echo $lastDiscussionby; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Discussion Comment</label><input type="text" class="form-control check" autocomplete="off" name="lastInteractioncomment" value="<?php echo $lastInteractioncomment; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Landline</label><input type="text" class="form-control check" autocomplete="off" name="branchLandline" value="<?php echo $branchLandline; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Additional Name</label><input type="text" class="form-control check" autocomplete="off" name="additionalName" value="<?php echo $additionalName; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Deadine for final payment</label><input type="date" class="form-control check" autocomplete="off" name="finalPaydeadline" value="<?php echo $finalPaydeadline; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Time Disclipine Email</label><input type="date" class="form-control check" autocomplete="off" name="timeDisclipineemail" value="<?php echo $timeDisclipineemail; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Uniform Disclipine Email</label><input type="date" class="form-control check" autocomplete="off" name="uniformDisclipineemail" value="<?php echo $uniformDisclipineemail; ?>"><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Upgrade UPTO Class-2</label><input type="text" class="form-control check" autocomplete="off" name="upgradeUptoclass" value="<?php echo $upgradeUptoclass; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Happiness level of branch</label><input type="text" class="form-control check" autocomplete="off" name="happinessLevelbranch" value="<?php echo $happinessLevelbranch; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Special Remark</label><input type="text" class="form-control check" autocomplete="off" name="specialRemark" value="<?php echo $specialRemark; ?>"><span class="error"></span></div>
                                </div>
                                
                                <?php
                                    } if ($is_admin == 1 || $role==23 || $role==15) {
                                     ?>    
                                <!---Start-Dispatch-Section---->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Material Dispatch Date</label><input type="date" class="form-control check" autocomplete="off" name="insmatDispatchdate" value="<?php echo $insmatDispatchdate; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Details & Receipt mail Status</label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="DetailsReceiptmail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($DetailsReceiptmail == ACTIVE) {echo "selected=selected";} ?>>Shared</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($DetailsReceiptmail == INACTIVE) {echo "selected=selected";} ?> >Not Shared</option>
                                    </select></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Confirmation From Branch on Material Received </label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="ConfBrinsScheduledemail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($ConfBrinsScheduledemail == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($ConfBrinsScheduledemail == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Material Received date</label><input type="date" class="form-control check" autocomplete="off" name="Materialrecdate" value="<?php echo $Materialrecdate; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Scheduled Date</label><input type="date" class="form-control check" autocomplete="off" name="BrinsScheduleddate" value="<?php echo $BrinsScheduleddate; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Scheduled Email</label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="BrinsScheduledemail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($BrinsScheduledemail == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($BrinsScheduledemail == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>
                                    </select></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation - Remark</label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="brInstalationRemark" value="<?php echo $brInstalationRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Video Feedback From Branch</label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="videoFeedbackbr" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($videoFeedbackbr == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($videoFeedbackbr == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Written Feedback From Branch</label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="writtenFeedbackbr" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($writtenFeedbackbr == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($writtenFeedbackbr == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select></div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Shared - Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="ShoppinPortSharedDate" value="<?php echo $ShoppinPortSharedDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Training Status <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="ShoppinPortTraining" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($ShoppinPortTraining == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($ShoppinPortTraining == INACTIVE) {echo "selected=selected";} ?> >Pending</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Training - Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="ShoppinPortTrainingDate" value="<?php echo $ShoppinPortTrainingDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Training - Remark</label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="ShoppinPortRemark" value="<?php echo $ShoppinPortRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Return Items</label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="returnItems" value="<?php echo $returnItems; ?>"><span class="error"></span>
                                    </div>
                                </div>
                               
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Mode Of Despatch <span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="modeOfDespatch" value="<?php echo $modeOfDespatch; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Number Of Boxes <span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="NumOfBoxes" value="<?php echo $NumOfBoxes; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">POD Number <span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="PoDNum" value="<?php echo $PoDNum; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Specific Items / Gifts / Offer - (If Any)   <span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="SpecificGiftOffer" value="<?php echo $SpecificGiftOffer; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Confirmation After Branch Installation Over Phone <span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="ConfBrInsOverPhone" value="<?php echo $ConfBrInsOverPhone; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Short Comming - (If Any) <span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="shortComming" value="<?php echo $shortComming; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Solutions Of Short Comming<span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="solutionShortComming" value="<?php echo $solutionShortComming; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <!---End-Dispatch-Section---->
                                <!---Start-Admission-Section---->
                                <?php
                                    } if ($is_admin == 1 || $role==20 || $role==15) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">1st Admission Cracked on</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="admissionCracked" value="<?php echo $branchAnniversaryDate; ?>"><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">PG Decided Fee</label><input type="text" class="form-control check" autocomplete="off" name="pgDecidedFee" value="<?php echo $pgDecidedFee; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Nursery Decided Fee</label><input type="text" class="form-control check" autocomplete="off" name="nurseryDecidedFee" value="<?php echo $nurseryDecidedFee; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">KG-1 Decided Fee</label><input type="text" class="form-control check" autocomplete="off" name="KG1DecidedFee" value="<?php echo $KG1DecidedFee; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">KG-2 Decided Fee</label><input type="text" class="form-control check" autocomplete="off" name="KG2DecidedFee" value="<?php echo $KG2DecidedFee; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Fees Shared Status <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="feeSharedStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($feeSharedStatus == ACTIVE) {echo "selected=selected";} ?>>Shared</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($feeSharedStatus == INACTIVE) {echo "selected=selected";} ?> >Not Shared</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Fees Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="feesRemark" value="<?php echo $feesRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <!---New-field-Admissions-18-May-2023--->   
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions PG <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmissionPG" value="<?php echo $addmissionPG; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions NURSERY <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmissionNursary" value="<?php echo $addmissionNursary; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions KG1<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmissionKg1" value="<?php echo $addmissionKg1;  ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions KG2<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmissionKg2" value="<?php echo $addmissionKg2;  ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions1st<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmission1st" value="<?php echo $addmission1st; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions2nd<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmission2nd" value="<?php echo $addmission2nd; ?>"><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                  <?php $totalAddmission = $addmission2nd + $addmission1st + $addmissionKg2 + $addmissionKg1 + $addmissionNursary + $addmissionPG ?>
                                    <div class="form-group"><label class="control-label">Total Admissions<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="totalAddmission" value="<?php echo $totalAddmission; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admission Counselor Name<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmissionCounselor" value="<?php echo $addmissionCounselor; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Discussion (Admissions)<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="lastDiscussaddmission" value="<?php echo $lastDiscussaddmission; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                 <!-- <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions Excel Sheet Link<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="addmissionSheetlink" value="<?php echo $addmissionSheetlink; ?>"><span class="error"></span>
                                    </div>
                                </div>
                               <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Date of Excel Sheet Shared<span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="dateexlSheetshared" value=""><span class="error"></span>
                                    </div>
                                </div>    -->       
                                <!---End-New-field-Admissions-18-May-2023---> 
                                
                                <!---End-Admissions-Section---->
                                <!---Start-Design-Promotion-Section----> 
                                <?php
                                    } if ($is_admin == 1 || $role==19 || $role==15) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Designs &amp; Promotional images shared <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="DesignsPromotional" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($DesignsPromotional == ACTIVE) {echo "selected=selected";} ?>>Shared</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($DesignsPromotional == INACTIVE) {echo "selected=selected";} ?> >Not Shared</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Designs &amp; Promotional images - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="DesignsPromotionalRemark" value="<?php echo $DesignsPromotionalRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-12 mb-sm">
                                    <div class="form-group"><label class="control-label">Special Note for the branch</label><textarea type="textarea" class="form-control check" name="BranchSpecialNote"><?php echo $BranchSpecialNote; ?></textarea><span class="error"></span></div>
                                </div>
                                
                               <!--New-Design-Field---->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Congratulations image of  branch Installation  <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="congratulationsImg" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($congratulationsImg == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($congratulationsImg == INACTIVE) {echo "selected=selected";} ?> >Pending</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on FB<span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brimguploadedFBStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($brimguploadedFBStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brimguploadedFBStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on FB Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="brimguploadedFBDate" value="<?php echo $brimguploadedFBDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on Instagram<span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brimguploadedInstaStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($brimguploadedInstaStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brimguploadedInstaStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on Instagram Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="brimguploadedInstaDate" value="<?php echo $brimguploadedInstaDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admission Open Image(Creation & sharing)</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="admissionOpenimgStatus" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($admissionOpenimgStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($admissionOpenimgStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Staff Hiring Image(Creation & sharing)</label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="staffHiringimgStatus" tabindex="-1" aria-hidden="true">
                                         <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($staffHiringimgStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($staffHiringimgStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - January</label><input type="date" class="form-control check" autocomplete="off" name="newsletterMarch" value="<?php echo $newsletterMarch; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - April</label><input type="date" class="form-control check" autocomplete="off" name="newsletterJune" value="<?php echo $newsletterJune; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - July</label><input type="date" class="form-control check" autocomplete="off" name="newsletterSeptember" value="<?php echo $newsletterSeptember; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - October</label><input type="date" class="form-control check" autocomplete="off" name="newsletterDecember" value="<?php echo $newsletterDecember; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Birthday Image Shared</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="OBirthDayImgStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($OBirthDayImgStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($OBirthDayImgStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Birthday Image Shared Date</label><input type="date" class="form-control check" autocomplete="off" name="OBirthDayImgSharedDtm" value="<?php echo $OBirthDayImgSharedDtm; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Anniversery Image Shared</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="OwnerAnnImgStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($OwnerAnnImgStatus == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($OwnerAnnImgStatus == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Anniversery Image Shared Date</label><input type="date" class="form-control check" autocomplete="off" name="OwnerAnnImgSharedDtm" value="<?php echo $OwnerAnnImgSharedDtm; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Custom Website Link<span class="required">*</span></label><input type="text" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="customWebsiteLink" value="<?php echo $customWebsiteLink; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <!---End-Design-Promotion-Section---->
                                <!-- Start Administration Training-Section -->
                                <?php
                                    } if ($is_admin == 1 || $role==30 || $role==15) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Biometric (Installed &amp; Operating)<span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="biometricInstalled" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($biometricInstalled == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($biometricInstalled == INACTIVE) {echo "selected=selected";} ?> >Pending</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Add Remark for Biometric<span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="biometricRemark" value="<?php echo $biometricRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Biometric Installed Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="biometricInstalledDate" value="<?php echo $biometricInstalledDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Camera (Installed &amp; Operating) <span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="camaraInstalled" tabindex="-1" aria-hidden="true"><option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($camaraInstalled == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($camaraInstalled == INACTIVE) {echo "selected=selected";} ?> >Pending</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Add Remark for Camera <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="camaraRemark" value="<?php echo $camaraRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Camera Installed Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="camaraInstalledDate" value="<?php echo $camaraInstalledDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">EduMETA APP Training <span class="required">*</span></label><select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="eduMetaAppTraining" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($eduMetaAppTraining == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($eduMetaAppTraining == INACTIVE) {echo "selected=selected";} ?> >Pending</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">EduMETA APP Training - Remark <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="AppTrainingRemark" value="<?php echo $AppTrainingRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">EduMETA APP Training - Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="AppTrainingRemarkDate" value="<?php echo $AppTrainingRemarkDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group">
                                        <label class="control-label">Welcome Folder Status </label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="welComeFolderStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($welComeFolderStatus == ACTIVE) {echo "selected=selected";} ?>> Yes </option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($welComeFolderStatus == INACTIVE) {echo "selected=selected";} ?> > No </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">  
                                  <div class="form-group">
                                      <label class="control-label">Welcome Folder Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="welComeFolderDtm" value="<?php echo $welComeFolderDtm; ?>"><span class="error"></span>
                                  </div>
                                </div>  
                                <!-- End-Administration-Traingin-Section -->
                                <!---Start-Training-Section---->
                                <?php
                                    } if ($is_admin == 1 || $role==21 || $role==14) {
                                     ?>
                                 <h2>Initial Training</h2>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Introduction</label>
        <input type="date" class="form-control check" autocomplete="off" name="IntroductionDate" value="<?php echo $IntroductionDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Pre-marketing</label>
        <input type="date" class="form-control check" autocomplete="off" name="Pre_marketingDate" value="<?php echo $Pre_marketingDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Admin/Orientation</label>
        <input type="date" class="form-control check" autocomplete="off" name="Admin_OrientationDate" value="<?php echo $Admin_OrientationDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Inauguration/Refer and Earn</label>
        <input type="date" class="form-control check" autocomplete="off" name="Inauguration_Refer_and_EarnDate" value="<?php echo $Inauguration_Refer_and_EarnDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Classroom decoration</label>
        <input type="date" class="form-control check" autocomplete="off" name="Classroom_decorationDate" value="<?php echo $Classroom_decorationDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Movie club</label>
        <input type="date" class="form-control check" autocomplete="off" name="Movie_clubDate" value="<?php echo $Movie_clubDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Fee structure</label>
        <input type="date" class="form-control check" autocomplete="off" name="Fee_structureDate" value="<?php echo $Fee_structureDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Day care</label>
        <input type="date" class="form-control check" autocomplete="off" name="Day_careDate" value="<?php echo $Day_careDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group">
        <label class="control-label">Toddlers</label>
        <input type="date" class="form-control check" autocomplete="off" name="ToddlerDate" value="<?php echo $ToddlerDate; ?>">
        <span class="error"></span>
    </div>
</div>

                            <h2>PG</h2>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">April/June</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_April_JuneDate" value="<?php echo $pG_April_JuneDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">July</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_JulyDate" value="<?php echo $pG_JulyDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">August</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_AugustDate" value="<?php echo $pG_AugustDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">September</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_SeptemberDate" value="<?php echo $pG_SeptemberDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">October</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_OctoberDate" value="<?php echo $pG_OctoberDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">November</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_NovemberDate" value="<?php echo $pG_NovemberDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">December</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_DecemberDate" value="<?php echo $pG_DecemberDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">January</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_JanuaryDate" value="<?php echo $pG_JanuaryDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">February</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_FebruaryDate" value="<?php echo $pG_FebruaryDate; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">March</label>
        <input type="date" class="form-control check" autocomplete="off" name="pG_MarchDate" value="<?php echo $pG_MarchDate; ?>">
        <span class="error"></span>
    </div>
</div>


                               <h2>Nursery</h2>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-1</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_1_Date" value="<?php echo $NurseryBook_1_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-2</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_2_Date" value="<?php echo $NurseryBook_2_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-3</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_3_Date" value="<?php echo $NurseryBook_3_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-4</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_4_Date" value="<?php echo $NurseryBook_4_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-5</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_5_Date" value="<?php echo $NurseryBook_5_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-6</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_6_Date" value="<?php echo $NurseryBook_6_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-7</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_7_Date" value="<?php echo $NurseryBook_7_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-8</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_8_Date" value="<?php echo $NurseryBook_8_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-9</label>
        <input type="date" class="form-control check" autocomplete="off" name="NurseryBook_9_Date" value="<?php echo $NurseryBook_9_Date; ?>">
        <span class="error"></span>
    </div>
</div>

<h2>KG-1</h2>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-1</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_1_Date" value="<?php echo $KG1Book_1_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-2</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_2_Date" value="<?php echo $KG1Book_2_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-3</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_3_Date" value="<?php echo $KG1Book_3_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-4</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_4_Date" value="<?php echo $KG1Book_4_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-5</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_5_Date" value="<?php echo $KG1Book_5_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-6</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_6_Date" value="<?php echo $KG1Book_6_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-7</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_7_Date" value="<?php echo $KG1Book_7_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-8</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_8_Date" value="<?php echo $KG1Book_8_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-9</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG1Book_9_Date" value="<?php echo $KG1Book_9_Date; ?>"><span class="error"></span>
    </div>
</div>

                                  <h2>KG-2</h2>

<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-1</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_1_Date" value="<?php echo $KG2Book_1_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-2</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_2_Date" value="<?php echo $KG2Book_2_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-3</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_3_Date" value="<?php echo $KG2Book_3_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-4</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_4_Date" value="<?php echo $KG2Book_4_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-5</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_5_Date" value="<?php echo $KG2Book_5_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-6</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_6_Date" value="<?php echo $KG2Book_6_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-7</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_7_Date" value="<?php echo $KG2Book_7_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-8</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_8_Date" value="<?php echo $KG2Book_8_Date; ?>"><span class="error"></span>
    </div>
</div>
<div class="col-md-4 mb-sm">
    <div class="form-group"><label class="control-label">Book-9</label>
        <input type="date" class="form-control check" autocomplete="off" name="KG2Book_9_Date" value="<?php echo $KG2Book_9_Date; ?>"><span class="error"></span>
    </div>
</div>

                                 <!--  -->
                                 <h2>Event/Celebration</h2>

<?php
// Example PHP values (you need to populate these from DB)
$eventCelebration_April_JuneDate = ''; // Fill from DB
$eventCelebration_JulyDate = '';
$eventCelebration_AugustDate = '';
$eventCelebration_SeptemberDate = '';
$eventCelebration_OctoberDate = '';
$eventCelebration_NovemberDate = '';
$eventCelebration_DecemberDate = '';
$eventCelebration_JanuaryDate = '';
$eventCelebration_FebruaryDate = '';
$eventCelebration_MarchDate = '';
$Workshop_1Date = '';
$Workshop_2Date = '';
$Workshop_3Date = '';
$Workshop_4Date = '';
$Workshop_5Date = '';
$Workshop_6Date = '';
$Workshop_7Date = '';
?>

<!-- Event Celebration Dates -->
<?php
$eventFields = [
    "April/June" => "eventCelebration_April_JuneDate",
    "July" => "eventCelebration_JulyDate",
    "August" => "eventCelebration_AugustDate",
    "September" => "eventCelebration_SeptemberDate",
    "October" => "eventCelebration_OctoberDate",
    "November" => "eventCelebration_NovemberDate",
    "December" => "eventCelebration_DecemberDate",
    "January" => "eventCelebration_JanuaryDate",
    "February" => "eventCelebration_FebruaryDate",
    "March" => "eventCelebration_MarchDate"
];

foreach ($eventFields as $label => $name): ?>
    <div class="col-md-4 mb-sm">
        <div class="form-group">
            <label class="control-label"><?= $label ?></label>
            <input type="date" class="form-control check" autocomplete="off" name="<?= $name ?>" value="<?php echo $$name; ?>">
            <span class="error"></span>
        </div>
    </div>
<?php endforeach; ?>

<h2>Workshop</h2>

<?php
$workshopFields = [
    "Workshop-1" => "Workshop_1Date",
    "Workshop-2" => "Workshop_2Date",
    "Workshop-3" => "Workshop_3Date",
    "Workshop-4" => "Workshop_4Date",
    "Workshop-5" => "Workshop_5Date",
    "Workshop-6" => "Workshop_6Date",
    "Workshop-7" => "Workshop_7Date"
];

foreach ($workshopFields as $label => $name): ?>
    <div class="col-md-6 mb-sm">
        <div class="form-group">
            <label class="control-label"><?= $label ?></label>
            <input type="date" class="form-control check" autocomplete="off" name="<?= $name ?>" value="<?php echo $$name; ?>">
            <span class="error"></span>
        </div>
    </div>
<?php endforeach; ?>

                                 <h2>Others</h2>

<?php
// PHP variables (populate from DB in controller)
$others_Settlers_program_Date = '';
$others_Circle_time_Date = '';
$others_Interview_Date = '';
$others_Academic_Overview_Date = '';
$others_Teacher_interaction_Date = '';
$others_Assessment_Date = '';
$others_PTM_Date = '';
$others_Summer_camp_Date = '';
$others_Winter_Camp_Date = '';
$others_Aayam_Date = '';
$others_Sports_day_Date = '';
$others_midterm_session = '';
$others_bridgecourse = '';
?>

<?php
$othersFields = [
    "Settlers program" => "others_Settlers_program_Date",
    "Circle time" => "others_Circle_time_Date",
    "Interview" => "others_Interview_Date",
    "Academic Overview" => "others_Academic_Overview_Date",
    "Teacher interaction" => "others_Teacher_interaction_Date",
    "Assessment" => "others_Assessment_Date",
    "PTM" => "others_PTM_Date",
    "Summer camp" => "others_Summer_camp_Date",
    "Winter Camp" => "others_Winter_Camp_Date",
    "Aayam" => "others_Aayam_Date",
    "Sports day" => "others_Sports_day_Date",
    "Mid Term Session" => "others_midterm_session",
    "Bridge Course" => "others_bridgecourse"
];

foreach ($othersFields as $label => $name): ?>
    <div class="col-md-6 mb-sm">
        <div class="form-group">
            <label class="control-label"><?= $label ?></label>
            <input type="date" class="form-control check" autocomplete="off" name="<?= $name ?>" value="<?php echo $$name; ?>">
            <span class="error"></span>
        </div>
    </div>
<?php endforeach; ?>
                                <!--end-new-field---->
                                
                                <!---End-Training-Section---->
                                
                                <!---Start-Main-Account-Section---->
                                <?php
                                    } if ($is_admin == 1 || $role==15 || $role==16) {
                                     ?>
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Offer Plan Name </label><input type="text" class="form-control check" autocomplete="off" name="offerPlanname" value="<?php //echo $offerPlanname; ?>"><span class="error"></span></div>
                                    <input type="hidden" value="<?php //echo $branchesId; ?>" name="branchesId" id="branchesId" />
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Discount </label><input type="text" class="form-control check" autocomplete="off" name="discountAmount" value="<?php //echo $discountAmount; ?>"><span class="error"></span></div>
                                </div>-->
                                
                               <!--  <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Training Amount </label><input type="text" class="form-control check" autocomplete="off" name="trainingAmount" value="<?php echo $trainingAmount; ?>"><span class="error"></span></div>
                                </div> -->
                              <!--   <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Society Service Amount </label><input type="text" class="form-control check" autocomplete="off" name="societyServiceamount" value="<?php echo $societyServiceamount; ?>"><span class="error"></span></div>
                                </div> -->
                                <div class="col-md-4 mb-sm">
                                  <?php //@$totalAmount = $finalAmount + $trainingAmount + $societyServiceamount; ?>
                                    <div class="form-group"><label class="control-label">AMC Amount</label><input type="text" class="form-control check" autocomplete="off" name="totalAmount" value="<?php echo $totalAmount; ?>"><span class="error"></span></div>
                                </div>
                                                           
                                <!-- <div class="col-md-6 mb-sm">
                                  <?php //$totalfranchisegstFund = $totalAmount + $gstAmount  ?>
                                    <div class="form-group"><label class="control-label">Total Franchise Cost with GST+Society Fund</label><input type="text" class="form-control check" autocomplete="off" name="totalfranchisegstFund" value="<?php echo $totalfranchisegstFund; ?>"><span class="error"></span></div>
                                </div> -->
                               <!--  <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges</label><input type="text" class="form-control check" autocomplete="off" name="legalCharges" value="<?php echo $legalCharges; ?>"><span class="error"></span></div>
                                </div> -->
                               
                                
                               
                                
                              
                                <!-- <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Number of Initial Kit</label><input type="text" class="form-control check" autocomplete="off" name="numinitalKits" value="<?php //echo $numinitalKits; ?>"><span class="error"></span></div>
                                </div> -->
                                
                              
                                <div class="col-md-4 mb-sm">
                                  <?php  //@$dueKitamount = $totalKitsamt - $kitamtReceived  ?>
                                    <div class="form-group"><label class="control-label">Due Kit amount</label><input type="text" class="form-control check" autocomplete="off" name="dueKitamount" value="<?php echo $dueKitamount; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Setup and Installation charges including GST</label><input type="text" class="form-control check" autocomplete="off" name="transporttravCharge" value="<?php echo $transporttravCharge; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Setup and Installation charges Received</label><input type="text" class="form-control check" autocomplete="off" name="brsetupinstachargReceived" value="<?php echo $brsetupinstachargReceived; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                  <?php  //@$brsetupinstachargDue = $transporttravCharge - $brsetupinstachargReceived  ?>
                                    <div class="form-group"><label class="control-label">Branch Setup and Installation charges Due</label><input type="text" class="form-control check" autocomplete="off" name="brsetupinstachargDue" value="<?php echo $brsetupinstachargDue; ?>"><span class="error"></span></div>
                                </div>
                               <!--  <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Travel Amount including GST</label><input type="text" class="form-control check" autocomplete="off" name="travelAmount" value="<?php echo $travelAmount; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Received Travel Amount</label><input type="text" class="form-control check" autocomplete="off" name="receivedtravelAmount" value="<?php echo $receivedtravelAmount; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                  <?php  //$duetravelAmount = $travelAmount - $receivedtravelAmount  ?>
                                    <div class="form-group"><label class="control-label">Due Travel AMT</label><input type="text" class="form-control check" autocomplete="off" name="duetravelAmount" value="<?php echo $duetravelAmount; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Transport charges</label><input type="text" class="form-control check" autocomplete="off" name="transportCharges" value="<?php echo $transportCharges; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Transport amt received</label><input type="text" class="form-control check" autocomplete="off" name="transportAmtreceived" value="<?php echo $transportAmtreceived; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                  <?php  //@$duetransportCharges = $transportCharges - $transportAmtreceived  ?>
                                    <div class="form-group"><label class="control-label">Due Transport Charges</label><input type="text" class="form-control check" autocomplete="off" name="duetransportCharges" value="<?php echo $duetransportCharges; ?>"><span class="error"></span></div>
                                </div> -->
                                <div class="col-md-6 mb-sm">
                                  <?php  //@$finaltotalamtDue = $dueFranchiseamt + $dueKitamount + $legalChargesdue + $brsetupinstachargDue + $duetravelAmount + $duetransportCharges  ?>
                                    <div class="form-group"><label class="control-label">Final Total amount due (including Franchise)</label><input type="text" class="form-control check" autocomplete="off" name="finaltotalamtDue" value="<?php echo $finaltotalamtDue; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">AMC with GST <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="amcAmount" value="<?php echo $amcAmount; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <!----Accounts-new-Added-fields-30-May-2023---->  
                                <!-- <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger - March</label><input type="date" class="form-control check" autocomplete="off" name="ledgerMarch" value="<?php echo $ledgerMarch; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger - June</label><input type="date" class="form-control check" autocomplete="off" name="ledgerJune" value="<?php echo $ledgerJune; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger - September</label><input type="date" class="form-control check" autocomplete="off" name="ledgerSeptember" value="<?php echo $ledgerSeptember; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger - December</label><input type="date" class="form-control check" autocomplete="off" name="ledgerDecember" value="<?php echo $ledgerDecember; ?>"><span class="error"></span>
                                    </div>
                                </div> -->
                                 <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger</label>
                                <select class="form-control required" id="franchiseNumber" name="LedgerMonthDrop"  >
                                            
                                            <option value="march">March</option>
                                             <option value="june">June</option>
                                             <option value="september">September</option>
                                             <option value="december">December</option>
                                                      
                                        </select>
                                </div> 
                                </div> 

                                 <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger</label>
                                <select class="form-control required" id="LedgerYear" name="LedgerYear"  >
                                         
                                            <option value="">Select Year</option>
                                            <option value="2024">2024</option>
                                            <option value="2025">2025</option>
                                            <option value="2026">2026</option>
                                            <option value="2027">2027</option>
                                            <option value="2028">2028</option>
                                            <option value="2029">2029</option>
                                            <option value="2030">2030</option>
                                            <option value="2031">2031</option>
                                            <option value="2032">2032</option>
                                            <option value="2033">2033</option>
                                            <option value="2034">2034</option>
                                            <option value="2035">2035</option>
                                            <option value="2036">2036</option>
                                            <option value="2037">2037</option>
                                            <option value="2038">2038</option>
                                            <option value="2039">2039</option>
                                            <option value="2040">2040</option>
                                            <option value="2041">2041</option>
                                            <option value="2042">2042</option>
                                            <option value="2043">2043</option>
                                            <option value="2044">2044</option>
                                            <option value="2045">2045</option>
                                            
                                        </select>
                                </div> 
                                </div> 
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 1st Decemeber</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus1Dec" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($reminderAMCStatus1Dec == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($reminderAMCStatus1Dec == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 1st Decemeber</label><input type="date" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC Remark</label><input type="text" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 10th December</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus10Dec" tabindex="-1" aria-hidden="true">
                                          <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($reminderAMCStatus10Dec == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($reminderAMCStatus10Dec == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>  
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 10th December</label><input type="date" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC Remark</label><input type="text" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 15th Decemeber</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus15Dec" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($reminderAMCStatus15Dec == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($reminderAMCStatus15Dec == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 15th Decemeber</label><input type="date" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC Remark</label><input type="text" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 19th Decemeber</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus19Dec" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($reminderAMCStatus19Dec == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($reminderAMCStatus19Dec == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 19th Decemeber</label><input type="date" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC Remark</label><input type="text" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 20th Decemeber</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($reminderAMCStatus20Dec == ACTIVE) {echo "selected=selected";} ?>>Done</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($reminderAMCStatus20Dec == INACTIVE) {echo "selected=selected";} ?> >Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 20th Decemeber</label><input type="date" class="form-control check" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>--> 
                              <!--   <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Remark for AMC Mail</label><input type="text" class="form-control check" autocomplete="off" name="RemarkforAMCmail" value="<?php echo $RemarkforAMCmail; ?>"><span class="error"></span>
                                    </div>
                                </div>
                               
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Invoice of AMC clearance (generate & mail)</label><input type="text" class="form-control check" autocomplete="off" name="InvoiceAMCClearance" value="<?php echo $InvoiceAMCClearance; ?>"><span class="error"></span>
                                    </div>
                                </div>  -->
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Penalty mail (In case of Non clearance)</label><input type="text" class="form-control check" autocomplete="off" name="PenaltyMailnoncle" value="<?php echo $PenaltyMailnoncle; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Invoice Number - (All) <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="invoiceNumberAll" value="<?php echo $invoiceNumberAll; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <?php  }  ?>
                                <!---End-Main-Account-Section---->
                            </div>
                        </div><!-- /.box-body -->
    
                      
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery(".check").each(function() {
            if (jQuery(this).val().trim() === "") {
                jQuery(this).css("border", "2px solid red");
            } else {
                jQuery(this).css("border", "1px solid #ccc");
            }
        });

    });
    /*Read-oly*/
    $.each($('form').serializeArray(), function(index, value){
      $('[name="' + value.name + '"]').attr('readonly', 'readonly');
    }); 
    $("form :select").attr("disabled", true);
    /*End-Read-only*/
</script>
<style type="text/css">
    .bar.red-bar:before, .bar.red-bar:after {
        border-bottom: 1px solid red !important;
    }
    .legal-hed-title{
      text-align: center;
      font-weight: 700;
      width: 27%;
      margin-left: auto;
      margin-right: auto;
      border: 2px solid #0c87cf;
      margin-bottom: 25px;
      background: #0c87cf;
      color: #fff;
      border-radius: 5px;
      padding: 5px;
    }
    .row {
      margin-right: 0px;
      margin-left: 0px;
  }
</style>
<script>
    const dropdown = document.getElementById('assignedTo');
    const otherInput = document.getElementById('branchSalesDonebyOther');

    dropdown.addEventListener('change', function () {
        if (this.value === 'other') {
            otherInput.style.display = 'block';
            otherInput.required = true;
            otherInput.value = ''; // Clear value for new input
        } else {
            otherInput.style.display = 'none';
            otherInput.required = false;
            otherInput.value = this.value; // Sync the dropdown value with the input field
        }
    });

    // Ensure the correct value is submitted
    document.querySelector('form').addEventListener('submit', function () {
        if (dropdown.value !== 'other') {
            otherInput.value = dropdown.value; // Submit dropdown value if not "Other"
        }
    });
</script>