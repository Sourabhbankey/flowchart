<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Holiday Management
        <small>Add / Edit Holiday</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Holiday Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>brholiday/addNewBrholiday" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="roomName">Holiday Title</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('holidayTitle'); ?>" id="holidayTitle" name="holidayTitle" maxlength="256" />
                                    </div>  
                                </div>

                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="roomName">Holiday Day</label>
                                        <select class="form-control required" id="holidayDay" name="holidayDay" required="">
                                            <option value="">Select Day</option>
                                            <option value="Monday">Monday</option>
                                            <option value="Tuesday">Tuesday</option>
                                            <option value="Wednesday">Wednesday</option>
                                            <option value="Thursday">Thursday</option>
                                            <option value="Friday">Friday</option>
                                            <option value="Saturday">Saturday</option>
                                            <option value="Sunday">Sunday</option>
                                        </select>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="roomName">Holiday From Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('holidayFromdate'); ?>" id="holidayFromdate" name="holidayFromdate" maxlength="256" />
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="roomName">Holiday To Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('holidayTodate'); ?>" id="holidayTodate" name="holidayTodate" maxlength="256" />
                                    </div>  
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('training/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>