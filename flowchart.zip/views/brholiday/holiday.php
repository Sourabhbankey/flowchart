<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-clock-o"></i> Holiday List
           
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Events & Date</h3>
                    </div>

                    <div class="box-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Date</th>
                                    <th>Event</th>
                                    <th>Day</th>
                                </tr>
                            </thead>
                            <tbody>
                         <tr>
    <td>1.</td>
    <td>01/01/2025</td>
    <td>New Year</td>
    <td>Wednesday</td>
</tr>
<tr>
    <td>2.</td>
    <td>26/01/2025</td>
    <td>Republic Day</td>
    <td>Sunday</td>
</tr>
<tr>
    <td>3.</td>
    <td>14/03/2025</td>
    <td>Holi</td>
    <td>Friday</td>
</tr>
<tr>
    <td>4.</td>
    <td>19/03/2025</td>
    <td>Rangpanchmi</td>
    <td>Wednesday</td>
</tr>
<tr>
    <td>5.</td>
    <td>16/06/2025</td>
    <td>EID-UL-Zuha (Specific)</td>
    <td>Sunday</td>
</tr>
<tr>
    <td>6.</td>
    <td>15/08/2025</td>
    <td>Independence Day</td>
    <td>Friday</td>
</tr>
<tr>
    <td>7.</td>
    <td>08/08/2025</td>
    <td>Rakshabandhan</td>
    <td>Friday</td>
</tr>
<tr>
    <td>8.</td>
    <td>06/09/2025</td>
    <td>EID-E-Miladunnabi (Specific)</td>
    <td>Saturday</td>
</tr>
<tr>
    <td>9.</td>
    <td>01/10/2025</td>
    <td>Dussehra</td>
    <td>Wednesday</td>
</tr>
<tr>
    <td>10.</td>
    <td>02/10/2025</td>
    <td>Gandhi Jayanti</td>
    <td>Thursday</td>
</tr>
<tr>
    <td>11.</td>
    <td>19/10/2025 to 21/10/2025</td>
    <td>Diwali</td>
    <td>Sunday to Tuesday</td>
</tr>
<tr>
    <td>12.</td>
    <td>05/11/2025</td>
    <td>Guru Nanak Jayanti (Specific)</td>
    <td>Wednesday</td>
</tr>
<tr>
    <td>13.</td>
    <td>25/12/2025</td>
    <td>Christmas (Specific)</td>
    <td>Thursday</td>
</tr>
                                   
                                    
                               
                            </tbody>
                        </table>
                    </div>

                    <!-- <div class="box-footer">
                        <a href="<?php //echo base_url('dailyreport'); ?>" class="btn btn-primary">
                            <i class="fa fa-arrow-left"></i> Back to Reports
                        </a>
                    </div> -->

                </div>
            </div>
        </div>
    </section>
</div>
