<?php 
    $holidayId = $brholidayInfo->holidayId; 
    $holidayTitle = $brholidayInfo->holidayTitle;
    $holidayDay = $brholidayInfo->holidayDay;
    $holidayFromdate = $brholidayInfo->holidayFromdate;
    $holidayTodate = $brholidayInfo->holidayTodate; 
    $description = $brholidayInfo->description; 
?>  

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Holiday Management
            <small>Edit Holiday</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Edit Holiday Details</h3>
                    </div>

                    <form role="form" action="<?php echo base_url('brholiday/editBrholiday'); ?>" method="post" id="editBrholiday">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="holidayTitle">Holiday Nam</label>
                                        <input type="text" class="form-control required" value="<?php echo htmlspecialchars($holidayTitle, ENT_QUOTES, 'UTF-8'); ?>" id="holidayTitle" name="holidayTitle" maxlength="256" required />
                                        <input type="hidden" value="<?php echo $holidayId; ?>" name="holidayId" id="holidayId" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="holidayTitle">Holiday Day</label>
                                        <input type="text" class="form-control required" value="<?php echo htmlspecialchars($holidayTitle, ENT_QUOTES, 'UTF-8'); ?>" id="holidayTitle" name="holidayTitle" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="holidayTitle">Holiday Day</label>
                                        <select class="form-control required" id="holidayDay" name="holidayDay" required >
                                           <option value="<?php echo $holidayDay; ?>" <?php echo "selected=selected"; ?>><?php echo $holidayDay; ?></option>
                                            <option value="">Select Day</option>
                                            <option value="Monday">Monday</option>
                                            <option value="Tuesday">Tuesday</option>
                                            <option value="Wednesday">Wednesday</option>
                                            <option value="Thursday">Thursday</option>
                                            <option value="Friday">Friday</option>
                                            <option value="Saturday">Saturday</option>
                                            <option value="Sunday">Sunday</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="holidayTitle">Holiday From Date</label>
                                        <input type="date" class="form-control required" value="<?php echo htmlspecialchars($holidayFromdate, ENT_QUOTES, 'UTF-8'); ?>" id="holidayFromdate" name="holidayFromdate" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="holidayTitle">Holiday To Date</label>
                                        <input type="date" class="form-control required" value="<?php echo htmlspecialchars($holidayTodate, ENT_QUOTES, 'UTF-8'); ?>" id="holidayTodate" name="holidayTodate" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description" rows="5" required><?php echo htmlspecialchars($description, ENT_QUOTES, 'UTF-8'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo base_url('announcement'); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>

                </div>
            </div>

            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $error; ?>
                </div>
                <?php } ?>

                <?php 
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
