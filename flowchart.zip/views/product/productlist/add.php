<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Stock Management
        <small>Add / Edit Stock</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Stock Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addProductlist" action="<?php echo base_url() ?>productlist/addNewProductlist" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
 
    <input type="hidden" class="form-control required" id="productCode" name="productCode" maxlength="256" 
        value="<?php echo isset($nextProductCode) ? $nextProductCode : ''; ?>" readonly />
</div>

                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productName">Product Name</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('productName'); ?>" id="productName" name="productName" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="openingStock">Opening Stock - (01 - April)</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('openingStock'); ?>" id="openingStock" name="openingStock" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="currentStock">Current Stock</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('currentStock'); ?>" id="currentStock" name="currentStock" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Product Description</label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
	   <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('productlist/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>