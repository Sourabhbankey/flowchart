<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Branch Setup & Installation Management
        <small>Add / Edit Staff</small>
      </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Branch Setup & Installation Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>branchinstallation/addNewBranchinstallation" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                        <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                            <option value="0">Select Role</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchSetupName">Branch Name </label>
                                        <input type="text" readonly class="form-control required" id="branchSetupName" name="branchSetupName" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="brcompAddress">Branch Complete Address <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="brcompAddress" name="brcompAddress" readonly></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" id="city" name="city" maxlength="256" readonly>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="state">State <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" id="state" name="state" maxlength="256" readonly>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pincode">Pincode <span class="re-mend-field">*</span></label>
                                        <input required readonly type="text" class="form-control required" value="<?php echo set_value('pincode'); ?>" id="pincode" name="pincode" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="acClearance">Account Clearance </label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="acClearance" tabindex="-1" aria-hidden="true">
                                            <option value="" selected>Select</option>
                                            <option value="<?= ACTIVE ?>" <?= (set_value('acClearance') == ACTIVE) ? 'selected' : ''; ?>>Yes</option>
                                            <option value="<?= INACTIVE ?>" <?= (set_value('acClearance') == INACTIVE) ? 'selected' : ''; ?>>No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="acRemark">Accounts Remark</label>
                                        <textarea class="form-control required" id="acRemark" name="acRemark"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="frcostInvoiceS3File">Upload Franchise Cost Invoice</label>
                                        <input type="file" name="frcostInvoiceS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="frCostInvoicenum">Franchise Cost Invoice No.<span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('frCostInvoicenum'); ?>" id="frCostInvoicenum" name="frCostInvoicenum" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="studkitInvoiceS3File">Upload Student Kit Invoice</label>
                                        <input type="file" name="studkitInvoiceS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="studKitInvoicenum">Student Kit Invoice No.</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('studKitInvoicenum'); ?>" id="studKitInvoicenum" name="studKitInvoicenum" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brsetupInvoiceS3File">Upload Branch Setup Cost Invoice</label>
                                        <input type="file" name="brsetupInvoiceS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brsetupInvoicenum">Branch Setup Cost Invoice No.<span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('brsetupInvoicenum'); ?>" id="brsetupInvoicenum" name="brsetupInvoicenum" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="lgchargInvoiceS3File">Upload Legal Charges Invoice</label>
                                        <input type="file" name="lgchargInvoiceS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="lginvoicenum">Legal Charges Invoice No.</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('lginvoicenum'); ?>" id="lginvoicenum" name="lginvoicenum" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="eBayinstallkitInvoiceS3File">Upload eBay Bill (Installation-Kit)</label>
                                        <input type="file" name="eBayinstallkitInvoiceS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="eBaystudKitInvoiceS3File">Upload eBay Bill (Student Kit)</label>
                                        <input type="file" name="eBaystudKitInvoiceS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="lgClearance">Legal Clearance</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="lgClearance" tabindex="-1" aria-hidden="true">
                                            <option value="" selected>Select</option>
                                            <option value="<?= ACTIVE ?>" <?= (set_value('lgClearance') == ACTIVE) ? 'selected' : ''; ?>>Yes</option>
                                            <option value="<?= INACTIVE ?>" <?= (set_value('lgClearance') == INACTIVE) ? 'selected' : ''; ?>>No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="lgRemark">Legal Remark</label>
                                        <textarea class="form-control required" id="lgRemark" name="lgRemark"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="infraRemark">Infrastructure Remark<span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="infraRemark" name="infraRemark"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="numOfStudKit">No. Of Initial Student KITS <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('numOfStudKit'); ?>" id="numOfStudKit" name="numOfStudKit" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="studKitDesc">Student Kit Description<span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="studKitDesc" name="studKitDesc"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="additionlOffer">Additional Offering<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('additionlOffer'); ?>" id="additionlOffer" name="additionlOffer" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="specialRemark">Special Remark<span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="specialRemark" name="specialRemark"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateOfDespatch">Date Of Despatch </label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('dateOfDespatch'); ?>" id="dateOfDespatch" name="dateOfDespatch" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="modeOfDespatch">Mode Of Despatch </label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('modeOfDespatch'); ?>" id="modeOfDespatch" name="modeOfDespatch" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="materialReceivedOn">Material Received On by Branch</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('materialReceivedOn'); ?>" id="materialReceivedOn" name="materialReceivedOn" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="instaBrstatusDate">Dates Available For Installation (Installation Team)</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('instaBrstatusDate'); ?>" id="instaBrstatusDate" name="instaBrstatusDate" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="prefInstalldate">Preferable Date Of Installation From Branch<span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('prefInstalldate'); ?>" id="prefInstalldate" name="prefInstalldate" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="preInstallAttachment">Upload Pre-Installation Attachment</label>
                                        <input type="file" name="preInstallAttachment" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="preInstallPremises">Pre-Installation Premises</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="preInstallPremises" tabindex="-1" aria-hidden="true">
                                            <option value="" selected>Select</option>
                                            <option value="Yes" <?= (set_value('preInstallPremises') == 'Yes') ? 'selected' : ''; ?>>Yes</option>
                                            <option value="No" <?= (set_value('preInstallPremises') == 'No') ? 'selected' : ''; ?>>No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="schInstalldate">Scheduled Date Of Installation </label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('schInstalldate'); ?>" id="schInstalldate" name="schInstalldate" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installDate">Installation Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('installDate'); ?>" id="installDate" name="installDate" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="instaBrstatus">Installation Status</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="instaBrstatus" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option>
                                            <option value="<?= ACTIVE ?>">Installed</option>
                                            <option value="<?= INACTIVE ?>"> Not Installed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="upDespatchReceiptS3File">Upload Despatch Receipt</label>
                                        <input type="file" name="upDespatchReceiptS3File" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="deliverychallan">Delivery Challan</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('deliverychallan'); ?>" id="deliverychallan" name="deliverychallan" maxlength="256">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
<script>
$(document).ready(function () {
    $('#franchiseNumber').change(function () {
        let franchiseNumber = $(this).val();
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("branchinstallation/getBranchDetails"); ?>',
                type: 'POST',
                data: { franchiseNumber: franchiseNumber },
                dataType: 'json',
                success: function (response) {
                    if (response) {
                        $('#branchSetupName').val(response.branchSetupName);
                        $('#brcompAddress').val(response.brcompAddress);
                        $('#city').val(response.city);
                        $('#state').val(response.state);
                    } else {
                        alert("No data found for the selected franchise.");
                        $('#branchSetupName, #brcompAddress, #city, #state').val('');
                    }
                },
                error: function () {
                    alert("Error fetching branch details.");
                }
            });
        } else {
            $('#branchSetupName, #brcompAddress, #city, #state').val('');
        }
    });
});

function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("branchinstallation/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response);
                  $('#branchFranchiseAssigned option[value="0"]').remove();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
      $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
    }
}

const form = document.getElementById('yourForm');
const submitBtn = document.getElementById('submitBtn');

form.addEventListener('submit', function (e) {
    if (submitBtn.disabled) {
        e.preventDefault();
        return;
    }
    submitBtn.disabled = true;
    submitBtn.innerText = 'Submitting...';
});
</script>