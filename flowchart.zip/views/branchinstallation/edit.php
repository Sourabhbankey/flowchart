<?php
$brsetupid = $branchinstallationInfo->brsetupid;
$branchSetupName = $branchinstallationInfo->branchSetupName;
$brspFranchiseAssigned = $branchinstallationInfo->brspFranchiseAssigned;
$brcompAddress = $branchinstallationInfo->brcompAddress;
$city = $branchinstallationInfo->city;
$state = $branchinstallationInfo->state;
$pincode = $branchinstallationInfo->pincode;
$acClearance = $branchinstallationInfo->acClearance;
$frCostInvoicenum = $branchinstallationInfo->frCostInvoicenum;
$studKitInvoicenum = $branchinstallationInfo->studKitInvoicenum;
$brsetupInvoicenum = $branchinstallationInfo->brsetupInvoicenum;
$lginvoicenum = $branchinstallationInfo->lginvoicenum;
$acRemark = $branchinstallationInfo->acRemark;
$lgClearance = $branchinstallationInfo->lgClearance;
$lgRemark = $branchinstallationInfo->lgRemark;
$infraRemark = $branchinstallationInfo->infraRemark;  
$deliverychallan = $branchinstallationInfo->deliverychallan;  
$numOfStudKit = $branchinstallationInfo->numOfStudKit;
$studKitDesc = $branchinstallationInfo->studKitDesc;
$additionlOffer = $branchinstallationInfo->additionlOffer;
$specialRemark = $branchinstallationInfo->specialRemark;
$dateOfDespatch = $branchinstallationInfo->dateOfDespatch;
$modeOfDespatch = $branchinstallationInfo->modeOfDespatch;
$materialReceivedOn = $branchinstallationInfo->materialReceivedOn;
$schInstalldate = $branchinstallationInfo->schInstalldate;
$installDate = $branchinstallationInfo->installDate;
$instaBrstatus = $branchinstallationInfo->instaBrstatus;
$brAddressInstall = $branchinstallationInfo->brAddressInstall;
$instaBrstatusDate = $branchinstallationInfo->instaBrstatusDate;
$prefInstalldate = $branchinstallationInfo->prefInstalldate;
/*$fathername = $branchinstallationInfo->fathername;*/
$franchiseNumberArray = explode(",",$branchinstallationInfo->franchiseNumber);
$description = $branchinstallationInfo->description;
$frcostInvoiceS3File = $branchinstallationInfo->frcostInvoiceS3File;
$studkitInvoiceS3File = $branchinstallationInfo->studkitInvoiceS3File;
$brsetupInvoiceS3File= $branchinstallationInfo->brsetupInvoiceS3File;
$lgchargInvoiceS3File = $branchinstallationInfo->lgchargInvoiceS3File;
$eBayinstallkitInvoiceS3File = $branchinstallationInfo->eBayinstallkitInvoiceS3File;
$eBaystudKitInvoiceS3File = $branchinstallationInfo->eBaystudKitInvoiceS3File;
$upDespatchReceiptS3File = $branchinstallationInfo->upDespatchReceiptS3File;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Branch Setp & Installation  Management
        <small>Add / Edit Branch Setp & Installation </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Branch Setp & Installation Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>branchinstallation/editBranchinstallation" enctype="multipart/form-data" method="post" id="editBranchinstallation" role="form">
                        <div class="box-body">
                        <div class="row">
                                <!--  -->
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="studentName">Student Name<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php //echo $studentName; ?>" id="studentName" name="studentName" maxlength="256" />
                                        <input type="hidden" value="<?php //echo $enqid; ?>" name="enqid" id="enqid" />
                                    </div>
                                </div> -->
                                <?php 
                                    if($role==16 || $role==17 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                       <select class="form-control required <?php echo $classnameedit; ?>" id="franchiseNumber" disabled data-live-search="true">
    <option value="0">Select Franchise</option>
    <?php
    if (!empty($branchDetail)) {
        foreach ($branchDetail as $bd) {
            $franchiseNumber = $bd->franchiseNumber;
            ?>
            <option value="<?php echo $franchiseNumber; ?>" <?php if (in_array($franchiseNumber, $franchiseNumberArray)) { echo "selected=selected"; } ?>>
                <?php echo $franchiseNumber; ?>
            </option>
            <?php
        }
    }
    ?>
</select>

<!-- ✅ Add this hidden input to ensure the value is submitted -->
<?php
foreach ($franchiseNumberArray as $franNum) {
    echo '<input type="hidden" name="franchiseNumber[]" value="' . $franNum . '">';
}
?>

<input type="hidden" value="<?php echo $brsetupid; ?>" name="brsetupid" id="brsetupid" />

                                       
                                    </div>
                                </div>
                                  <input type="hidden" value="<?php echo $brspFranchiseAssigned; ?>" name="brspFranchiseAssigned" id="brspFranchiseAssigned" />
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="branchSetupName">Branch Name</label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $branchSetupName; ?>" id="branchSetupName" name="branchSetupName" maxlength="256" readonly />
                                        <input type="hidden" value="<?php echo $brsetupid; ?>" name="brsetupid" id="brsetupid" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="brcompAddress">Branch Complete Address </label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="brcompAddress" readonly name="brcompAddress"><?php echo $brcompAddress; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="city">City </label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>"  readonly value="<?php echo $city; ?>" id="city" name="city" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="state">State </label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>" readonly value="<?php echo $state; ?>" id="state" name="state" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="pincode">Pincode </label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>"  readonly value="<?php echo $pincode; ?>" id="pincode" name="pincode" maxlength="256">
                                    </div>   
                                </div>
                            <?php 
                                    if($role==15 || $role==17 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?>    
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="acClearance">Account Clearance <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo $acClearance; ?>" id="acClearance" name="acClearance" maxlength="256"> -->
                                       
                                         <select class="form-control select2-hidden-accessible <?php echo $classnameedit; ?>" 
        data-plugin-selecttwo="" 
        data-width="100%" 
        data-minimum-results-for-search="Infinity" 
        name="lgClearance" 
        tabindex="-1" 
        aria-hidden="true">
        
    <option value="" <?php if(empty($acClearance)) {echo "selected=selected";} ?>>Select</option>
    <option value="<?= ACTIVE ?>" <?php if($acClearance == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
    <option value="<?= INACTIVE ?>" <?php if($acClearance == INACTIVE) {echo "selected=selected";} ?>>No</option>
</select>
                                    </div>   
                                </div>
                               <div class="col-md-6">                                
                            <div class="form-group">
                        <label for="uploadReceipt">Upload Franchise Cost Invoice</label>
                        
                        <!-- Display the uploaded image if it exists -->
                        <?php if (!empty($frcostInvoiceS3File)): ?>
                            <div>
                                <img src="<?php echo $frcostInvoiceS3File; ?>" alt="Uploaded Franchise Cost Invoice" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
                            </div>
                        <?php endif; ?>
                        
                        <!-- Hidden input to retain the existing file URL -->
                        <input type="hidden" name="existing_frcostInvoiceS3File" value="<?php echo $frcostInvoiceS3File; ?>">
                        
                        <!-- File input for uploading a new file -->
                        <input type="file" name="frcostInvoiceS3File">
                    </div>


                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="frCostInvoicenum">Franchise Cost Invoice No.</label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $frCostInvoicenum; ?>" id="frCostInvoicenum" name="frCostInvoicenum" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
          <div class="form-group">
    <label for="uploadReceipt">Upload Student Kit Invoice</label>

    <!-- Check and display the uploaded image(s) if they exist -->
    <?php if (!empty($studkitInvoiceS3File)): ?>
        <div>
            <img src="<?php echo $studkitInvoiceS3File; ?>" alt="Uploaded Student Kit Invoice" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
        </div>
    <?php else: ?>
        <div>
            <p style="color: gray;">No image uploaded. You can add one now.</p>
        </div>
    <?php endif; ?>

    <!-- Hidden input to retain the existing file URL -->
    <input type="hidden" name="existing_studkitInvoiceS3File" value="<?php echo !empty($studkitInvoiceS3File) ? $studkitInvoiceS3File : ''; ?>">

    <!-- File input for uploading a new file -->
    <input class="<?php echo $studkitInvoiceS3File; ?>" type="file" name="studkitInvoiceS3File" multiple>
</div>

 
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="studKitInvoicenum">Student Kit Invoice No.</label>
                                        <input type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $studKitInvoicenum; ?>" id="studKitInvoicenum" name="studKitInvoicenum" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                <label for="uploadReceipt">Upload Branch Setup Cost Invoice</label>
                                
                                <!-- Display the uploaded image if it exists -->
                                <?php if (!empty($brsetupInvoiceS3File)): ?>
                                    
                                        <img src="<?php echo $brsetupInvoiceS3File; ?>" alt="Uploaded Branch Setup Cost Invoice" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
                                  
                                <?php else: ?>
                                    
                                <?php endif; ?>
                                
                                <!-- Hidden input to retain the existing file URL -->
                                <input type="hidden" name="existing_brsetupInvoiceS3File" value="<?php echo !empty($brsetupInvoiceS3File) ? $brsetupInvoiceS3File : ''; ?>">
                                
                                <!-- File input for uploading a new file -->
                                <input class="<?php echo $classnameedit; ?>" type="file" name="brsetupInvoiceS3File" multiple>
                            </div>

                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="brsetupInvoicenum">Branch Setup Cost Invoice No.</label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $brsetupInvoicenum; ?>" id="brsetupInvoicenum" name="brsetupInvoicenum" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
    <label for="uploadReceipt">Upload Legal Charges Invoice</label>
    
    <!-- Display the uploaded image if it exists -->
    <?php if (!empty($lgchargInvoiceS3File)): ?>
        <div>
            <img src="<?php echo $lgchargInvoiceS3File; ?>" alt="Uploaded Legal Charges Invoice" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
        </div>
    <?php else: ?>
        <div>
            <p style="color: gray;">No image uploaded. You can add one now.</p>
        </div>
    <?php endif; ?>
    
    <!-- Hidden input to retain the existing file URL -->
    <input type="hidden" name="existing_lgchargInvoiceS3File" value="<?php echo !empty($lgchargInvoiceS3File) ? $lgchargInvoiceS3File : ''; ?>">
    
    <!-- File input for uploading a new file -->
    <input class="<?php echo $lgchargInvoiceS3File; ?>" type="file" name="lgchargInvoiceS3File" multiple>
</div>

                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="lginvoicenum">Legal Charges Invoice No.</label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $lginvoicenum; ?>" id="lginvoicenum" name="lginvoicenum" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
    <label for="uploadReceipt">Upload eBay Bill (Installation-Kit)</label>
    
    <!-- Display the uploaded image if it exists -->
    <?php if (!empty($eBayinstallkitInvoiceS3File)): ?>
        <div>
            <img src="<?php echo $eBayinstallkitInvoiceS3File; ?>" alt="Uploaded eBay Bill (Installation-Kit)" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
        </div>
    <?php else: ?>
        <div>
            <p style="color: gray;">No image uploaded. You can add one now.</p>
        </div>
    <?php endif; ?>
    
    <!-- Hidden input to retain the existing file URL -->
    <input type="hidden" name="existing_eBayinstallkitInvoiceS3File" value="<?php echo !empty($eBayinstallkitInvoiceS3File) ? $eBayinstallkitInvoiceS3File : ''; ?>">
    
    <!-- File input for uploading a new file -->
    <input class="<?php echo $eBayinstallkitInvoiceS3File; ?>" type="file" name="eBayinstallkitInvoiceS3File" multiple>
</div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
    <label for="uploadReceipt">Upload eBay Bill (Student Kit)</label>
    
    <!-- Display the uploaded image if it exists -->
    <?php if (!empty($eBaystudKitInvoiceS3File)): ?>
        <div>
            <img src="<?php echo $eBaystudKitInvoiceS3File; ?>" alt="Uploaded eBay Bill (Student Kit)" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
        </div>
    <?php else: ?>
        <div>
            <p style="color: gray;">No image uploaded. You can add one now.</p>
        </div>
    <?php endif; ?>
    
    <!-- Hidden input to retain the existing file URL -->
    <input type="hidden" name="existing_eBaystudKitInvoiceS3File" value="<?php echo !empty($eBaystudKitInvoiceS3File) ? $eBaystudKitInvoiceS3File : ''; ?>">
    
    <!-- File input for uploading a new file -->
    <input class="<?php echo $eBaystudKitInvoiceS3File; ?>" type="file" name="eBaystudKitInvoiceS3File" multiple>
</div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="acRemark">Accounts Remark</label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="acRemark" name="acRemark"><?php echo $acRemark; ?></textarea>

                                    </div>   
                                </div>
                                <?php 
                                    if($role==15 || $role==16 || $role==17) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="lgClearance">Legal Clearance <span class="re-mend-field">*</span></label>
                                        
                                     <select class="form-control select2-hidden-accessible <?php echo $classnameedit; ?>" 
        data-plugin-selecttwo="" 
        data-width="100%" 
        data-minimum-results-for-search="Infinity" 
        name="lgClearance" 
        tabindex="-1" 
        aria-hidden="true">
        
    <option value="" <?php if(empty($lgClearance)) {echo "selected=selected";} ?>>Select</option>
    <option value="<?= ACTIVE ?>" <?php if($lgClearance == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
    <option value="<?= INACTIVE ?>" <?php if($lgClearance == INACTIVE) {echo "selected=selected";} ?>>No</option>
</select>

                                    </div>   
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="lgRemark">Legal Remark</label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="lgRemark" name="lgRemark"></textarea>
                                    </div>   
                                </div>
                                <?php 
                                    if($role==16 || $role==17 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="infraRemark">Infrastructure Remark</label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="infraRemark" name="infraRemark"><?php echo $infraRemark; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="numOfStudKit">No. Of Initial Student KITS </label>
                                        <input required type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $numOfStudKit; ?>" id="numOfStudKit" name="numOfStudKit" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="studKitDesc">Student Kit Description</label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="studKitDesc" name="studKitDesc"><?php echo $studKitDesc; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="additionlOffer">Additional Offering</label>
                                        <input  type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $additionlOffer; ?>" id="additionlOffer" name="additionlOffer" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="specialRemark">Special Remark</label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="description" name="description"><?php echo $specialRemark; ?></textarea>
                                    </div>
                                </div>
                                <?php 
                                    if($role==15 || $role==16 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfDespatch">Date Of Despatch <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $dateOfDespatch; ?>" id="dateOfDespatch" name="dateOfDespatch" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="modeOfDespatch">Mode Of Despatch <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $modeOfDespatch; ?>" id="modeOfDespatch" name="modeOfDespatch" maxlength="256">
                                    </div>   
                                </div>
                                <?php 
                                    if($role==16 || $role==17 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="materialReceivedOn">Material Received by Branch On <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $materialReceivedOn; ?>" id="materialReceivedOn" name="materialReceivedOn" maxlength="256">
                                    </div>   
                                </div>
                                <?php 
                                    if($role==15 || $role==16 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="instaBrstatusDate">Dates Available For Installation (Installation Team)<span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $instaBrstatusDate; ?>" id="instaBrstatusDate" name="instaBrstatusDate" maxlength="256">
                                    </div>   
                                </div>
                                <?php 
                                    if($role==16 || $role==17 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prefInstalldate">Preferable Date Of Installation From Branch<span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $prefInstalldate; ?>" id="prefInstalldate" name="prefInstalldate" maxlength="256">
                                    </div>   
                                </div>
                                <?php 
                                    if($role==15 || $role==16 || $role==24) {
                                    $classnameedit = "clsp";
                                    }else{
                                        $classnameedit = "clsp1";
                                    }
                                ?> 
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="schInstalldate">Scheduled Date Of Installation <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $schInstalldate; ?>" id="schInstalldate" name="schInstalldate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="installDate">Installation Date</label>
                                        <input type="date" class="form-control required <?php echo $classnameedit; ?>" value="<?php echo $installDate; ?>" id="installDate" name="installDate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="instaBrstatus">Installation Status<span class="re-mend-field">*</span></label>
                                        <!-- <input required type="date" class="form-control required" value="<?php echo set_value('instaBrstatus'); ?>" id="instaBrstatus" name="instaBrstatus" maxlength="256"> -->
                                        <select class="form-control select2-hidden-accessible <?php echo $classnameedit; ?>" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="instaBrstatus" tabindex="-1" aria-hidden="true">
                                        <option value="<?= ACTIVE ?>" <?php if($instaBrstatus == ACTIVE) {echo "selected=selected";} ?>>Installed</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($instaBrstatus == INACTIVE) {echo "selected=selected";} ?> >Not Installed</option>
                                        </select>
                                    </div>   
                                </div>
                                <!-- <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="brAddressInstall">Branch Address <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description"><?php //echo $brAddressInstall; ?></textarea>
                                    </div>
                                </div> -->
                                <div class="col-md-6">                                
                                    <!-- Upload Despatch Receipt -->
<div class="form-group">
    <label for="uploadReceipt">Upload Despatch Receipt</label>
    
    <!-- Display the uploaded image if it exists -->
    <?php if (!empty($upDespatchReceiptS3File)): ?>
        <div>
            <img src="<?php echo $upDespatchReceiptS3File; ?>" alt="Uploaded Despatch Receipt" style="max-width: 100px; max-height: 100px; display: block; margin-bottom: 10px;">
        </div>
    <?php else: ?>
        <div>
            <p style="color: gray;">No image uploaded. You can add one now.</p>
        </div>
    <?php endif; ?>
    
    <!-- Hidden input to retain the existing file URL -->
    <input type="hidden" name="existing_upDespatchReceiptS3File" value="<?php echo !empty($upDespatchReceiptS3File) ? $upDespatchReceiptS3File : ''; ?>">
    
    <!-- File input for uploading a new file -->
    <input class="<?php echo $upDespatchReceiptS3File; ?>" type="file" name="upDespatchReceiptS3File" multiple>
</div>

                                    
                                </div>
                                   <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="deliverychallan">Delivery Challan</label>
                                        <input  type="text" class="form-control required" value="<?php echo $deliverychallan; ?>" id="deliverychallan" name="deliverychallan" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required <?php echo $classnameedit; ?>" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .clsp{pointer-events:none;}
    </style>
</div>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("branchinstallation/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
        $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
    }
}

const form = document.getElementById('yourForm');
const submitBtn = document.getElementById('submitBtn');

form.addEventListener('submit', function (e) {
    if (submitBtn.disabled) {
        e.preventDefault();
        return;
    }
    submitBtn.disabled = true;
    submitBtn.innerText = 'Submitting...';
});
</script>