<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Coupons 
        <small>Add / Edit Coupons</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Coupons Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addFaq" action="<?php echo base_url() ?>coupons/addNewCoupons" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">                                
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                                    <option value="">Select Franchise</option>
                                                                     <?php
                                                                    if (!empty($branchDetail)) {
                                                                        foreach ($branchDetail as $bd) {
                                                                      $franchiseNumber = $bd->franchiseNumber;
                                                                    ?>
                                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                              <?php
                                                                  }
                                                               }
                                                            ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                            <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                                <option value="0">Select Role</option>
                                            </select>
                                        </div>
                                    </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('couponsTitle'); ?>" id="couponsTitle" name="couponsTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                                    <div class="col-md-4">                                
                                       <div class="form-group">
                                            <label for="prodListdespatch">CouponsType </label>
                                              <select class="form-control required" name="couponsType" id="couponsType">
                                                 <option value="Percentage discount">Percentage discount</option>
                                                 <option value="Fixed product discount">Fixed product discount</option>
                                                 <option value="Fixed cart discount">Fixed Cart Discount</option>
                                            </select>
                                        </div>
                                    </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Code <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('couponsCode'); ?>" id="couponsCode" name="couponsCode" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Amount <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('couponsAmount'); ?>" id="couponsAmount" name="couponsAmount" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Uses <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('couponsUses'); ?>" id="couponsUses" name="couponsUses" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Limit <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('couponsLimit'); ?>" id="couponsUses" name="couponsLimit" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Expiry Date <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('couponsEdate'); ?>" id="couponsEdate" name="couponsEdate" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Coupons Assigned By <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('couponsAssignedby'); ?>" id="couponsAssignedby" name="couponsAssignedby" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description"> Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            /*filebrowserUploadUrl: "<?= base_url('training/upload'); ?>",*/
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber !== "") {
        $.ajax({
            url: "<?php echo base_url('credentials/fetchAssignedUsers'); ?>",
            type: "POST",
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $("#branchFranchiseAssigned").html(response);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: " + status + " - " + error);
            }
        });
    } else {
        $("#branchFranchiseAssigned").html('<option value="0">Select Role</option>');
    }
}
</script>