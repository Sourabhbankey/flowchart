<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Coupons Record Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                 <?php  if($is_admin == 1 || $role==14) { ?>
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>coupons/add"><i class="fa fa-plus"></i> Add New  Record</a>
                </div> 
            <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 text-left">
                <?php  if($is_admin == 1 || $role==14) { ?>
                <div class="form-group">
                    <label for="resultrecordlist">Search By Franchise</label>
                    <form method="GET" action="<?= base_url('coupons/couponsListing'); ?>">
    <label for="franchiseNumber">Franchise No. <span class="re-mend-field">*</span></label>
    <select id="franchiseNumber" name="franchiseNumber" data-live-search="true" >
        <option value="">Select Franchise</option>
        <?php
        if (!empty($branchDetail)) {
            foreach ($branchDetail as $bd) {
                $selected = ($bd->franchiseNumber == $franchiseFilter) ? 'selected' : '';
                ?>
                <option value="<?= $bd->franchiseNumber; ?>" <?= $selected; ?>><?= $bd->franchiseNumber; ?></option>
                <?php
            }
        }
        ?>
    </select>
    <button type="submit" class="btn btn-primary customreset-fil">Filter</button>
    <a href="<?= base_url('coupons/couponsListing'); ?>" class="btn btn-danger btn-secondary">Reset</a>
</form>


                    </div>
                <?php } ?>
            </div>
        </div> 
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Coupons List</h3>

                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                  <table id="example" class="display responsive nowrap table table-hover">
                    <thead>
                    <tr>
                        <th>Sr. No.</th>
                        <?php  if($is_admin == 1 || $role==14) { ?>
                        <th>Franchise Number</th>
                        <th>Franchise Assigned To</th>
                          <th>Coupons Uses</th>
                        <th>Coupons Limit</th>
                        <th>Coupons Assigned By</th>
                        <th>Coupons Type</th>
                        <?php } ?>
                        <th>Coupons Title</th>
                        
                        <th>Coupons Code</th>
                        <th>Coupons Amount</th>
                      
                        <th>Coupons Expiry Date</th>
                        
                        <th>Description</th>
                        <?php  if($is_admin == 1 || $role==14) { ?>
                        <th class="text-center">Actions</th>
<?php } ?>
                        
                    </tr>
                    </thead>
                 <tbody>
                   <?php
                   $serial = $offset + 1;
                    if(!empty($records))
                    {
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                         <td><?php echo $serial++; ?></td>
                         <?php  if($is_admin == 1 || $role==14) { ?>
                        <td><?php echo $record->franchiseNumber  ?></td>
                        <td><?php echo $record->brspFranchiseAssigned ?></td>

                        <td><?php echo $record->couponsUses ?></td>
                        <td><?php echo $record->couponsLimit ?></td>
                        <td><?php echo $record->couponsAssignedby ?></td>
                         <td><?php echo $record->couponsType ?></td>
                        <?php } ?>
                           <td><?php echo $record->couponsTitle ?></td>
                       
                         <td class="discodecls"><?php echo $record->couponsCode ?></td>
                     
                       
                        <td><?php echo $record->couponsAmount ?></td>
                        
                        <td><?php echo $record->couponsEdate ?></td>
                       
                        <td><?php echo $record->description ?></td>
                        <?php  if($is_admin == 1 || $role==14) { ?>
                        <td class="text-center">
                              
                                    <a class="btn btn-sm btn-info" href="<?php echo base_url().'coupons/edit/'.$record->coupnsId; ?>" title="Edit">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    <a class="btn btn-sm btn-danger deleteStock" href="#" data-salesrecId="<?php echo $record->coupnsId; ?>" title="Delete">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <!-- <a class="btn btn-sm btn-info"  href="<?php echo base_url().'coupons/view/'.$record->credId; ?>" title="Edit">
                                        <i class="fa fa-eye"></i>
                                    </a> -->
                              
                        </td>
                    <?php } ?>


                   
                    </tr>
                   <?php
                        }
                    }
                    ?>
                  </tbody>


                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <div class="br-pagi">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>

<style type="text/css">
tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
.discodecls {
    background: #9102abd1;
    color: #fff;
    font-size: 2rem;
    font-weight: 800;
    text-align: center;
    background: linear-gradient(to bottom, #9102ab 0%, #ff99cc 100%);
}
</style>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

