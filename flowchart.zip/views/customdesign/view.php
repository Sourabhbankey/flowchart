<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-image" aria-hidden="true"></i> View Custom Design
            <small>Preview of the selected custom design</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <?php
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Custom Design: <?php echo isset($customdesignInfo->designTitle) ? htmlspecialchars($customdesignInfo->designTitle) : 'N/A'; ?></h3>
                        <div class="box-tools pull-right">
                            <a href="<?php echo base_url('customdesign/customdesignListing'); ?>" class="btn btn-primary">
                                <i class="fa fa-arrow-left"></i> Back to List
                            </a>
                        </div>
                    </div>
                    <div class="box-body">
                        <?php if (!empty($customdesignInfo->attachmentS3File)) { ?>
                            <?php
                            $file_paths = explode(',', $customdesignInfo->attachmentS3File);
                            if (count($file_paths) > 0) {
                                echo '<div class="row">';
                                foreach ($file_paths as $index => $file_path) {
                                    if (!empty($file_path)) {
                                        $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
                                       $isImage = in_array($extension, ['png', 'jpg', 'jpeg', 'cdr']);
                                        $isVideo = in_array($extension, ['mp4', 'mpeg', 'mov']);
                                        // Get file name without extension
                                        $file_name = pathinfo($file_path, PATHINFO_FILENAME);
                            ?>
                                        <div class="col-md-4 col-sm-6 col-xs-12">
                                            <div class="card-wrapper text-center">
                                                <div class="card-title h5 mb-2"><?php echo isset($customdesignInfo->designTitle) ? htmlspecialchars($customdesignInfo->designTitle) : 'Custom Design'; ?> <?php echo $index + 1; ?></div>
                                                <div class="card position-relative" id="card_<?php echo $customdesignInfo->customdesignId . '_' . $index; ?>">
                                                    <?php if ($isImage) { ?>
                                                        <img src="<?php echo htmlspecialchars($file_path); ?>"
                                                             alt="<?php echo isset($customdesignInfo->designTitle) ? htmlspecialchars($customdesignInfo->designTitle) : 'Custom Design'; ?> Image <?php echo $index + 1; ?>"
                                                             class="img-responsive" crossorigin="anonymous">
                                                    <?php } elseif ($isVideo) { ?>
                                                        <video controls class="video-responsive" crossorigin="anonymous">
                                                            <source src="<?php echo htmlspecialchars($file_path); ?>" type="video/<?php echo $extension; ?>">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php } else { ?>
                                                        <p>Unsupported file type: <?php echo htmlspecialchars($extension); ?></p>
                                                    <?php } ?>
                                                </div>
                                                <button class="btn btn-primary mt-2 save-btn" id="save_btn_<?php echo $customdesignInfo->customdesignId . '_' . $index; ?>"
                                                        onclick="downloadMedia('<?php echo $customdesignInfo->customdesignId . '_' . $index; ?>', this, '<?php echo htmlspecialchars($file_path); ?>', '<?php echo $isImage ? 'image' : ($isVideo ? 'video' : 'file'); ?>', '<?php echo htmlspecialchars($file_name); ?>')">
                                                    <i class="fa fa-download"></i> Download <?php echo $isImage ? 'Image' : ($isVideo ? 'Video' : 'File'); ?> <?php echo $index + 1; ?>
                                                </button>
                                            </div>
                                        </div>
                            <?php
                                    }
                                }
                                echo '</div>';
                            } else {
                            ?>
                                <p>No files available for this custom design.</p>
                            <?php
                            }
                            ?>
                        <?php } else { ?>
                            <p>No files available for this custom design.</p>
                        <?php } ?>
                    </div>
                    <div class="box-footer text-center">
                        <a href="<?php echo base_url('customdesign/customdesignListing'); ?>" class="btn btn-default">
                            <i class="fa fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style type="text/css">
    .img-responsive, .video-responsive {
        display: block;
        max-width: 100%;
        height: 400px;
        width: auto;
        border-radius: 5px;
        margin: 0 auto;
        object-fit: cover;
    }

    .box {
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .box-header {
        background-color: #f8f9fa;
        padding: 15px;
    }

    .box-body {
        padding: 20px;
    }


    .card {
        border: 1px solid #ddd;
        border-radius: 8px;
        margin-bottom: 7px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        position: relative;
        width: 325px;
        height: 450px;
        overflow: hidden;
    }

    .card-wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }

    .card-title {
        font-size: 1.1em;
        font-weight: bold;
        margin-bottom: 10px;
    }

    

    

   

</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('img').on('error', function() {
            jQuery(this).hide();
            jQuery(this).parent().append('<p class="text-danger">Unable to load image. Please check the URL or try again later.</p>');
        });

        jQuery('video').on('error', function() {
            jQuery(this).hide();
            jQuery(this).parent().append('<p class="text-danger">Unable to load video. Please check the URL or try again later.</p>');
        });
    });

    function downloadMedia(id, button, fileUrl, mediaType, fileName) {
        $(button).prop('disabled', true).addClass('download-btn').text(`Downloading ${mediaType.charAt(0).toUpperCase() + mediaType.slice(1)}...`);

        if (mediaType === 'image') {
            const img = document.querySelector(`#card_${id} img`);
            if (!img) {
                console.error(`No image found in card_${id}.`);
                alert('Error: Image not found.');
                $(button).prop('disabled', false).removeClass('download-btn').text(`Download Image ${id.split('_')[1]}`);
                return;
            }
            if (!img.complete || img.naturalWidth === 0) {
                console.error(`Image in card_${id} not loaded. Attempting to reload.`);
                img.crossOrigin = 'Anonymous';
                img.src = img.src + (img.src.includes('?') ? '&' : '?') + 't=' + new Date().getTime();
                img.onload = () => {
                    renderImage(id, button, fileName);
                };
                img.onerror = () => {
                    console.error(`Failed to load image in card_${id}. Check S3 URL or CORS.`);
                    alert('Error: Failed to load image. Please try again.');
                    $(button).prop('disabled', false).removeClass('download-btn').text(`Download Image ${id.split('_')[1]}`);
                };
                return;
            }
            renderImage(id, button, fileName);
        } else if (mediaType === 'video') {
            const video = document.querySelector(`#card_${id} video source`);
            if (!video || !video.src) {
                console.error(`No video source found in card_${id}.`);
                alert('Error: Video source not found.');
                $(button).prop('disabled', false).removeClass('download-btn').text(`Download Video ${id.split('_')[1]}`);
                return;
            }
            fetch(video.src, {
                method: 'GET',
                mode: 'cors',
                headers: {
                    'Accept': video.type || 'video/mp4'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.blob();
            })
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `${fileName}.${fileUrl.split('.').pop()}`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url);
            })
            .catch(error => {
                console.error(`Failed to download video for card_${id}:`, error);
                alert('Error: Failed to download video. Please check the video URL or try again later.');
            })
            .finally(() => {
                $(button).prop('disabled', false).removeClass('download-btn').text(`Download Video ${id.split('_')[1]}`);
            });
        } else {
            console.error(`Unsupported media type: ${mediaType}`);
            alert('Error: Unsupported file type.');
            $(button).prop('disabled', false).removeClass('download-btn').text(`Download File ${id.split('_')[1]}`);
        }
    }

    function renderImage(id, button, fileName) {
        const img = document.querySelector(`#card_${id} img`);
        html2canvas(img, {
            scale: 2,
            useCORS: true,
            logging: true,
            backgroundColor: null // Ensure transparent background
        }).then(canvas => {
            const link = document.createElement('a');
            link.href = canvas.toDataURL('image/png');
            link.download = `${fileName}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            $(button).prop('disabled', false).removeClass('download-btn').text(`Download Image ${id.split('_')[1]}`);
        }).catch(error => {
            console.error('Error rendering image:', error);
            alert('Error: Failed to download image. Please try again.');
            $(button).prop('disabled', false).removeClass('download-btn').text(`Download Image ${id.split('_')[1]}`);
        });
    }
</script>