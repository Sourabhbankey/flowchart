<?php
$customdesignId = $customdesignInfo->customdesignId;
$designTitle = $customdesignInfo->designTitle;
$franchiseNumberArray = explode(",",$customdesignInfo->franchiseNumber);
$attachmentType = $customdesignInfo->attachmentType;
$requirementSpe = $customdesignInfo->requirementSpe;
$submissionDate = $customdesignInfo->submissionDate;
$description = $customdesignInfo->description;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Custom Design On Demand
        <small>Add / Edit Custom Designs</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Custom Design On Demand / Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>customdesign/editCustomdesign" enctype="multipart/form-data" method="post" id="editCustomdesign" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="taskTitle" >Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true"  disabled="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;

                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>" <?php if(in_array($franchiseNumber,$franchiseNumberArray)){echo "selected=selected";} ?>><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-8">                                
                                    <div class="form-group">
                                        <label for="designTitle">Design Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required clsp" value="<?php echo $designTitle; ?>" id="designTitle" name="designTitle" maxlength="256"  readonly/>
                                        <input type="hidden" value="<?php echo $customdesignId; ?>" name="customdesignId" id="customdesignId" />
                                    </div> 
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Attachment Type <span class="re-mend-field">*</span></label>
                                        <select class="form-control required clsp" id="selectUserId" name="attachmentType" readonly>
                                            <option value="<?php echo $attachmentType; ?>" <?php echo "selected=selected"; ?>><?php echo $attachmentType; ?></option>
                                            <option value="Image">Image</option>
                                            <option value="Video">Video</option>     
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="requirementSpe">Requirement</label>
                                        <textarea class="form-control required clsp" id="requirementSpe" name="requirementSpe" readonly><?php echo $requirementSpe; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File <span class="re-mend-field">*</span></label>
                                        <input required type="file" name="file" multiple>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="submissionDate">Submission Date <span class="re-mend-field">*</span></label>
                                        <input required="" type="date" class="form-control required" value="<?php echo $submissionDate; ?>" id="submissionDate" name="submissionDate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .clsp {
            pointer-events: none;
        }
    </style>
</div>