<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>  
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
        }
        .content-wrapper {
            padding: 20px;
        }
        .content-header h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .content-header h1 i {
            margin-right: 10px;
        }
        .content-header small {
            font-size: 14px;
            color: #777;
        }
        .box-primary {
            border-top: 3px solid #3c8dbc;
            background: #fff;
            box-shadow: 0 1px 1px rgba(0,0,0,0.1);
        }
        .box-header {
            padding: 10px 15px;
            border-bottom: 1px solid #f4f4f4;
        }
        .box-header h3 {
            font-size: 18px;
            margin: 0;
            line-height: 1;
        }
        .box-body {
            padding: 15px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        @media print {
            .no-print {
                display: none;
            }
            .content-wrapper {
                padding: 0;
            }
            .box-primary {
                border: none;
                box-shadow: none;
            }
            .box-header {
                border-bottom: none;
            }
        }
    </style>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <i class="fa fa-money"></i> Daycare Fee Template Management
                <small>Print Template</small>
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-8">
                    <div class="box box-primary">
                        <div class="box-header">
                            <h3 class="box-title">Daycare Fee Template Details</h3>
                            <div class="box-tools no-print">
                                <button onclick="window.print()" class="btn btn-success btn-sm">
                                    <i class="fa fa-print"></i> Print
                                </button>
                                <a href="<?php echo base_url('daycarefeetemplate/viewDaycareFeeTemplate/' . $feeTemplateInfo->dcfeetempId); ?>" class="btn btn-default btn-sm">
                                    <i class="fa fa-arrow-left"></i> Back to View
                                </a>
                            </div>
                        </div>
                        <div class="box-body">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Fee Type</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1 Hour Fee</td>
                                        <td><?php echo number_format($feeTemplateInfo->stayupto1Hoursmonthlyfee, 2); ?></td>
                                    </tr>
                                    <tr>
                                        <td>4 Hours Fee</td>
                                        <td><?php echo number_format($feeTemplateInfo->stayupto4Hoursmonthlyfee, 2); ?></td>
                                    </tr>
                                    <tr>
                                        <td>6 Hours Fee</td>
                                        <td><?php echo number_format($feeTemplateInfo->stayupto6Hoursmonthlyfee, 2); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        // Auto-trigger print dialog on page load
        window.onload = function() {
            window.print();
        };
    </script>
