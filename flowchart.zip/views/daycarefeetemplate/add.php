<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Daycare Fee Template Management
            <small><?php echo isset($feeTemplateInfo) ? 'Edit' : 'Add'; ?> Template</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Daycare Fee Template Details</h3>
                        <div class="pull-right">
            <a href="<?php echo base_url() ?>daycarefeetemplate/daycarefeetemplatelisting" class="btn btn-info">Back to Listing</a>
        </div>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form id="feeTemplateForm" action="<?php echo base_url() . (isset($feeTemplateInfo) ? 'daycarefeetemplate/updateDaycareFeeTemplate' : 'daycarefeetemplate/addDaycareFeeTemplate'); ?>" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <?php if (isset($feeTemplateInfo)) { ?>
                                    <input type="hidden" name="dcfeetempId" value="<?php echo $feeTemplateInfo->dcfeetempId; ?>">
                                <?php } ?>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="required">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchFranchiseData(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                foreach ($franchises as $franchise) {
                                                    $selected = ($franchise->franchiseNumber == (isset($feeTemplateInfo) ? $feeTemplateInfo->franchiseNumber : $defaultFranchise)) ? 'selected' : '';
                                                ?>
                                                    <option value="<?php echo htmlspecialchars($franchise->franchiseNumber); ?>" <?php echo $selected; ?>>
                                                        <?php echo htmlspecialchars($franchise->franchiseNumber); ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedName">Assigned Growth Manager <span class="required">*</span></label>
                                        <?php if (in_array($role, [14, 1, 16, 24, 13])) { ?>
                                            <input type="text" class="form-control" id="branchFranchiseAssignedName" name="branchFranchiseAssignedName" value="<?php echo htmlspecialchars($this->session->userdata('name')); ?>" readonly required>
                                            <input type="hidden" id="branchFranchiseAssigned" name="branchFranchiseAssigned" value="<?php echo $this->session->userdata('userId'); ?>">
                                        <?php } else { ?>
                                            <input type="text" class="form-control" id="branchFranchiseAssignedName" name="branchFranchiseAssignedName" value="<?php echo isset($feeTemplateInfo) && $feeTemplateInfo->branchFranchiseAssigned ? htmlspecialchars($this->dft->getUserNameById($feeTemplateInfo->branchFranchiseAssigned)) : ''; ?>" readonly required aria-describedby="branchFranchiseAssignedLoading">
                                            <input type="hidden" id="branchFranchiseAssigned" name="branchFranchiseAssigned" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->branchFranchiseAssigned : ''; ?>">
                                            <span id="branchFranchiseAssignedLoading" class="help-block" style="display: none;">Loading...</span>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brAddress">Branch Address <span class="required" aria-label="required">*</span></label>
                                        <input type="text" class="form-control" id="brAddress" name="brAddress" value="<?php echo isset($feeTemplateInfo) ? htmlspecialchars($feeTemplateInfo->brAddress) : ''; ?>" maxlength="255" required aria-describedby="brAddressLoading" readonly>
                                        <span id="brAddressLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchContacNum">Contact Number <span class="required" aria-label="required">*</span></label>
                                        <input type="text" class="form-control" id="branchContacNum" name="branchContacNum" value="<?php echo isset($feeTemplateInfo) ? htmlspecialchars($feeTemplateInfo->branchContacNum) : ''; ?>" maxlength="255" required aria-describedby="branchContacNumLoading" readonly>
                                        <span id="branchContacNumLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="ageGroupEarlyYears">Age Group-(2-6 Years)</label>
                                        <input type="text" step="0.01" class="form-control" id="ageGroupEarlyYears" name="ageGroupEarlyYears" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->ageGroupEarlyYears : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="earlyYearsDays_operation">Days of operation</label>
                                        <input type="text" step="0.01" class="form-control" id="earlyYearsDays_operation" name="earlyYearsDays_operation" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->earlyYearsDays_operation : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="earlyYearsHourse">Hours of  operation</label>
                                        <input type="text" step="0.01" class="form-control" id="earlyYearsHourse" name="earlyYearsHourse" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->earlyYearsHourse : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="earlyYearsFeeMonthly">Fees Monthly basis</label>
                                        <input type="number" step="0.01" class="form-control" id="earlyYearsFeeMonthly" name="earlyYearsFeeMonthly" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->earlyYearsFeeMonthly : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="earlyYearsFeeHourly">Fees Hourly basis</label>
                                        <input type="number" step="0.01" class="form-control" id="earlyYearsFeeHourly" name="earlyYearsFeeHourly" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->earlyYearsFeeHourly : ''; ?>" min="0">
                                    </div>
                                </div>
                                <!-- Start Junior -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="ageGroupJuniors">Age Group - (7-14 Years)</label>
                                        <input type="text" step="0.01" class="form-control" id="ageGroupJuniors" name="ageGroupJuniors" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->ageGroupJuniors : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="juniorsDays_operation">Juniors Days of operation</label>
                                        <input type="text" step="0.01" class="form-control" id="juniorsDays_operation" name="juniorsDays_operation" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->juniorsDays_operation : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="juniorsHourse">Juniors Hours of  operation</label>
                                        <input type="text" step="0.01" class="form-control" id="juniorsHourse" name="juniorsHourse" value="<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->juniorsHourse : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="juniorsFeeMonthly">Juniors Fees Monthly basis</label>
                                        <input type="text" class="form-control" id="juniorsFeeMonthly" name="juniorsFeeMonthly" value="<?php echo set_value('juniorsFeeHourly'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="juniorsFeeHourly">Juniors Fees Hourly basis</label>
                                        <input type="text" class="form-control" id="juniorsFeeHourly" name="juniorsFeeHourly" value="<?php echo set_value('juniorsFeeHourly'); ?>">
                                    </div>
                                </div>
                                <!-- End Junior Section-->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description"><?php echo isset($feeTemplateInfo) ? htmlspecialchars($feeTemplateInfo->description) : ''; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" id="submitBtn" class="btn btn-primary">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-4">
                <?php if ($error = $this->session->flashdata('error')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php if ($success = $this->session->flashdata('success')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '</div>'); ?>
            </div>
        </div>
    </section>

    <style>
        .required {
            color: red;
        }
    </style>
</div>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    $(document).ready(function() {
        // Initialize CKEditor for description
        CKEDITOR.replace('description');

        // Initialize Select2 for franchiseNumber (only for role != 25)
        $('#franchiseNumber').select2({
            placeholder: "Select Franchise",
            allowClear: true,
            width: '100%'
        });

        // Fetch franchise data on page load if franchiseNumber is set
        const franchiseInput = $('#franchiseNumber');
        if (franchiseInput.val()) {
            fetchFranchiseData(franchiseInput.val());
        }

        // Fetch franchise data on franchiseNumber change
        $('#franchiseNumber').on('change', function() {
            fetchFranchiseData(this.value);
        });

        // Form submission handling
        $('#feeTemplateForm').on('submit', function(e) {
            let submitBtn = $('#submitBtn');
            let branchFranchiseAssigned = $('#branchFranchiseAssigned').val();

            // Validate Growth Manager for all users
            if (!branchFranchiseAssigned) {
                e.preventDefault();
                alert('No Growth Manager assigned for this franchise. Please ensure a Growth Manager is assigned.');
                submitBtn.prop('disabled', false).text('Submit');
                return false;
            }

            if (submitBtn.prop('disabled')) {
                e.preventDefault();
                return;
            }
            submitBtn.prop('disabled', true).text('Submitting...');
        });
    });

    function fetchFranchiseData(franchiseNumber) {
        const assignedNameInput = $('#branchFranchiseAssignedName');
        const assignedIdInput = $('#branchFranchiseAssigned');
        const brAddressInput = $('#brAddress');
        const branchContacNumInput = $('#branchContacNum');
        const assignedLoading = $('#branchFranchiseAssignedLoading');
        const brAddressLoading = $('#brAddressLoading');
        const branchContacNumLoading = $('#branchContacNumLoading');

        assignedNameInput.prop('disabled', true);
        assignedLoading.show();
        brAddressLoading.show();
        branchContacNumLoading.show();

        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("daycarefeetemplate/fetchFranchiseData"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    selectedUserId: '<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->branchFranchiseAssigned : ''; ?>',
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.userIds) {
                        let userIds = response.userIds.split(',');
                        let userNames = response.html.split(', ');
                        let selectedUserId = '<?php echo isset($feeTemplateInfo) ? $feeTemplateInfo->branchFranchiseAssigned : ''; ?>';

                        // Assume the first Growth Manager for simplicity (or use selectedUserId if editing)
                        let assignedUserId = selectedUserId || userIds[0];
                        let assignedUserName = userNames[userIds.indexOf(assignedUserId)] || userNames[0];

                        assignedNameInput.val(assignedUserName || '');
                        assignedIdInput.val(assignedUserId || '');
                    } else {
                        assignedNameInput.val('');
                        assignedIdInput.val('');
                        if (response.message) {
                            alert(response.message);
                        }
                    }

                    assignedNameInput.prop('disabled', false);

                    if (response.status === 'success' && response.franchiseData) {
                        brAddressInput.val(response.franchiseData.brAddress || '');
                        branchContacNumInput.val(response.franchiseData.branchContacNum || '');
                    } else {
                        brAddressInput.val('');
                        branchContacNumInput.val('');
                        if (response.franchiseMessage) {
                            alert(response.franchiseMessage);
                        }
                    }

                    assignedLoading.hide();
                    brAddressLoading.hide();
                    branchContacNumLoading.hide();
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    assignedNameInput.val('Failed to load Growth Manager').prop('disabled', false);
                    assignedIdInput.val('');
                    brAddressInput.val('');
                    branchContacNumInput.val('');
                    assignedLoading.hide();
                    brAddressLoading.hide();
                    branchContacNumLoading.hide();
                    alert('Failed to fetch franchise data. Please try again or contact support.');
                }
            });
        } else {
            assignedNameInput.val('').prop('disabled', false);
            assignedIdInput.val('');
            brAddressInput.val('');
            branchContacNumInput.val('');
            assignedLoading.hide();
            brAddressLoading.hide();
            branchContacNumLoading.hide();
        }
    }
</script>