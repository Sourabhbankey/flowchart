<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-edit"></i> Daycare Fee Template Management
            <small>Edit Template</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit Daycare Fee Template</h3>
                        <div class="box-tools">
                            <a href="<?php echo base_url('daycarefeetemplate/daycarefeetemplatelisting'); ?>" class="btn btn-default btn-sm">
                                <i class="fa fa-arrow-left"></i> Back to Listing
                            </a>
                        </div>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form id="feeTemplateForm" action="<?php echo base_url('daycarefeetemplate/updateDaycareFeeTemplate'); ?>" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <input type="hidden" name="dcfeetempId" value="<?php echo isset($feeTemplateInfo->dcfeetempId) ? htmlspecialchars($feeTemplateInfo->dcfeetempId) : ''; ?>">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="required">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <select class="form-control select2" id="franchiseNumber" name="franchiseNumber" required onchange="fetchFranchiseData(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                foreach ($franchises as $franchise) {
                                                    $selected = ($franchise->franchiseNumber == ($feeTemplateInfo->franchiseNumber ?? $defaultFranchise)) ? 'selected' : '';
                                                ?>
                                                    <option value="<?php echo htmlspecialchars($franchise->franchiseNumber); ?>" <?php echo $selected; ?>>
                                                        <?php echo htmlspecialchars($franchise->franchiseNumber); ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedName">Assigned Growth Manager <span class="required">*</span></label>
                                        <input type="text" class="form-control" id="branchFranchiseAssignedName" name="branchFranchiseAssignedName" value="<?php echo isset($feeTemplateInfo) && $feeTemplateInfo->branchFranchiseAssigned ? htmlspecialchars($this->dft->getUserNameById($feeTemplateInfo->branchFranchiseAssigned)) : ''; ?>" readonly required aria-describedby="branchFranchiseAssignedLoading">
                                        <input type="hidden" id="branchFranchiseAssigned" name="branchFranchiseAssigned" value="<?php echo isset($feeTemplateInfo) ? htmlspecialchars($feeTemplateInfo->branchFranchiseAssigned) : ''; ?>">
                                        <span id="branchFranchiseAssignedLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="brAddress">Branch Address <span class="required">*</span></label>
                                        <input type="text" class="form-control" id="brAddress" name="brAddress" value="<?php echo isset($feeTemplateInfo->brAddress) ? htmlspecialchars($feeTemplateInfo->brAddress) : ''; ?>" maxlength="255" readonly required aria-describedby="brAddressLoading">
                                        <span id="brAddressLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchContacNum">Contact Number <span class="required">*</span></label>
                                        <input type="text" class="form-control" id="branchContacNum" name="branchContacNum" value="<?php echo isset($feeTemplateInfo->branchContacNum) ? htmlspecialchars($feeTemplateInfo->branchContacNum) : ''; ?>" maxlength="255" required aria-describedby="branchContacNumLoading" readonly>
                                        <span id="branchContacNumLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ageGroupEarlyYears">Age Group-(2-6 Years)</label>
                                        <input type="number" step="0.01" class="form-control" id="ageGroupEarlyYears" name="ageGroupEarlyYears" value="<?php echo isset($feeTemplateInfo->ageGroupEarlyYears) ? htmlspecialchars($feeTemplateInfo->ageGroupEarlyYears) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="earlyYearsDays_operation">Days of operation</label>
                                        <input type="number" step="0.01" class="form-control" id="earlyYearsDays_operation" name="earlyYearsDays_operation" value="<?php echo isset($feeTemplateInfo->earlyYearsDays_operation) ? htmlspecialchars($feeTemplateInfo->earlyYearsDays_operation) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="earlyYearsHourse">Hours of  operation</label>
                                        <input type="number" step="0.01" class="form-control" id="earlyYearsHourse" name="earlyYearsHourse" value="<?php echo isset($feeTemplateInfo->earlyYearsHourse) ? htmlspecialchars($feeTemplateInfo->earlyYearsHourse) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="earlyYearsFeeMonthly">Fees Monthly basis</label>
                                        <input type="number" step="0.01" class="form-control" id="earlyYearsFeeMonthly" name="earlyYearsFeeMonthly" value="<?php echo isset($feeTemplateInfo->earlyYearsFeeMonthly) ? htmlspecialchars($feeTemplateInfo->earlyYearsFeeMonthly) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="earlyYearsFeeHourly">Fees Hourly basis</label>
                                        <input type="number" step="0.01" class="form-control" id="earlyYearsFeeHourly" name="earlyYearsFeeHourly" value="<?php echo isset($feeTemplateInfo->earlyYearsFeeHourly) ? htmlspecialchars($feeTemplateInfo->earlyYearsFeeHourly) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <!-- Start Junior-sec -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ageGroupJuniors">Age Group - (7-14 Years)</label>
                                        <input type="number" step="0.01" class="form-control" id="ageGroupJuniors" name="ageGroupJuniors" value="<?php echo isset($feeTemplateInfo->ageGroupJuniors) ? htmlspecialchars($feeTemplateInfo->ageGroupJuniors) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="juniorsDays_operation">Juniors Days of operation</label>
                                        <input type="number" step="0.01" class="form-control" id="juniorsDays_operation" name="juniorsDays_operation" value="<?php echo isset($feeTemplateInfo->juniorsDays_operation) ? htmlspecialchars($feeTemplateInfo->juniorsDays_operation) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="juniorsHourse">Juniors Hours of  operation</label>
                                        <input type="number" step="0.01" class="form-control" id="juniorsHourse" name="juniorsHourse" value="<?php echo isset($feeTemplateInfo->juniorsHourse) ? htmlspecialchars($feeTemplateInfo->juniorsHourse) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="juniorsFeeMonthly">Juniors Fees Monthly basis</label>
                                        <input type="number" step="0.01" class="form-control" id="juniorsFeeMonthly" name="juniorsFeeMonthly" value="<?php echo isset($feeTemplateInfo->juniorsFeeMonthly) ? htmlspecialchars($feeTemplateInfo->juniorsFeeMonthly) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="juniorsFeeHourly">Juniors Fees Hourly basis</label>
                                        <input type="number" step="0.01" class="form-control" id="juniorsFeeHourly" name="juniorsFeeHourly" value="<?php echo isset($feeTemplateInfo->juniorsFeeHourly) ? htmlspecialchars($feeTemplateInfo->juniorsFeeHourly) : ''; ?>" min="0">
                                    </div>
                                </div>
                                <!-- End-Start Junior-sec -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description"><?php echo isset($feeTemplateInfo->description) ? htmlspecialchars($feeTemplateInfo->description) : ''; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" id="submitBtn" class="btn btn-info">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                            <a href="<?php echo base_url('daycarefeetemplate/daycarefeetemplatelisting'); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php if ($error = $this->session->flashdata('error')) { ?>
                    <div class="alert alert-danger alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php if ($success = $this->session->flashdata('success')) { ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '</div>'); ?>
            </div>
        </div>
    </section>
</div>

<style>
    .box-info {
        border-top-color: #3c8dbc;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .required {
        color: #d73925;
    }
</style>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
$(document).ready(function() {
    // Initialize Select2 for franchiseNumber (only for role != 25)
    $('#franchiseNumber').select2({
        placeholder: "Select Franchise",
        allowClear: true,
        width: '100%'
    });

    // Initialize CKEditor
    CKEDITOR.replace('description');

    // Fetch franchise data on page load if franchiseNumber is set
    const franchiseInput = $('#franchiseNumber');
    if (franchiseInput.val()) {
        fetchFranchiseData(franchiseInput.val());
    }

    // Fetch franchise data on franchiseNumber change
    $('#franchiseNumber').on('change', function() {
        fetchFranchiseData(this.value);
    });

    // Form submission handling
    $('#feeTemplateForm').on('submit', function(e) {
        let submitBtn = $('#submitBtn');
        let branchFranchiseAssigned = $('#branchFranchiseAssigned').val();

        // Validate Growth Manager for all users
        if (!branchFranchiseAssigned) {
            e.preventDefault();
            alert('No Growth Manager assigned for this franchise. Please ensure a Growth Manager is assigned.');
            submitBtn.prop('disabled', false).text('Submit');
            return false;
        }

        if (submitBtn.prop('disabled')) {
            e.preventDefault();
            return;
        }
        submitBtn.prop('disabled', true).text('Submitting...');
    });
});

function fetchFranchiseData(franchiseNumber) {
    const assignedNameInput = $('#branchFranchiseAssignedName');
    const assignedIdInput = $('#branchFranchiseAssigned');
    const brAddressInput = $('#brAddress');
    const branchContacNumInput = $('#branchContacNum');
    const assignedLoading = $('#branchFranchiseAssignedLoading');
    const brAddressLoading = $('#brAddressLoading');
    const branchContacNumLoading = $('#branchContacNumLoading');

    assignedNameInput.prop('disabled', true);
    assignedLoading.show();
    brAddressLoading.show();
    branchContacNumLoading.show();

    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("daycarefeetemplate/fetchFranchiseData"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                selectedUserId: '<?php echo isset($feeTemplateInfo) ? htmlspecialchars($feeTemplateInfo->branchFranchiseAssigned) : ''; ?>',
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success' && response.userIds) {
                    let userIds = response.userIds.split(',');
                    let userNames = response.html.split(', ');
                    let selectedUserId = '<?php echo isset($feeTemplateInfo) ? htmlspecialchars($feeTemplateInfo->branchFranchiseAssigned) : ''; ?>';

                    // Use selectedUserId for editing, or first user for adding
                    let assignedUserId = selectedUserId || userIds[0];
                    let assignedUserName = userNames[userIds.indexOf(assignedUserId)] || userNames[0];

                    assignedNameInput.val(assignedUserName || '');
                    assignedIdInput.val(assignedUserId || '');
                } else {
                    assignedNameInput.val('');
                    assignedIdInput.val('');
                    if (response.message) {
                        alert(response.message);
                    }
                }

                assignedNameInput.prop('disabled', false);

                if (response.status === 'success' && response.franchiseData) {
                    brAddressInput.val(response.franchiseData.brAddress || '');
                    branchContacNumInput.val(response.franchiseData.branchContacNum || '');
                } else {
                    brAddressInput.val('');
                    branchContacNumInput.val('');
                    if (response.franchiseMessage) {
                        alert(response.franchiseMessage);
                    }
                }

                assignedLoading.hide();
                brAddressLoading.hide();
                branchContacNumLoading.hide();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                assignedNameInput.val('Failed to load Growth Manager').prop('disabled', false);
                assignedIdInput.val('');
                brAddressInput.val('');
                branchContacNumInput.val('');
                assignedLoading.hide();
                brAddressLoading.hide();
                branchContacNumLoading.hide();
                alert('Failed to fetch franchise data. Please try again or contact support.');
            }
        });
    } else {
        assignedNameInput.val('').prop('disabled', false);
        assignedIdInput.val('');
        brAddressInput.val('');
        branchContacNumInput.val('');
        assignedLoading.hide();
        brAddressLoading.hide();
        branchContacNumLoading.hide();
    }
}
</script>