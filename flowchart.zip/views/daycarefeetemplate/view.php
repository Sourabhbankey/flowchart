<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1 style="text-align: left;">
            <i class="fa fa-money"></i> Daycare Fee Template Management
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Daycare Fee Template Details</h3>
                        <div class="box-tools">
                            <!-- <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">
                                <i class="fa fa-print"></i> Print
                            </button> -->
                            <button type="button" class="btn btn-success btn-sm" onclick="downloadPDF()">
                              <i class="fa fa-file-pdf-o"></i> Download PDF
                            </button>

                            <a href="<?php echo base_url('daycarefeetemplate/daycarefeetemplatelisting'); ?>" class="btn btn-default btn-sm">
                                <i class="fa fa-arrow-left"></i> Back to Listing
                            </a>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="container">
                            <div class="row dcfee">
                            <!-- New-Code -->
                                  <div style="text-align: center; padding: 0px 0 0 0; position: relative;">
                                  <div style="position: absolute;top: 104px;left: 0px;right: 0;text-align: center;color: white;">
                                    <h1 style="margin: 0; font-size: 36px; font-weight: 800;">Day Care Fee Structure</h1>
                                    <h2 style="margin: 5px 0 0 0; font-size: 24px; color: black; font-weight: 700;">Session – 2025-26</h2>
                                    <h3 style="margin-top: 20px; color: #956760;">One Time Registration Charges</h3>
                                  </div>

                                  <img
                                    src="<?php echo base_url('uploads/fee/daycarebanner.jpeg'); ?>" alt="eduMETA Creche" style="height: 300px;"
                                    width="100%" />
                                </div>
                                    <div class="feeinfosec" style="background-color: #ffd8a8;padding-top: 20px;">
                                    <table>
                                      <thead>
                                        <tr>
                                          <th>Age Group</th>
                                          <th>Days of operation</th>
                                          <th>Hours of  operation</th>
                                          <th>Fees Monthly</th>
                                          <th>Fees Hourly basis</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <!-- <td><?php //echo is_numeric($feeTemplateInfo->ageGroupEarlyYears) ? number_format((float)$feeTemplateInfo->ageGroupEarlyYears, 2) : 'N/A'; ?></td> -->
                                          <td><?php echo !empty($feeTemplateInfo->ageGroupEarlyYears) ? $feeTemplateInfo->ageGroupEarlyYears : 'N/A'; ?></td>
                                          <td><?php echo is_numeric($feeTemplateInfo->earlyYearsDays_operation) ? number_format((float)$feeTemplateInfo->earlyYearsDays_operation, 2) : 'N/A'; ?></td>
                                          <td><?php echo is_numeric($feeTemplateInfo->earlyYearsHourse) ? number_format((float)$feeTemplateInfo->earlyYearsHourse, 2) : 'N/A'; ?></td>
                                          <td><?php echo is_numeric($feeTemplateInfo->earlyYearsFeeMonthly) ? number_format((float)$feeTemplateInfo->earlyYearsFeeMonthly, 2) : 'N/A'; ?></td>
                                          <td><?php echo is_numeric($feeTemplateInfo->earlyYearsFeeHourly) ? number_format((float)$feeTemplateInfo->earlyYearsFeeHourly, 2) : 'N/A'; ?></td>
                                        </tr>
                                        <tr style="height: 32px;">
                                            <td><?php echo !empty($feeTemplateInfo->ageGroupJuniors) ? $feeTemplateInfo->ageGroupJuniors : ''; ?></td>
                                            <td><?php echo !empty($feeTemplateInfo->juniorsDays_operation) ? $feeTemplateInfo->juniorsDays_operation : ''; ?></td>
                                            <td><?php echo !empty($feeTemplateInfo->juniorsHourse) ? $feeTemplateInfo->juniorsHourse : ''; ?></td>
                                            <td><?php echo !empty($feeTemplateInfo->juniorsFeeMonthly) ? $feeTemplateInfo->juniorsFeeMonthly : ''; ?></td>
                                            <td><?php echo !empty($feeTemplateInfo->juniorsFeeHourly) ? $feeTemplateInfo->juniorsFeeHourly : ''; ?></td>
                                          </tr>

                                        <!-- <tr>
                                          <td>Upto 6 Hours</td>
                                          <td><?php //echo is_numeric($feeTemplateInfo->stayupto6Hoursmonthlyfee) ? number_format((float)$feeTemplateInfo->stayupto6Hoursmonthlyfee, 2) : 'N/A'; ?></td>
                                        </tr> -->
                                      </tbody>
                                    </table>
                                    <div class="mainfac row">
                                      <div class="facilities col-12 col-md-8" style="margin-bottom: -30px; margin-left: 25px;">
                                        <?php //echo !empty($feeTemplateInfo->description) ? nl2br(htmlspecialchars($feeTemplateInfo->description)) : 'N/A'; ?>
                                        <h2 style="text-align: left;font-weight: 700;text-transform: uppercase;color: #8b0c02;margin: 5px 0 6px;">Facilities</h2>
                                        <ul>
                                            <li>Live Application for parents</li>
                                            <li>Indoor Play / Activity Space &amp; Materials</li>
                                            <li>Outdoor Play / Activity Space &amp; Materials</li>
                                            <li>Activity Classes</li>
                                            <li>Academic Support</li>
                                            <li>RO Water</li>
                                            <li>Trained &amp; Caring staff</li>
                                            <li>Hygienic Atmosphere</li>
                                            <li>Milk &amp; Atta Cookies as refreshments</li>
                                            <li>CCTV Camera</li>
                                        </ul>
                                          <div class="addonpoints"><?php 
                                          echo !empty($feeTemplateInfo->description) 
                                               ? $feeTemplateInfo->description 
                                               : 'N/A'; 
                                          ?>
                                        </div>
                                      </div>
                                      <!-- <div class="prism col-12 col-md-4 text-center">
                                        <img src="<?php //echo base_url('uploads/fee/prismo.png'); ?>" alt="Prismo" style="width: 100%; max-width: 250px;" />
                                      </div> -->
                                    </div>
                                    <div class="row sign-sec">
                                        <div class="col-md-6 admsign">Signature of Admin</div>
                                        <div class="col-md-6 psign"> Signature of Parents</div>
                                    </div>

                                </div>    
                                <div class="footer" style="background-color: #fff4e6; padding: 20px; text-align: center;color: #333;">
                                  <p style="margin: 5px 0;"><strong>School Address : <?php echo !empty($feeTemplateInfo->brAddress) ? htmlspecialchars($feeTemplateInfo->brAddress) : 'N/A'; ?></strong></p>
                                  <p style="margin: 5px 0;"><strong>Contact : <?php echo !empty($feeTemplateInfo->branchContacNum) ? htmlspecialchars($feeTemplateInfo->branchContacNum) : 'N/A'; ?></strong></p>
                                                            <!-- End-New-code -->
                                </div>
                            </div>
                    </div>
                    <style>
    body {
      margin: 0;
      color: #333;
      
    }
    .container {
      width: auto;
    }
    h1 {
      margin: 0;
      padding-top: 20px;
      font-size: 2.5em;
      color: #5f2f24;
      text-align: center;
    }
    h2 {
      margin: 5px 0 30px;
      font-size: 1.8em;
      text-align: center;
    }
    .registration {
      margin: 0 auto 30px;
      padding: 15px;
      width: 80%;
      text-align: center;
      font-weight: bold;
      color: #5f2f24;
    }
    table {
      width: 75%;
      border-collapse: collapse;
      background-color: #fff;
      margin-bottom: 30px;
      margin-left: auto;
      margin-right: auto;
      font-weight: 700;
    }
    th, td {
      border: 1px solid #333;
      padding: 6px;
      text-align: center;
    }
    th {
      /* background-color: #ffe5b4; */
      font-weight: bold;
    }
    .facilities {
      margin-bottom: 40px;
      padding-bottom: 30px;
    }
    .facilities h3 {
      font-size: 1.5em;
      margin-bottom: 10px;
      text-decoration: underline;
      color: #5f2f24;
    }
    .facilities ul {
      list-style-type: disc;
      padding-left: 20px;
      margin-bottom: 0px;
      column-count: 2;
    }
    .facilities ul ul {
      list-style-type: circle;
      margin-top: 5px;
    }
    .facilities li {
      margin-bottom: 0px;
    }
    .mainfac{
      display: flex;
    }
    .feeinfosec{
        background-color: #ffd8a8;
        padding-top: 20px;
    }
    .row{
        margin-right: 0;
    margin-left: 0;
    }
    .mainfac {
  display: flex;
  gap: 20px;
}

.facilities {
  flex: 2;
}
.addonpoints {
    margin-bottom: 20px;
}
.prism {
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;
}
.sign-sec{padding-bottom: 60px;}
.admsign{font-weight: 700;padding-left: 58px;}
.psign{font-weight: 700;}
  </style>

                </div>
            </div>
            <div class="col-md-4">
                <?php if ($error = $this->session->flashdata('error')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php if ($success = $this->session->flashdata('success')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
</div>
<script>
  function printContent() {
    alert("To remove the page URL from the printout, please uncheck 'Headers and Footers' in the print dialog.");
    
    var printContents = document.querySelector('.content').innerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    location.reload(); // optional
  }
</script>

<style type="text/css">
    @media print {
  header, footer, .main-header, .main-footer {
    display: none !important;
  }

  /* Also hide navigation or page tools if needed */
  .box-tools, .btn, .alert, .col-md-4 {
    display: none !important;
  }
  .box-header {
    display: none !important;
  }
  /*New-code*/
  /* Hide unnecessary UI elements */
  .box-header, .box-tools, .btn, .alert, .col-md-4, header, footer, .main-header, .main-footer {
    display: none !important;
  }

  /* Prevent browser headers/footers – user must uncheck manually */
  body {
    margin: 0;
    padding: 0;
  }

  /* Hide links containing view page URL if needed */
  a[href*="daycarefeetemplate/viewdaycarefeetemplate"] {
    display: none !important;
  }
  /*End-new-code*/
  a, a:after {
    content: none !important;
    text-decoration: none !important;
  }
  .box.box-primary{border: none !important;}
  .feeinfosec {
    border: 3px solid #ffd8a8 !important;
    padding: 20px !important;
    background-color: transparent !important;
  }
}
.dcfee {
  width: 100%;
  margin: 0;
  padding: 0;
}
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script type="text/javascript">
    function downloadPDF() {
  const element = document.querySelector('.dcfee');
  html2pdf().from(element).set({
    margin: 0.5,
    filename: 'DayCare-Fee-Template.pdf',
    html2canvas: {
      scale: 2,
      useCORS: true
    },
    jsPDF: {
      unit: 'in',
      format: 'letter',
      orientation: 'portrait'
    }
  }).save();
}
</script>