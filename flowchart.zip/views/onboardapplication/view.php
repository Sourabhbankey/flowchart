<?php
$frAppFormId = $onboardapplicationInfo->frAppFormId;
$full_name = $onboardapplicationInfo->full_name;
$email = $onboardapplicationInfo->email;
$dob = $onboardapplicationInfo->dob;
$comm_address = $onboardapplicationInfo->comm_address;
$city = $onboardapplicationInfo->city;
$state = $onboardapplicationInfo->state;
$pincode = $onboardapplicationInfo->pincode;
$gender = $onboardapplicationInfo->gender;
$alternate_contact_no = $onboardapplicationInfo->alternate_contact_no;
$contact_person_number = $onboardapplicationInfo->contact_person_number;
$branch_location = $onboardapplicationInfo->branch_location;
$branch_area = $onboardapplicationInfo->branch_area;
$current_school_name = $onboardapplicationInfo->current_school_name;
$year_founded = $onboardapplicationInfo->year_founded;
$current_school_address = $onboardapplicationInfo->current_school_address;
$current_strength = $onboardapplicationInfo->current_strength;
$total_experience = $onboardapplicationInfo->total_experience;
$purpose_opening = $onboardapplicationInfo->purpose_opening;
$skills_experience = $onboardapplicationInfo->skills_experience;
$current_occupation = $onboardapplicationInfo->current_occupation;
$vision_with_edumeta = $onboardapplicationInfo->vision_with_edumeta;
$heard_about_edumeta = $onboardapplicationInfo->heard_about_edumeta;
$additional_info = $onboardapplicationInfo->additional_info;
$franchise_owner = $onboardapplicationInfo->franchise_owner;
$org_type = $onboardapplicationInfo->org_type;
$franchise_applicant = $onboardapplicationInfo->franchise_applicant;
$gstin = $onboardapplicationInfo->gstin;
$father_name = $onboardapplicationInfo->father_name;
$permanent_address = $onboardapplicationInfo->permanent_address;
$father_contact_no = $onboardapplicationInfo->father_contact_no;
$branch_full_address = $onboardapplicationInfo->branch_full_address;
$spouse_name = $onboardapplicationInfo->spouse_name;
$spouse_contact_no = $onboardapplicationInfo->spouse_contact_no;
$comm_current_address = $onboardapplicationInfo->comm_current_address;
$map_location = $onboardapplicationInfo->map_location;
$payment_mode = $onboardapplicationInfo->payment_mode;
$amount = $onboardapplicationInfo->amount;
$reference_id = $onboardapplicationInfo->reference_id;
$payment_remark = $onboardapplicationInfo->payment_remark;
$payment_date = $onboardapplicationInfo->payment_date;
$pan_card_photo_path = $onboardapplicationInfo->pan_card_photo_path;
$aadhar_front_photo_path = $onboardapplicationInfo->aadhar_front_photo_path;
$aadhar_back_photo_path = $onboardapplicationInfo->aadhar_back_photo_path;
$passport_photo_path = $onboardapplicationInfo->passport_photo_path;
$payment_screenshot_path = $onboardapplicationInfo->payment_screenshot_path;
$proposed_setup_date = $onboardapplicationInfo->proposed_setup_date;
$advertising_plan = $onboardapplicationInfo->advertising_plan;
$proposed_inauguration_date = $onboardapplicationInfo->proposed_inauguration_date;
$declaname = $onboardapplicationInfo->declaname;
$sodo = $onboardapplicationInfo->sodo;
$decsodoname = $onboardapplicationInfo->decsodoname;
$clientname = $onboardapplicationInfo->clientname;
$nominated = $onboardapplicationInfo->nominated;
$nomibranch = $onboardapplicationInfo->nomibranch;
$nomidist = $onboardapplicationInfo->nomidist;
$nomistate = $onboardapplicationInfo->nomistate;
$created_at = $onboardapplicationInfo->created_at;
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Management
            <small>Add / Edit </small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Application Details</h3>
                    </div>
                    <form role="form" action="<?php echo base_url() ?>onboardapplication/editOnboardapplication" method="post" id="editOnboardapplication" enctype="multipart/form-data">
                        <div class="box-body">
                            <!-- Start of Table for Form Fields -->
                            <table class="table table-bordered">
                                <tbody>
                                    <?php
                                    $fields = [
                                        'frAppFormId' => 'Form ID', 'full_name' => 'Full Name', 'email' => 'Email', 'dob' => 'Date of Birth', 'comm_address' => 'Comm Address', 'city' => 'City', 'state' => 'State', 'pincode' => 'Pincode',
                                        'gender' => 'Gender', 'alternate_contact_no' => 'Alternate Contact No', 'contact_person_number' => 'Contact Person Number', 'branch_location' => 'Branch Location', 'branch_area' => 'Branch Area',
                                        'current_school_name' => 'Current School Name', 'year_founded' => 'Year Founded', 'current_school_address' => 'Current School Address', 'current_strength' => 'Current Strength', 'total_experience' => 'Total Experience',
                                        'purpose_opening' => 'Purpose of Opening', 'skills_experience' => 'Skills/Experience', 'current_occupation' => 'Current Occupation', 'vision_with_edumeta' => 'Vision with EduMeta', 'heard_about_edumeta' => 'Heard About EduMeta',
                                        'additional_info' => 'Additional Information', 'franchise_owner' => 'Franchise Owner', 'org_type' => 'Org Type', 'franchise_applicant' => 'Franchise Applicant', 'gstin' => 'GSTIN', 'father_name' => 'Father Name',
                                        'permanent_address' => 'Permanent Address', 'father_contact_no' => 'Father Contact No', 'branch_full_address' => 'Branch Full Address', 'spouse_name' => 'Spouse Name', 'spouse_contact_no' => 'Spouse Contact No',
                                        'comm_current_address' => 'Comm Current Address', 'map_location' => 'Map Location', 'payment_mode' => 'Payment Mode', 'amount' => 'Amount', 'reference_id' => 'Reference ID', 'payment_remark' => 'Payment Remark',
                                        'payment_date' => 'Payment Date', 'proposed_setup_date' => 'Proposed Setup Date', 'advertising_plan' => 'Advertising Plan', 'proposed_inauguration_date' => 'Proposed Inauguration Date', 'declaname' => 'Declaname',
                                        'sodo' => 'Sodo', 'decsodoname' => 'Decsodoname', 'clientname' => 'Clientname', 'nominated' => 'Nominated', 'nomibranch' => 'Nomibranch', 'nomidist' => 'Nomidist', 'nomistate' => 'Nomistate', 'created_at' => 'Created At'
                                    ];

                                    foreach ($fields as $field => $label) {
                                        $value = $onboardapplicationInfo->$field ?? '';
                                        if ($field === 'frAppFormId') {
                                            echo '<input type="hidden" name="' . $field . '" value="' . htmlspecialchars($value) . '" />';
                                            continue;
                                        }
                                        ?>
                                        <tr>
                                            <td><strong><?= $label ?></strong></td>
                                            <td><?= htmlspecialchars($value) ?></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <!-- End of Table for Form Fields -->

                            <!-- File Fields (Images and PDFs) -->
                            <table class="table table-bordered">
                                <tbody>
                                    <?php
                                    $fileFields = [
                                        'pan_card_photo_path' => 'PAN Card',
                                        'aadhar_front_photo_path' => 'Aadhaar Front',
                                        'aadhar_back_photo_path' => 'Aadhaar Back',
                                        'passport_photo_path' => 'Passport Photo',
                                        'payment_screenshot_path' => 'Payment Screenshot'
                                    ];

                                    foreach ($fileFields as $field => $label) {
                                        $path = $onboardapplicationInfo->$field ?? '';
                                        if (!empty($path)) {
                                            $fileSrc = (strpos($path, 'http') === 0) ? $path : base_url($path);
                                            $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
                                            ?>
                                            <tr>
                                                <td><strong><?= $label ?></strong></td>
                                                <td>
                                                    <?php if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) { ?>
                                                        <img src="<?= $fileSrc ?>" alt="<?= $label ?>" style="max-width: 100%; height: auto; border: 1px solid #ccc; padding: 4px;">
                                                    <?php } elseif ($extension === 'pdf') { ?>
                                                        <a href="<?= $fileSrc ?>" target="_blank" class="btn btn-primary btn-sm">View <?= $label ?> (PDF)</a>
                                                    <?php } else { ?>
                                                        <span>Unsupported file type: <?= $extension ?></span>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <button type="button" class="btn btn-info" onclick="printForm()">Print</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>

</script>

<script>
    function printForm() {
var formContent = document.querySelector('.box').innerHTML;
var printWindow = window.open('', '', 'height=800,width=1000');

// Write the content to the print window
printWindow.document.write('<html><head>');

// Set the title to "Onboarding"
printWindow.document.write('<title>Onboarding</title>'); 

// Add necessary styles to center the logo and ensure the logo appears on each printed page
printWindow.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">');
printWindow.document.write('<style>');
printWindow.document.write('body { padding: 20px; }');
printWindow.document.write('img { max-width: 100px; margin: 0 auto; display: block; }'); // Center align the logo
printWindow.document.write('table { width: 100%; border-collapse: collapse; }');
printWindow.document.write('td, th { border: 1px solid #ccc; padding: 8px; text-align: left; }');
printWindow.document.write('th { background-color: #f9f9f9; }');
printWindow.document.write('@page { margin-top: 100px; }'); // Space from the top of the page for logo
printWindow.document.write('.page { page-break-before: always; }'); // Add page breaks if content is long
printWindow.document.write('</style>');

// Add logo at the top of each page (centered)
printWindow.document.write('<div style="text-align: center; margin-bottom: 20px;">');
printWindow.document.write('<img src="https://theischool.com/blog/wp-content/uploads/2022/05/logo-1.png" alt="Logo" style="max-width: 100px;">');
printWindow.document.write('</div>');

// Write the form content below the logo
printWindow.document.write('</head><body>');
printWindow.document.write(formContent);
printWindow.document.write('</body></html>');

printWindow.document.close(); // Close the document to finish writing
printWindow.focus(); // Focus on the print window

// Print after a short delay
setTimeout(() => {
    printWindow.print(); // Trigger the print dialog
    printWindow.close(); // Close the print window after printing
}, 500);
}

</script>
</div>