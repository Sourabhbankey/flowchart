<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Onboardapplication Record Management
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">

            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">

                    <form action="<?php echo base_url() ?>onboardapplication/onboardapplicationListing" method="GET" id="searchUser">

                        <div class="row">
                            <div class="col-md-12">
                                <?php
                                $this->load->helper('form');
                                $error = $this->session->flashdata('error');
                                if ($error) {
                                ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <?php echo $this->session->flashdata('error'); ?>
                                    </div>
                                <?php } ?>
                                <?php
                                $success = $this->session->flashdata('success');
                                if ($success) {
                                ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <?php echo $this->session->flashdata('success'); ?>
                                    </div>
                                <?php } ?>

                                <div class="row">
                                    <div class="col-md-12">
                                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="box">
                                    <div class="box-header">
                                        <h3 class="box-title"> Record List</h3>
                                        <div class="box-tools">
                                            <!--  <form action="<?php echo base_url() ?>followup/followupListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form> -->
                                        </div>
                                    </div><!-- /.box-header -->
                                    <div class="box-body table-responsive no-padding1">
                                        <table id="example" class="display responsive nowrap" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No.</th>
                                                    <th>Franchise</th>
                                                    <th>Full Name</th>
                                                    <th>Email</th>
                                                    <th>Date of Birth</th>
                                                    <th>Communication Address</th>
                                                    <th>City</th>
                                                    <th>State</th>
                                                    <th>Pincode</th>
                                                    <th>Gender</th>
                                                    <th>Alternate Contact No</th>
                                                    <th>Contact Person Number</th>
                                                    <th>Branch Location</th>
                                                    <th>Branch Area</th>
                                                    <th>Current School Name</th>
                                                    <th>Year Founded</th>
                                                    <th>Current School Address</th>
                                                    <th>Current Strength</th>
                                                    <th>Total Experience</th>
                                                    <th>Purpose of Opening</th>
                                                    <th>Skills & Experience</th>
                                                    <th>Current Occupation</th>
                                                    <th>Vision with Edumeta</th>
                                                    <th>Heard About Edumeta</th>
                                                    <th>Additional Info</th>
                                                    <th>Franchise Owner</th>
                                                    <th>Organization Type</th>
                                                    <th>Franchise Applicant</th>
                                                    <th>GSTIN</th>
                                                    <th>GST Type</th>
                                                    <th>Father Name</th>
                                                    <th>Permanent Address</th>
                                                    <th>Father Contact No</th>
                                                    <th>Branch Full Address</th>
                                                    <th>Spouse Name</th>
                                                    <th>Spouse Contact No</th>
                                                    <th>Communication Current Address</th>
                                                    <th>Map Location</th>
                                                    <th>Payment Mode</th>
                                                    <th>Amount</th>
                                                    <th>Reference ID</th>
                                                    <th>Payment Remark</th>
                                                    <th>Payment Date</th>
                                                    <th>Pan Card Photo</th>
                                                    <th>Aadhar Front Photo</th>
                                                    <th>Aadhar Back Photo</th>
                                                    <th>Passport Photo</th>
                                                    <th>Payment Screenshot</th>
                                                    <th>Proposed Setup Date</th>
                                                    <th>Advertising Plan</th>
                                                    <th>Proposed Inauguration Date</th>
                                                    <th>Declaration Name</th>
                                                    <th>SODO</th>
                                                    <th>Declaration SODO Name</th>
                                                    <th>Client Name</th>
                                                    <th>Nominated</th>
                                                    <th>Nominated Branch</th>
                                                    <th>Nominated District</th>
                                                    <th>Nominated State</th>
                                                    <th>Created At</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
    <?php if (!empty($records)) {
        $sr_no = 1;
        foreach ($records as $record) { ?>
            <tr>
                <td><?php echo $sr_no++; ?></td>
                <td><?php echo $record->franchiseNumber; ?></td>
                <td><?php echo $record->full_name; ?></td>
                <td><?php echo $record->email; ?></td>
                <td><?php echo $record->dob; ?></td>
                <td><?php echo $record->comm_address; ?></td>
                <td><?php echo $record->city; ?></td>
                <td><?php echo $record->state; ?></td>
                <td><?php echo $record->pincode; ?></td>
                <td><?php echo $record->gender; ?></td>
                <td><?php echo $record->alternate_contact_no; ?></td>
                <td><?php echo $record->contact_person_number; ?></td>
                <td><?php echo $record->branch_location; ?></td>
                <td><?php echo $record->branch_area; ?></td>
                <td><?php echo $record->current_school_name; ?></td>
                <td><?php echo $record->year_founded; ?></td>
                <td><?php echo $record->current_school_address; ?></td>
                <td><?php echo $record->current_strength; ?></td>
                <td><?php echo $record->total_experience; ?></td>
                <td><?php echo $record->purpose_opening; ?></td>
                <td><?php echo $record->skills_experience; ?></td>
                <td><?php echo $record->current_occupation; ?></td>
                <td><?php echo $record->vision_with_edumeta; ?></td>
                <td><?php echo $record->heard_about_edumeta; ?></td>
                <td><?php echo $record->additional_info; ?></td>
                <td><?php echo $record->franchise_owner; ?></td>
                <td><?php echo $record->org_type; ?></td>
                <td><?php echo $record->franchise_applicant; ?></td>
                <td><?php echo $record->gstin; ?></td>
                <td><?php echo $record->gsttype; ?></td>
                <td><?php echo $record->father_name; ?></td>
                <td><?php echo $record->permanent_address; ?></td>
                <td><?php echo $record->father_contact_no; ?></td>
                <td><?php echo $record->branch_full_address; ?></td>
                <td><?php echo $record->spouse_name; ?></td>
                <td><?php echo $record->spouse_contact_no; ?></td>
                <td><?php echo $record->comm_current_address; ?></td>
                <td><?php echo $record->map_location; ?></td>
                <td><?php echo $record->payment_mode; ?></td>
                <td><?php echo $record->amount; ?></td>
                <td><?php echo $record->reference_id; ?></td>
                <td><?php echo $record->payment_remark; ?></td>
                <td><?php echo $record->payment_date; ?></td>
                <!-- Dynamic File Columns -->
                <td>
                    <?php
                    $pan_card_path = strpos($record->pan_card_photo_path, 'http') === 0
                        ? $record->pan_card_photo_path
                        : base_url($record->pan_card_photo_path);
                    ?>
                    <?php if ($record->pan_card_photo_path && strtolower(pathinfo($pan_card_path, PATHINFO_EXTENSION)) == 'pdf') { ?>
                        <a href="<?php echo $pan_card_path; ?>" class="btn btn-primary btn-sm view-pdf" data-pdf-url="<?php echo $pan_card_path; ?>" target="_blank">
                            <img src="<?php echo base_url('assets/images/pdf_icon.png'); ?>" width="50" title="View PDF" loading="lazy">
                        </a>
                    <?php } elseif ($record->pan_card_photo_path) { ?>
                        <img src="<?php echo $pan_card_path; ?>" width="50" title="View Image" loading="lazy">
                    <?php } else { ?>
                        <span>No file</span>
                    <?php } ?>
                </td>
                <td>
                    <?php
                    $aadhar_front_path = strpos($record->aadhar_front_photo_path, 'http') === 0
                        ? $record->aadhar_front_photo_path
                        : base_url($record->aadhar_front_photo_path);
                    ?>
                    <?php if ($record->aadhar_front_photo_path && strtolower(pathinfo($aadhar_front_path, PATHINFO_EXTENSION)) == 'pdf') { ?>
                        <a href="<?php echo $aadhar_front_path; ?>" class="view-pdf" data-pdf-url="<?php echo $aadhar_front_path; ?>" target="_blank">
                            <img src="<?php echo base_url('assets/images/pdf_icon.png'); ?>" width="50" title="View PDF" loading="lazy">
                        </a>
                    <?php } elseif ($record->aadhar_front_photo_path) { ?>
                        <img src="<?php echo $aadhar_front_path; ?>" width="50" title="View Image" loading="lazy">
                    <?php } else { ?>
                        <span>No file</span>
                    <?php } ?>
                </td>
                <td>
                    <?php
                    $aadhar_back_path = strpos($record->aadhar_back_photo_path, 'http') === 0
                        ? $record->aadhar_back_photo_path
                        : base_url($record->aadhar_back_photo_path);
                    ?>
                    <?php if ($record->aadhar_back_photo_path && strtolower(pathinfo($aadhar_back_path, PATHINFO_EXTENSION)) == 'pdf') { ?>
                        <a href="<?php echo $aadhar_back_path; ?>" class="view-pdf" data-pdf-url="<?php echo $aadhar_back_path; ?>" target="_blank">
                            <img src="<?php echo base_url('assets/images/pdf_icon.png'); ?>" width="50" title="View PDF" loading="lazy">
                        </a>
                    <?php } elseif ($record->aadhar_back_photo_path) { ?>
                        <img src="<?php echo $aadhar_back_path; ?>" width="50" title="View Image" loading="lazy">
                    <?php } else { ?>
                        <span>No file</span>
                    <?php } ?>
                </td>
                <td>
                    <?php
                    $passport_path = strpos($record->passport_photo_path, 'http') === 0
                        ? $record->passport_photo_path
                        : base_url($record->passport_photo_path);
                    ?>
                    <?php if ($record->passport_photo_path && strtolower(pathinfo($passport_path, PATHINFO_EXTENSION)) == 'pdf') { ?>
                        <a href="<?php echo $passport_path; ?>" class="view-pdf" data-pdf-url="<?php echo $passport_path; ?>" target="_blank">
                            <img src="<?php echo base_url('assets/images/pdf_icon.png'); ?>" width="50" title="View PDF" loading="lazy">
                        </a>
                    <?php } elseif ($record->passport_photo_path) { ?>
                        <img src="<?php echo $passport_path; ?>" width="50" title="View Image" loading="lazy">
                    <?php } else { ?>
                        <span>No file</span>
                    <?php } ?>
                </td>
                <td>
                    <?php
                    $payment_path = strpos($record->payment_screenshot_path, 'http') === 0
                        ? $record->payment_screenshot_path
                        : base_url($record->payment_screenshot_path);
                    ?>
                    <?php if ($record->payment_screenshot_path && strtolower(pathinfo($payment_path, PATHINFO_EXTENSION)) == 'pdf') { ?>
                        <a href="<?php echo $payment_path; ?>" class="view-pdf" data-pdf-url="<?php echo $payment_path; ?>" target="_blank">
                            <img src="<?php echo base_url('assets/images/pdf_icon.png'); ?>" width="50" title="View PDF" loading="lazy">
                        </a>
                    <?php } elseif ($record->payment_screenshot_path) { ?>
                        <img src="<?php echo $payment_path; ?>" width="50" title="View Image" loading="lazy">
                    <?php } else { ?>
                        <span>No file</span>
                    <?php } ?>
                </td>
                <td><?php echo $record->proposed_setup_date; ?></td>
                <td><?php echo $record->advertising_plan; ?></td>
                <td><?php echo $record->proposed_inauguration_date; ?></td>
                <td><?php echo $record->declaname; ?></td>
                <td><?php echo $record->sodo; ?></td>
                <td><?php echo $record->decsodoname; ?></td>
                <td><?php echo $record->clientname; ?></td>
                <td><?php echo $record->nominated; ?></td>
                <td><?php echo $record->nomibranch; ?></td>
                <td><?php echo $record->nomidist; ?></td>
                <td><?php echo $record->nomistate; ?></td>
                <td><?php echo $record->created_at; ?></td>
                <td class="text-center">
                    <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'onboardapplication/view/' . $record->frAppFormId; ?>" title="View"><i class="fa fa-eye"></i></a>
                    <a class="btn btn-sm btn-danger deletepdc" href="#" data-trainingid="<?php echo $record->frAppFormId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                </td>
            </tr>
    <?php }
    } ?>
</tbody>
                                        </table>


                                    </div><!-- /.box-body -->
                                    <div class="box-footer clearfix">
                                        <div class="br-pagi">
                                            <?php echo $this->pagination->create_links(); ?>
                                        </div>
                                    </div>
                                </div><!-- /.box -->
                            </div>
                        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }

    /*table-css*/
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        /*min-width: 75px;*/
        min-width: 50%;
        font-weight: bold;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }

    div.dataTables_wrapper li {
        text-indent: 0;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
        content: "-";
        background-color: #d33333;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "training/trainingListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>