<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i>onboardapplication
            <small>Submission Confirmation</small>
        </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <!-- Main content -->
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Thank You!</h3>
                    </div><!-- /.box-header -->
                    <div class="box-body">
                        <div class="text-center">
                            <div class="checkmark" style="font-size: 50px; color: #28a745;">✔</div>
                            <h4>Your submission has been received successfully.</h4>
                            <p>Thank you for adding a new Onboarding Form. You will be redirected shortly, or you can return to the homepage.</p>
                            
                        </div>
                    </div><!-- /.box-body -->
                </div>
            </div>
            <!-- Sidebar for alerts -->
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<!-- Bootstrap 5 JS (required for alerts) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>