<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i>Application Form
            <small>Add / Edit onboardapplication</small>
        </h1>
    </section>
    <style>
        .invalid-feedback {
            color: red;
        }

        .form-control[type="date"] {
            position: relative;
            z-index: 1;
        }

        #franchiseNumber,
        .col-md-8,
        .form-group {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
        }
    </style>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter onboardapplication Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addonboardapplication" action="<?php echo base_url() ?>onboardapplication/addNewOnboardapplication" method="post" role="form" enctype="multipart/form-data">

                        <!-- Step 1: Personal Details -->
                        <div id="step1" class="form-step box-body">
                            <h3 class="text-center">Personal Details</h3>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <?php if ($role != 25) { ?>
                                            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php } ?>
                                        <?php if ($role == 25) { ?>
                                            <!-- Hidden input for role 25 -->
                                            <input type="hidden" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>">
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="full_name">Full Name (As in Pan Card/Aadhar/Voter’s ID)</label>
                                    <input type="text" name="full_name" id="full_name" placeholder="Full Name" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="email">E-mail</label>
                                    <input type="email" name="email" id="email" placeholder="Your Email" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="contact_person_number">Contact No.</label>
                                    <input type="number" name="contact_person_number" id="contact_person_number" placeholder="Mobile Number" class="form-control" required oninput="validateContact(this)" pattern="\d{10}">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="alternate_contact_no">Alternate Number</label>
                                    <input type="number" name="alternate_contact_no" id="alternate_contact_no" placeholder="Alternate Number" class="form-control" required oninput="validateContact(this)" pattern="\d{10}">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="dob">D.O.B</label>
                                    <input type="date" name="dob" id="dob" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="comm_address">Communication Address</label>
                                    <input type="text" name="comm_address" id="comm_address" placeholder="Communication Address" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <label for="city">City</label>
                                    <input type="text" name="city" id="city" placeholder="City" class="form-control" required>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label for="state">State</label>
                                    <input type="text" name="state" id="state" placeholder="State" class="form-control" required>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label for="pincode">Pincode</label>
                                    <input type="text" name="pincode" id="pincode" placeholder="Pincode" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender:</label>
                                <select name="gender" id="gender" class="form-control">
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="branch_location">Branch Location (City in which you want to start)</label>
                                    <input type="text" name="branch_location" id="branch_location" placeholder="Branch Location" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="branch_area">Branch Area (Landmark, Area, Colony, Sector, etc.)</label>
                                    <input type="text" name="branch_area" id="branch_area" placeholder="Branch Area" class="form-control" required>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="current_school_name">Current School’s Name (If Any)</label>
                                    <input type="text" name="current_school_name" id="current_school_name" placeholder="Current School" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="year_founded">Year Founded / Started</label>
                                    <input type="text" name="year_founded" id="year_founded" placeholder="Year Founded" class="form-control" required>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="current_school_address">Current School’s Address</label>
                                    <input type="text" name="current_school_address" id="current_school_address" placeholder="School Address" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="current_strength">Current Strength of Pre-School</label>
                                    <input type="number" name="current_strength" id="current_strength" placeholder="Current Strength" class="form-control" required>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="total_experience">Total Experience in Playschool</label>
                                    <input type="text" name="total_experience" id="total_experience" placeholder="Total Experience" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="purpose_opening">Purpose of Opening the i-School/Evening Classes</label>
                                    <select name="purpose_opening" id="purpose_opening" class="form-control">
                                        <option value="" disabled selected>Select Purpose</option>
                                        <option value="business">Business</option>
                                        <option value="as_alternate_business">As a Alternate Business</option>
                                        <option value="ultilization_avail">Utilization of Available Premise/Property</option>


                                    </select>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="skills_experience">Skills and Experience to Contribute to eduMETA Network</label>
                                    <input type="text" name="skills_experience" id="skills_experience" placeholder="Skills and Experience" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="current_occupation">Current Occupation</label>
                                    <select name="current_occupation" id="current_occupation" class="form-control">
                                        <option value="" disabled selected>Select Occupation</option>
                                        <option value="school_employee">A: SCHOOL EMPLOYEE(E.G., TEACHER , ADMINISTRATOR, ETC.)</option>
                                        <option value="student">B: FRESHER/STUDENT (UNDERGRADUATE, GRADUATE)</option>
                                        <option value="nonprofit_organization">NONPROFIT ORGANIZATION</option>
                                        <option value="professional">PROFRSSIONAL, CONSULTANT, ETC</option>
                                        <option value="gov_employee">GOVERNMENT EMPLOYEE</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="vision_with_edumeta">Why Working with eduMETA Would Fulfill Your Vision</label>
                                    <select name="vision_with_edumeta" id="vision_with_edumeta" class="form-control">
                                        <option value="" disabled selected>Select Your Vision</option>
                                        <option value="Easy to Start Business">Easy to Start Business</option>
                                        <option value="Very Low Investment">Very Low Investment</option>
                                        <option value="Best Service Provider">Best Service Provider</option>
                                        <option value="Popular in my Area">Popular in my Area</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label for="heard_about_edumeta">How You First Heard About eduMETA</label>
                                    <select name="heard_about_edumeta" id="heard_about_edumeta" class="form-control" required>
                                        <option value="A-SOCIAL MEDIA">A: SOCIAL MEDIA</option>
                                        <option value="B-FRIEND">B: FRIEND</option>
                                        <option value="C-NEWSPAPER">C: NEWSPAPER</option>
                                        <option value="D-EMAIL">D: EMAIL</option>
                                        <option value="E-ONLINE SEARCH">E: ONLINE SEARCH</option>
                                        <option value="F-EDUMETA EMPLOYEE">F: EDUMETA EMPLOYEE</option>
                                        <option value="G-OTHER">G: OTHER</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <label for="additional_info">Any Other Information (Optional)</label>
                                    <input type="text" name="additional_info" id="additional_info" placeholder="Additional Information" class="form-control" required>
                                </div>
                            </div>
                            <div class="text-center" style="margin: 10px;">
                                <button type="button" class="btn btn-primary" onclick="nextStep(1)">Next</button>
                            </div>
                        </div>

                        <!-- Step 2: Location Confirmation -->
                        <div id="step2" class="form-step box-body" style="display: none;">
                            <h3 class="text-center">Location Confirmation</h3>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="franchise_owner">Franchise in the Name of (Branch Owner)</label>
                                    <input type="text" name="franchise_owner" id="franchise_owner" placeholder="Branch Owner" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="org_type">Organization Type</label>
                                    <select name="org_type" id="org_type" class="form-control">
                                        <option value="" disabled selected>Select Organization Type</option>
                                        <option value="Individual">Individual</option>
                                        <option value="Proprietor">Proprietor</option>
                                        <option value="Society">Society</option>
                                        <option value="Company">Company</option>
                                        <option value="Partnership">Partnership</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="franchise_applicant">Name of Franchise Applicant</label>
                                    <input type="text" name="franchise_applicant" id="franchise_applicant" placeholder="Franchise Applicant" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="gstin">GSTIN (If Available)</label>
                                    <input type="text" name="gstin" id="gstin" placeholder="GSTIN" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="gsttype">GSTIN Type</label>
                                    <input type="text" name="gsttype" id="gsttype" placeholder="GST Type" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="father_name">Father’s Name</label>
                                    <input type="text" name="father_name" id="father_name" placeholder="Father’s Name" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="permanent_address">Permanent Address (Branch Owner)</label>
                                    <input type="text" name="permanent_address" id="permanent_address" placeholder="Permanent Address" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="father_contact_no">Father’s Contact No.</label>
                                    <input type="number" name="father_contact_no" id="father_contact_no" placeholder="Father’s Contact" class="form-control" required pattern="\d{10}">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="branch_full_address">Confirm Location for eduMETA i-School Franchise</label>
                                    <select name="branch_full_address" id="branch_full_address" class="form-control">
                                        <option value="" disabled selected>Select Your Location</option>
                                        <option value="Yes-I have the Confirmed Location">Yes I have the Confirmed Location</option>
                                        <option value="Need to Search for the Premise, I will update Later">Need to Search for the Premise, I will update Later</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="spouse_name">Spouse’s Name</label>
                                    <input type="text" name="spouse_name" id="spouse_name" placeholder="Spouse’s Name" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="complete_branch_address">Complete Branch Address</label>
                                    <input type="text" name="complete_branch_address" id="complete_branch_address" placeholder="Complete Branch Address" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="spouse_contact_no">Spouse’s Contact No.</label>
                                    <input type="number" name="spouse_contact_no" id="spouse_contact_no" placeholder="Spouse’s Contact" class="form-control" pattern="\d{10}" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="map_location">Confirm Map Location</label>
                                    <input type="text" name="map_location" id="map_location" placeholder="Map Location" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="comm_current_address">Communication Address (Current Residence)</label>
                                    <input type="text" name="comm_current_address" id="comm_current_address" placeholder="Current Residence" class="form-control" required>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <p>I ………<input placeholder="Enter your name..." oninput="this.className = ''" name="declaname" class="declasec" required>………<select name="sodo" id="cur-locname" class="declasec">
                                            <option value="S/O">S/O</option>
                                            <option value="D/O">D/O</option>
                                        </select>.………<input placeholder="Father Name...." oninput="this.className = ''" name="decsodoname" class="declasec" required>……do here by declared that all the above information provided by me is correct and location is confirmed. This above location will be considering as my initial starting location for eduMETA THE i-SCHOOL</p>
                                </div>
                            </div>
                            <div class="form-group text-center" style="margin: 10px;">
                                <button type="button" class="btn btn-secondary" onclick="prevStep(2)">Previous</button>
                                <button type="button" class="btn btn-primary" onclick="nextStep(2)">Next</button>
                            </div>
                        </div>

                        <!-- Step 3: Payment Details -->
                        <div id="step3" class="form-step box-body" style="display: none;">
                            <h3>To proceed further, Kindly click on the link for the payment <a href="https://pages.razorpay.com/eduPAY" class="btn btn-outline-warning" target="_blank">Pay Now</a></h3>
                            <h3 class="text-center">Payment Details</h3>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="payment_mode">Mode of Payment</label>
                                    <select name="payment_mode" id="payment_mode" class="form-control">
                                        <option value="" disabled selected>Select Payment Mode</option>
                                        <option value="Bank (Cash / Cheque Deposit)">Bank (Cash / Cheque Deposit)</option>
                                        <option value="Online (RTGS/NEFT/UPI/RAZOR PAY)">Online (RTGS/NEFT/UPI/RAZOR PAY)</option>
                                    </select>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="amount">Amount (Including GST)</label>
                                    <input type="number" name="amount" id="amount" placeholder="Amount" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="reference_id">Reference ID (Cheque No./UTR, etc.)</label>
                                    <input type="text" name="reference_id" id="reference_id" placeholder="Reference ID" class="form-control" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label for="payment_remark">Other Details (Payment Remark)</label>
                                    <input type="text" name="payment_remark" id="payment_remark" placeholder="Payment Remark" class="form-control">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label for="payment_date">Date of Payment</label>
                                    <input type="date" name="payment_date" id="payment_date" class="form-control" required>
                                </div>
                            </div>
                            <h4 class="text-center mt-4">Upload</h4>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="pan_card_photo">PAN Card Photo</label>
                                    <input type="file" name="file" id="file" class="form-control-file" accept="image/*,application/pdf" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="aadhar_front_photo_path">Aadhar Card Front Photo</label>
                                    <input type="file" name="file2" id="file2" class="form-control-file" accept="image/*,application/pdf" required>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="passport_photo_path">Upload Your Passport Size Photo</label>
                                    <input type="file" name="file3" id="file2" class="form-control-file" accept="image/*,application/pdf" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="aadhar_back_photo_path">Aadhar Card Back Photo</label>
                                    <input type="file" name="file4" id="file4" class="form-control-file" accept="image/*,application/pdf" required>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="payment_screenshot">Upload Payment Screenshot</label>
                                    <input type="file" name="file5" id="file5" class="form-control-file" accept="image/*,application/pdf" required>
                                </div>
                            </div>
                            <h3 class="text-center">Miscellaneous</h3>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="proposed_setup_date">Proposed Date for Setup</label>
                                    <input type="date" name="proposed_setup_date" id="proposed_setup_date" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="advertising_plan">Advertising Planning and Budget for First 3 Months</label>
                                    <select name="advertising_plan" id="advertising_plan" class="form-control">
                                        <option value="" disabled selected>Select Advertising Budget</option>
                                        <option value="25 Thousand">25 Thousand</option>
                                        <option value="50 Thousand">50 Thousand</option>
                                        <option value="75 Thousand">75 Thousand</option>
                                        <option value="1 Lakh">1 Lakh</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="proposed_inauguration_date">Proposed Date for Inauguration</label>
                                    <input type="date" name="proposed_inauguration_date" id="proposed_inauguration_date" class="form-control" required>
                                </div>
                            </div>
                            <h4 class="text-center mt-4">Appointment of One Individual for Future Communication</h4>
                            <div class="col-md-12">
                                <p>Client’s declaration:<br>
                                    I …<input placeholder="" name="clientname" class="declasec" required>……wish to nominate……<input placeholder="" name="nominated" class="declasec" required>…as my representative, For future communication with eduMETA head office on behalf of my franchisee at …<input placeholder="" name="nomibranch" class="declasec" required>…… district……<input placeholder="" name="nomidist" class="declasec" required>………state…<input placeholder="" name="nomistate" class="declasec" required>… In India. After this appointment, representative may be able to act for me in all Situations with full responsibility for all matters with eduMETA THE i-SCHOOL head office.
                                </p>
                            </div>
                            <div class="form-group text-center" style="margin: 10px;">
                                <button type="button" class="btn btn-primary" onclick="prevStep(3)">Previous</button>
                                <input type="submit" value="Submit" class="btn btn-success" id="submitBtn">
                            </div>
                        </div>

                </div>
                </form>
                </form>
            </div>
        </div>
        <div class="col-md-4">
            <?php
            $this->load->helper('form');
            $error = $this->session->flashdata('error');
            if ($error) {
            ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
            <?php } ?>
            <?php
            $success = $this->session->flashdata('success');
            if ($success) {
            ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php } ?>

            <div class="row">
                <div class="col-md-12">
                    <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                </div>
            </div>
        </div>
</div>
</section>
<!-- Editor -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        /*filebrowserUploadUrl: "<?= base_url('training/upload'); ?>",*/
        filebrowserUploadMethod: 'form'
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- <script>
            function nextStep(step) {
                document.getElementById(`step${step}`).style.display = 'none';
                document.getElementById(`step${step + 1}`).style.display = 'block';
            }

            function prevStep(step) {
                document.getElementById(`step${step}`).style.display = 'none';
                document.getElementById(`step${step - 1}`).style.display = 'block';
            }

            function validateContact(input) {
                if (input.value.length > 10) input.value = input.value.slice(0, 10);
            }

            function toggleApplicationDetails() {
                const appliedBefore = document.getElementById('applied_before').value;
                document.getElementById('applicationDetailsDiv').style.display = appliedBefore === 'yes' ? 'block' : 'none';
            }
        </script> -->
<script>
    function validateContact(input) {
        if (input.value.length > 10) input.value = input.value.slice(0, 10);
    }

    function validateStep(stepElement) {
        const requiredFields = stepElement.querySelectorAll('[required]');
        let isValid = true;
        let firstInvalidField = null;

        requiredFields.forEach(field => {
            let errorDiv;

            // Remove existing error message
            if (field.nextElementSibling && field.nextElementSibling.classList.contains('invalid-feedback')) {
                errorDiv = field.nextElementSibling;
                errorDiv.remove();
            }

            // Check if field is empty or invalid
            if (field.tagName === 'SELECT' && (!field.value || field.value === '')) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'Please select an option';
                field.parentNode.appendChild(errorDiv);
            } else if (field.type === 'text' || field.type === 'number' || field.type === 'date' || field.tagName === 'TEXTAREA') {
                if (!field.value.trim()) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'This field is required';
                    field.parentNode.appendChild(errorDiv);
                } else {
                    field.classList.remove('is-invalid');
                }
            } else if (field.type === 'email') {
                let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                if (!field.value.trim()) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'This field is required';
                    field.parentNode.appendChild(errorDiv);
                } else if (!emailPattern.test(field.value.trim())) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'Please enter a valid email address';
                    field.parentNode.appendChild(errorDiv);
                } else {
                    field.classList.remove('is-invalid');
                }
            } else if (
                field.name === 'contact_person_number' ||
                field.name === 'alternate_contact_no' ||
                field.name === 'father_contact_no' ||
                field.name === 'spouse_contact_no'
            ) {
                let phonePattern = /^\d{10}$/;
                if (!field.value.trim()) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'This field is required';
                    field.parentNode.appendChild(errorDiv);
                } else if (!phonePattern.test(field.value.trim())) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'Please enter a valid 10-digit phone number';
                    field.parentNode.appendChild(errorDiv);
                } else {
                    field.classList.remove('is-invalid');
                }
            } else if (field.type === 'file' && !field.files.length) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'Please upload a file';
                field.parentNode.appendChild(errorDiv);
            } else {
                field.classList.remove('is-invalid');
            }
        });

        // Scroll to the first invalid field
        if (!isValid && firstInvalidField) {
            firstInvalidField.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
            firstInvalidField.focus();
        }

        return isValid;
    }

    function nextStep(stepNumber) {
        const currentStep = document.getElementById(`step${stepNumber}`);
        const nextStep = document.getElementById(`step${stepNumber + 1}`);

        if (validateStep(currentStep) && nextStep) {
            currentStep.style.display = 'none';
            nextStep.style.display = 'block';
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    }

    function prevStep(stepNumber) {
        const currentStep = document.getElementById(`step${stepNumber}`);
        const prevStep = document.getElementById(`step${stepNumber - 1}`);

        if (currentStep && prevStep) {
            currentStep.style.display = 'none';
            prevStep.style.display = 'block';
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    }

    function toggleApplicationDetails() {
        const appliedBefore = document.getElementById('applied_before')?.value;
        const applicationDetailsDiv = document.getElementById('applicationDetailsDiv');
        if (applicationDetailsDiv) {
            applicationDetailsDiv.style.display = appliedBefore === 'yes' ? 'block' : 'none';
        }
    }

    document.getElementById('addonboardapplication').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const allSteps = document.querySelectorAll('.form-step');
        let isValid = true;
        let firstInvalidStep = null;

        // Validate all steps
        allSteps.forEach(step => {
            if (!validateStep(step)) {
                isValid = false;
                if (!firstInvalidStep) firstInvalidStep = step;
            }
        });

        // If any step is invalid, show the first invalid step
        if (!isValid && firstInvalidStep) {
            allSteps.forEach(step => {
                step.style.display = step === firstInvalidStep ? 'block' : 'none';
            });
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            return;
        }

        // If all steps are valid, submit the form
        this.submit();
    });
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });

    // Updated fetchAssignedFranchise function to fetch Growth Manager's name
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue'); // Reference hidden input
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.html) {
                        assignedDiv.innerHTML = response.html; // Display Growth Manager's name(s)
                        hiddenInput.value = response.userIds || ''; // Set hidden input to userIds
                    } else {
                        assignedDiv.innerText = 'No Growth Manager assigned';
                        hiddenInput.value = ''; // Clear hidden input
                        alert(response.message || 'No Growth Manager found for this franchise');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    assignedDiv.innerText = 'Error fetching Growth Manager';
                    hiddenInput.value = ''; // Clear hidden input
                    alert('Error fetching Growth Manager data');
                }
            });
        } else {
            assignedDiv.innerText = 'Select a franchise to assign';
            hiddenInput.value = ''; // Clear hidden input
        }
    }

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        // For dropdown (non-readonly, roles other than 25)
        if (franchiseInput && franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }

        // For readonly input (role 25)
        if (franchiseInput && franchiseInput.readOnly) {
            fetchAssignedFranchise(franchiseInput.value);
            // Trigger staff fetch if needed
            // fetchStaffByFranchise(franchiseInput.value);
        }
    });
</script>
<script>
    function validateStep(stepElement) {
    const requiredFields = stepElement.querySelectorAll('[required]');
    let isValid = true;
    let firstInvalidField = null;

    requiredFields.forEach(field => {
        let errorDiv;

        // Remove existing error message
        if (field.nextElementSibling && field.nextElementSibling.classList.contains('invalid-feedback')) {
            errorDiv = field.nextElementSibling;
            errorDiv.remove();
        }

        // Validate text, select, email, and phone fields (unchanged)
        if (field.tagName === 'SELECT' && (!field.value || field.value === '')) {
            isValid = false;
            if (!firstInvalidField) firstInvalidField = field;
            field.classList.add('is-invalid');
            errorDiv = document.createElement('div');
            errorDiv.classList.add('invalid-feedback');
            errorDiv.innerText = 'Please select an option';
            field.parentNode.appendChild(errorDiv);
        } else if (field.type === 'text' || field.type === 'number' || field.type === 'date' || field.tagName === 'TEXTAREA') {
            if (!field.value.trim()) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'This field is required';
                field.parentNode.appendChild(errorDiv);
            } else {
                field.classList.remove('is-invalid');
            }
        } else if (field.type === 'email') {
            let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!field.value.trim()) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'This field is required';
                field.parentNode.appendChild(errorDiv);
            } else if (!emailPattern.test(field.value.trim())) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'Please enter a valid email address';
                field.parentNode.appendChild(errorDiv);
            } else {
                field.classList.remove('is-invalid');
            }
        } else if (
            field.name === 'contact_person_number' ||
            field.name === 'alternate_contact_no' ||
            field.name === 'father_contact_no' ||
            field.name === 'spouse_contact_no'
        ) {
            let phonePattern = /^\d{10}$/;
            if (!field.value.trim()) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'This field is required';
                field.parentNode.appendChild(errorDiv);
            } else if (!phonePattern.test(field.value.trim())) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'Please enter a valid 10-digit phone number';
                field.parentNode.appendChild(errorDiv);
            } else {
                field.classList.remove('is-invalid');
            }
        } else if (field.type === 'file') {
            // Handle required file uploads
            if (!field.files.length) {
                isValid = false;
                if (!firstInvalidField) firstInvalidField = field;
                field.classList.add('is-invalid');
                errorDiv = document.createElement('div');
                errorDiv.classList.add('invalid-feedback');
                errorDiv.innerText = 'Please upload a file';
                field.parentNode.appendChild(errorDiv);
            } else {
                const file = field.files[0];
                const validTypes = ['image/jpeg', 'image/png', 'application/pdf'];
                const maxSize = 5 * 1024 * 1024; // 5MB

                if (!validTypes.includes(file.type)) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'Please upload a JPG, PNG, or PDF file';
                    field.parentNode.appendChild(errorDiv);
                } else if (file.size > maxSize) {
                    isValid = false;
                    if (!firstInvalidField) firstInvalidField = field;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'File size exceeds 5MB';
                    field.parentNode.appendChild(errorDiv);
                } else {
                    field.classList.remove('is-invalid');
                }
            }
        } else {
            field.classList.remove('is-invalid');
        }
    });

    // Scroll to the first invalid field
    if (!isValid && firstInvalidField) {
        firstInvalidField.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
        firstInvalidField.focus();
    }

    return isValid;
}
</script>
</div>