<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Account Attachment Management
        <small>Add / Edit Attachment</small>
    </h1>
    </section>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                    <h3 class="box-title">Attachment / Upload File Details</h3>
                    <div class="pull-right">
            <a href="<?php echo base_url() ?>acattachment/acattachmentListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>acattachment/addNewAcattachment" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Attachment Title</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('acattachmentitle'); ?>" id="acattachmentTitle" name="acattachmentTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                                  <div class="col-md-6">
    <div class="form-group">
        <label for="acattachmentTitle">Attachment</label>
        <select class="form-control required" id="attachmentLeg" name="attachmentLeg">
            <option value="0">Select one</option>
            <option value="invoice">Invoice</option>
            <option value="ledger">Ledger</option>
        </select>
    </div>
</div>

<!-- Month Dropdown (Hidden by Default) -->
<div class="col-md-6" id="monthDropdown" style="display: none;">
    <div class="form-group">
        <label for="monthSelect">Select Month</label>
        <select class="form-control" id="monthSelect" name="month">
            <option value="0">Select Month</option>
            <option value="January">January</option>
            <option value="February">February</option>
            <option value="March">March</option>
            <option value="April">April</option>
            <option value="May">May</option>
            <option value="June">June</option>
            <option value="July">July</option>
            <option value="August">August</option>
            <option value="September">September</option>
            <option value="October">October</option>
            <option value="November">November</option>
            <option value="December">December</option>
        </select>
    </div>
</div>

                               <!--  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Assigned To</label>
                                        <select class="form-control required" id="assignedTo" name="assignedTo">
                                            <option value="0">Select User</option>
                                             <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('selectUserId')) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                    
                                </div> -->
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="trainingTitle">Date of Attachment <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dtOfInvoice'); ?>" id="dtOfInvoice" name="dtOfInvoice" maxlength="256">
                                    </div>   
                                </div>
                                
                               <!--  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise No.</label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"  data-live-search="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                     <option value="<?php echo $franchiseNumber; ?>" ><?php echo $franchiseNumber; ?></option>
                                                    <?php

                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                    
                                </div> -->

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                    <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                        <option value="">Select Franchise</option>
                                        <?php
                                        if (!empty($branchDetail)) {
                                            foreach ($branchDetail as $bd) {
                                                $franchiseNumber = $bd->franchiseNumber;
                                                ?>
                                                <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="branchFranchiseAssigned">Franchise Assigned to</label><span class="re-mend-field">*</span>
                                    <select class="form-control required" id="branchFranchiseAssigned" name="assignedTo" required>
                                       <option value="0">Select Role</option>
                                    </select>
                                </div>
                            </div>

                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Upload File</label>
                                        <input  type="file" name="file" multiple>
                                    </div>
                                    
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Remark - Short Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                             
                        </div>

                       
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>

<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("acattachment/fetchAssignedUsers"); ?>', // Ensure this URL matches your controller/method
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                // Assuming response contains options with growth manager's name
                $('#branchFranchiseAssigned').html(response); // Populate dropdown with response
                // Remove "Select Role" option if it exists in the response
                $('#branchFranchiseAssigned option[value="0"]').remove();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
                $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
            }
        });
    } else {
        // If no franchise number, clear dropdown and show placeholder
        $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
    }
}
</script>

<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Indicate submission
    });
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function() {
        $('#attachmentLeg').change(function() {
            if ($(this).val() === 'ledger') {
                $('#monthDropdown').show();
            } else {
                $('#monthDropdown').hide();
            }
        });
    });
</script>