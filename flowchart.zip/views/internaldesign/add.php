<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i>
        <small>Add / Edit Design list</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Design Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addTodo" action="<?php echo base_url() ?>internaldesign/addNewInternaldesign" method="post" enctype="multipart/form-data" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="todoTitle">Title</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('internaldesignTitle'); ?>" id="internaldesignTitle" name="internaldesignTitle" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload File</label>
                                        <input  type="file" name="file" multiple>
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                    <div class="form-group">
                        <label for="designStatus">Status</label>
                        <select class="form-control" name="designStatus" id="designStatus" >
                            <option value="">-- Select Status --</option>
                            <option value="Pending" <?= set_value('designStatus') == 'Pending' ? 'selected' : '' ?>>Pending</option>
                            <option value="Ready for Review" <?= set_value('designStatus') == 'Ready for Review' ? 'selected' : '' ?>>Ready for Review</option>
                            <option value="Completed" <?= set_value('designStatus') == 'Completed' ? 'selected' : '' ?>>Completed</option>
                        </select>
                    </div>
                </div>

                               <!--  <div class="col-md-6">
    <div class="form-group">
        <label for="user">Select User</label>
        <select class="form-control" name="userId" id="userId">
            <option value="">-- Select User --</option>
            <?php foreach ($users as $user): ?>
                <option value="<?= $user->userId ?>"><?= $user->name ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div> -->
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            /*filebrowserUploadUrl: "<?= base_url('training/upload'); ?>",*/
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>