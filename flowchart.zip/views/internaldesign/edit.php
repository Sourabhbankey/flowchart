    <?php
    $internaldesignId = $internaldesignInfo->internaldesignId;
    $internaldesignTitle = $internaldesignInfo->internaldesignTitle;
    $description = $internaldesignInfo->description;
     $designStatus = $internaldesignInfo->designStatus;
    $reply = $internaldesignInfo->reply ?? '';
    $replyAttachment = $internaldesignInfo->replyAttachment ?? '';
    ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <i class="fa fa-user-circle-o" aria-hidden="true"></i> Design Management
                <small>Add / Edit Design</small>
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-10">
                    <div class="box box-primary">
                        <div class="box-header">
                            <h3 class="box-title">Enter Design Details</h3>
                        </div>

                        <form role="form" action="<?php echo base_url() ?>Internaldesign/editInternaldesign" method="post" id="editInternaldesign" enctype="multipart/form-data">
                            <div class="box-body">
                                <div class="row">
                                    <!-- Title -->
                                    <div class="col-md-12">                                
                                        <div class="form-group">
                                            <label for="internaldesignTitle">Title</label>
                                            <input type="text" class="form-control required" value="<?php echo $internaldesignTitle; ?>" id="internaldesignTitle" name="internaldesignTitle" maxlength="256" />
                                            <input type="hidden" value="<?php echo $internaldesignId; ?>" name="internaldesignId" id="internaldesignId" />
                                        </div>
                                    </div>

                                    <!-- Description -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                        </div>
                                    </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="designStatus">Status</label>
                                        <select class="form-control" name="designStatus" id="designStatus">
                                            <option value="Pending" <?= $internaldesignInfo->designStatus == 'Pending' ? 'selected' : '' ?>>Pending</option>
                                            <option value="Ready for Review" <?= $internaldesignInfo->designStatus == 'Ready for Review' ? 'selected' : '' ?>>Ready for Review</option>
                                            <option value="Completed" <?= $internaldesignInfo->designStatus == 'Completed' ? 'selected' : '' ?>>Completed</option>
                                        </select>
                                    </div>
                                </div>
    
                                   
                                </div>
                            </div><!-- /.box-body -->

                            <div class="box-footer">
                                <input type="submit" class="btn btn-primary" value="Submit" />
                                <input type="reset" class="btn btn-default" value="Reset" />
                            </div>
                        </form>
                        <div class="box-body">
                                <div class="row">
                                <div class="col-md-12">  
                                <h4>Add a Reply</h4>
                                <form action="<?php echo base_url('internaldesign/addReply'); ?>" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="internaldesignId" value="<?php echo $internaldesignId; ?>">
                                    <div class="form-group">
                                        <label for="replyText">Your Message</label>
                                        <textarea name="replyText" class="form-control" id="replyText" required></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="replyAttachment">Attach an Image or File</label>
                                        <input type="file" name="replyAttachment" class="form-control" id="replyAttachment">
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" value="Send Reply" class="btn btn-primary">
                                    </div>
                                </form>
                                <h4>Conversation</h4>
                                <?php
                                    $currentUserName = $this->session->userdata('name');
                                    $currentUserProfilePic = $this->session->userdata('profilePic'); 

                                    // Set full URL
                                    $currentUserProfilePicUrl = !empty($currentUserProfilePic)
                                        ? base_url($currentUserProfilePic)
                                        : base_url('uploads/userprofile/profilepicture12.jpeg');
                                    ?>

                                    <div class="conversation-thread">
                                        <?php if (!empty($replies)) : ?>
                                            <?php foreach ($replies as $reply): ?>
                                                <?php
                                                    $isCurrentUser = (strtolower(trim($reply->username)) === strtolower(trim($currentUserName)));
                                                    $alignmentClass = $isCurrentUser ? 'message-right' : 'message-left';
                                                    $replyPic = !empty($reply->profilePic) ? base_url($reply->profilePic) : base_url('uploads/userprofile/profilepicture12.jpeg');
                                                    $profilePicToShow = $isCurrentUser ? $currentUserProfilePicUrl : $replyPic;
                                                ?>
                                                <div class="message-box <?php echo $alignmentClass; ?>">
                                                    <div class="avatar-container">
                                                        <img src="<?php echo $profilePicToShow; ?>" alt="Avatar" class="avatar" onerror="this.onerror=null;this.src='<?php echo base_url('assets/img/default-avatar.png'); ?>';">
                                                    </div>
                                                    <div class="message-content">
                                                        <div class="bubble">
                                                            <p><strong><?php echo $reply->username; ?>:</strong></p>
                                                            <p><?php echo $reply->replyText; ?></p>

                                                            <?php if (!empty($reply->replyAttachment)) : ?>
                                                                <div class="attachment">
                                                                    <strong>Attachment:</strong><br>
                                                                    <img src="<?php echo $reply->replyAttachment; ?>" alt="Attachment">
                                                                    <a href="<?php echo base_url('internaldesign/downloadFile?file=' . urlencode($reply->replyAttachment)); ?>" class="btn btn-sm btn-success">
                                                                        <i class="fa fa-download"></i> Download
                                                                    </a>
                                                                </div>
                                                            <?php endif; ?>
                                                            <div class="timestamp"><?php echo date('d M Y h:i A', strtotime($reply->createdDtm)); ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <p>No replies yet.</p>
                                        <?php endif; ?>
                                    </div>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
                <!-- Right Column -->
                <div class="col-md-4">
                    <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error) {
                        echo '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'
                                . $error .
                              '</div>';
                    }

                    $success = $this->session->flashdata('success');
                    if($success) {
                        echo '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'
                                . $success .
                              '</div>';
                    }

                    echo validation_errors('<div class="alert alert-danger alert-dismissable">', 
                                           ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>');
                    ?>
                </div>
            </div>
        </section>

        <!-- CKEditor -->
        <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
        <script>
            CKEDITOR.replace('description', {
                filebrowserUploadMethod: 'form'
            });
            CKEDITOR.replace('replyText', {
                filebrowserUploadMethod: 'form'
            });
        </script>
    </div>
    <style>
        .conversation-thread {
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 5px;
        max-height: 400px;
        overflow-y: auto;
        background: #edbbc41c;
    }

    .message-box {
        margin-bottom: 15px;
        padding: 10px;
        /*background: #f1f1f1;*/
        border-radius: 5px;
    }
/*New-Layout-style*/
.conversation-thread {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.message-box {
    display: flex;
    align-items: flex-end;
    max-width: 80%;
}

.message-left {
    align-self: flex-start;
    flex-direction: row;
}

.message-right {
    align-self: flex-end;
    flex-direction: row-reverse;
}

.avatar-container {
    margin: 0 8px;
}

.avatar {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    object-fit: cover;
}

.message-content {
    display: flex;
    flex-direction: column;
}

.bubble {
    position: relative;
    background-color: #bcc7b0; 
    padding: 10px;
    border-radius: 10px;
    max-width: 100%;
    word-wrap: break-word;
}

.message-right .bubble {
    background-color: #dcf8c6; 
}

.bubble::after {
    content: "";
    position: absolute;
    bottom: 0;
    width: 0;
    height: 0;
    border: 10px solid transparent;
}

.message-left .bubble::after {
    left: -10px;
    border-right-color: #bcc7b0;
    border-left: 0;
    margin-top: -10px;
}

.message-right .bubble::after {
    right: -10px;
    border-left-color: #dcf8c6;
    border-right: 0;
    margin-top: -10px;
}

.attachment img {
    max-width: 80px;
    max-height: 80px;
    margin: 10px 0;
}

.timestamp {
    font-size: 11px;
    color: #555;
    text-align: right;
    margin-top: 5px;
}


/*End-New-Layout-style*/
    </style>
 <script>
  function downloadImage(url) {
    fetch(url, {
      mode: 'cors' // This works only if S3 allows CORS
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.blob();
    })
    .then(blob => {
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = url.split('/').pop(); // Use filename from URL
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(blobUrl);
    })
    .catch(error => {
      console.error('Download failed:', error);
      alert('Image could not be downloaded. Please check CORS settings on S3.');
    });
  }
</script>

