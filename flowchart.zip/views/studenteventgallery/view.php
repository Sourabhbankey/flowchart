<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Student Event Gallery Details
            <small>View Event Details</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Event: <?php echo htmlspecialchars($studenteventgalleryInfo['eventName']); ?></h3>
                        <div class="box-tools pull-right">
                            <a href="<?php echo base_url('studenteventgallery/listing'); ?>" class="btn btn-primary">
                                <i class="fa fa-arrow-left"></i> Back to List
                            </a>
                        </div>
                    </div>
                    <div class="box-body">
                        <?php if (!empty($studenteventgalleryInfo)) { ?>
                            <?php
                            $image_paths = !empty($studenteventgalleryInfo['eventS3attachment']) ? explode(',', $studenteventgalleryInfo['eventS3attachment']) : [];
                            $video_paths = !empty($studenteventgalleryInfo['eventvideoS3attachment']) ? explode(',', $studenteventgalleryInfo['eventvideoS3attachment']) : [];
                            $all_files = array_merge($image_paths, $video_paths);
                            if (count($all_files) > 0) {
                                echo '<div class="row">';
                                foreach ($all_files as $index => $file_path) {
                                    if (!empty($file_path)) {
                                        $file_path = trim($file_path);
                                        $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
                                        $isImage = in_array($extension, ['png', 'jpg', 'jpeg', 'gif']);
                                        $isVideo = in_array($extension, ['mp4', 'mpeg', 'mov']);
                                        $isZip = ($extension === 'zip');
                            ?>
                                        <div class="col-md-3 col-sm-6 col-xs-12">
                                            <div class="card" id="card_<?php echo $studenteventgalleryInfo['studeventId'] . '_' . $index; ?>">
                                                <div class="card-media">
                                                    <?php if ($isImage) { ?>
                                                        <img src="<?php echo htmlspecialchars($file_path); ?>"
                                                            alt="<?php echo htmlspecialchars($studenteventgalleryInfo['eventName']); ?> Image <?php echo $index + 1; ?>"
                                                            class="img-responsive downloadable-image" data-url="<?php echo $file_path; ?>" data-index="<?php echo $index; ?>">
                                                    <?php } elseif ($isVideo) { ?>
                                                        <video controls class="video-responsive">
                                                            <source src="<?php echo htmlspecialchars($file_path); ?>" type="video/<?php echo $extension; ?>">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php } elseif ($isZip) { ?>
                                                        <img src="<?php echo base_url('assets/icons/zip-icon.png'); ?>"
                                                            alt="ZIP File" class="img-responsive">
                                                    <?php } else { ?>
                                                        <p>Unsupported file type: <?php echo $extension; ?></p>
                                                    <?php } ?>
                                                </div>
                                                <div class="card-body text-center">
                                                    <button class="btn btn-primary download-btn"
                                                        data-url="<?php echo $file_path; ?>" data-index="<?php echo $index; ?>"
                                                        onclick="downloadFile('<?php echo $file_path; ?>', this, '<?php echo $studenteventgalleryInfo['studeventId'] . '_' . $index; ?>', '<?php echo $isImage ? 'Image' : ($isVideo ? 'Video' : 'ZIP'); ?>')">
                                                        <i class="fa fa-download"></i> Download <?php echo $isImage ? 'Image' : ($isVideo ? 'Video' : 'ZIP'); ?> <?php echo $index + 1 ?>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                <?php
                                    }
                                }
                                echo '</div>';
                            } else {
                                ?>
                                <p>No files available for this event.</p>
                            <?php
                            }
                            ?>
                        <?php } else { ?>
                            <p>No event details found.</p>
                        <?php } ?>
                    </div>
                    <div class="box-footer text-center">
                        <a href="<?php echo base_url('studenteventgallery/listing'); ?>" class="btn btn-default">
                            <i class="fa fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style type="text/css">
    .img-responsive,
    .video-responsive {
        display: block;
        /* max-width: 100%; */
        /* height: 400px; */    
        /* width: auto; */
        border-radius: 5px;
        margin: 0 auto;
        /* cursor: pointer; */
        /* For images to indicate clickability */
    }

    .box {
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .box-header {
        background-color: #f8f9fa;
        padding: 15px;
    }

    .box-body {
        padding: 20px;
    }

    .box-footer {
        padding: 15px;
        background-color: #f8f9fa;
    }

    .card {
        border: 1px solid #ddd;
        border-radius: 5px;
        margin-bottom: 20px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        background-color: #fff;
    }

    .card-media {
        padding: 10px;
        text-align: center;
    }

    .card-body {
        padding: 4px;
    }

    .download-btn:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
    /* .img-responsive{
        max-width: 60%;
    } */
</style>
<!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" type="text/javascript"></script>

<script type="text/javascript">
    jQuery(document).ready(function() {
        // Handle image load errors
        jQuery('.downloadable-image').on('error', function() {
            jQuery(this).hide();
            jQuery(this).parent().append('<p class="text-danger">Unable to load image. Please check the URL or try again later.</p>');
        });

        // Handle video load errors
        jQuery('video').on('error', function() {
            jQuery(this).hide();
            jQuery(this).parent().append('<p class="text-danger">Unable to load video. Please check the URL or try again later.</p>');
        });

        // Trigger download on image click and prevent default navigation
        jQuery('.downloadable-image').on('click', function(event) {
            event.preventDefault(); // Prevent the default navigation to the image URL
            const url = jQuery(this).data('url');
            const index = jQuery(this).data('index');
            const uniqueId = '<?php echo $studenteventgalleryInfo['studeventId']; ?>_' + index;
            downloadFile(url, null, uniqueId, 'Image');
        });
    });

    function downloadFile(fileUrl, buttonElement, uniqueId, fileType) {
        if (!fileUrl) {
            alert('File URL not found.');
            return;
        }

        // Disable button while downloading (if buttonElement is provided)
        if (buttonElement) {
            $(buttonElement).prop('disabled', true).text('Downloading...');
        }

        // Use fetch to handle the download, which helps with CORS
        fetch(fileUrl, {
                method: 'GET',
                headers: {
                    'Cache-Control': 'no-cache' // Prevent caching issues
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.blob();
            })
            .then(blob => {
                // Create a temporary URL for the blob
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                // Set the file name for download
                link.setAttribute('download', `${fileType}_${uniqueId}.${fileUrl.split('.').pop().split('?')[0]}`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                window.URL.revokeObjectURL(url); // Clean up

                // Re-enable button (if provided)
                if (buttonElement) {
                    $(buttonElement).prop('disabled', false).html(`<i class="fa fa-download"></i> Download ${fileType} ${uniqueId.split('_')[1]}`);
                }
            })
            .catch(error => {
                console.error('Download error:', error);
                alert('Error: Failed to download file. The file may be restricted by the server or unavailable.');
                if (buttonElement) {
                    $(buttonElement).prop('disabled', false).html(`<i class="fa fa-download"></i> Download ${fileType} ${uniqueId.split('_')[1]}`);
                }
            });
    }
</script>


