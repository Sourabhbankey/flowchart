<?php
$studeventId = isset($studenteventgalleryInfo) && is_object($studenteventgalleryInfo) ? $studenteventgalleryInfo->studeventId : '';
$eventName = isset($studenteventgalleryInfo) && is_object($studenteventgalleryInfo) ? $studenteventgalleryInfo->eventName : '';
$venue = isset($studenteventgalleryInfo) && is_object($studenteventgalleryInfo) ? $studenteventgalleryInfo->venue : '';
$eventDate = isset($studenteventgalleryInfo) && is_object($studenteventgalleryInfo) ? $studenteventgalleryInfo->eventDate : '';
$description = isset($studenteventgalleryInfo) && is_object($studenteventgalleryInfo) ? $studenteventgalleryInfo->description : '';
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Student  Event Management
        <!-- <small>Add / Edit Employee of month</small> -->
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Student Event Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editstudenteventgallery/listing" method="post" id="editHreventgallery" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="eventName">Event Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $eventName; ?>" id="eventName" name="eventName" maxlength="256" />
                                        <input type="hidden" value="<?php echo $studeventId; ?>" name="studeventId" id="studeventId" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="roomName">Event Date</label>
                                        <input type="text" class="form-control required" value="<?php echo $eventDate; ?>" id="eventDate" name="eventDate" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="venue">Venue</label>
                                        <input type="text" class="form-control required" value="<?php //echo $venue; ?>" id="venue" name="venue" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>