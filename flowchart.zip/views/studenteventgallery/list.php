<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Student Event Gallery Management
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <?php if($role==1 || $role==14 || $role==25) { ?>
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>studenteventgallery/add"><i class="fa fa-plus"></i> Add New Student Event Gallery</a>
                </div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $error; ?>
                </div>
                <?php } ?>
                <?php
                    $success = $this->session->flashdata('success');
                    if($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Student Event List</h3>
                        <div class="box-tools">
                            <form action="<?php echo base_url() ?>studenteventgallery/listing" method="POST" id="searchList">
                                <div class="input-group">
                                    <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                                    <div class="input-group-btn">
                                        <button class="btn btn-sm btn-default searchList" type="submit"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="box-body table-responsive ">
                        <table id="example" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Franchise Number</th>
                                    <th>Event Name</th>
                                    <th>Venue</th>
                                    <th>Date</th>
                                    <th>Image/Video</th>
                                    <th>Description</th>
                                    <th>Created On</th>
                                    <?php if($role==26 || $role==14 || $is_admin == 1) { ?>
                                    <th class="text-center">Actions</th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 1;
                                if(!empty($records)) {
                                    foreach($records as $record) {
                                ?>
                                <tr>
                                    <td><?php echo $counter++; ?></td>
                                    <td><?php echo $record->franchiseNumber?></td>
                                    <td><?php echo $record->eventName ?></td>
                                    <td><?php echo $record->venue ?></td>
                                    <td><?php echo $record->eventDate ?></td>
                                    <td><a class="btn btn-sm btn-info" href="<?php echo base_url().'studenteventgallery/view/'.$record->studeventId; ?>" title="View"><i class="fa fa-eye"></i></a></td>
                                    <td><?php echo $record->description ?></td>
                                    <td><?php echo date("d-m-Y", strtotime($record->createdDtm)) ?></td>
                                    <?php if($role==26 || $role==14 || $is_admin == 1) { ?>
                                    <td class="text-center">
                                        <a class="btn btn-sm btn-info" href="<?php echo base_url().'studenteventgallery/edit/'.$record->studeventId; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                                        <a class="btn btn-sm btn-danger deletehreventgallery" href="#" data-studeventId="<?php echo $record->studeventId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                                    </td>
                                    <?php } ?>
                                </tr>
                                <?php
                                    }
                                } else {
                                ?>
                                <tr>
                                    <td colspan="<?php echo ($role==26 || $role==14 || $is_admin == 1) ? 9 : 8; ?>">No records found.</td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="box-footer clearfix">
                         <div class="br-pagi">
                        <?php echo $this->pagination->create_links(); ?>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
       
            jQuery("#searchList").attr("action", baseURL + "studenteventgallery/listing/" + value);
            jQuery("#searchList").submit();
        });
    });
    
</script>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    
</style>