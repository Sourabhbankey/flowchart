<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Student Event Gallery
            <small>Add / Edit</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Student Event Gallery Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addstudenteventgallery" action="<?php echo base_url() ?>studenteventgallery/addNew" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchAssignedFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php if ($role != 25) { ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                            <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                                <span>Select a franchise to assign</span>
                                            </div>
                                            <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                        </div>
                                    </div>
                                <?php } ?>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="eventName">Event Name <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('eventName'); ?>" id="eventName" name="eventName" maxlength="255" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="eventDate">Event Date <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('eventDate'); ?>" id="eventDate" name="eventDate" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="venue">Venue <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('venue'); ?>" id="venue" name="venue" maxlength="255" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="classType">Class Type <span class="re-mend-field">*</span></label>
                                        <select class="form-control" id="classType" name="classType">
                                            <option value="all" <?php echo set_select('classType', 'all', TRUE); ?>>All</option>
                                            <option value="classwise" <?php echo set_select('classType', 'classwise'); ?>>Classwise</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="customWebsiteLink">Website Link</label>
                                        <input type="text" class="form-control" id="customWebsiteLink" name="customWebsiteLink" readonly />
                                    </div>
                                </div> -->
                                <div class="col-md-6" id="classSelection">
                                    <div class="form-group">
                                        <label for="className">Class Name <span class="re-mend-field">*</span></label>
                                        <select required class="form-control selectpicker" id="className" name="class_name" multiple>
                                            <option value="select_all">Select All</option>
                                            <?php if (!empty($classes)) {
                                                foreach ($classes as $classs) { ?>
                                                    <option value="<?php echo htmlspecialchars($classs->className); ?>" <?php echo set_select('className', $classs->className); ?>>
                                                        <?php echo htmlspecialchars($classs->className); ?>
                                                    </option>
                                            <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6" id="sectionSelection">
                                    <div class="form-group">
                                        <label for="sectionName">Section Name <span class="re-mend-field">*</span></label>
                                        <select required class="form-control selectpicker" id="sectionName" name="section_name" multiple>
                                            <option value="select_all">Select All</option>
                                            <?php if (!empty($sections)) {
                                                foreach ($sections as $section) { ?>
                                                    <option value="<?php echo htmlspecialchars($section->sectionName); ?>" <?php echo set_select('sectionName', $section->sectionName); ?>>
                                                        <?php echo htmlspecialchars($section->sectionName); ?>
                                                    </option>
                                            <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6" id="studentSelection" style="display: none;">
                                    <div class="form-group">
                                        <label for="students">Select Students</label>
                                        <select class="students form-control" id="students" name="students[]" multiple data-live-search="true">
                                            <option value="">Select class and section</option>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="eventS3attachment">Image Attachments (in ZIP Format)</label>
                                        <input type="file" name="files[]" class="form-control" multiple />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="eventvideoS3attachment">Video Attachments (in ZIP Format)</label>
                                        <input type="file" name="file2" class="form-control" multiple accept=".zip" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description" rows="6" required><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-3">
                <?php
                $error = $this->session->flashdata('error');
                if ($error): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>


<style type="text/css">
    .re-mend-field {
        color: red;
    }
</style>

<script>
    CKEDITOR.replace('description', {});

    $(document).ready(function() {
        // Initialize Bootstrap Select
        $('.selectpicker').selectpicker();

        // Function to populate class and section selects with "Select All" option
        function populateSelectWithSelectAll(selectElement, options, defaultOptionText) {
            selectElement.empty().append(`<option value="">${defaultOptionText}</option>`).append('<option value="select_all">Select All</option>');
            $.each(options, function(index, option) {
                selectElement.append(`<option value="${option.value}">${option.text}</option>`);
            });
            selectElement.selectpicker('refresh');
        }

        // Function to toggle visibility of class, section, and student fields
        function toggleFields() {
            const classType = $('#classType').val();
            if (classType === 'classwise') {
                $('#classSelection').show();
                $('#className').prop('required', true).selectpicker('val', '').selectpicker('refresh');
                $('#sectionSelection').show();
                $('#sectionName').prop('required', true).selectpicker('val', '').selectpicker('refresh');
                $('#studentSelection').show();
                $('#students').prop('required', true).empty().append('<option value="">Select class and section</option>').selectpicker('refresh');
                fetchStudents();
            } else {
                $('#classSelection').hide();
                $('#className').prop('required', false).selectpicker('val', '').selectpicker('refresh');
                $('#sectionSelection').hide();
                $('#sectionName').prop('required', false).selectpicker('val', '').selectpicker('refresh');
                $('#studentSelection').hide();
                $('#students').prop('required', false).empty().append('<option value="">Select class and section</option>').selectpicker('refresh');
            }
        }

        // Set default selection to "All" and initialize visibility
        $('#classType').val('all').selectpicker('refresh');
        toggleFields();

        // Handle classType change
        $('#classType').on('change', function() {
            toggleFields();
        });

        // Handle class, section, or franchise change to fetch students
        $('#className, #sectionName, #franchiseNumber').on('change', function() {
            if ($('#classType').val() === 'classwise') {
                fetchStudents();
            }
        });

        // Handle "Select All" for className
        $('#className').on('change', function() {
            const selectedValues = $(this).val() || [];
            if (selectedValues.includes('select_all')) {
                const allOptions = $(this).find('option').map(function() {
                    return $(this).val();
                }).get().filter(val => val !== 'select_all' && val !== '');
                $(this).selectpicker('val', allOptions);
            }
        });

        // Handle "Select All" for sectionName
        $('#sectionName').on('change', function() {
            const selectedValues = $(this).val() || [];
            if (selectedValues.includes('select_all')) {
                const allOptions = $(this).find('option').map(function() {
                    return $(this).val();
                }).get().filter(val => val !== 'select_all' && val !== '');
                $(this).selectpicker('val', allOptions);
            }
        });

        // Handle "Select All" for students
        $('#students').on('change', function() {
            const selectedValues = $(this).val() || [];
            if (selectedValues.includes('select_all')) {
                const allOptions = $(this).find('option').map(function() {
                    return $(this).val();
                }).get().filter(val => val !== 'select_all' && val !== '');
                $(this).selectpicker('val', allOptions);
            }
        });

        // Function to fetch students via AJAX
        function fetchStudents() {
            const classNames = $('#className').val() || [];
            const sectionNames = $('#sectionName').val() || [];
            const franchiseNumber = $('#franchiseNumber').val();
            const studentSelect = $('#students');

            studentSelect.empty().append('<option value="">Loading students...</option>').selectpicker('refresh');

            if (classNames.length > 0 && sectionNames.length > 0 && franchiseNumber && $('#classType').val() === 'classwise') {
                $.ajax({
                    url: '<?php echo base_url("studenteventgallery/getStudentsByFranchiseClassAndSection"); ?>',
                    type: 'POST',
                    data: {
                        franchiseNumber: franchiseNumber,
                        classNames: classNames.filter(val => val !== 'select_all'),
                        sectionNames: sectionNames.filter(val => val !== 'select_all'),
                        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.csrfName && response.csrfHash) {
                            $('[name="' + response.csrfName + '"]').val(response.csrfHash);
                        }
                        studentSelect.empty();
                        if (response.status === 'success' && response.students && response.students.length > 0) {
                            studentSelect.append('<option value="select_all">Select All</option>');
                            $.each(response.students, function(index, student) {
                                studentSelect.append(`<option value="${student.admid}">${student.name}</option>`);
                            });
                            studentSelect.selectpicker('refresh');
                        } else {
                            studentSelect.append('<option value="">No students found</option>').selectpicker('refresh');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching students:', status, error, xhr.responseText);
                        studentSelect.empty().append('<option value="">Error fetching students</option>').selectpicker('refresh');
                        $('.col-md-3').prepend('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert">×</button>Error fetching student data: ' + error + '</div>');
                    }
                });
            } else {
                studentSelect.empty().append('<option value="">Select class and section</option>').selectpicker('refresh');
            }
        }

        // Prevent multiple form submissions
        const form = document.getElementById('addstudenteventgallery');
        const submitBtn = document.getElementById('submitBtn');
        form.addEventListener('submit', function(e) {
            if (submitBtn.disabled) {
                e.preventDefault();
                return;
            }
            submitBtn.disabled = true;
            submitBtn.innerText = 'Submitting...';
        });

        // Initialize on page load
        const franchiseInput = $('#franchiseNumber');
        if (franchiseInput.length && franchiseInput.val()) {
            fetchAssignedFranchise(franchiseInput.val());
        }

        // Handle franchise number change
        $('#franchiseNumber').on('change', function() {
            const franchiseNumber = $(this).val();
            fetchAssignedFranchise(franchiseNumber);
            if ($('#classType').val() === 'classwise') {
                fetchStudents();
            }
        });

        // CKEditor initialization
        CKEDITOR.replace('description', {});
    });

    // Function to fetch assigned franchise users
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue');
        if (assignedDiv) assignedDiv.innerHTML = '<span>Loading...</span>';

        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("studenteventgallery/fetchAssignedUsers"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    console.log("fetchAssignedFranchise Response:", response);
                    if (response.status === 'success' && response.html) {
                        if (assignedDiv) assignedDiv.innerHTML = response.html;
                        if (hiddenInput) hiddenInput.value = response.userIds || '';
                    } else {
                        if (assignedDiv) assignedDiv.innerText = 'No Growth Manager assigned';
                        if (hiddenInput) hiddenInput.value = '';
                    }
                },
                error: function(xhr, status, error) {
                    console.error("fetchAssignedFranchise Error: ", status, error, xhr.responseText);
                    if (assignedDiv) assignedDiv.innerText = 'Error fetching Growth Manager';
                    if (hiddenInput) hiddenInput.value = '';
                    $('.col-md-3').prepend('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert">×</button>Error fetching Growth Manager data</div>');
                }
            });
        } else {
            if (assignedDiv) assignedDiv.innerText = 'Select a franchise to assign';
            if (hiddenInput) hiddenInput.value = '';
        }
    } 
</script>
</body>

</html>