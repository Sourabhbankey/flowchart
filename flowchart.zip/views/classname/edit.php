<?php
$classId = $ClassnameInfo->classId;
$className = $ClassnameInfo->className;
$classNumeric = $ClassnameInfo->classNumeric;

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> 
        <small>Add / Edit Class</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter  Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>classname/editclassname" method="post" id="editclassname" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="className">Class <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $className; ?>" id="className" name="className" maxlength="256" />
                                        <input type="hidden" value="<?php echo $classId; ?>" name="classId" id="classId" />
                                    </div>
                                    
                                </div>
                              
                               
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="classNumeric">Class Numeric <span class="re-mend-field">*</span></label>
                                        <input  type="text" class="form-control required" value="<?php echo $classNumeric; ?>" id="classNumeric" name="classNumeric" maxlength="256">
                                    </div>   
                                </div>
                                
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>