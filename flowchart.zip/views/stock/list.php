<div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <h1>

        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Stock Management

        <small>Add, Edit, Delete</small>

      </h1>

    </section>

    <section class="content">

        <div class="row">

            <div class="col-xs-12 text-right">

                <div class="form-group">

                    <a class="btn btn-primary" href="<?php echo base_url(); ?>stock/add"><i class="fa fa-plus"></i> Add New Stock</a>

                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-md-12">

                <?php

                    $this->load->helper('form');

                    $error = $this->session->flashdata('error');

                    if($error)

                    {

                ?>

                <div class="alert alert-danger alert-dismissable">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <?php echo $this->session->flashdata('error'); ?>                    

                </div>

                <?php } ?>

                <?php  

                    $success = $this->session->flashdata('success');

                    if($success)

                    {

                ?>

                <div class="alert alert-success alert-dismissable">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <?php echo $this->session->flashdata('success'); ?>

                </div>

                <?php } ?>

                

                <div class="row">

                    <div class="col-md-12">

                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>

                    </div>

                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-xs-12">

              <div class="box">

                <div class="box-header">

                    <h3 class="box-title">Stock List</h3>          

                    <form action="<?php echo base_url('stock/stockListing'); ?>" method="POST" id="searchList">

                        <div class="col-md-6">    

                                <div class="form-group">

                                         <label for="productName">Product Code</label>

                                    <!-- Product Code Dropdown -->

                                    <select name="productCode" class="form-control input-sm" style="margin-right: 10px;">

                                        <option value="">Select Product Code</option>

                                        <?php foreach ($productCodes as $code): ?>

                                            <option value="<?php echo $code['productCode']; ?>" <?php echo ($code['productCode'] == $productCode) ? 'selected' : ''; ?>>

                                                <?php echo $code['productCode']; ?>

                                            </option>

                                        <?php endforeach; ?>

                                    </select>

                                </div>  

                             <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>     

                        </div>

                        <!-- Product Name Dropdown -->

                        <div class="col-md-6">    

                            <div class="form-group">

                                <label for="productName">Product Code</label>

                                <select name="productName" class="form-control input-sm" style="margin-right: 10px;">

                                    <option value="">Select Product Name</option>

                                    <?php foreach ($productNames as $name): ?>

                                        <option value="<?php echo $name['productName']; ?>" <?php echo ($name['productName'] == $productName) ? 'selected' : ''; ?>>

                                            <?php echo $name['productName']; ?>

                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>  

                            <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>     

                        </div>

                    </form>

                    <!-- </div> -->

                </div><!-- /.box-header>-->

                <div class="box-body table-responsive no-padding">

                  <table id="example" class="display responsive nowrap" style="width:100%">

                     <thead>

                        <tr>

                        <th>Sr. No.</th>

                        <th>Product Code</th>

                        <th>Product Name</th>

                        <th>Opening Stock </th>

                        <th>Opening Stock Date</th>

                        <th>Current Stock</th>


                       <th>Image</th>

                        <th>Product Description</th>

                        <th>Created On</th>

                        

                         </tr>

                    </thead>

                     <tbody>

                        <?php

                        if(!empty($records))

                        {

                            foreach($records as $record)

                            {

                        ?>

                        <tr>

                            <td><?php echo $record->stockId ?></td>

                            <td><?php echo $record->productCode ?></td>

                            <td><?php echo $record->productName ?></td>

                            <td><?php echo $record->openingStock ?></td>

                             <td><?php echo $record->openingStockDate ?></td>

                            <td><?php //echo $record->currentStock ?>
                                    <?php 
                                        echo $record->currentStock; 
                                        if ($record->currentStock < 50) {
                                            echo ' <span class="badge bg-danger" style="background-color: #dd4b39;">Re-Order Now</span>';
                                        }
                                    ?>
                            </td>
                            <td>
                                <?php if (!empty($record->stockattachment)): ?>
                                    <img src="<?= $record->stockattachment ?>" alt="Stock Image" width="100" height="80"><br>
                                    <a href="<?= $record->stockattachment ?>" target="_blank" class="btn btn-sm btn-primary mt-2">View</a>
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                            <td class="ac-desc-breakcls"><?php echo $record->description ?></td>

                            <td><?php echo date("d-m-Y", strtotime($record->createdDtm)) ?></td>

                          

                        </tr>

                        <?php

                            }

                        }

                        ?>

                       </tbody>

                  </table>

                  

                </div><!--.box-body -->

                    <div class="box-footer clearfix">

                       <div class="br-pagi">

                          <?php echo $pagination; ?><br>

                           Showing <?php echo $startRecord; ?> to <?php echo $endRecord; ?> of <?php echo $totalRecords; ?> entries

                        </div>

                    </div>

              </div><!-- /.box -->

            </div>

        </div>

    </section>

</div>

<style type="text/css">

    tr:nth-child(even) {

        background-color: #D6EEEE !important;

    }



    /*table-css*/

    table.dataTable>tbody>tr.child span.dtr-title {

        display: inline-block;

        /*min-width: 75px;*/

        min-width: 50%;

        font-weight: bold;

    }



    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,

    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {

        position: relative;

        padding-left: 30px;

        cursor: pointer;

    }



    div.dataTables_wrapper li {

        text-indent: 0;

    }



    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,

    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {

        content: "-";

        background-color: #d33333;

    }



    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,

    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {

        top: 50%;

        left: 5px;

        height: 1em;

        width: 1em;

        margin-top: -9px;

        display: block;

        position: absolute;

        color: white;

        border: .15em solid white;

        border-radius: 1em;

        box-shadow: 0 0 .2em #444;

        box-sizing: content-box;

        text-align: center;

        text-indent: 0 !important;

        font-family: "Courier New", Courier, monospace;

        line-height: 1em;

        content: "+";

        background-color: #31b131;

    }



    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,

    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {

        top: 50%;

        left: 5px;

        height: 1em;

        width: 1em;

        margin-top: -9px;

        display: block;

        position: absolute;

        color: white;

        border: .15em solid white;

        border-radius: 1em;

        box-shadow: 0 0 .2em #444;

        box-sizing: content-box;

        text-align: center;

        text-indent: 0 !important;

        font-family: "Courier New", Courier, monospace;

        line-height: 1em;

        content: "+";

        background-color: #31b131;

    }

/* Ensure text wrapping for the dtr-data span */

.dtr-data {

    white-space: normal !important;

    /* word-wrap: break-word !important; */

    /* word-break: break-word !important; */

    display: inline-block !important;

    max-width: 50%;

}



/* Optional: Add some margin to the description for better visibility */

.dtr-details li {

    margin-bottom: 8px;

}



</style>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>

<script type="text/javascript">

    jQuery(document).ready(function(){

        jQuery('ul.pagination li a').click(function (e) {

            e.preventDefault();            

            var link = jQuery(this).get(0).href;            

            var value = link.substring(link.lastIndexOf('/') + 1);

            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);

            jQuery("#searchList").submit();

        });

    });

</script>

<script type="text/javascript">

    jQuery(document).ready(function() {

        jQuery('#example').DataTable();

    });

</script>

<!-- DataTables Select CSS -->

<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->



<!-- DataTables Select JS -->

<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>

<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

