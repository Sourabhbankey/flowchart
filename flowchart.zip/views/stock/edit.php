<?php
$stockId = $stockInfo->stockId;
$productCode = $stockInfo->productCode;
$productName = $stockInfo->productName;
$openingStockDate = $stockInfo->openingStockDate;
$openingStock = $stockInfo->openingStock;
$currentStock = $stockInfo->currentStock;
$prodQuantity = $stockInfo->prodQuantity;
$description = $stockInfo->description;
$productType = $stockInfo->productType;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Stock Management
        <small>Add / Edit Stock</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Stock Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>stock/editStock" method="post" id="editStock" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productName">Product Name</label>
                                        <select class="form-control required" id="productName" name="productName" required >
                                           <option value="<?php echo $productName; ?>" <?php echo "selected=selected"; ?>><?php echo $productName; ?></option>
                                          <option value="Toy">Toy</option>
                                          <option value="Moon Table">Moon Table</option>
                                          <option value="Chair">Chair</option>
                                          <option value="Easy KIT">Easy KIT</option>
                                          <option value="Pen">Pen</option>
                                        </select>
                                        <input type="hidden" value="<?php echo $stockId; ?>" name="stockId" id="stockId" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="trainingTitle">Product Code <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="productCode" name="productCode" required >
                                           <option value="<?php echo $productCode; ?>" <?php echo "selected=selected"; ?>><?php echo $productCode; ?></option>
                                           <option value="ES01">ES01</option>
                                          <option value="ES02">ES02</option>
                                          <option value="ES03">ES03</option>
                                          <option value="ES04">ES04</option>
                                          <option value="ES05">ES05</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="openingStock">Opening Stock </label>
                                        <input required type="text" class="form-control required" value="<?php echo $openingStock; ?>" id="openingStock" name="openingStock" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="openingStockDate">Opening Stock Date</label>
                                        <input required type="date" class="form-control required" value="<?php echo $openingStockDate; ?>" id="openingStockDate" name="openingStockDate" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="currentStock">Current Stock</label>
                                        <input required type="text" class="form-control required" value="<?php echo $currentStock; ?>" id="currentStock" name="currentStock" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
    <div class="form-group">
        <label for="currentStock">Current Stock</label>
        <select required class="form-control required" id="currentStock" name="currentStock">
            <option value="sales" <?php echo ($currentStock == 'sales') ? 'selected' : ''; ?>>Sales</option>
            <option value="free gift" <?php echo ($currentStock == 'free gift') ? 'selected' : ''; ?>>Free Gift</option>
            <option value="sample" <?php echo ($currentStock == 'sample') ? 'selected' : ''; ?>>Sample</option>
            <option value="damaged" <?php echo ($currentStock == 'damaged') ? 'selected' : ''; ?>>Damaged</option>
        </select>
    </div>
</div>

                                 <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Product Quantity</label>
                                        <input type="text" class="form-control required" value="<?php //echo $prodQuantity; ?>" id="prodQuantity" name="prodQuantity" maxlength="256" />
                                    </div>
                                    
                                </div> -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="description">Product Description</label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
	   <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('stock/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>