<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-user-circle-o"></i> Stock Management <small>Add / Edit Stock</small></h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- Left column -->
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Stock Details</h3>
                    </div>

                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?= base_url() ?>stock/addNewStock" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="productCode">Product Code</label>
                                        <input required type="text" class="form-control" value="<?= set_value('productCode'); ?>" id="productCode" name="productCode" />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="productName">Product Name</label>
                                        <input required type="text" class="form-control" value="<?= set_value('productName'); ?>" id="productName" name="productName" />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="openingStock">Opening Stock</label>
                                        <input required type="text" class="form-control" value="<?= set_value('openingStock'); ?>" id="openingStock" name="openingStock" />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="openingStockDate">Opening Stock Date</label>
                                        <input required type="date" class="form-control" value="<?= set_value('openingStockDate'); ?>" id="openingStockDate" name="openingStockDate" />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="currentStock">Current Stock</label>
                                        <input required type="text" class="form-control" value="<?= set_value('currentStock'); ?>" id="currentStock" name="currentStock" />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="productType">Product Type</label>
                                        <select required class="form-control" id="productType" name="productType">
                                            <option value="sales" <?= set_select('productType', 'sales', true); ?>>Sales</option>
                                            <option value="free gift" <?= set_select('productType', 'free gift'); ?>>Free Gift</option>
                                            <option value="sample" <?= set_select('productType', 'sample'); ?>>Sample</option>
                                            <option value="damaged" <?= set_select('productType', 'damaged'); ?>>Damaged</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="kitName">Select Kit</label>
                                        <select class="form-control" id="kitName" name="kitName">
                                            <option value="">Select Kit</option>
                                            <option value="nursery">Nursery Kit</option>
                                            <option value="pg">PG Kit</option>
                                            <option value="KG1">KG1</option>
                                            <option value="Kg2">Kg2</option>
                                             <option value="Installation kit">Installation kit</option>
                                             <option value="Conversion Kit">Conversion Kit</option>
                                        </select>
                                    </div>
                                </div>

                                <div id="kitItemsContainer" class="col-md-12">
                                    <!-- Kit items via JS -->
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Product Description</label>
                                        <textarea required class="form-control" id="description" name="description"></textarea>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="file">Attachment (optional)</label>
                                        <input type="file" class="form-control" id="file" name="file" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <!-- Right Column: Alerts -->
            <div class="col-md-4">
                <?php if ($this->session->flashdata('error')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?= $this->session->flashdata('error'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('success')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?= $this->session->flashdata('success'); ?>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?= validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Scripts -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        filebrowserUploadUrl: "<?= base_url('stock/upload'); ?>",
        filebrowserUploadMethod: 'form'
    });

    document.getElementById('yourForm').addEventListener('submit', function (e) {
        const btn = document.getElementById('submitBtn');
        if (btn.disabled) {
            e.preventDefault();
            return;
        }
        btn.disabled = true;
        btn.value = 'Submitting...';
    });

    $('#kitName').change(function () {
        const kit = $(this).val();
        if (kit !== '') {
            $.ajax({
                url: '<?= base_url("stock/getKitItems") ?>',
                type: 'POST',
                dataType: 'json',
                data: { kitName: kit },
                success: function (items) {
                    let html = '<h4>Kit Items</h4><div class="row">';
                    items.forEach((item, i) => {
                        html += `
                            <div class="col-md-4"><div class="form-group">
                                <label>Product Code</label>
                                <input type="text" class="form-control" readonly name="kitItems[${i}][productCode]" value="${item.productCode}">
                            </div></div>
                            <div class="col-md-4"><div class="form-group">
                                <label>Product Name</label>
                                <input type="text" class="form-control" readonly name="kitItems[${i}][productName]" value="${item.productName}">
                            </div></div>
                            <div class="col-md-4"><div class="form-group">
                                <label>Quantity</label>
                                <input type="number" class="form-control" readonly name="kitItems[${i}][quantity]" value="${item.quantity}">
                            </div></div>`;
                    });
                    html += '</div>';
                    $('#kitItemsContainer').html(html);
                }
            });
        } else {
            $('#kitItemsContainer').html('');
        }
    });
</script>
