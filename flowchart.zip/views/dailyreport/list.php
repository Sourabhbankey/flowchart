<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Dailyreport Record Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>dailyreport/add"><i class="fa fa-plus"></i> Add New  Record</a>
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>dailyreport/talkTimeReport"><i class="fa fa-plus"></i> View Talktime report </a>
                </div> 
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <label for="resultrecordlist">Search By User</label>
                        <form action="<?php echo base_url() ?>dailyreport/dailyreportListing" method="GET" id="searchUser">
    <div class="row">
        <!-- User Filter -->
        <div class="col-md-3">
           
            <select name="searchUserId" class="form-control-old input-sm">
                <option value="">All Users</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?php echo $user->userId; ?>" 
                        <?php echo ($searchUserId == $user->userId) ? 'selected' : ''; ?>>
                        <?php echo $user->name; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Date Filters -->
        <div class="col-md-3">
            <label for="fromDate">From Date</label>
            <input type="date" name="fromDate" value="<?php echo $fromDate; ?>" class="form-control-old input-sm"/>
        </div>
        
        <div class="col-md-3">
            <label for="toDate">To Date</label>
            <input type="date" name="toDate" value="<?php echo $toDate; ?>" class="form-control-old input-sm"/>
        </div>

        <!-- Search & Reset Buttons -->
        <div class="col-md-3">
            <label>&nbsp;</label>
            <div>
                <button type="submit" class="btn btn-primary btn-sm btn-default" style="color: #fff;">
                    <i class="fa fa-search"></i> Search
                </button>
                <a href="<?php echo base_url() ?>dailyreport/dailyreportListing" class="btn btn-secondary btn-sm">
                    <i class="fa fa-refresh"></i> Reset
                </a>
            </div>
        </div>
    </div>
</form>

                    </div>
            </div>
        </div> 
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Record List</h3>

                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                  <table id="example" class="display responsive nowrap table table-hover">
                    <thead>
                    <tr>
                        <th>Sr. No.</th>
                         <?php if ($userRole != 29) { ?>
                            <th>User Name</th>
                        <?php } ?>
                        <th>Date</th>
                        <th>Talktime</th>
                        <th>No of Fresh Calls</th>
                        <th>No of Total Connected Calls</th>
                        <th>No of Old Followups</th>
                        <th>No of Recording Shared</th>
                        <th>Prospects</th>
                        <th>Virtual Meetings</th>
                        
                        <th>Converted</th>
                        <!-- <th>Description</th> -->
                        <th class="text-center">Actions</th>

                        
                    </tr>
                    </thead>
                 <tbody>
                   <?php
                    if(!empty($records))
                    { $counter = 1;
                        foreach($records as $record)
                        {
                    ?>
                    <tr>
                         <td><?php echo $counter++; ?></td>
                          <?php if ($userRole != 29) { ?>
                            <td><?php echo $record->userName; ?></td>
                        <?php } ?>
                        <td><?php echo $record->date ?></td>
                        <td><?php echo $record->talktime ?></td>
                        <td><?php echo $record->nooffreshcalls  ?></td>
                        <td><?php echo $record->nooftotalconnectedcalls  ?></td>
                        <td><?php echo $record->noofoldfollowups  ?></td>
                        <td><?php echo $record->noofrecordingshared  ?></td>
                        <td><?php echo $record->prospects ?></td>
                        <td><?php echo $record->virtualmeetings ?></td>
                        <td><?php echo $record->converted ?></td>
                        <!-- <td><?php //echo $record->description ?></td> -->
                        <td class="text-center">
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'dailyreport/edit/'.$record->dailyreportId; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                            <a class="btn btn-sm btn-danger deleteStock" href="#" data-salesrecId="<?php echo $record->dailyreportId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                        </td>

                   
                    </tr>
                   <?php
                        }
                    }
                    ?>
                  </tbody>


                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <div class="br-pagi">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

