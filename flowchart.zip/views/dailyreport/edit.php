<?php
$dailyreportId = $dailyreportrecordInfo->dailyreportId;
 $date  = $dailyreportrecordInfo->date ;
 
 $nooffreshcalls  = $dailyreportrecordInfo->nooffreshcalls ;
 $nooftotalconnectedcalls = $dailyreportrecordInfo->nooftotalconnectedcalls;
  $virtualmeetings = $dailyreportrecordInfo->virtualmeetings;
 $noofoldfollowups  = $dailyreportrecordInfo->noofoldfollowups ;
 $noofrecordingshared = $dailyreportrecordInfo->noofrecordingshared;
 $prospects = $dailyreportrecordInfo->prospects;
  $converted = $dailyreportrecordInfo->converted;

 $talktime = $dailyreportrecordInfo->talktime;


 $description = $dailyreportrecordInfo->description;



?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i>  Record Management
        <small>Add / Edit Daily Report Record</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Daily Report Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>dailyreport/editdailyreportrecord" method="post" id="editdailyreportrecord" role="form">
                        <div class="box-body">
                        <div class="row">
                                <input type="hidden" name="dailyreportId" value="<?php echo $dailyreportId; ?>">
                            
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="issuedon">Date</label>
                                        <input required type="date" class="form-control required" value="<?php echo $date; ?>" id="date" name="date" maxlength="256" />
                                    </div>
                                </div>
                               
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity"> No of fresh calls</label>
                                        <input required type="text" class="form-control required" value="<?php echo $nooffreshcalls; ?>" id="nooffreshcalls" name="nooffreshcalls" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">No of total connected calls </label>
                                        <input required type="text" class="form-control required" value="<?php echo $nooftotalconnectedcalls; ?>" id="nooftotalconnectedcalls" name="nooftotalconnectedcalls" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">No Of Old Followups</label>
                                        <input required type="text" class="form-control required" value="<?php echo $noofoldfollowups; ?>" id="noofoldfollowups" name="noofoldfollowups" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">No of Recording shared</label>
                                        <input required type="text" class="form-control required" value="<?php echo $noofrecordingshared; ?>" id="noofrecordingshared" name="noofrecordingshared" maxlength="256" />
                                    </div>
                                </div> 
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Prospects</label>
                                        <input required type="text" class="form-control required" value="<?php echo $prospects; ?>" id="prospects" name="prospects" maxlength="256" />

                                    </div>
                                </div>    
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">No Of Virtual Meetings</label>
                                        <input required type="text" class="form-control required" value="<?php echo $virtualmeetings; ?>" id="virtualmeetings" name="virtualmeetings" maxlength="256" />

                                    </div>
                                </div>    
                                    <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Converted</label>
                                        <input required type="text" class="form-control required" value="<?php echo $converted; ?>" id="converted" name="converted" maxlength="256" />
                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Talktime</label>
                                        <input required type="text" class="form-control required" value="<?php echo $talktime; ?>" id="talktime" name="talktime" maxlength="256" />
                                    </div>
                                </div> 
                                
                              
                                
                               <!--  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Description</label>
                                        <textarea required class="form-control required" id="description" name="description" maxlength="256" rows="4"><?php //echo $description; ?></textarea>

                                    </div>
                                </div>   -->
                              

                               
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>