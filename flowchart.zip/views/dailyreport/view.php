<div class="content-wrapper">
    <section class="content-header">
        <h1><i class="fa fa-clock-o"></i> Talk Time Report <small>Monthly Report</small></h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Select Month</h3>
                        <div class="pull-right">
                            <select id="monthFilter" class="form-control">
                                <?php
                                for ($m = 1; $m <= 12; $m++) {
                                    $monthValue = str_pad($m, 2, '0', STR_PAD_LEFT);
                                    $selected = ($selectedMonth == $monthValue) ? "selected" : "";
                                    echo "<option value='$monthValue' $selected>" . date('F', mktime(0, 0, 0, $m, 1)) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="box-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User Name</th>
                                    <th>Total Talk Time (mins)</th>
                                    <th>Average Talk Time (mins)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($talkTimeStats)) { 
                                    $count = 1;
                                    foreach ($talkTimeStats as $row) { ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td><?php echo $row->name; ?></td>
                                            <td><?php echo round($row->total_talktime, 2); ?></td>
                                            <td><?php echo round($row->avg_talktime, 2); ?></td>
                                        </tr>
                                    <?php } 
                                } else { ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No data available for this month</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="box-footer">
                        <a href="<?php echo base_url('dailyreport'); ?>" class="btn btn-primary">
                            <i class="fa fa-arrow-left"></i> Back to Reports
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </section>
</div>

<script>
    document.getElementById("monthFilter").addEventListener("change", function() {
        let selectedMonth = this.value;
        window.location.href = "<?php echo base_url('dailyreport/talkTimeReport?month='); ?>" + selectedMonth;
    });
</script>
