<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Purchase Records Management
        <small>Add / Edit Purchase Records</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Purchase Records Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>purchaserecord/addNewPurchaserecord" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productCode">Product Code</label>
                                         <select class="form-control required" id="product_code" name="productCode" required>
                                        <?php foreach ($codes as $code): ?>
                                            <option value="<?php echo $code['productCode']; ?>"><?php echo $code['productCode']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productName">Product Name</label>
                                          <select class="form-control required" id="product_name" name="productName" required>
                                <?php foreach ($name as $names): ?>
                                            <option value="<?php echo $names['productName']; ?>"><?php echo $names['productName']; ?></option>
                                        <?php endforeach; ?>
                                    <?php //endif; ?>
                                </select>
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                <div class="form-group">
                                    <label for="requestDate">Date of request</label>
                                    <input required type="date" class="form-control required" id="requestDate" name="requestDate" value="<?php echo set_value('requestDate'); ?>">
                                </div>
                            </div>

                            <div class="col-md-4">                                
    <div class="form-group">
        <label for="requestRaisedBy">Request Raised By</label>
        <select class="form-control required" id="requestRaisedBy" name="requestRaisedBy" required>
            <option value="">Select</option>
            <option value="Godown">Godown</option>
            <option value="Purchase Manager">Purchase Manager</option>
            <option value="Management">Management</option>
        </select>
    </div>
</div>


<div class="col-md-4">                                
    <div class="form-group">
        <label for="quantityRequested">Quantity Requested</label>
        <input required type="number" class="form-control required" id="quantityRequested" name="quantityRequested" value="<?php echo set_value('quantityRequested'); ?>">
    </div>
</div>


<!-- FOR PURCHASE MANAGER -->


                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfOrderplaced">Date Of Order Placed</label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateOfOrderplaced'); ?>" id="dateOfOrderplaced" name="dateOfOrderplaced" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderQty">Order Quantity</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('orderQty'); ?>" id="orderQty" name="orderQty" maxlength="256" />
                                    </div>
                                </div>
                               <!--  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="boughtFrom">Bought From (Vendor)</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('boughtFrom'); ?>" id="boughtFrom" name="boughtFrom" maxlength="256" />
                                    </div>
                                </div> -->
                                                              <div class="col-md-4">
                            <div class="form-group">
                                <label for="defective_from">Bought From</label>
                                <select class="form-control" id="defective_from" name="boughtFromVenderlist" required>
                                    <option value="TCD">TCD</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-4" id="other_source_div" style="display:none;">
                            <div class="form-group">
                                <label for="boughtFrom">Vendor Name</label>
                                <input type="text" class="form-control" id="boughtFrom" name="boughtFrom">
                            </div>
                        </div>
                        <!-- ACCOUNTS  -->

                        <div class="col-md-4">                                
    <div class="form-group">
        <label for="amountPaid">Amount Paid</label>
        <input required type="number" class="form-control required" id="amountPaid" name="amountPaid" value="<?php echo set_value('amountPaid'); ?>">
    </div>
</div>

<!-- Amount Paid Date -->
<div class="col-md-4">                                
    <div class="form-group">
        <label for="amountPaidDate">Amount Paid Date</label>
        <input required type="date" class="form-control required" id="amountPaidDate" name="amountPaidDate" value="<?php echo set_value('amountPaidDate'); ?>">
    </div>
</div>

<div class="col-md-12">                                
    <div class="form-group">
        <label for="invoiceAttachment">Invoice Attachment</label>
        <input type="file" class="form-control" id="invoiceAttachment" name="invoiceAttachment">
    </div>
</div>
     <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="purchaseReceived">Order Received On</label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('purchaseReceived'); ?>" id="purchaseReceived" name="purchaseReceived" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="receivedQty">Received Quantity</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('receivedQty'); ?>" id="receivedQty" name="receivedQty" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                      
                                        <input  type="hidden" class="form-control required" value="<?php echo set_value('updatedStock'); ?>" id="updatedStock" name="updatedStock" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-12">
                                <div class="form-group">
                                    <label for="file">Attachment (optional)</label>
                                    <input type="file" class="form-control" id="file" name="file">
                                </div>
                            </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Remark - Description</label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
	   <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('purchaserecord/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
        <script>
    $(document).ready(function() {
        $('#product_code').select2({
            placeholder: 'Select a product code',
            allowClear: true
        });
    });
</script>
<script>
    $(document).ready(function(){
        $('#product_code').change(function(){
            var productCode = $(this).val();

            if(productCode) {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url('salesrecord/get_product_names'); ?>', // URL to call controller method
                    data: {productCode: productCode},
                    success: function(response) {
                        $('#product_name').html(response); // Populate the product name dropdown
                    }
                });
            } else {
                $('#product_name').html('<option value="">Select Product Name</option>');
            }
        });
    });
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script>
    $(document).ready(function() {
        $('#defective_from').change(function() {
            if ($(this).val() === 'Others') {
                $('#other_source_div').show();
                $('#other_source').attr('required', true);
            } else {
                $('#other_source_div').hide();
                $('#other_source').val('');
                $('#other_source').removeAttr('required');
            }
        });
    });
</script>