<?php
$purcrecId = $purchaserecordInfo->purcrecId;
$productCode = $purchaserecordInfo->productCode;
$productName = $purchaserecordInfo->productName;
$dateOfOrderplaced = $purchaserecordInfo->dateOfOrderplaced;
$orderQty = $purchaserecordInfo->orderQty;
$boughtFrom = $purchaserecordInfo->boughtFrom;
$purchaseReceived = $purchaserecordInfo->purchaseReceived;
$receivedQty = $purchaserecordInfo->receivedQty;
$updatedStock = $purchaserecordInfo->updatedStock;
$qtySupplied = isset($purchaserecordInfo->qtySupplied) ? $purchaserecordInfo->qtySupplied : '';
$dateOfSupplied = isset($purchaserecordInfo->dateOfSupplied) ? $purchaserecordInfo->dateOfSupplied : '';
$description = $purchaserecordInfo->description;

$role = $this->session->userdata('role');

$is_role_36 = ($role == 36);

?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Purchase Record Management
            <small>Add / Edit Purchase Record</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Purchase Record Details</h3>
                    </div>

                    <form role="form" action="<?php echo base_url() ?>purchaserecord/editPurchaserecord" method="post" id="editPurchaserecord">
                        <div class="box-body">
                            <div class="row">

                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productCode">Product Code</label>
                                        <select class="form-control required" id="product_code" name="productCode" required
                                            <?= $is_role_36 ? 'disabled' : (!in_array($role, [1,14,36]) ? 'disabled' : ''); ?>>
                                            <?php foreach ($codes as $code): ?>
                                                <option value="<?php echo $code['productCode']; ?>" 
                                                    <?php echo ($code['productCode'] == $productCode) ? 'selected' : ''; ?>>
                                                    <?php echo $code['productCode']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productName">Product Name</label>
                                        <select class="form-control required" id="product_name" name="productName" required
                                            <?= $is_role_36 ? 'disabled' : (!in_array($role, [1,14,36]) ? 'disabled' : ''); ?>>
                                            <?php foreach ($name as $names): ?>
                                                <option value="<?php echo $names['productName']; ?>" 
                                                    <?php echo ($names['productName'] == $productName) ? 'selected' : ''; ?>>
                                                    <?php echo $names['productName']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfOrderplaced">Date Of Order Placed</label>
                                        <input type="date" class="form-control required" value="<?php echo $dateOfOrderplaced; ?>" id="dateOfOrderplaced" name="dateOfOrderplaced" 
                                            <?= $is_role_36 ? 'readonly' : ''; ?> />
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderQty">Order Quantity</label>
                                        <input required type="text" class="form-control required" value="<?php echo $orderQty; ?>" id="orderQty" name="orderQty"
                                            <?= $is_role_36 ? 'readonly' : ''; ?> />
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="purchaseReceived">Purchase Received On</label>
                                        <input type="date" class="form-control required" value="<?php echo $purchaseReceived; ?>" id="purchaseReceived" name="purchaseReceived"
                                            <?= $is_role_36 ? 'readonly' : ''; ?> />
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="receivedQty">Received Quantity</label>
                                        <input type="text" class="form-control required" value="<?php echo $receivedQty; ?>" id="receivedQty" name="receivedQty"
                                            <?= $is_role_36 ? 'readonly' : ''; ?> />
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="updatedStock">Updated Stock</label>
                                        <input type="text" class="form-control required" value="<?php echo $updatedStock; ?>" id="updatedStock" name="updatedStock"
                                            <?= $is_role_36 ? 'readonly' : ''; ?> />
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="qtySupplied">Qty Supplied</label>
                                        <input type="text" class="form-control" value="<?php echo $qtySupplied; ?>" id="qtySupplied" name="qtySupplied"
                                            <?= $is_role_36 ? '' : (in_array($role, [1,14]) ? '' : 'readonly'); ?> />
                                    </div>
                                </div>

                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfSupplied">Date of Supplied</label>
                                        <input type="date" class="form-control" value="<?php echo $dateOfSupplied; ?>" id="dateOfSupplied" name="dateOfSupplied"
                                            <?= $is_role_36 ? '' : (in_array($role, [1,14]) ? '' : 'readonly'); ?> />
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Remark Description</label>
                                        <textarea class="form-control required" id="description" name="description" <?= $is_role_36 ? 'readonly' : ''; ?>><?php echo $description; ?></textarea>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>


<?php if (!empty($replies)) { ?>
    <div class="box-footer mt-4">
        <h4>Previous Replies</h4>
        <div class="chat-container">

            <?php foreach ($replies as $reply) {
                // You can replace 'System Administrator' with the currently logged-in user's name if needed
               $currentUserName = $this->session->userdata('name');
$isSender = strtolower($reply->repliedByName) === strtolower($currentUserName);
                //$isSender = $reply->repliedById === $_SESSION['user_id']; // or similar
                //$isSender = strtolower($reply->repliedByName) === strtolower($_SESSION['user_name']);

                ?>
                <div class="chat-message <?php echo $isSender ? 'sender' : 'receiver'; ?>">
                    <div class="chat-header"><?php echo htmlspecialchars($reply->repliedByName); ?></div>
                    
                    <?php echo html_entity_decode($reply->message); ?>

                    <?php if (!empty($reply->attachment)): ?>
                        <div style="margin-top: 10px;">
                            <a href="<?php echo $reply->attachment ?>" target="_blank">
                                <button class="btn">
                                    <img src="<?php echo $reply->attachment ?>" style="height: 24px;width: 24px;"> View
                                </button>
                            </a>
                        </div>
                    <?php endif; ?>

                   
                    <div class="chat-meta">
    (<?php echo date('d M Y h:i A', strtotime($reply->createdDtm)); ?>)

    <?php if ($isSender): ?>
        <?php
            // Example: status = sent / delivered / read OR use read_at timestamp
            if (!empty($reply->read_at)) {
                $tickClass = 'tick read'; // ✓✓ in blue
            } elseif ($reply->status === 'delivered') {
                $tickClass = 'tick double'; // ✓✓ in gray
            } else {
                $tickClass = 'tick single'; // ✓ in gray
            }
        ?>
        <span class="<?php echo $tickClass; ?>"></span>
    <?php endif; ?>
</div>

                </div>
            <?php } ?>
        </div>
    </div>
<?php } ?>


                      <form role="form" action="<?php echo base_url('purchaserecord/addReply'); ?>" method="post" id="purchaseReplyForm" enctype="multipart/form-data">
    <div class="box-footer">
        
        <div class="form-group">
            <label for="replyMessage">Reply</label>
            <textarea required class="form-control" name="replyMessage" id="replyMessage" rows="5" placeholder="Write your reply here..."></textarea>
        </div>
        
        <div class="form-group">
            <label for="attachment">Attachment (Optional)</label>
            <input type="file" class="form-control" name="file1" id="file1" />
        </div>
        
        <input type="hidden" name="purcrecId" value="<?php echo $purcrecId; ?>" />
        <button type="submit" class="btn btn-success">Submit Reply</button>
    </div>
</form>
                </div>
            </div>

            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <?php echo $error; ?>                    
                </div>
                <?php } ?>
                
                <?php  
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description', {
        filebrowserUploadUrl: "<?= base_url('purchaserecord/upload'); ?>",
        filebrowserUploadMethod: 'form',
        readOnly: <?= $is_role_36 ? 'true' : 'false'; ?>
    });
</script>
<script>
    $(document).ready(function(){
        $('#product_code').change(function(){
            var productCode = $(this).val();

            if(productCode) {
                $.ajax({
                    type: 'POST',
                    url: '<?php echo base_url('salesrecord/get_product_names'); ?>',
                    data: {productCode: productCode},
                    success: function(response) {
                        $('#product_name').html(response);
                    }
                });
            } else {
                $('#product_name').html('<option value="">Select Product Name</option>');
            }
        });
    });
</script>
<style>
.chat-container {
    max-width: 90%;
    margin: auto;
    font-family: Arial, sans-serif;
    display: flex;
    flex-direction: column;
}

.chat-message {
    margin: 10px 0;
    max-width: 75%;
    padding: 10px 15px;
    border-radius: 10px;
    position: relative;
    word-wrap: break-word;
    clear: both;
}

.sender {
    align-self: flex-end;
    background-color: #dcf8c6; /* WhatsApp light green */
    border-bottom-right-radius: 0;
    text-align: left;
    width: 90%
}

.receiver {
    align-self: flex-start;
    background-color: #ffffff;
    border: 1px solid #ddd;
    border-bottom-left-radius: 0;
    text-align: left;
    width: 90%
}

.chat-meta {
    font-size: 12px;
    color: #777;
    margin-top: 5px;
}

.chat-header {
    font-weight: bold;
    font-size: 14px;
    margin-bottom: 4px;
}

.box-footer h4 {
    text-align: center;
    margin-top: 20px;
    color: #444;
    border-bottom: 1px solid #ccc;
    padding-bottom: 5px;
}
</style>
