<?php
date_default_timezone_set('Asia/Kolkata');
?>

<div class="content-wrapper">
    <!-- Content Header -->
    <section class="content-header">
        <h1>
            <i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo ($role == 25) ? 'My Dashboard' : 'Dashboard'; ?>
            <small>Control panel</small>
        </h1>
    </section>

    <?php if ($role == 25): ?>
        <section class="content-header">
            <div class="row">
                <div class="col-md-6">
                    <?php
                    $userId = $this->session->userdata('userId');
                    $query = $this->db->query('SELECT upattachmentS3File FROM tbl_users WHERE userId = ?', [$userId]);
                    $user = $query->row();
                    $profileImg = !empty($user->upattachmentS3File) ? base_url($user->upattachmentS3File) : '';
                    ?>
                    <img class="profile-user-img img-responsive img-circle1" src="<?php echo htmlspecialchars($profileImg); ?>" alt="User profile picture" style="margin: 0; width: auto;">
                </div>
                <div class="col-md-6 frnewbtn">
                    <h4>My Quick Links -</h4>
                    <a href="https://shop.theischool.com/" target="_blank"><button><i class="fa fa-shopping-basket" aria-hidden="true"></i> Shop Now</button></a>
                    <a href="https://play.google.com/store/apps/details?id=com.theischool.edumeta&pcampaignid=web_share" target="_blank"><button><img src="https://onboarding.edumeta.in/support-sms/assets/dist/img/playstoreicon.webp" style="width: 18px;"> Download App</button></a>
                    <a href="https://apps.apple.com/app/edumeta-diary/id6475728137" target="_blank"><button><i class="fa-brands fa-app-store-ios"></i> Download iOS App</button></a>
                    <a href="https://theischool.com/my_branch/" target="_blank"><button><i class="fa fa-globe" aria-hidden="true"></i> School Diary Dashboard</button></a>
                    <a href="<?php echo htmlspecialchars($this->session->userdata('customWebsiteLink')); ?>" target="_blank"><button><i class="fa fa-globe" aria-hidden="true"></i> Branch Website</button></a>
                    <a href="#" target="_blank"><button><i class="fa-brands fa-facebook-f"></i> Facebook</button></a>
                    <a href="#" target="_blank"><button><i class="fa-brands fa-instagram"></i> Instagram</button></a>
                    <a href="#" target="_blank"><button><i class="fa-brands fa-youtube"></i> YouTube</button></a>
                    <a href="#" target="_blank"><button><i class="fa fa-map" aria-hidden="true"></i> Google Map</button></a>
                    <a href="<?php echo base_url('announcement'); ?>" target="_blank"><button><i class="fa fa-bullhorn" aria-hidden="true"></i> Announcement</button></a>
                    <a href="<?php echo base_url('support/add'); ?>" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Schedule Meeting</button></a>
                    <a href="<?php echo base_url('guidelines/guidelinesListing'); ?>" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Guidelines</button></a>
                    <a href="<?php echo base_url('standardformat'); ?>" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Standard Format</button></a>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="content">
        <div class="row">
            <!-- Pending Queries -->
            <?php
            $userId = $this->session->userdata('userId');
            $query = $this->db->query(
                'SELECT COUNT(*) AS total FROM tbl_task WHERE assignedTo = ? OR assignedBy = ? OR FIND_IN_SET(?, collabrators)',
                [$userId, $userId, $userId]
            );
            $totalTasks = $query->row()->total ?? 0;
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>Pending Queries</h3>
                        <p>Total: <?php echo htmlspecialchars($totalTasks); ?></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-hourglass-half" style="color: #6cd4ed; font-size: 39px;"></i>
                    </div>
                    <a href="<?php echo base_url('ticket/ticketListing'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Admission Count -->
            <?php
            $franchiseNo = $this->session->userdata('franchiseNumber');
            $this->db->where('franchiseNumber', $franchiseNo);
            $count = $this->db->count_all_results('tbl_admission_details_2526');
            $isPrime = $count > 10;
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>Admission <?php echo $isPrime ? '🎉' : ''; ?></h3>
                        <p>Total: <?php echo htmlspecialchars($count); ?></p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-people" style="color: #6cd4ed"></i>
                    </div>
                    <a href="<?php echo base_url('admissiondetails'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Training Count -->
            <?php
            $query = $this->db->query('SELECT COUNT(*) AS total FROM tbl_training WHERE franchiseNumber = ?', [$franchiseNo]);
            $trainingCount = $query->row()->total ?? 0;
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3>Training</h3>
                        <p>Total: <?php echo htmlspecialchars($trainingCount); ?></p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-paper" style="color: #ecbba5;"></i>
                    </div>
                    <a href="<?php echo base_url('training'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Pending Orders -->
            <?php
            $query = $this->db->query('SELECT COUNT(*) AS total FROM tbl_despatch WHERE franchiseNumber = ? AND delStatus = 2', [$franchiseNo]);
            $despatchCount = $query->row()->total ?? 0;
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>Pending Orders</h3>
                        <p>Total: <?php echo htmlspecialchars($despatchCount); ?></p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-cart" style="color: #6cd4ed"></i>
                    </div>
                    <a href="<?php echo base_url('despatch'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Accounts -->
            <?php
            $query = $this->db->query('SELECT COUNT(*) AS total FROM tbl_despatch WHERE franchiseNumber = ?', [$franchiseNo]);
            $accountCount = $query->row()->total ?? 0;
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3>Accounts</h3>
                        <p>Total: <?php echo htmlspecialchars($accountCount); ?></p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-calculator" style="color: #ffeacc; font-size: 39px;"></i>
                    </div>
                    <a href="<?php echo base_url('account'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Pending Design -->
            <?php
            $query = $this->db->query(
                'SELECT COUNT(*) AS total FROM tbl_custom_desing WHERE franchiseNumber = ? AND (attachmentS3File IS NULL OR attachmentS3File = "")',
                [$franchiseNo]
            );
            $designCount = $query->row()->total ?? 0;
            ?>
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3>Pending Design</h3>
                        <p>Total: <?php echo htmlspecialchars($designCount); ?></p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-timer-outline" style="color: #6cd4ed"></i>
                    </div>
                    <a href="<?php echo base_url('customdesign/customdesignListing'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Connect to HO -->
            <div class="col-lg-3 col-xs-6">
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3>Connect to HO</h3>
                        <p>Click on More Button</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-chatboxes" style="color: #ecbba5;"></i>
                    </div>
                    <a href="<?php echo base_url('ticket/add'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

            <!-- Admission by Class -->
            <?php
            $classes = ['Nursery', 'Play Group', 'KG-1', 'KG-2', 'Toddlers', '1st'];
            $icons = [
                'Nursery' => 'ion-ios-book',
                'Play Group' => 'ion-ios-bookmarks',
                'KG-1' => 'ion-compose',
                'KG-2' => 'ion-university',
                'Toddlers' => 'ion-ios-briefcase',
                '1st' => 'ion-ios-paper'
            ];
            foreach ($classes as $class) {
                $query = $this->db->query('SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = ? AND franchiseNumber = ?', [$class, $franchiseNo]);
                $count = $query->row()->total ?? 0;
            ?>
                <div class="col-lg-3 col-xs-6">
                    <div class="small-box bg-orange">
                        <div class="inner">
                            <h3>Admission <?php echo htmlspecialchars($class); ?></h3>
                            <p>Total: <?php echo htmlspecialchars($count); ?></p>
                        </div>
                        <div class="icon">
                            <i class="ion <?php echo $icons[$class]; ?>" style="color: #fdf3d2"></i>
                        </div>
                        <a href="<?php echo base_url('admissiondetailsnew/admissiondetailsListing'); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- Student Birthday List -->
    <?php
    $query = $this->db->query(
        'SELECT admid, franchiseNumber, birthday, name FROM tbl_admission_details_2526 WHERE birthday IS NOT NULL AND franchiseNumber IS NOT NULL AND name IS NOT NULL AND MONTH(birthday) = MONTH(CURDATE()) AND DAY(birthday) >= DAY(CURDATE()) ORDER BY DAY(birthday) ASC'
    );
    $rows = $query->result();
    ?>
    <div class="col-md-12 col-lg-5 col-xl-5 panel">
        <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Student Birthday List</h4>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>S. No.</th>
                    <th>Branch No.</th>
                    <th>Birthday</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="4">No student birthdays found for the current month.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $index => $row): ?>
                        <tr class="<?php echo (date('m-d', strtotime($row->birthday)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary'); ?>">
                            <td><?php echo !empty($row->admid) ? htmlspecialchars($row->admid) : 'No Data'; ?></td>
                            <td><?php echo !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data'; ?></td>
                            <td><?php echo !empty($row->birthday) ? htmlspecialchars(date('F j, Y', strtotime($row->birthday))) : 'No Data'; ?></td>
                            <td><?php echo !empty($row->name) ? htmlspecialchars($row->name) : 'No Data'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Employee Birthday List -->
    <?php if (in_array($role, [1, 2, 14, 26, 25])): ?>
        <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Branch Employee Birthday List</h4>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Branch No</th>
                        <th>Birthday</th>
                        <th>Staff Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)): ?>
                        <tr>
                            <td colspan="3">No staff birthdays found for the current month.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($rows as $index => $row): ?>
                            <tr class="<?php echo (date('m-d', strtotime($row->birthday)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary'); ?>">
                                <td><?php echo !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data'; ?></td>
                                <td><?php echo !empty($row->birthday) ? htmlspecialchars(date('F j, Y', strtotime($row->birthday))) : 'No Data'; ?></td>
                                <td><?php echo !empty($row->name) ? htmlspecialchars($row->name) : 'No Data'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
    <?php
    date_default_timezone_set('Asia/Kolkata');

    $query = $this->db->query("
    SELECT 
        hronboardId,
        dob,
        first_name
    FROM tbl_hrforms_onboard
    WHERE dob IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(dob) = MONTH(CURDATE())
    AND DAY(dob) >= DAY(CURDATE())
    ORDER BY DAY(dob) ASC;
");

    $rows = $query->result();
    ?>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-6 col-xl-6 panel pg-fw">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title" id="admissionChartTitle"><?php echo date('Y'); ?> Admission Details</h4>
                <p class="card-category">Total Number of Admissions Per Month</p>
                <div style="display: flex; gap: 10px; align-items: center;">
                  <select id="admissionYearSelector" class="form-control" style="width: 100px; display: inline-block;">
                    <option value="<?php echo date('Y'); ?>" selected><?php echo date('Y'); ?></option>
                    <?php for ($i = date('Y') - 5; $i <= date('Y'); $i++) { ?>
                      <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                    <?php } ?>
                  </select>

                </div>
              </div>
              <div class="card-body">
                <div id="admissionChart" style="min-height: 350px; width: 100%;"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
</div>


 
    </section>
<!-- Prime Member Alert -->
<?php if ($isPrime): ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        window.onload = function() {
            Swal.fire({
                title: '🎉 Congratulations!',
                text: 'You are a Prime Member!',
                iconHtml: '<i class="fa-solid fa-crown" style="color: #f39c12;"></i>',
                customClass: { icon: 'no-border' },
                confirmButtonText: 'Awesome!',
                backdrop: `rgba(0,0,123,0.4) left top no-repeat`
            });
        };
    </script>
<?php endif; ?>

<style>
.modrow-cls {
    padding: 4px;
    text-align: center;
    border-bottom: 1px solid #fff;
    background-color: #e3e3e3;
}

.label-success1 {
    color: #1d1d1d;
    font-size: 14px;
}

.modviewbtn {
    padding: 5px;
    font-size: 10px;
    text-align:: center;
    cursor: pointer;
    outline: none;
    color: #fff;
    background-color: #f4511e;
    border: none;
    border-radius: 15px;
    box-shadow: 0 3px #d1d1d1;
}

.modviewbtn:active {
    background-color: #f4511e;
    box-shadow: 0 5px #666;
    transform: translateY(4px);
}

.modviewbtn:hover {
    color: #fff;
    text-decoration: none;
    background: #f93b00;
    box-shadow: 0 6px #e5e4e4;
}

.modrow-cls .label {
    font-weight: 500;
}

.modal-content {
    border: 4px solid #f93b00;
    border-radius: 5px;
}

.frnewbtn a button:hover {
    background: #3c8dbc;
    color: #fff;
    border: 2px solid #f39c12;
}

.frnewbtn a button {
    padding: 5px;
    border-radius: 5px;
    border: 2px solid #f39c12;
    margin: 4px;
    background: #fff;
}

.progress {
    background-color: #f16868;
    border-radius: 50px;
    height: 15px;
    margin-bottom: 5px;
}

.progress-bar {
    height: 97%;
    background-color: #238f2a;
    line-height: 14px;
}

.progress-bar-striped,
.progress-striped .progress-bar {
    background-size: 10px 10px;
}

.img-circle1 {
    width: 50%;
    height: 130px;
    object-fit: inherit;
}

.panel {
    border: 1px solid #b5b2b2ba;
    margin-left: 15px;
}

.small-box .icon {
    font-size: 48px;
}

.small-box h3 {
    font-size: 18px;
    margin: 0 0 0px 0;
}

.small-box:hover .icon {
    font-size: 56px;
}
</style>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="<?php echo base_url('assets/js/common.js'); ?>" charset="utf-8"></script>
<script>
$(document).ready(function() {
    $('#franchiseNumber').selectpicker();
});
</script>
<script>
  $(document).ready(function() {
    let admissionChartInstance = null;

    function renderAdmissionChart(year, franchiseFilter = '') {
      console.log("Fetching admission data for year:", year, "franchiseFilter:", franchiseFilter);

      $.ajax({
        url: '<?php echo base_url('admissiondetailsnew/getAdmissionChartData'); ?>',
        type: 'GET',
        data: {
          year: year,
          franchiseFilter: franchiseFilter
        },
        dataType: 'json',
        success: function(response) {
          console.log("Admission data received:", response);

          const admissions = Array.isArray(response.admissions) && response.admissions.length === 12 ?
            response.admissions :
            Array(12).fill(0);

          console.log("Admissions data:", admissions);

          const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          $('#admissionChartTitle').text(year + ' Admission Details' + (franchiseFilter ? ' for Franchise ' + $('#franchiseSelector option:selected').text() : ''));

          const options = {
            chart: {
              type: 'bar',
              height: 350,
              toolbar: {
                show: true
              }
            },
            series: [{
              name: 'Admissions',
              data: admissions
            }],
            xaxis: {
              categories: months,
              title: {
                text: 'Months'
              }
            },
            yaxis: {
              title: {
                text: 'Admission Count'
              }
            },
            plotOptions: {
              bar: {
                columnWidth: '40%',
                endingShape: 'rounded'
              }
            },
            dataLabels: {
              enabled: true,
              formatter: val => val > 0 ? val : ''
            },
            stroke: {
              show: true,
              width: 2,
              colors: ['transparent']
            },
            colors: ['#00E396'],
            fill: {
              opacity: 1
            },
            tooltip: {
              y: {
                formatter: val => val + " admissions"
              }
            },
            legend: {
              position: 'top'
            }
          };

          const chartElement = document.querySelector("#admissionChart");
          if (chartElement) {
            if (admissionChartInstance) admissionChartInstance.destroy();
            admissionChartInstance = new ApexCharts(chartElement, options);
            admissionChartInstance.render();
          } else {
            console.error("Chart element #admissionChart not found.");
          }
        },
        error: function(xhr, status, error) {
          console.error("AJAX Error:", status, error, xhr.responseText);
        }
      });
    }

    // Initial render with current year and no franchise filter
    const currentYear = new Date().getFullYear();
    renderAdmissionChart(currentYear);

    // Update chart on year or franchise change
    $('#admissionYearSelector, #franchiseSelector').on('change', function() {
      const year = parseInt($('#admissionYearSelector').val(), 10);
      const franchiseFilter = $('#franchiseSelector').val();
      renderAdmissionChart(year, franchiseFilter);
    });
  });
</script>