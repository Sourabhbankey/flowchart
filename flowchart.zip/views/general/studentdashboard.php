<div class="content-wrapper">

  <!-- Content Header (Page header) -->
  <?php if ($role == 25) { ?>
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> My Dashboard
        <small>Control panel</small>
      </h1>
    </section>
  <?php } else { ?>
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Student Dashboard
        <small>Control panel</small>
      </h1>
    </section>
  <?php } ?>
 



    <section class="content">
      <div class="row">

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
            <h3>0</h3>
              <p>Assigned Homework</p>
            </div>
            <div class="icon">
              <i class="ion ion-clipboard" style="color: #bfe2ff"></i>
            </div>
          </div>
        </div>

        <!-- ./col -->
     
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>0</h3>
                <p>Completed Homework</p>
              </div>
              <div class="icon">

                <i class="ion ion-checkmark-circled" style="color: #6cd4ed;font-size: 42px;"></i>
              </div>
            </div>
          </div>
        
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>0</h3>
                <p>Event Gallery</p>
              </div>
              <div class="icon">
                <i class="fas fa-hourglass-half" style="color: #6cd4ed;font-size: 39px;"></i>
              </div>
            </div>
          </div>
        

        <!-- FOR DESIGNING -->
        
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>0</h3>
                <p>Fee Structure</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-compose" style="color: #6cd4ed"></i>
              </div>
            </div>
          </div>
        
      
        <!-- ./col -->
      </div>
</div>

<style type="text/css">
  .modrow-cls {
    /*background-color: #E3F2FD;*/
    padding: 4px;
    text-align: center;
    border-bottom: 1px solid #fff;
    /*height: auto; */
    background-color: #e3e3e3;
    /*background-image: repeating-linear-gradient(red, yellow 25%, green 100%);*/
  }

  .label-success1 {
    /*color: #545454;*/
    color: #1d1d1d;
    font-size: 14px;
  }

  .modviewbtn {
    padding: 5px 5px 5px 5px;
    font-size: 10px;
    text-align: center;
    cursor: pointer;
    outline: none;
    color: #fff;
    background-color: #f4511e;
    border: none;
    border-radius: 15px;
    box-shadow: 0 3px #d1d1d1;
  }

  .modviewbtn:active {
    background-color: #f4511e;
    box-shadow: 0 5px #666;
    transform: translateY(4px);
  }

  .modviewbtn:hover {
    color: #fff;
    text-decoration: none;
    background: #f93b00;
    box-shadow: 0 6px #e5e4e4;
  }

  .modrow-cls .label {
    font-weight: 500;
  }

  .modal-content {
    border: 4px solid #f93b00;
    border-radius: 5px;
  }

  .frnewbtn a button:hover {
    background: #3c8dbc;
    color: #fff;
    border: 2px solid #f39c12;
  }

  .frnewbtn a button {
    padding: 5px;
    border-radius: 5px;
    border: 2px solid #f39c12;
    margin: 4px;
    background: #fff;
  }

  /*---Progress-Bar---*/
  .progress {
    background-color: #f16868;
    border-radius: 50px;
    height: 15px;
    margin-bottom: 5px;
  }

  .progress-bar {
    height: 97%;
    background-color: #238f2a;
    line-height: 14px;
  }

  .progress-bar-striped,
  .progress-striped .progress-bar {
    background-size: 10px 10px;
  }

  .img-circle1 {
    width: 50%;
    height: 130px;
    object-fit: inherit;
  }

  .panel {
    border: 1px solid #b5b2b2ba;
    margin-left: 15px;
  }

  .small-box .icon {
    font-size: 48px;
  }

  .small-box h3 {
    font-size: 18px;
    margin: 0 0 0px 0;
  }

  .small-box:hover .icon {
    font-size: 56px;

  }
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/apexcharts.min.js'); ?>"></script>
<script>
  $(document).ready(function() {
    $('#franchiseNumber').selectpicker();
  });
</script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>