<div class="content-wrapper">
  <!-- <div class="modal fade bs-example-modal-new" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="gridSystemModalLabel" style="text-align: center;">Welcome <span><?php echo $name; ?></span></h4>
        </div>
        <div class="modal-body">
          <div class="body-message">
            <p style="text-align: center;font-size: 20px;color: #e32020;">Please complete the missing field click here on view button</p>
            <?php
            $records = $this->session->userdata('data');

            if (!empty($records)) {
              foreach ($records as $branch) {
            ?>
                <div class="row modrow-cls">
                <img class="loader1" style="display: none;"src="<?php //echo base_url() ?>assets/images/Rolling.svg">
                  <div class="col-md-3">
                    <span class="label label-success1"> <?php echo $branch->franchiseNumber ?></span>
                  </div>
                  <div class="col-md-3">
                    <span class="label label-success1" style="margin-left: -37px;"><?php echo $branch->applicantName ?></span>
                  </div>
                  <div class="col-md-3">
                    <span class="label label-success1"><?php echo $branch->mobile ?></span>
                  </div>
                  <div class="col-md-3">
                    <a class="btn btn-sm btn-info1 modviewbtn" style="margin-top: 3px;" href="<?php echo base_url() . 'branches/edit/' . $branch->branchesId; ?>">View <i class="fa fa-eye"></i></a>
                  </div>
                </div>


            <?php
              }
            }
            ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div> -->
  <!-- <div class="modal fade bs-example-modal-new" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal2">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="gridSystemModalLabel">Welcome <span><?php echo $name; ?></span></h4>
        </div>
        <div class="modal-body">
          <div class="body-message">
            <p>Weldone <span><?php echo $name; ?></span></p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div> -->
  <!-- Content Header (Page header) -->
  <?php if ($role == 25) { ?>
    <section class="content-header">
    <h1>
      <i class="fa fa-tachometer" aria-hidden="true"></i> Franchise Dashboard
      <small>Control panel</small>
    </h1>
  </section>
  <?php }else{ ?>  
  <section class="content-header">
    <h1>
      <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
      <small>Control panel</small>
    </h1>
  </section>
<?php } ?>  
  <?php if ($role == 25) { ?>
    <section class="content-header">
       <div class="row">
        <div class="col-md-6">
      <h1>
      <?php
      // print_r($this->session->userdata('growthName'));
      //               echo '<br>';
      //               print_r($this->session->userdata('growthcontact'));
      //               echo '<br>';
      //               print_r($this->session->userdata('growthvalidDate'));
      //               echo '<br>';
      //               exit;
                    ?></h1>
                    <?php
                  $userId = $this->session->userdata('userId');
                  $query = $this->db->query('SELECT * FROM tbl_users WHERE userId = ?', array($userId));
                  $user = $query->row();
                  $profileImg = $user->upattachmentS3File;
            ?>
        <img class="profile-user-img img-responsive img-circle1" src="<?php echo base_url($profileImg ?? ''); ?>" alt="User profile picture" style="margin: 0;width: auto;">            
        <!-- <h4>License Number : <?php //echo $this->session->userdata('licenseNumber') ?></h4>
        <h4>Growth Manager Name : <?php //echo $this->session->userdata('growthName') ?></h4>
        <h4>Mobile No : <?php //echo $this->session->userdata('growthcontact') ?></h4>
        <h4>Valid From Date : <?php //echo $this->session->userdata('growthvalidDate') ?></h4>
        <h4>Valid Till Date : <?php //echo $this->session->userdata('growthvalidDateTill') ?></h4>
        <h4>Franchise : <?php //echo $this->session->userdata('franchiseNumber') ?></h4> -->
    </div>
    <div class="col-md-6 frnewbtn">
      <h4>My Quick Links -</h4>
        <a href="https://shop.theischool.com/" target="_blank"><button><i class="fa fa-shopping-basket" aria-hidden="true"></i> Shop Now</button></a>
        <a href="https://play.google.com/store/apps/details?id=com.theischool.edumeta&pcampaignid=web_share" target="_blank"><button><img src="https://onboarding.edumeta.in/support-sms/assets/dist/img/playstoreicon.webp" style="width: 18px;"> Download App</button></a>
        <a href="https://apps.apple.com/app/edumeta-diary/id6475728137" target="_blank"><button><i class="fa fa-apple" aria-hidden="true"></i> Download iOS App</button></a>
        <a href="https://theischool.com/my_branch/" target="_blank"><button><i class="fa fa-globe" aria-hidden="true"></i> School Diary Dashboard </button></a>
        <a href="<?php echo $this->session->userdata('customWebsiteLink') ?>" target="_blank"><button><i class="fa fa-globe" aria-hidden="true"></i> Branch Website</button></a>
        <a href="#" target="_blank"><button><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</button></a>
        <a href="#" target="_blank"><button><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</button></a>
        <a href="#" target="_blank"><button><i class="fa fa-youtube" aria-hidden="true"></i> YouTube</button></a>
        <a href="#" target="_blank"><button><i class="fa fa-map" aria-hidden="true"></i> Google Map</button></a>
        <a href="<?php echo base_url(); ?>announcement" target="_blank"><button><i class="fa fa-bullhorn" aria-hidden="true"></i> Announcement </button></a>
        <a href="<?php echo base_url(); ?>support/add" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Schedule Meeting </button></a>
    </div>
  </div>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua" style="background-color: #ed5d24;">
            <div class="inner">
              <!-- <h3><?php //$query = $this->db->query('SELECT * FROM tbl_task');
                  //echo $query->num_rows(); ?></h3>
              <p>New Tasks</p> -->
              <h3>My Tickets<?php //echo $this->session->userdata('PGAddmisn')?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="<?php echo base_url(); ?>task" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <!-- <h3><?php //echo $this->session->userdata('totalAddmisn') ?></h3>
              <p>Total Admissions</p> -->
              <h3>Admissions<?php //echo $this->session->userdata('PGAddmisn')?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url(); ?>admissiondetails" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>Training<?php //echo $this->session->userdata('PGAddmisn')?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url(); ?>training" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>Despatch<?php //echo $this->session->userdata('NursaryAddmisn')?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url(); ?>despatch" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>Accounts<?php //echo $this->session->userdata('KG1Addmisn') ?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url(); ?>account" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Attachment<?php //echo $this->session->userdata('KG2Addmisn')?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url(); ?>attachment" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>Design<?php //echo $this->session->userdata('KG2Addmisn')?></h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->  
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>Connect to HO</h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
      </div>
    </section>
    <!-- <section class="content">
        <div class="row">
          <div class="col-md-12">
            <p>Complete Single Progress Bar</p>
            <div class="progress">
            <?php 
            $AllCount = round(100 - $this->session->userdata('percentageEmpty'),2);
            ?>
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $AllCount ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $AllCount ?>%">
              <?php echo $AllCount ?>%
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <p>Account Department Progress Bar</p>
            <div class="progress">
            <?php 
            $AllAcCount = round(100 - $this->session->userdata('accountColumn'),2);
            ?>
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $AllAcCount ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $AllAcCount ?>%">
              <?php echo $AllAcCount ?>%
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <p>Design Department Progress Bar</p>
            <?php 
            $design = round(100 - $this->session->userdata('design'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $design ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $design ?>%">
              <?php echo $design ?>%
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <p>Sales Department Progress Bar</p>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:40%">
                40%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Support Department Progress Bar</p>
            <?php 
            $SupportDepartment = round(100 - $this->session->userdata('SupportDepartment'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $SupportDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $SupportDepartment ?>%">
              <?php echo $SupportDepartment ?>%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Legal Department Progress Bar</p>
            <?php 
            $LegalDepartment = round(100 - $this->session->userdata('LegalDepartment'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $LegalDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $LegalDepartment ?>%">
              <?php echo $LegalDepartment ?>%
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <p>Material Department Progress Bar</p>
            <?php 
              $LegalDepartment = round(100 - $this->session->userdata('LegalDepartment'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $LegalDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $LegalDepartment ?>%">
              <?php echo $LegalDepartment ?>%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Admission Progress Bar</p>
            <?php 
              $AddmissionDepartment = round(100 - $this->session->userdata('AddmissionDepartment'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $AddmissionDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $AddmissionDepartment ?>%">
              <?php echo $AddmissionDepartment ?>%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Digital Marketing Progress Bar</p>
            <?php 
              $DigitalDepartment = round(100 - $this->session->userdata('DigitalDepartment'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $DigitalDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $DigitalDepartment ?>%">
              <?php echo $DigitalDepartment ?>%
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <p>Training Department Progress Bar</p>
            <?php 
            // print_r($this->session->userdata('TrainingDepartment'));
            // exit;
              $TrainingDepartment = round(100 - $this->session->userdata('TrainingDepartment'),2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $TrainingDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $TrainingDepartment ?>%">
              <?php echo $TrainingDepartment ?>%
              </div>
            </div>
          </div>
        </div>
    </section> -->
  <?php }  else if ($role == 32) { ?>
<section class="content">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>Countries</h3>
              <p>5+</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); ?>task" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>Cities<sup style="font-size: 20px"></sup></h3>
              <p>280+</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>State</h3>
              <p>28</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Blog</h3>
              <p><a href="https://theischool.com/blog/" target="_blank">Click Here</a></p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>Announcement</h3>
              <p></p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
      </div>
      <div class="row">
        <div class="col-lg-6 col-xs-12">
          <h3>Top 20 Cities</h3>
         </div>
      </div>
    </section>
  <?php  } else { ?>
    <section class="content">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
      <div class="inner">
    <h3 id="taskCounts">
        <?php 
            // Get the logged-in user's ID and role
            $loggedInUserId = $this->session->userdata('userId'); 
            $userRole = $this->session->userdata('role'); 

            if ($userRole === '1' || $userRole === '14') { 
                // Admin: Fetch all tasks
                $queryTotal = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task");
                $queryCompleted = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task WHERE status = 'closed'");
            } else { 
                // Regular user: Fetch only tasks assigned to them
                $queryTotal = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task WHERE assignedTo = ? OR assignedBy = ?", [$loggedInUserId, $loggedInUserId]);
                $queryCompleted = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task WHERE status = 'closed' AND (assignedTo = ? OR assignedBy = ?)", [$loggedInUserId, $loggedInUserId]);
            }

            // Fetch the count of tasks
            $totalTasks = $queryTotal->row()->count;
            $completedTasks = $queryCompleted->row()->count;
            $pendingTasks = $totalTasks - $completedTasks;

            
        ?>
    </h3>
    <p>Task Status</p>
</div>

<!-- Pie Chart Container -->
<canvas id="taskStatusChart"></canvas>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Fetch task counts from PHP
        let completedTasks = <?php echo $completedTasks; ?>;
        let pendingTasks = <?php echo $pendingTasks; ?>;
        let totalTasks = <?php echo $totalTasks; ?>;

        // Define data for the chart
        let data = {
            labels: [
                "Completed (" + completedTasks + ")", 
                "Pending (" + pendingTasks + ")"
            ],
            datasets: [{
                data: [completedTasks, pendingTasks],
                backgroundColor: ["#28a745", "#ffc107"] // Green for completed, Yellow for pending
            }]
        };

        // Render the chart
        let ctx = document.getElementById("taskStatusChart").getContext("2d");
        new Chart(ctx, {
            type: "pie",
            data: data,
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: "Task Distribution (Total: " + totalTasks + ")"
                    }
                }
            }
        });
    });
</script>


            <!-- <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); ?>task" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
          </div>
        </div>
        <div class="col-lg-3 col-xs-6">
         
          <div class="small-box bg-green"> 
       <div class="inner">
    <h3 id="completedTasks">
        <?php 
        // Get the logged-in user's ID and role
        $loggedInUserId = $this->session->userdata('userId'); 
        $userRole = $this->session->userdata('role'); 

        if ($userRole === '1' || $userRole === '14') { 
            // Admin: Fetch all tasks and closed tasks
            $queryTotal = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task");
            $queryCompleted = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task WHERE status = 'closed'");
        } else { 
            // Regular user: Fetch only their assigned tasks and closed tasks
            $queryTotal = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task WHERE assignedTo = ? OR assignedBy = ?", [$loggedInUserId, $loggedInUserId]);
            $queryCompleted = $this->db->query("SELECT COUNT(*) AS count FROM tbl_task WHERE status = 'closed' AND (assignedTo = ? OR assignedBy = ?)", [$loggedInUserId, $loggedInUserId]);
        }

        // Fetch and calculate counts
        $totalTasks = $queryTotal->row()->count;
        $completedTasks = $queryCompleted->row()->count;
        $pendingTasks = $totalTasks - $completedTasks;

        echo "Completed: " . $completedTasks . " | Pending: " . $pendingTasks;
        ?>
    </h3>
    <p>Task Status</p>
</div>

 
<canvas id="taskCompletionChart"></canvas>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Fetch counts from PHP
        let completedTasks = <?php echo $completedTasks; ?>;
        let pendingTasks = <?php echo $pendingTasks; ?>;
        let totalTasks = <?php echo $totalTasks; ?>;

        // Define the data for the chart
        let data = {
            labels: [
                "Completed (" + completedTasks + ")", 
                "Pending (" + pendingTasks + ")"
            ],
            datasets: [{
                data: [completedTasks, pendingTasks],
                backgroundColor: ["#28a745", "#ffc107"] // Green for completed, Yellow for pending
            }]
        };

        // Render the chart
        let ctx = document.getElementById("taskCompletionChart").getContext("2d");
        new Chart(ctx, {
            type: "pie",
            data: data,
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: "Task Completion (Total: " + totalTasks + ")"
                    }
                }
            }
        });
    });
</script> -->

            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
         <?php    $userRole = $this->session->userdata('role');
                 if ($userRole === '1' || $userRole === '14') {  ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
       
          <div class="small-box bg-yellow">
          <div class="inner">
    <h3 id="newUsers">
        <?php 
            // Get total number of users
            $query = $this->db->query('SELECT * FROM tbl_users');
            $newUsers = $query->num_rows();
            echo $newUsers;
        ?>
    </h3>
    <p>New Users</p>
</div>

<!-- Pie Chart Container -->
<canvas id="newUsersChart"></canvas>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Fetch new users count from PHP
        let newUsers = parseInt(document.getElementById("newUsers").innerText);
        let totalUsers = 100; // Adjust this based on actual total user count
        let existingUsers = totalUsers - newUsers;

        // Define data for the chart
        let data = {
            labels: ["New Users", "Existing Users"],
            datasets: [{
                data: [newUsers, existingUsers],
                backgroundColor: ["#007bff", "#adb5bd"] // Blue for new users, Grey for existing users
            }]
        };

        // Render the chart
        let ctx = document.getElementById("newUsersChart").getContext("2d");
        new Chart(ctx, {
            type: "pie",
            data: data
        });
    });
</script>

            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <?php } else {

        } ?> <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
    <h3 id="allottedBranches">
        <?php 
            // Fetch the logged-in user's ID and role
            $loggedInUserId = $this->session->userdata('userId'); 
            $userRole = $this->session->userdata('role');

            if ($userRole === '1' || $userRole === '14') { 
                // Admin: Count all branches
                $query = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches");
            } else { 
                // Regular users: Count only branches assigned to them
                $query = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches WHERE branchFranchiseAssigned = ?", [$loggedInUserId]);
            }

            // Fetch and display the result
            $result = $query->row();
            $allottedBranches = $result->count;
            echo $allottedBranches;
        ?>
    </h3>
    <p>Allotted Branches</p>
</div>

<!-- Pie Chart Container -->
<canvas id="allottedBranchesChart"></canvas>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Fetch allotted branches count from PHP
        let allottedBranches = parseInt(document.getElementById("allottedBranches").innerText);
        let totalBranches = 50; // Adjust this based on the actual total number of branches
        let unassignedBranches = totalBranches - allottedBranches;

        // Define data for the chart
        let data = {
            labels: ["Allotted", "Unassigned"],
            datasets: [{
                data: [allottedBranches, unassignedBranches],
                backgroundColor: ["#dc3545", "#ffc107"] // Red for allotted, Yellow for unassigned
            }]
        };

        // Render the chart
        let ctx = document.getElementById("allottedBranchesChart").getContext("2d");
        new Chart(ctx, {
            type: "pie",
            data: data
        });
    });
</script>

            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
      <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
           <div class="inner">
    <h3 id="branchCounts">
        <?php 
            // Fetch the logged-in user's ID and role
            $loggedInUserId = $this->session->userdata('userId'); 
            $userRole = $this->session->userdata('role');

            if ($userRole === '1' || $userRole === '14' || $userRole === '13') { 
                // Admin: Count all active, inactive, and total branches
                $queryActive = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches WHERE currentStatus = '1'");
                $queryInactive = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches WHERE currentStatus = '0'");
                $queryTotal = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches");
            } else { 
                // Regular users: Count only active, inactive, and total branches assigned to them
                $queryActive = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches WHERE currentStatus = '1' AND branchFranchiseAssigned = ?", [$loggedInUserId]);
                $queryInactive = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches WHERE currentStatus = '0' AND branchFranchiseAssigned = ?", [$loggedInUserId]);
                $queryTotal = $this->db->query("SELECT COUNT(*) AS count FROM tbl_branches WHERE branchFranchiseAssigned = ?", [$loggedInUserId]);
            }

            // Fetch and display the results
            $resultActive = $queryActive->row();
            $resultInactive = $queryInactive->row();
            $resultTotal = $queryTotal->row();

            $activeBranches = $resultActive->count;
            $inactiveBranches = $resultInactive->count;
            $totalBranches = $resultTotal->count;

            
        ?>
    </h3>
    <p>Branch Status</p>
</div>

<!-- Pie Chart Container -->
<canvas id="branchStatusChart"></canvas>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Fetch branch counts from PHP
        let activeBranches = parseInt(<?php echo $activeBranches; ?>);
        let inactiveBranches = parseInt(<?php echo $inactiveBranches; ?>);
        let totalBranches = parseInt(<?php echo $totalBranches; ?>);

        // Define data for the chart
        let data = {
            labels: [
                "Active (" + activeBranches + ")",
                "Inactive (" + inactiveBranches + ")"
            ],
            datasets: [{
                data: [activeBranches, inactiveBranches],
                backgroundColor: ["#28a745", "#dc3545"] // Green for active, Red for inactive
            }]
        };

        // Render the chart
        let ctx = document.getElementById("branchStatusChart").getContext("2d");
        new Chart(ctx, {
            type: "pie",
            data: data,
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: "Branches (Total: " + totalBranches + ")"
                    }
                }
            }
        });
    });
</script>



            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
      </div>
    </section>
    <!-- Include FullCalendar CSS & JS -->
<!-- Include FullCalendar CSS & JS -->
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>

<!-- Calendar Container -->
<div id="calendar-container">
    <div id="calendar"></div>
</div>

<!-- CSS for Calendar Size -->
<style>
    #calendar-container {
        width: 60%;
        height: 60vh; /* 30% of viewport height */
        display: flex;
        justify-content: center;
        align-items: center;
    }

    #calendar {
        width: 100%;
        height: 100%;
    }
</style>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        let calendarEl = document.getElementById("calendar");

        let calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            selectable: true,
            height: "100%", // Full height within the container
        });

        calendar.render();
    });
</script>

    <section>
      <div class="row">
        <div class="col-lg-12 col-xs-12">
          <div class="modal-body">
            <div class="body-message">
            <div class="loderr">
              <!-- <img class="submit-loader" src="<?php //echo base_url() ?>assets/images/loader.gif" alt="loader" id="DashboardLoader"/> -->
            </div>
              <!-- <p style="text-align: center;font-size: 20px;color: #e32020;" class="textHide">Please complete the missing field click here on view button</p> -->
              <?php
              $records = $this->session->userdata('data');
              if (!empty($records)) {
                foreach ($records as $branch) {
              ?>
                  <div class="row modrow-cls">
                    <div class="col-md-3">
                      <span class="label label-success1"> <?php echo $branch->franchiseNumber ?></span>
                    </div>
                    <div class="col-md-3">
                      <span class="label label-success1" style="margin-left: -37px;"><?php echo $branch->applicantName ?></span>
                    </div>
                    <div class="col-md-3">
                      <span class="label label-success1"><?php echo $branch->mobile ?></span>
                    </div>
                    <div class="col-md-3">
                      <a class="btn btn-sm btn-info1 modviewbtn" target="_blank" style="margin-top: 0px;" href="<?php echo base_url() . 'branches/edit/' . $branch->branchesId; ?>">View <i class="fa fa-eye"></i></a>
                    </div>
                  </div>


              <?php
                }
              }
              ?>
            </div>
          </div>
        </div>
    </section>
  <?php } ?>


</div>
<style type="text/css">
  .modrow-cls {
    /*background-color: #E3F2FD;*/
    padding: 4px;
    text-align: center;
    border-bottom: 1px solid #fff;
    /*height: auto; */
    background-color: #e3e3e3;
    /*background-image: repeating-linear-gradient(red, yellow 25%, green 100%);*/
  }

  .label-success1 {
    /*color: #545454;*/
    color: #1d1d1d;
    font-size: 14px;
  }

  .modviewbtn {
    padding: 5px 5px 5px 5px;
    font-size: 10px;
    text-align: center;
    cursor: pointer;
    outline: none;
    color: #fff;
    background-color: #f4511e;
    border: none;
    border-radius: 15px;
    box-shadow: 0 3px #d1d1d1;
  }

  .modviewbtn:active {
    background-color: #f4511e;
    box-shadow: 0 5px #666;
    transform: translateY(4px);
  }

  .modviewbtn:hover {
    color: #fff;
    text-decoration: none;
    background: #f93b00;
    box-shadow: 0 6px #e5e4e4;
  }
.modrow-cls .label{font-weight: 500;}
  .modal-content {
    border: 4px solid #f93b00;
    border-radius: 5px;
  }
  .frnewbtn a button:hover {
      background: #3c8dbc;
      color: #fff;
      border: 2px solid #f39c12;
  }
.frnewbtn a button{
    padding: 5px;
    border-radius: 5px;
    border: 2px solid #f39c12;
    margin: 4px;
    background: #fff;
}
/*---Progress-Bar---*/
.progress {
    background-color: #f16868;
    border-radius: 50px;
    height: 15px;
    margin-bottom: 5px;
}
.progress-bar {
    height: 97%;
    background-color: #238f2a;
    line-height: 14px;
}
.progress-bar-striped, .progress-striped .progress-bar {
     background-size: 10px 10px;
}
.img-circle1{
  width: 50%;
    height: 130px;
    object-fit: inherit;
}
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
  
  jQuery(document).ready(function() {
    $(".loderr").hide();
    var adminID = "<?php echo $is_admin; ?>";
    var modelshow = "<?php echo $this->session->userdata('modelShow'); ?>";
    var emptyRow = "<?php echo $this->session->userdata('emptyRow'); ?>";
    var roleId = "<?php echo $role; ?>";
    if (adminID != 1 && roleId != 25) {
      jQuery('#myModal').modal('show');
      jQuery('#myModal2').modal('hide');
    }else if (adminID != 1) {
      jQuery('#myModal2').modal('show');
      jQuery('#myModal').modal('hide');
    }
    if (adminID == 1) {
      jQuery('.textHide').modal('hide');
    }

  });
  Dashboard()
  function Dashboard() {
    var userId  = <?php echo $userId ?>;
    var roleId  = <?php echo $role ?>;
    var isAdmin = <?php echo $is_admin ?>;
    $.ajax({
      url: "<?php echo base_url('login/getBranchData'); ?>",
      method: "POST",
      data: {
        userId: userId,
        roleId: roleId,
        isAdmin: isAdmin 
      },
      beforeSend: function() {
          $("#DashboardLoader").show();
      },
      success: function(data) {
          $("#DashboardData").html(data);
          $("#DashboardLoader").hide();
          $("#fromRa").hide();
          $("#toRa").hide();
          $("#to2").hide();
          $("#getRangeDataService").hide();
      },
      error: function(data) {
          $("#SubmitLoader").hide();
      }
    });
  }
</script>