<div class="content-wrapper">

  <!-- Content Header (Page header) -->
  <?php if ($role == 25) { ?>
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> My Dashboard
        <small>Control panel</small>
      </h1>
    </section>
  <?php } else { ?>
    <section class="content-header">
      <h1>
        <i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard
        <small>Control panel</small>
      </h1>
    </section>
  <?php } ?>
  <?php if ($role == 25) { ?>
    <section class="content-header">
      <div class="row">
        <div class="col-md-6">
          <h1>
            <?php

            ?></h1>
          <?php
          $userId = $this->session->userdata('userId');
          $query = $this->db->query('SELECT * FROM tbl_users WHERE userId = ?', array($userId));
          $user = $query->row();
          $profileImg = $user->upattachmentS3File;
          ?>
          <img class="profile-user-img img-responsive img-circle1" src="<?php echo base_url($profileImg ?? ''); ?>" alt="User profile picture" style="margin: 0;width: auto;">
          <!-- <h4>License Number : <?php //echo $this->session->userdata('licenseNumber') 
                                    ?></h4>
        <h4>Growth Manager Name : <?php //echo $this->session->userdata('growthName') 
                                  ?></h4>
        <h4>Mobile No : <?php //echo $this->session->userdata('growthcontact') 
                        ?></h4>
        <h4>Valid From Date : <?php //echo $this->session->userdata('growthvalidDate') 
                              ?></h4>
        <h4>Valid Till Date : <?php //echo $this->session->userdata('growthvalidDateTill') 
                              ?></h4>
        <h4>Franchise : <?php //echo $this->session->userdata('franchiseNumber') 
                        ?></h4> -->
        </div>
        <div class="col-md-6 frnewbtn">
          <h4>My Quick Links -</h4>
          <a href="https://shop.theischool.com/" target="_blank"><button><i class="fa fa-shopping-basket" aria-hidden="true"></i> Shop Now</button></a>
          <a href="https://play.google.com/store/apps/details?id=com.theischool.edumeta&pcampaignid=web_share" target="_blank"><button><img src="https://onboarding.edumeta.in/support-sms/assets/dist/img/playstoreicon.webp" style="width: 18px;"> Download App</button></a>
          <a href="https://apps.apple.com/app/edumeta-diary/id6475728137" target="_blank"><button><i class="fa-brands fa-app-store-ios"></i> Download iOS App</button></a>
          <a href="https://theischool.com/my_branch/" target="_blank"><button><i class="fa fa-globe" aria-hidden="true"></i> School Diary Dashboard </button></a>
          <a href="<?php echo $this->session->userdata('customWebsiteLink') ?>" target="_blank"><button><i class="fa fa-globe" aria-hidden="true"></i> Branch Website</button></a>
          <a href="#" target="_blank"><button><i class="fa-brands fa-facebook-f"></i> Facebook</button></a>
          <a href="#" target="_blank"><button><i class="fa-brands fa-instagram"></i> Instagram</button></a>
          <a href="#" target="_blank"><button><i class="fa-brands fa-youtube"></i> YouTube</button></a>
          <a href="#" target="_blank"><button><i class="fa fa-map" aria-hidden="true"></i> Google Map</button></a>
          <a href="<?php echo base_url(); ?>announcement" target="_blank"><button><i class="fa fa-bullhorn" aria-hidden="true"></i> Announcement </button></a>
          <a href="<?php echo base_url(); ?>support/add" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Schedule Meeting </button></a>
          <a href="<?php echo base_url(); ?>guidelines/guidelinesListing" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Guidelines</button></a>
          <a href="<?php echo base_url(); ?>standardformat" target="_blank"><button><i class="fa fa-calendar" aria-hidden="true"></i> Standard format</button></a>

        </div>
      </div>
    </section>
    <section class="content">
      <div class="row">

        <?php
        $userId = $this->session->userdata('userId');

        $query = $this->db->query("
        SELECT COUNT(*) AS total 
        FROM tbl_task 
        WHERE 
        assignedTo = " . $this->db->escape($userId) . " 
        OR assignedBy = " . $this->db->escape($userId) . "
        OR FIND_IN_SET(" . $this->db->escape($userId) . ", collabrators)
");

        $totalTasks = $query->row()->total ?? 0;
        ?>



        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>Pending Queries</h3>
              <p>Total : <?php echo $totalTasks; ?></p>
            </div>
            <div class="icon">
              <i class="fas fa-hourglass-half" style="color: #6cd4ed;font-size: 39px;"></i>
            </div>
            <a href="<?php echo base_url(); ?>ticket/ticketListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>



        <!-- ./col -->
        <?php
        $franchiseNo = $this->session->userdata('franchiseNumber');
        $this->db->where('franchiseNumber', $franchiseNo);
        $count = $this->db->count_all_results('tbl_admission_details_2526');
        $isPrime = $count > 10;
        ?>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <h3>
                Admission <?php echo ($count > 10) ? '🎉' : ''; ?>
              </h3>
              <p>Total: <?php echo $count; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-people" style="color: #6cd4ed"></i>
            </div>
            <a href="<?php echo base_url(); ?>admissiondetails" class="small-box-footer">
              More info <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

        <?php if ($isPrime): ?>
          <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
          <script>
            window.onload = function() {
              Swal.fire({
                title: '🎉 Congratulations!',
                text: 'You are a Prime Member!',
                iconHtml: '<i class="fa-solid fa-crown" style="color: #f39c12;"></i>',
                customClass: {
                  icon: 'no-border' // Optional: Remove default icon border
                },
                confirmButtonText: 'Awesome!',
                backdrop: `
             rgba(0,0,123,0.4)
          left top
          no-repeat
        `
              });
            };
          </script>
        <?php endif; ?>


        <!-- <?php //if (!empty($birthdayUsers)): 
              ?>
    <script>
        window.onload = function () {
            alert("🎉 Today is the birthday of: \n<?php
                                                  foreach ($birthdayUsers as $user) {
                                                    echo $user->name . " (" . date('d M', strtotime($user->dob)) . ")\\n";
                                                  }
                                                  ?>");
        };
    </script>
<?php //endif; 
?> -->



        <!-- ./col -->
        <?php
        $franchiseNo = $this->session->userdata('franchiseNumber');

        $query = $this->db->query("
    SELECT COUNT(*) AS total 
    FROM tbl_training 
    WHERE franchiseNumber = " . $this->db->escape($franchiseNo) . "
");

        $row = $query->row();
        $trainingCount = $row->total;
        ?>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Training </h3>
              <p>Total : <?php echo $trainingCount; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-paper" style="color: #ecbba5;"></i>
            </div>
            <a href="<?php echo base_url(); ?>training" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <?php
        $franchiseNo = $this->session->userdata('franchiseNumber');

        $query = $this->db->query("
    SELECT COUNT(*) AS total 
    FROM tbl_despatch 
    WHERE franchiseNumber = " . $this->db->escape($franchiseNo) . " 
    AND delStatus = 2
");

        $row = $query->row();
        $despatchCount = $row->total;
        ?>


        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>Pending Orders <?php //echo $this->session->userdata('NursaryAddmisn')
                                  ?></h3>
              <p> Total : <?php echo $despatchCount; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-cart" style="color: #6cd4ed"></i>
            </div>
            <a href="<?php echo base_url(); ?>despatch" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <?php
        $franchiseNo = $this->session->userdata('franchiseNumber');

        $query = $this->db->query("
    SELECT COUNT(*) AS total 
    FROM tbl_despatch 
    WHERE franchiseNumber = " . $this->db->escape($franchiseNo) . "
");

        $row = $query->row();
        $accountCount = $row->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>Accounts<?php //echo $this->session->userdata('KG1Addmisn') 
                          ?></h3>
              <p> Total :<?php echo $accountCount; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-calculator" style="color: #ffeacc;font-size: 39px; "></i>
            </div>
            <a href="<?php echo base_url(); ?>account" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <!--  -->
        <?php
        $franchiseNo = $this->session->userdata('franchiseNumber');

        $query = $this->db->query("
    SELECT COUNT(*) AS total 
    FROM tbl_custom_desing 
    WHERE franchiseNumber = " . $this->db->escape($franchiseNo) . " 
    AND (attachmentS3File IS NULL OR attachmentS3File = '')
");

        $row = $query->row();
        $designCount = $row->total;
        ?>

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>Pending Design<?php //echo $this->session->userdata('KG2Addmisn')
                                ?></h3>
              <p> Total - <?php echo $designCount; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-timer-outline" style="color: #6cd4ed"></i>
            </div>
            <a href="<?php echo base_url(); ?>customdesign/customdesignListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Connect to HO</h3>
              <p> Click on More Button</p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-chatboxes" style="color: #ecbba5;"></i>
            </div>
            <a href="<?php echo base_url(); ?>ticket/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div><!-- ./col -->
        <?php
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = 'Nursery' AND franchiseNumber = '$franchiseNumber'");
        $data['Nursery'] = $query->row()->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-orange">
            <div class="inner">
              <h3>Admission Nursery</h3>
              <p>Total: <?php echo $data['Nursery']; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-book" style="color: #fdf3d2"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = 'Play Group' AND franchiseNumber = '$franchiseNumber'");
        $data['Play Group'] = $query->row()->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-orange">
            <div class="inner">
              <h3>Admission PlayGroup</h3>
              <p>Total: <?php echo $data['Play Group']; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-bookmarks" style="color: #fdf3d2"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = 'KG-1' AND franchiseNumber = '$franchiseNumber'");
        $data['kg1_count'] = $query->row()->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-orange">
            <div class="inner">
              <h3>Admission KG-1</h3>
              <p>Total: <?php echo $data['kg1_count']; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-compose" style="color: #fdf3d2"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = 'KG-2' AND franchiseNumber = '$franchiseNumber'");
        $data['kg2_count'] = $query->row()->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-orange">
            <div class="inner">
              <h3>Admission KG-2</h3>
              <p>Total: <?php echo $data['kg2_count']; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-university" style="color: #fdf3d2"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = 'Toddlers' AND franchiseNumber = '$franchiseNumber'");
        $data['Toddlers'] = $query->row()->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-orange">
            <div class="inner">
              <h3>Admission Toddlers</h3>
              <p>Total: <?php echo $data['Toddlers']; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-briefcase" style="color: #fdf3d2"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <?php
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526 WHERE class = '1st' AND franchiseNumber = '$franchiseNumber'");
        $data['1st'] = $query->row()->total;
        ?>
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-orange">
            <div class="inner">
              <h3>Admission 1st</h3>
              <p>Total: <?php echo $data['1st']; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-ios-paper" style="color: #fdf3d2"></i>
            </div>
            <a href="<?php echo base_url(); ?>task/add" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
      </div>
    </section>

    <?php
    date_default_timezone_set('Asia/Kolkata');

    $query = $this->db->query("
    SELECT 
        admid,
        franchiseNumber,
        birthday,
        name
    FROM tbl_admission_details_2526
    WHERE birthday IS NOT NULL
    AND franchiseNumber IS NOT NULL
    AND name IS NOT NULL
    AND MONTH(birthday) = MONTH(CURDATE())
    AND DAY(birthday) >= DAY(CURDATE())
    ORDER BY DAY(birthday) ASC;
");

    $rows = $query->result();
    ?>


    <div class="col-md-12 col-lg-5 col-xl-5 panel">
      <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Student Birthday List 111 </h4>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>S. No.</th>
            <th>Branch No.</th>
            <th>Birthday</th>
            <th>Name</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($rows)): ?>
            <tr>
              <td colspan="4">No staff birthdays found for the current month.</td>
            </tr>
          <?php else: ?>
            <?php foreach ($rows as $index => $row): ?>
              <tr class="<?= (date('m-d', strtotime($row->birthday)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                <td><?= !empty($row->admid) ? htmlspecialchars($row->admid) : 'No Data' ?></td>
                <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                <td><?= !empty($row->birthday) ? htmlspecialchars(date('F j, Y', strtotime($row->birthday))) : 'No Data' ?></td>
                <td><?= !empty($row->name) ? htmlspecialchars($row->name) : 'No Data' ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if (in_array($role, [1, 2,  14,  26, 25])) { ?>
      <div class="col-md-12 col-lg-5 col-xl-5 panel">
        <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Branch Employee Birthday List</h4>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>Branch No</th>
              <th>Birthday</th>
              <th>Staff Name</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)): ?>
              <tr>
                <td colspan="3">No staff birthdays found for the current month.</td>
              </tr>
            <?php else: ?>
              <?php foreach ($rows as $index => $row): ?>
                <tr class="<?= (date('m-d', strtotime($row->birthday)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                  <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                  <td><?= !empty($row->birthday) ? htmlspecialchars(date('F j, Y', strtotime($row->birthday))) : 'No Data' ?></td>
                  <td><?= !empty($row->name) ? htmlspecialchars($row->name) : 'No Data' ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>


    <?php } ?>
    <?php
    date_default_timezone_set('Asia/Kolkata');

    $query = $this->db->query("
    SELECT 
        hronboardId,
        dob,
        first_name
    FROM tbl_hrforms_onboard
    WHERE dob IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(dob) = MONTH(CURDATE())
    AND DAY(dob) >= DAY(CURDATE())
    ORDER BY DAY(dob) ASC;
");

    $rows = $query->result();
    ?>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-6 col-xl-6 panel pg-fw">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title" id="admissionChartTitle"><?php echo date('Y'); ?> Admission Details</h4>
                <p class="card-category">Total Number of Admissions Per Month</p>
                <div style="display: flex; gap: 10px; align-items: center;">
                  <select id="admissionYearSelector" class="form-control" style="width: 100px; display: inline-block;">
                    <option value="<?php echo date('Y'); ?>" selected><?php echo date('Y'); ?></option>
                    <?php for ($i = date('Y') - 5; $i <= date('Y'); $i++) { ?>
                      <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                    <?php } ?>
                  </select>

                </div>
              </div>
              <div class="card-body">
                <div id="admissionChart" style="min-height: 350px; width: 100%;"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>




    <!-- <section class="content">
        <div class="row">
          <div class="col-md-12">
            <p>Complete Single Progress Bar</p>
            <div class="progress">
            <?php
            $AllCount = round(100 - $this->session->userdata('percentageEmpty'), 2);
            ?>
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $AllCount ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $AllCount ?>%">
              <?php echo $AllCount ?>%
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <p>Account Department Progress Bar</p>
            <div class="progress">
            <?php
            $AllAcCount = round(100 - $this->session->userdata('accountColumn'), 2);
            ?>
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $AllAcCount ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $AllAcCount ?>%">
              <?php echo $AllAcCount ?>%
              </div>
            </div>
          </div>
          <div class="col-sm-4">
            <p>Design Department Progress Bar</p>
            <?php
            $design = round(100 - $this->session->userdata('design'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $design ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $design ?>%">
              <?php echo $design ?>%
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <p>Sales Department Progress Bar</p>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:40%">
                40%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Support Department Progress Bar</p>
            <?php
            $SupportDepartment = round(100 - $this->session->userdata('SupportDepartment'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $SupportDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $SupportDepartment ?>%">
              <?php echo $SupportDepartment ?>%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Legal Department Progress Bar</p>
            <?php
            $LegalDepartment = round(100 - $this->session->userdata('LegalDepartment'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $LegalDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $LegalDepartment ?>%">
              <?php echo $LegalDepartment ?>%
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <p>Material Department Progress Bar</p>
            <?php
            $LegalDepartment = round(100 - $this->session->userdata('LegalDepartment'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $LegalDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $LegalDepartment ?>%">
              <?php echo $LegalDepartment ?>%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Admission Progress Bar</p>
            <?php
            $AddmissionDepartment = round(100 - $this->session->userdata('AddmissionDepartment'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $AddmissionDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $AddmissionDepartment ?>%">
              <?php echo $AddmissionDepartment ?>%
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <p>Digital Marketing Progress Bar</p>
            <?php
            $DigitalDepartment = round(100 - $this->session->userdata('DigitalDepartment'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $DigitalDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $DigitalDepartment ?>%">
              <?php echo $DigitalDepartment ?>%
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <p>Training Department Progress Bar</p>
            <?php
            // print_r($this->session->userdata('TrainingDepartment'));
            // exit;
            $TrainingDepartment = round(100 - $this->session->userdata('TrainingDepartment'), 2);
            ?>
            <div class="progress">
              <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="<?= $TrainingDepartment ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $TrainingDepartment ?>%">
              <?php echo $TrainingDepartment ?>%
              </div>
            </div>
          </div>
        </div>
    </section> -->
  <?php } else if ($role == 32) { ?>
    <section class="content">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>Countries</h3>
              <p>5+</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); 
                          ?>task" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>Cities<sup style="font-size: 20px"></sup></h3>
              <p>280+</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>State</h3>
              <p>28</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); 
                          ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Blog</h3>
              <p><a href="https://theischool.com/blog/" target="_blank">Click Here</a></p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>Announcement</h3>
              <p></p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); 
                          ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->
      </div>
      <div class="row">
        <div class="col-lg-6 col-xs-12">
          <h3>Top 20 Cities</h3>
        </div>
      </div>
    </section>
  <?php } else if ($role == 2 || $role == 28) { ?>
    <section class="content">
      <div class="row">
        <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3 style="font-size: 29px;">Total Active Members</h3>

              <?php
              // Fetch count of users with roleId 29 and 32
              $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_users 
                    WHERE roleId IN (29, 31)
                ");

              // Get the total count
              $row = $query->row();
              echo '<h3>' . $row->total . '</h3>';
              ?>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="<?php echo base_url('clients/listusers'); ?>" class="small-box-footer">
              View <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3 style="font-size: 29px;">Monthly Conversion<sup style="font-size: 20px"></sup></h3>

              <?php
              $userId = $this->session->userdata('userId');
              $role = $this->session->userdata('role'); // Make sure role is defined
              $currentMonth = date('Y-m'); // Get current year and month (YYYY-MM)

              // Check if the logged-in user has roleId 28 or 2
              if ($role == 28 || $role == 2) {
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_results_sales");
              } else {
                // For other users, filter by their userId
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_results_sales WHERE userId = ?", [$userId]);
              }

              $row = $query->row();
              echo '<h3>' . $row->total . '</h3>';
              ?>

            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <!-- View Button -->
            <a href="<?= base_url('results/resultsListing') ?>" class="small-box-footer">
              View <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>

        <!-- ./col -->
        <div class="col-lg-4 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3 style="font-size: 29px;">Top Performer</h3>
              <?php
              $userId = $this->session->userdata('userId');
              $role = $this->session->userdata('role');

              // Fetch the user with the highest number of conversions
              $query = $this->db->query("
                SELECT u.userId, u.name, COUNT(rs.userId) AS total_records 
                FROM tbl_results_sales rs
                JOIN tbl_users u ON rs.userId = u.userId
                GROUP BY rs.userId
                ORDER BY total_records DESC, u.userId ASC 
                LIMIT 1
            ");

              $row = $query->row();

              if ($row) {
                echo "<h3>" . $row->name . "</h3>";
                $topPerformerId = $row->userId; // Store the top performer's ID for redirection
              } else {
                echo "No Top Performer";
                $topPerformerId = null;
              }
              ?>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>

            <!-- View Button -->
            <!--  <?php if ($topPerformerId): ?>
            <a href="<?= base_url('results/resultsListing?userId=' . $topPerformerId) ?>" class="small-box-footer">
                View <i class="fa fa-arrow-circle-right"></i>
            </a>
        <?php endif; ?> -->

            <!-- View All Button -->
            <a href="<?= base_url('results/resultsListing') ?>" class="small-box-footer">
              View All <i class="fa fa-arrow-circle-right"></i>
            </a>
          </div>
        </div>
        <!-- ./col -->
    </section>
  <?php } else if ($role == 29 || $role == 31) { ?>
    <section class="content">
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3 style="font-size: 29px;">Total Leads</h3>
              <?php
              $userId = $this->session->userdata('userId');


              if ($role == 28 || $role == 2) {
                // Fetch total count for roles 28 and 2
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales");
              } else {
                // Fetch count only for the logged-in user's records
                // Logged-in user ki details lein
                $user = $this->db->query("SELECT roleId FROM tbl_users WHERE userId = ?", [$userId])->row();

                if ($user->roleId == 31) { // Agar Team Leader hai
                  // TL apna data + assigned users ka data dekh sakta hai
                  $query = $this->db->query(
                    "
                                SELECT COUNT(*) AS total 
                                FROM tbl_clients_sales 
                                WHERE teamLeadsales = ? OR userId = ?",
                    [$userId, $userId]
                  );
                } else {
                  // Normal user sirf apna data dekh sakta hai
                  $query = $this->db->query(
                    "
                                SELECT COUNT(*) AS total 
                                FROM tbl_clients_sales 
                                WHERE userId = ?",
                    [$userId]
                  );
                }
                $result = $query->row();
                $total = $result->total;
                // Print the executed query for debugging
                //echo "<pre>" . $this->db->last_query() . "</pre>";
              }

              // Fetch the result
              $row = $query->row();
              echo '<h3>' . $row->total . '</h3>';
              ?>


            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); 
                          ?>task" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div><!-- ./col -->

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3 style="font-size: 29px;">Positive Leads<sup style="font-size: 20px"></sup></h3>
              <?php
              $userId = $this->session->userdata('userId');
              $role = $this->session->userdata('role');

              if ($role == 28 || $role == 2) {
                // Admin roles (28, 2) can see all 'Positive leads' & 'Hot leads' data
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales WHERE status IN ('Positive leads', 'Hot leads')");
              } elseif ($role == 31) {
                // Team Leader (31) can see their own + assigned users' 'Positive leads' & 'Hot leads' data
                $query = $this->db->query(
                  "
                    SELECT COUNT(*) AS total 
                    FROM tbl_clients_sales 
                    WHERE status IN ('Positive leads', 'Hot leads')
                    AND (userId = ? OR userId IN (SELECT userId FROM tbl_users WHERE teamLeadsales = ?))",
                  [$userId, $userId]
                );
              } else {
                // Other users (e.g., role 29) can only see their own 'Positive leads' & 'Hot leads' data
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales WHERE status IN ('Positive leads', 'Hot leads') AND userId = ?", [$userId]);
              }

              $row = $query->row();
              echo '<h3>' . ($row ? $row->total : 0) . '</h3>'; // Ensure 0 is shown if no data is found  
              ?>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
          </div>
        </div>

        <!-- ./col -->
        <!-- <div class="col-lg-3 col-xs-6">
         
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3 style="font-size: 29px;">Hot Leads</h3>
 <?php
    $userId = $this->session->userdata('userId');
    $role = $this->session->userdata('role');

    if ($role == 28 || $role == 2) {
      // Admin roles (28, 2) can see all 'hot lead' data
      $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales WHERE status = 'hot lead'");
    } elseif ($role == 31) {
      // Team Leader (31) can see their own + assigned users' 'hot lead' data
      $query = $this->db->query(
        "
        SELECT COUNT(*) AS total 
        FROM tbl_clients_sales 
        WHERE status = 'hot lead'
        AND (userId = ? OR userId IN (SELECT userId FROM tbl_users WHERE teamLeadsales = ?))",
        [$userId, $userId]
      );
    } else {
      // Other users (e.g., role 29) can only see their own 'hot lead' data
      $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales WHERE status = 'hot lead' AND userId = ?", [$userId]);
    }

    $row = $query->row();
    echo '<h3>' . ($row ? $row->total : 0) . '</h3>'; // Ensure 0 is shown if no data is found  
  ?>


            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <!-- <a href="<?php //echo base_url(); 
                          ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> 
          </div>
        </div> --><!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3 style="font-size: 29px;">Converted Leads</h3>
              <?php
              $userId = $this->session->userdata('userId');
              $role = $this->session->userdata('role');

              if ($role == 28 || $role == 2) {
                // Admin roles (28, 2) can see all data
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_results_sales");
              } elseif ($role == 31) {
                // Team Leader (31) can see their own data + assigned users' (29) data
                $query = $this->db->query(
                  "
        SELECT COUNT(*) AS total 
        FROM tbl_results_sales 
        WHERE userId = ? 
        OR userId IN (SELECT userId FROM tbl_users WHERE teamLeadsales = ?)",
                  [$userId, $userId]
                );
              } else {
                // Other users (e.g., role 29) can only see their own data
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_results_sales WHERE userId = ?", [$userId]);
              }

              $row = $query->row();
              echo '<h3>' . ($row ? $row->total : 0) . '</h3>'; // Ensure 0 is shown if no data is found  
              ?>

            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <!-- <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3 style="font-size: 29px;">Rejected</h3>
              <?php
              $userId = $this->session->userdata('userId');
              $role = $this->session->userdata('role');

              if ($role == 28 || $role == 2) {
                // Admin roles (28, 2) can see all rejected data
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales WHERE status = 'Not Interested'");
              } elseif ($role == 31) {
                // Team Leader (31) can see their own data + assigned users' rejected data
                $query = $this->db->query(
                  "
                    SELECT COUNT(*) AS total 
                    FROM tbl_clients_sales 
                    WHERE status = 'Not Interested' 
                    AND (userId = ? OR userId IN (SELECT userId FROM tbl_users WHERE teamLeadsales = ?))",
                  [$userId, $userId]
                );
              } else {
                // Other users (e.g., role 29) can only see their own rejected data
                $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_clients_sales WHERE status = 'Not Interested' AND userId = ?", [$userId]);
              }

              $row = $query->row();
              echo '<h3>' . ($row ? $row->total : 0) . '</h3>';
              ?>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
          </div>
        </div>
        <?php
        $userId = $this->session->userdata('userId');
        $roleId = $this->session->userdata('role');

        // Current user ka incentive nikal rahe hain
        $this->db->select_sum('incentiveReceived');
        $this->db->select_sum('incentiveReceivedSTL');
        $this->db->where('userId', $userId);
        $query = $this->db->get('tbl_incentive');
        $row = $query->row();
        $incentiveReceived = $row->incentiveReceived ?? 0;
        $incentiveReceivedSTL = $row->incentiveReceivedSTL ?? 0;

        // Logic based on role
        if ($roleId == 29) {
          $totalIncentive = $incentiveReceived;
        } elseif ($roleId == 31) {
          $totalIncentive = $incentiveReceivedSTL;
        } else {
          $totalIncentive = $incentiveReceived + $incentiveReceivedSTL;
        }

        // -------- New Code: Find max incentive user -----------

        // For 29
        $this->db->select('userId, SUM(incentiveReceived) as totalIncentive');
        $this->db->group_by('userId');
        $this->db->order_by('totalIncentive', 'DESC');
        $this->db->limit(1);
        $topIncentiveUser29 = $this->db->get('tbl_incentive')->row();

        // For 31
        $this->db->select('userId, SUM(incentiveReceivedSTL) as totalIncentive');
        $this->db->group_by('userId');
        $this->db->order_by('totalIncentive', 'DESC');
        $this->db->limit(1);
        $topIncentiveUser31 = $this->db->get('tbl_incentive')->row();

        $topUserId29 = $topIncentiveUser29->userId ?? null;
        $topUserId31 = $topIncentiveUser31->userId ?? null;

        // Final check
        $showCongratulations = false;
        if (($roleId == 29 && $userId == $topUserId29) || ($roleId == 31 && $userId == $topUserId31)) {
          $showCongratulations = true;
        }
        ?>

        <!-- UI Part -->
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua" style="background-color: #ed5d24;">
            <div class="inner">
              <h3>Incentive</h3>
              <strong>
                <p>Total : ₹<?= number_format($totalIncentive, 2); ?></p>
              </strong>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>

          </div>
        </div>

        <?php if ($showCongratulations): ?>
          <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
          <script>
            window.onload = function() {
              Swal.fire({
                title: '🎉 Congratulations!',
                text: 'You have the highest Incentive!',
                icon: 'success',
                confirmButtonText: 'Awesome!',
                backdrop: `rgba(0,0,123,0.4)`
              });
            };
          </script>
        <?php endif; ?>



    </section>


  <?php  } else { ?>
    <section class="content">
      <div class="row">

        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3>
                <?php
                $loggedInUserId = $this->session->userdata('userId');
                $userRole = $this->session->userdata('role');
                if ($userRole === '1' || $userRole === '14') {
                  // Admin: Fetch all tasks
                  $query = $this->db->query("SELECT * FROM tbl_task");
                } else {
                  // Others: Tasks assigned to or by them
                  $query = $this->db->query("
                    SELECT * 
                    FROM tbl_task 
                    WHERE assignedTo = ? OR assignedBy = ?", [$loggedInUserId, $loggedInUserId]);
                }

                echo $query->num_rows();
                ?>
              </h3>
              <p>Total Tasks</p>
            </div>
            <div class="icon">
              <i class="ion ion-clipboard" style="color: #bfe2ff"></i>
            </div>
            <a href="<?php echo base_url(); ?>/task/taskListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- ./col -->
        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole !== '26') { // Hide from role 26
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  $loggedInUserId = $this->session->userdata('userId');

                  if ($userRole === '1' || $userRole === '14') {
                    // Admin roles: all closed tasks
                    $query = $this->db->query("
                SELECT * 
                FROM tbl_task
                WHERE status = 'closed'
            ");
                  } else {
                    // Other roles: only closed tasks assigned to/by them
                    $query = $this->db->query("
                SELECT * 
                FROM tbl_task 
                WHERE status = 'closed' AND (assignedTo = ? OR assignedBy = ?)", [$loggedInUserId, $loggedInUserId]);
                  }

                  echo $query->num_rows();
                  ?>
                </h3>
                <p>Completed Tasks</p>
              </div>
              <div class="icon">
                <i class="ion ion-checkmark-circled" style="color: #6cd4ed;font-size: 42px;"></i>
              </div>
              <a href="<?php echo base_url(); ?>/task/taskListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>

          </div>
        <?php } ?>

        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole !== '26') {  // Exclude role 26
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Get the logged-in user's ID
                  $loggedInUserId = $this->session->userdata('userId');

                  if ($userRole === '1' || $userRole === '14') {
                    // Admin: Fetch all closed tasks
                    $query = $this->db->query("
                SELECT * 
                FROM tbl_task
                WHERE status = 'open'
            ");
                  } else {
                    // Regular user: Fetch only their open tasks assigned to or by them
                    $query = $this->db->query("
                SELECT * 
                FROM tbl_task 
                WHERE status = 'open' AND (assignedTo = ? OR assignedBy = ?)", [$loggedInUserId, $loggedInUserId]);
                  }

                  echo $query->num_rows();
                  ?>
                </h3>
                <p>Pending Tasks</p>
              </div>
              <div class="icon">
                <i class="fas fa-hourglass-half" style="color: #6cd4ed;font-size: 39px;"></i>
              </div>
              <a href="<?php echo base_url(); ?>/task/taskListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>


        <!-- FOR DESIGNING -->
        <?php $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '19') {  ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the total count of custom designs from tbl_custom_designs
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_custom_desing");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Total Custom Designs</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-compose" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>customdesign/customdesignListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the total count of custom designs where attachmentS3File is NULL or empty
                  $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_custom_desing 
                    WHERE attachmentS3File IS NULL OR attachmentS3File = ''
                ");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Pending Designs</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-timer-outline" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>customdesign/customdesignListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

        <?php } ?>
        <!-- FOR Digital Marketing  -->
        <?php $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '18') {  ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the count of distinct franchise numbers
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_dmfranchse");

                  // Get the result
                  $row = $query->row();
                  echo $row->total ?? 0;
                  ?>
                </h3>
                <p>Branches using DM</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>dmfranchse/dmfranchseListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Get current active campaigns where today is between start and end date
                  $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_dmfranchse 
                    WHERE CURDATE() BETWEEN CampaStartdate AND CampaEnddate
                ");

                  $row = $query->row();
                  echo $row->total ?? 0;
                  ?>
                </h3>
                <p>Active Campaigns</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-pulse" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>dmfranchse/dmfranchseListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>


        <?php } ?>


        <!-- For adminission -->

        <?php $userRole = $this->session->userdata('role');
        $userId = $this->session->userdata('userId');
        if ($userRole === '1' || $userRole === '14' || $userRole === '20') {  ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the total count of admissions from tbl_admission_details_2526
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_admission_details_2526");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Total Admissions</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-people" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>admissiondetailsnew/admissiondetailsListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-orange">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the count of admissions in KG-2 where class is KG-1
                  $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_admission_details_2526 
                    WHERE class = 'Play Group'
                ");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Admission Play Group</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-bookmarks" style="color: #fdf3d2"></i>
              </div>
              <a href="<?php echo base_url(); ?>admissiondetailsnew/admissiondetailsListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-orange">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the count of admissions in KG-2 where class is KG-1
                  $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_admission_details_2526 
                    WHERE class = 'Nursery'
                ");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Admission Nursery</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-book" style="color: #fdf3d2"></i>
              </div>
              <a href="<?php echo base_url(); ?>admissiondetailsnew/admissiondetailsListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-orange">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the count of admissions in KG-2 where class is KG-1
                  $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_admission_details_2526 
                    WHERE class = 'KG-1'
                ");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Admission KG-1</p>
              </div>
              <div class="icon">
                <i class="ion ion-compose" style="color: #fdf3d2"></i>
              </div>
              <a href="<?php echo base_url(); ?>admissiondetailsnew/admissiondetailsListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-orange">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the count of admissions in KG-2 where class is KG-1
                  $query = $this->db->query("
                    SELECT COUNT(*) AS total 
                    FROM tbl_admission_details_2526 
                    WHERE class = 'KG-2'
                ");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Admission KG-2</p>
              </div>
              <div class="icon">
                <i class="ion ion-university" style="color: #fdf3d2"></i>
              </div>
              <a href="<?php echo base_url(); ?>admissiondetailsnew/admissiondetailsListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch branch number, name, city, admission count, and Growth Manager name, limit to top 20
                  $query = $this->db->query("
          SELECT 
              a.franchiseNumber, 
              MAX(a.name) as name, 
              MAX(a.city) as city,
              COUNT(*) as admission_count,
              MAX(u.name) as growth_manager
          FROM tbl_admission_details_2526 a
          LEFT JOIN tbl_users u ON a.brspFranchiseAssigned = u.userId AND u.roleId = 15
          GROUP BY a.franchiseNumber
          HAVING admission_count > 0
          ORDER BY admission_count DESC
          LIMIT 1
        ");

                  // Fetch the result
                  $row = $query->row(); // Use row() since LIMIT 1 ensures one result
                  echo $row->franchiseNumber ?? "No Data"; // Display branch name or "No Data" if no results
                  ?>
                </h3>
                <p>Highest Admission</p>
              </div>
              <div class="icon">
                <i class="ion ion-ribbon-b" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>admissiondetailsnew/admissiondetailsListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>

        <!-- DESPATCH -->

        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '23') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the total count of records from tbl_despatch where status = 'pending'
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_despatch WHERE status = ?", ['pending']);

                  // Check if the query was successful
                  if ($query) {
                    $row = $query->row();
                    echo $row ? ($row->total ?? 0) : 0; // Display 0 if no records or query fails
                  } else {
                    echo 0; // Display 0 if query fails
                  }
                  ?>
                </h3>
                <p>Pending Orders</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-cart" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>despatch/despatchListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>

        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '23') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                 <?php
                  // Fetch the total count of records from tbl_despatch where status = 'pending'
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_despatch WHERE status = ?", ['processing']);

                  // Check if the query was successful
                  if ($query) {
                    $row = $query->row();
                    echo $row ? ($row->total ?? 0) : 0; // Display 0 if no records or query fails
                  } else {
                    echo 0; // Display 0 if query fails
                  }
                  ?>
                </h3>
                <p>Processing Orders</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-cart" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>despatch/despatchListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>



         <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '23') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                 <?php
                  // Fetch the total count of records from tbl_despatch where status = 'pending'
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_despatch WHERE status = ?", ['cancelled']);

                  // Check if the query was successful
                  if ($query) {
                    $row = $query->row();
                    echo $row ? ($row->total ?? 0) : 0; // Display 0 if no records or query fails
                  } else {
                    echo 0; // Display 0 if query fails
                  }
                  ?>
                </h3>
                <p>Cancelled  Orders</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-cart" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>despatch/despatchListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>


          <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '23') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                 <?php
                  // Fetch the total count of records from tbl_despatch where status = 'pending'
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_despatch WHERE status = ?", ['failed']);

                  // Check if the query was successful
                  if ($query) {
                    $row = $query->row();
                    echo $row ? ($row->total ?? 0) : 0; // Display 0 if no records or query fails
                  } else {
                    echo 0; // Display 0 if query fails
                  }
                  ?>
                </h3>
                <p>Failed Orders</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-cart" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>despatch/despatchListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>
        <!-- GROWTH -->


        <!-- ACCOUNTS -->
        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '16' || $userRole === '15') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  $userId = $this->session->userdata('userId');
                  $roleId = $this->session->userdata('role');

                  if ($roleId == 1 || $roleId == 14 || $roleId == 16) {
                    $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_amc WHERE statusAmc = 0 ");
                  } else {
                    $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_amc WHERE statusAmc = 2 AND brspFranchiseAssigned = ?", [$userId]);
                  }

                  $dueAmc = $query->row()->total ?? 0;
                  echo $dueAmc;
                  ?>
                </h3>
                <p>Due AMCs</p>
              </div>
              <div class="icon">
                <i class="ion ion-alert-circled" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>amc/amcListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>


          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  $userId = $this->session->userdata('userId');
                  $roleId = $this->session->userdata('role');

                  if ($roleId == 1 || $roleId == 14 || $roleId == 16) {
                    $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_pdc");
                  } else {
                    $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_pdc WHERE statusOfPDc = 2 AND brspFranchiseAssigned = ?", [$userId]);
                  }

                  $duePdc = $query->row()->total ?? 0;
                  echo $duePdc;
                  ?>
                </h3>
                <p>Due PDCs</p>
              </div>
              <div class="icon">
                <i class="ion ion-calendar" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>pdc/pdcListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

        <?php } ?>


        <!-- HR -->

        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '26') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 22");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total IT Employees</p>
              </div>
              <div class="icon">
                <i class="fas fa-laptop-code" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 15");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Growth Managers</p>
              </div>
              <div class="icon">
                <i class="ion-android-contacts" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 19");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Design Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-stalker" style="color: #ffeacc "></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-blue">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 13");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Onboarding Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-people-outline" style="color: #bfe2ff"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 24");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Legal Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-document-text" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 18");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Digital Marketing Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-podium" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 23");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Despatch Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-loop" style="color: #ffeacc "></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-blue">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId IN (34, 29, 31)");
                  echo $query->row()->total ?? 0;
                  ?>
                </h3>
                <p>Total Sales Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-stalker" style="color: #bfe2ff"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>

          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 21");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Training Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-ios-paper" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 20");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Admissions Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-log-out" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-yellow">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 16");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Accounts Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-calculator" style="color: #ffeacc "></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-blue">
              <div class="inner">
                <h3>
                  <?php
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_users WHERE roleId = 33");
                  $itEmployees = $query->row()->total ?? 0;
                  echo $itEmployees;
                  ?>
                </h3>
                <p>Total Social Media Employees</p>
              </div>
              <div class="icon">
                <i class="ion ion-social-youtube" style="color: #bfe2ff"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>
        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14' || $userRole === '21') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-green">
              <div class="inner">
                <h3>
                  <?php
                  // Fetch the total count of records from tbl_despatch where delStatus = 2
                  $query = $this->db->query("SELECT COUNT(*) AS total FROM tbl_despatch WHERE delStatus = 2");

                  // Fetch the count result
                  $row = $query->row();
                  echo $row->total ?? 0; // Display 0 if no records found
                  ?>
                </h3>
                <p>Total Staff Members</p>
              </div>
              <div class="icon">
                <i class="ion ion-android-people" style="color: #6cd4ed"></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>


        <!-- ./col -->
        <?php $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '14') {  ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->

            <div class="small-box bg-yellow">
              <div class="inner">
                <h3><?php
                    $query = $this->db->query('SELECT * FROM tbl_users');
                    echo $query->num_rows(); ?></h3>
                <p>New User</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add" style="color: #ffeacc "></i>
              </div>
              <a href="<?php echo base_url(); ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              <!-- <a href="<?php //echo base_url(); 
                            ?>userListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
            </div>
          </div>
        <?php } else {
        } ?> <!-- ./col -->
        <?php
        $loggedInUserId = $this->session->userdata('userId');
        $userRole = $this->session->userdata('role');

        // Hide block if userRole is 22
        if ($userRole !== '22' && $userRole !== '27' && $userRole !== '18' && $userRole !== '23' && $userRole !== '20' && $userRole !== '21' && $userRole !== '24' && $userRole !== '16' && $userRole !== '26' && $userRole !== '15') {
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-red">
              <div class="inner">
                <h3>
                  <?php
                  if ($userRole === '1' || $userRole === '14' || $userRole === '19' || $userRole === '33') {
                    // Admin: Count all branches
                    $query = $this->db->query("SELECT COUNT(*) AS alloted_branches_count FROM tbl_branches");
                  } else {
                    // Other users: Count only assigned branches
                    $query = $this->db->query("
                        SELECT COUNT(*) AS alloted_branches_count 
                        FROM tbl_branches 
                        WHERE branchFranchiseAssigned = ?", [$loggedInUserId]);
                  }

                  // Fetch and display the result
                  $result = $query->row();
                  echo $result->alloted_branches_count;
                  ?>
                </h3>
                <p>Total Branches</p>
              </div>
              <div class="icon">
                <i class="ion ion-network" style="color: #ecbba5;"></i>
              </div>
              <a href="<?php echo base_url(); ?>branches/branchesListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>
        <!-- ./col -->
        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole !== '26') { // Exclude role 26
        ?>
          <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-orange">
              <div class="inner">
                <h3>
                  <?php
                  $loggedInUserId = $this->session->userdata('userId');

                  if (in_array($userRole, ['1', '14', '13', '22', '27', '18', '23', '20', '21', '16', '24', '19', '33'])) {
                    // Allowed roles: count all active branches
                    $query = $this->db->query("SELECT COUNT(*) AS active_branches_count FROM tbl_branches WHERE currentStatus = 'Installed-Active'");
                  } else {
                    // Others: count only branches assigned to them
                    $query = $this->db->query("SELECT COUNT(*) AS active_branches_count FROM tbl_branches WHERE currentStatus = 'Installed-Active' AND branchFranchiseAssigned = ?", [$loggedInUserId]);
                  }

                  $result = $query->row();
                  echo $result->active_branches_count;
                  ?>
                </h3>
                <p>Active Branches</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph" style="color: #fdf3d2"></i>
              </div>
              <a href="<?php echo base_url(); ?>branches/branchesListing" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
            </div>
          </div>
        <?php } ?>

        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT franchiseNumber, branchAnniversaryDate, applicantName
    FROM tbl_branches
    WHERE branchAnniversaryDate IS NOT NULL
    AND franchiseNumber IS NOT NULL
    AND applicantName IS NOT NULL
    AND MONTH(branchAnniversaryDate) = MONTH(CURDATE())
    AND DAY(branchAnniversaryDate) >= DAY(CURDATE())
    ORDER BY DAY(branchAnniversaryDate) ASC
    LIMIT 10;
");

        $rows = $query->result();
        ?>

        <?php
        $userRole = $this->session->userdata('role');
        if ($userRole === '1' || $userRole === '2' || $userRole === '14' || $userRole === '26' || $userRole === '19') {
        ?>

          <div class="col-md-12 col-lg-5 col-xl-5  panel-old">
            <h4> Branch Anniversary List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Branch No</th>
                  <th>Branch Anniversary</th>
                  <th>Branch Owner</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="3">No anniversaries found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->branchAnniversaryDate)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                      <td><?= !empty($row->branchAnniversaryDate) ? htmlspecialchars(date('F j, Y', strtotime($row->branchAnniversaryDate))) : 'No Data' ?></td>
                      <td><?= !empty($row->applicantName) ? htmlspecialchars($row->applicantName) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        <?php } ?>

        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT franchiseNumber, OwnerAnniversery, applicantName
    FROM tbl_branches
    WHERE OwnerAnniversery IS NOT NULL
    AND franchiseNumber IS NOT NULL
    AND applicantName IS NOT NULL
    AND MONTH(OwnerAnniversery) = MONTH(CURDATE())
    AND DAY(OwnerAnniversery) >= DAY(CURDATE())
    ORDER BY DAY(OwnerAnniversery) ASC
    LIMIT 10;
");

        $rows = $query->result();
        ?>


        <?php if (in_array($role, [1, 2,  14,  26, 19])) { ?>
          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4> Branch Owner Anniversary List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Branch No</th>
                  <th>Owner Anniversary</th>
                  <th>Branch Owner</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="3">No anniversaries found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->OwnerAnniversery)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                      <td><?= !empty($row->OwnerAnniversery) ? htmlspecialchars(date('F j, Y', strtotime($row->OwnerAnniversery))) : 'No Data' ?></td>
                      <td><?= !empty($row->applicantName) ? htmlspecialchars($row->applicantName) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        <?php } ?>

        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT 
        franchiseNumber,
        birthday,
        name
    FROM tbl_staff_details
    WHERE birthday IS NOT NULL
    AND franchiseNumber IS NOT NULL
    AND name IS NOT NULL
    AND MONTH(birthday) = MONTH(CURDATE())
    AND DAY(birthday) >= DAY(CURDATE())
    ORDER BY DAY(birthday) ASC
    LIMIT 10;
");

        $rows = $query->result();
        ?>


        <?php if (in_array($role, [1, 2,  14,  26, 25, 19])) { ?>
          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Branch Employee Birthday List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Branch No</th>
                  <th>Birthday</th>
                  <th>Staff Name</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="3">No staff birthdays found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->birthday)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                      <td><?= !empty($row->birthday) ? htmlspecialchars(date('F j, Y', strtotime($row->birthday))) : 'No Data' ?></td>
                      <td><?= !empty($row->name) ? htmlspecialchars($row->name) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>


        <?php } ?>
        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT 
        hronboardId,
        dob,
        first_name
    FROM tbl_hrforms_onboard
    WHERE dob IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(dob) = MONTH(CURDATE())
    AND DAY(dob) >= DAY(CURDATE())
    ORDER BY DAY(dob) ASC
    LIMIT 10;
");

        $rows = $query->result();
        ?>

        <?php if (in_array($role, [1, 2,  14,  26, 19])) { ?>

          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Edumeta Employee Birthday List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>S. No.</th>
                  <th>Birthday</th>
                  <th>Name</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="3">No staff birthdays found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->dob)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= !empty($row->hronboardId) ? htmlspecialchars($row->hronboardId) : 'No Data' ?></td>
                      <td><?= !empty($row->dob) ? htmlspecialchars(date('F j, Y', strtotime($row->dob))) : 'No Data' ?></td>
                      <td><?= !empty($row->first_name) ? htmlspecialchars($row->first_name) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

        <?php } ?>

        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT 
        hronboardId,
        joining_date,
        first_name
    FROM tbl_hrforms_onboard
    WHERE joining_date IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(joining_date) = MONTH(CURDATE())
    AND DAY(joining_date) >= DAY(CURDATE())
    ORDER BY DAY(joining_date) ASC
      LIMIT 10;
");

        $rows = $query->result();
        ?>
        <?php if (in_array($role, [1, 2,  14,  26, 19])) { ?>
          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Edumeta Employee Work Anniversary List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>S.No.</th>
                  <th>Joining Date</th>
                  <th>Name</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="3">No staff birthdays found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->joining_date)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= $index + 1 ?></td>
                      <td><?= !empty($row->joining_date) ? htmlspecialchars(date('F j, Y', strtotime($row->joining_date))) : 'No Data' ?></td>
                      <td><?= !empty($row->first_name) ? htmlspecialchars($row->first_name) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>


        <?php } ?>
        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT 
        admid,
        franchiseNumber,
        birthday,
        name
    FROM tbl_admission_details
    WHERE birthday IS NOT NULL
    AND franchiseNumber IS NOT NULL
    AND name IS NOT NULL
    AND MONTH(birthday) = MONTH(CURDATE())
    AND DAY(birthday) >= DAY(CURDATE())
    ORDER BY DAY(birthday) ASC
      LIMIT 10;
");

        $rows = $query->result();
        ?>

        <?php if (in_array($role, [1, 2,  14,  26, 19])) { ?>

          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Student Birthday List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>S. No.</th>
                  <th>Branch No.</th>
                  <th>Birthday</th>
                  <th>Name</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="4">No staff birthdays found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->birthday)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= $index + 1 ?></td>
                      <td><?= !empty($row->franchiseNumber) ? htmlspecialchars($row->franchiseNumber) : 'No Data' ?></td>
                      <td><?= !empty($row->birthday) ? htmlspecialchars(date('F j, Y', strtotime($row->birthday))) : 'No Data' ?></td>
                      <td><?= !empty($row->name) ? htmlspecialchars($row->name) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        <?php } ?>


        <?php
        date_default_timezone_set('Asia/Kolkata');

        $query = $this->db->query("
    SELECT 
        hronboardId,
        anniversary_date,
        first_name
    FROM tbl_hrforms_onboard
    WHERE anniversary_date IS NOT NULL
    AND first_name IS NOT NULL
    AND MONTH(anniversary_date) = MONTH(CURDATE())
    AND DAY(anniversary_date) >= DAY(CURDATE())
    ORDER BY DAY(anniversary_date) ASC;
");

        $rows = $query->result();
        ?>



        <?php if (in_array($role, [1, 2,  14,  26, 19])) { ?>
          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-birthday-cake" style="color: #ff69b4;"></i> Edumeta Employee Marriage Anniversary List</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>S. No.</th>
                  <th>Anniversary Date</th>
                  <th>First Name</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="4">No staff birthdays found for the current month.</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= (date('m-d', strtotime($row->anniversary_date)) == date('m-d')) ? 'table-warning' : ($index % 2 == 0 ? 'table-primary' : 'table-secondary') ?>">
                      <td><?= $index + 1 ?></td>
                      <td><?= !empty($row->anniversary_date) ? htmlspecialchars(date('F j, Y', strtotime($row->anniversary_date))) : 'No Data' ?></td>
                      <td><?= !empty($row->first_name) ? htmlspecialchars($row->first_name) : 'No Data' ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

        <?php } ?>

        <!-- Training -->






        <?php
        $query = $this->db->query("
    SELECT franchiseNumber, COUNT(*) as despatch_count
    FROM tbl_despatch
    GROUP BY franchiseNumber
    HAVING despatch_count > 5
    ORDER BY despatch_count DESC
");

        $rows = $query->result();
        ?>
        <section>
          <?php
          if (in_array($role, [1, 14, 23, 15])) { ?>
            <div class="col-md-6">
              <div class="box">
                <div class="box-header with-border">
                  <h3 class="box-title">Dispatch Orders Per Month</h3>
                  <div class="box-tools pull-right">
                    <div class="form-group" style="display: flex; gap: 10px;">
                      <?php $branchDetails = $this->db
                        ->select('franchiseNumber')
                        ->from('tbl_branches') // Replace with your actual table name
                        ->where('isDeleted', 0) // Optional: only if you want to exclude deleted branches
                        ->get()
                        ->result();
                      ?>
                      <?php if (in_array($role, [1, 14, 16, 23])) { ?>
                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                          <option value="">Select Franchise</option>
                          <?php
                          if (!empty($branchDetails)) {
                            foreach ($branchDetails as $bd) {
                              $franchiseNumber = htmlspecialchars($bd->franchiseNumber, ENT_QUOTES, 'UTF-8');
                              echo '<option value="' . $franchiseNumber . '">' . $franchiseNumber . '</option>';
                            }
                          }
                          ?>
                        </select>
                      <?php } ?>
                      <select class="form-control" id="despatchYear">
                        <?php
                        $currentYear = date('Y');
                        for ($i = $currentYear - 5; $i <= $currentYear; $i++) {
                          echo '<option value="' . $i . '" ' . ($i == $currentYear ? 'selected' : '') . '>' . $i . '</option>';
                        }
                        ?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-12">
                      <div id="despatchChart"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </section>
      <?php } ?>

      </div>
    </section>

    <section>
      <?php
      if (in_array($role, [1, 14, 21, 25, 15])) { ?>
        <div class="col-md-5">
          <div class="box">
            <div class="box-header with-border">
              <p class="box-title">Training Schedules Per Month</p>
              <div class="box-tools">
                <div class="form-group">
                  <select class="form-control" id="trainingYear">
                    <?php
                    $currentYear = date('Y');
                    for ($i = $currentYear - 5; $i <= $currentYear; $i++) {
                      echo '<option value="' . $i . '" ' . ($i == $currentYear ? 'selected' : '') . '>' . $i . '</option>';
                    }
                    ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <div id="trainingChart"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php } ?>
    </section>

  <?php } ?>


  <!-- scheduled training -->

  <?php if (in_array($role, [1, 14, 15])) { ?>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-6 col-xl-6 panel pg-fw">
            <div class="card mt-4">
              <div class="card-header">
                <h5 class="card-title">Scheduled Trainings (Latest 10)</h5>
              </div>
              <div class="card-body">

                <!-- Training Table -->
                <div id="trainingTable">
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead class="thead-dark">
                        <tr>
                          <th>Franchise Number</th>
                          <th>Date</th>
                          <th>Title</th>
                          <th>Trainer</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $this->db->select('*');
                        $this->db->from('tbl_training');
                        $this->db->where('statusofTraining', 'Schedule');
                        if (!empty($this->input->get('franchiseNumber'))) {
                          $this->db->where('franchiseNumber', $this->input->get('franchiseNumber'));
                        }
                        $this->db->order_by('trainingId', 'DESC');
                        $this->db->limit(10);
                        $query = $this->db->get();
                        $scheduledTrainings = $query->result();
                        ?>
                        <?php if (!empty($scheduledTrainings)) { ?>
                          <?php foreach ($scheduledTrainings as $training) { ?>
                            <tr>
                              <td><?php echo htmlspecialchars($training->franchiseNumber ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?></td>
                              <td><?php echo isset($training->dateTraing) ? date('d M Y', strtotime($training->dateTraing)) : 'No Date'; ?></td>
                              <td><?php echo htmlspecialchars($training->trainingTitle ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?></td>
                              <td><?php echo htmlspecialchars($training->nameOfTrainer ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?></td>
                            </tr>
                          <?php } ?>
                        <?php } else { ?>
                          <tr>
                            <td colspan="4">No scheduled training found.</td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  <?php } ?>

  <!-- bar Graph Chart -->
  <?php
  $userRole = $this->session->userdata('role');
  if ($userRole === '2' || $userRole === '29' || $userRole === '31' || $userRole === '1' || $userRole === '14') {
  ?>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-6 col-xl-6 panel pg-fw">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title" id="chartTitle"><?php echo date('Y'); ?> Performance</h4>
                <p class="card-category">Total Number of Clients Added Per Month</p>
                <div style="display: flex; gap: 10px; align-items: center;">
                  <select id="yearSelector" class="form-control" style="width: 100px; display: inline-block;">
                    <option value="<?php echo date('Y'); ?>" selected><?php echo date('Y'); ?></option>
                  </select>
                  <select id="userSelector" class="form-control" style="width: 200px; display: inline-block;">
                    <option value="">All Users</option>
                  </select>
                </div>
              </div>
              <div class="card-body">
                <div id="salesChart" style="min-height: 350px; width: 100%;"></div>
              </div>
            </div>
          </div>


          <?php
          $query = $this->db->query("
  SELECT franchiseNumber, MAX(name) as name, MAX(city) as city, COUNT(*) as admission_count
  FROM tbl_admission_details_2526
  GROUP BY franchiseNumber
  HAVING admission_count > 5
  ORDER BY admission_count DESC
");

          $rows = $query->result();
          ?>
          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa-solid fa-crown" style="color: #f39c12;"></i> Prime Members</h4>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Branch No</th>
                  <th>Branch Name</th>
                  <th>Admission Count</th>
                  <th>City</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="4">No Data Available</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= $index % 2 == 0 ? 'table-primary' : 'table-secondary' ?>">
                      <td><?= $row->franchiseNumber ?? "No Data" ?></td>
                      <td><?= $row->name ?? "No Data" ?></td>
                      <td><?= $row->admission_count ?? "No Data" ?></td>
                      <td><?= $row->city ?? "No Data" ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>






          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa fa-line-chart"></i> Top Performer Branches Leader Board - Highest Admission</h4>
            <p>
              <?php
              // Fetch branch number, name, city, admission count, and Growth Manager name, limit to top 20
              $query = $this->db->query("
    SELECT 
        a.franchiseNumber, 
        MAX(a.name) as name, 
        MAX(a.city) as city,
        COUNT(*) as admission_count,
        MAX(u.name) as growth_manager
    FROM tbl_admission_details_2526 a
    LEFT JOIN tbl_users u ON a.brspFranchiseAssigned = u.userId AND u.roleId = 15
    GROUP BY a.franchiseNumber
    HAVING admission_count > 0
    ORDER BY admission_count DESC
    LIMIT 10
");

              // Fetch the results
              $rows = $query->result();
              ?>
              <!-- Start Table -->
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Branch No</th>
                  <th>Branch Name</th>
                  <th>City</th>
                  <th>Admission Count</th>
                  <th>Growth Manager</th>
                </tr>
              </thead>
              <tbody>
                <?php if (empty($rows)): ?>
                  <tr>
                    <td colspan="5">No Data Available</td>
                  </tr>
                <?php else: ?>
                  <?php foreach ($rows as $index => $row): ?>
                    <tr class="<?= $index % 2 == 0 ? 'table-primary' : 'table-secondary' ?>">
                      <td><?php echo $row->franchiseNumber ?? "No Data"; ?></td>
                      <td><?php echo $row->name ?? "No Data"; ?></td>
                      <td><?php echo $row->city ?? "No Data"; ?></td>
                      <td><?php echo $row->admission_count ?? "No Data"; ?></td>
                      <td><?php echo $row->growth_manager ?? "Not Assigned"; ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
            <!-- End Table -->
            </p>
          </div>
          <!-- Sales Monthly Results Leaderboard -->
          <div class="col-md-12 col-lg-5 col-xl-5 panel">
            <h4><i class="fa fa-line-chart"></i> Sales Monthly Results Leaderboard</h4>

            <!-- Month Selection Form -->
            <form id="monthForm" method="get" class="mb-3">
              <label for="month">Select Month:</label>
              <select name="month" id="month" class="form-control" style="width:200px; display:inline-block;">
                <option value="">All Months</option>
                <?php
                // Generate last 12 months
                for ($i = 0; $i < 12; $i++) {
                  $monthValue = date('Y-m', strtotime("-$i months"));
                  $monthLabel = date('F Y', strtotime($monthValue));
                  $selected = (isset($_GET['month']) && $_GET['month'] == $monthValue) ? 'selected' : '';
                  echo "<option value='$monthValue' $selected>$monthLabel</option>";
                }
                ?>
              </select>
            </form>

            <!-- Leaderboard Display -->
            <div id="leaderboardContent">
              <?php
              // Get user session data
              $userId = $this->session->userdata('userId');
              $role = $this->session->userdata('role');

              // Role-based filtering (aligned with Results_model)
              $whereClause = '';
              $params = [];
              if (in_array($role, [1, 2, 14, 28])) {
                $whereClause = '1 = 1'; // Admins see all users
              } elseif ($role == 31) {
                $whereClause = '(r.userID = ? OR r.userID IN (SELECT userId FROM tbl_users WHERE teamLeadsales = ?))';
                $params = [$userId, $userId]; // Team lead sees their team
              } else {
                $whereClause = 'r.userID = ?';
                $params = [$userId]; // Regular user sees only their data
              }

              // Get selected month or all months
              $selectedMonth = isset($_GET['month']) ? $_GET['month'] : '';
              $startDate = $selectedMonth ? $selectedMonth . '-01' : '';
              $endDate = $selectedMonth ? date('Y-m-t', strtotime($startDate)) : '';

              // Build WHERE clause for date filtering
              $dateClause = $selectedMonth ? 'AND DATE(r.issuedon) BETWEEN ? AND ?' : '';
              $queryParams = $selectedMonth ? array_merge($params, [$startDate, $endDate]) : $params;

              // Query to fetch sales records for all users from tbl_results_sales
              $query = $this->db->query("
      SELECT 
          u.name AS UserName,
          COUNT(r.resultsId) AS SalesCount,
          GROUP_CONCAT(r.clientname) AS ClientNames
      FROM tbl_results_sales r
      JOIN tbl_users u ON u.userId = r.userID
      WHERE $whereClause $dateClause AND r.isDeleted = 0
      GROUP BY r.userID
      ORDER BY SalesCount DESC
    ", $queryParams);

              $results = $query->result();

              // Display leaderboard table
              if (!empty($results)) {
                echo "<table class='table table-striped' id='leaderboardTable'>
            <thead>
                <tr class='table-primary'>
                    <th>Rank</th>
                    <th>User Name</th>
                    <th>Sales Count</th>
                </tr>
            </thead>
            <tbody>";
                $rank = 1;
                foreach ($results as $row) {
                  echo "<tr>
                <td>$rank</td>
                <td>{$row->UserName}</td>
                <td>{$row->SalesCount}</td>
              </tr>";
                  $rank++;
                }
                echo "</tbody></table>";
              } else {
                echo "<p>No sales data found for " . ($selectedMonth ? date('F Y', strtotime($selectedMonth)) : 'all months') . ".</p>";
              }
              ?>
            </div>
          </div>
          <!-- Scheduled Trainings -->


          <?php
          $userRole = $this->session->userdata('role');
          if ($userRole === '15' || $userRole === '1' || $userRole === '14') {
          ?>
            <section>
              <div class="container">
                <div class="row">
                  <div class="col-md-12 col-lg-8 col-xl-8 panel pg-fw">
                    <div class="card mt-4">
                      <div class="card-header">
                        <strong>
                          <h5 class="card-title">Growth Managers with Branch Numbers</h5>
                        </strong>
                      </div>
                      <div class="card-body">
                        <?php
                        $this->db->select('u.name as manager_name, GROUP_CONCAT(b.franchiseNumber ORDER BY b.franchiseNumber SEPARATOR ",") as franchiseNumbers');
                        $this->db->from('tbl_branches b');
                        $this->db->join('tbl_users u', 'u.userId = b.branchFranchiseAssigned', 'inner');
                        $this->db->group_by('b.branchFranchiseAssigned');
                        $this->db->order_by('u.name', 'ASC');
                        $query = $this->db->get();
                        $branches = $query->result();
                        ?>

                        <?php if (!empty($branches)) { ?>
                          <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                              <thead class="thead-dark">
                                <tr>
                                  <th>Growth Manager</th>
                                  <th>Branch Numbers</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php foreach ($branches as $index => $branch) {
                                  $allBranches = explode(',', $branch->franchiseNumbers);
                                  $total = count($allBranches);
                                  $firstTwo = array_slice($allBranches, 0, 2);
                                  $remaining = array_slice($allBranches, 2);
                                  $groupId = "branchGroup_" . $index;
                                  $linkId = "toggleLink_" . $index;
                                ?>
                                  <tr>
                                    <td><?php echo htmlspecialchars($branch->manager_name ?? 'N/A'); ?></td>
                                    <td>
                                      <?php echo implode(', ', array_map('trim', $firstTwo)); ?>
                                      <?php if ($total > 2) { ?>
                                        <span id="<?php echo $groupId; ?>" style="display:none;">
                                          , <?php echo implode(', ', array_map('trim', $remaining)); ?>
                                        </span>
                                        <a href="javascript:void(0);" id="<?php echo $linkId; ?>" class="text-primary" onclick="toggleBranches('<?php echo $groupId; ?>', '<?php echo $linkId; ?>')">
                                          +<?php echo count($remaining); ?> more
                                        </a>
                                      <?php } ?>
                                    </td>
                                  </tr>
                                <?php } ?>
                              </tbody>
                            </table>
                          </div>

                          <script>
                            function toggleBranches(groupId, linkId) {
                              const hiddenSpan = document.getElementById(groupId);
                              const toggleLink = document.getElementById(linkId);

                              if (hiddenSpan.style.display === 'none') {
                                // Show remaining branches
                                hiddenSpan.style.display = 'inline';
                                toggleLink.textContent = 'less';
                              } else {
                                // Hide remaining branches
                                hiddenSpan.style.display = 'none';
                                // Count how many branches are hidden for the +N more text
                                const count = hiddenSpan.textContent.split(',').length;
                                toggleLink.textContent = `+${count} more`;
                              }
                            }
                          </script>
                        <?php } else { ?>
                          <p>No branches found.</p>
                        <?php } ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          <?php } ?>


          <?php
          $userRole = $this->session->userdata('role');
          if ($userRole === '25' || $userRole === '1' || $userRole === '14') {
          ?>
            <section>
              <div class="container">
                <div class="row">
                  <div class="col-md-12 col-lg-6 col-xl-6 panel pg-fw">
                    <div class="card">
                      <div class="card-header">
                        <h4 class="card-title" id="admissionChartTitle"><?php echo date('Y'); ?> Admission Details</h4>
                        <p class="card-category">Total Number of Admissions Per Month</p>
                        <div style="display: flex; gap: 10px; align-items: center;">
                          <select id="admissionYearSelector" class="form-control" style="width: 100px; display: inline-block;">
                            <option value="<?php echo date('Y'); ?>" selected><?php echo date('Y'); ?></option>
                            <?php for ($i = date('Y') - 5; $i <= date('Y'); $i++) { ?>
                              <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php } ?>
                          </select>
                          </select>
                          <?php
                          $branchDetails = $this->db
                            ->select('franchiseNumber')
                            ->from('tbl_branches')
                            ->where('isDeleted', 0)
                            ->get()
                            ->result();
                          ?>
                          <select class="form-control" id="franchiseSelector" name="franchiseNumber" data-live-search="true" style="width: 150px; display: inline-block;">
                            <option value="">All Franchises</option>
                            <?php
                            if (!empty($branchDetails)) {
                              foreach ($branchDetails as $bd) {
                                $franchiseNumber = htmlspecialchars($bd->franchiseNumber, ENT_QUOTES, 'UTF-8');
                                echo '<option value="' . $franchiseNumber . '">' . $franchiseNumber . '</option>';
                              }
                            }
                            ?>
                          </select>
                        </div>
                      </div>
                      <div class="card-body">
                        <div id="admissionChart" style="min-height: 350px; width: 100%;"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php } ?>
        </div>
      </div>
    </section>
  <?php } ?>
</div>
</div>

<style type="text/css">
  .modrow-cls {
    /*background-color: #E3F2FD;*/
    padding: 4px;
    text-align: center;
    border-bottom: 1px solid #fff;
    /*height: auto; */
    background-color: #e3e3e3;
    /*background-image: repeating-linear-gradient(red, yellow 25%, green 100%);*/
  }

  .label-success1 {
    /*color: #545454;*/
    color: #1d1d1d;
    font-size: 14px;
  }

  .modviewbtn {
    padding: 5px 5px 5px 5px;
    font-size: 10px;
    text-align: center;
    cursor: pointer;
    outline: none;
    color: #fff;
    background-color: #f4511e;
    border: none;
    border-radius: 15px;
    box-shadow: 0 3px #d1d1d1;
  }

  .modviewbtn:active {
    background-color: #f4511e;
    box-shadow: 0 5px #666;
    transform: translateY(4px);
  }

  .modviewbtn:hover {
    color: #fff;
    text-decoration: none;
    background: #f93b00;
    box-shadow: 0 6px #e5e4e4;
  }

  .modrow-cls .label {
    font-weight: 500;
  }

  .modal-content {
    border: 4px solid #f93b00;
    border-radius: 5px;
  }

  .frnewbtn a button:hover {
    background: #3c8dbc;
    color: #fff;
    border: 2px solid #f39c12;
  }

  .frnewbtn a button {
    padding: 5px;
    border-radius: 5px;
    border: 2px solid #f39c12;
    margin: 4px;
    background: #fff;
  }

  /*---Progress-Bar---*/
  .progress {
    background-color: #f16868;
    border-radius: 50px;
    height: 15px;
    margin-bottom: 5px;
  }

  .progress-bar {
    height: 97%;
    background-color: #238f2a;
    line-height: 14px;
  }

  .progress-bar-striped,
  .progress-striped .progress-bar {
    background-size: 10px 10px;
  }

  .img-circle1 {
    width: 50%;
    height: 130px;
    object-fit: inherit;
  }

  .panel {
    border: 1px solid #b5b2b2ba;
    margin-left: 15px;
  }

  .small-box .icon {
    font-size: 48px;
  }

  .small-box h3 {
    font-size: 18px;
    margin: 0 0 0px 0;
  }

  .small-box:hover .icon {
    font-size: 56px;

  }
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/apexcharts.min.js'); ?>"></script>
<script>
  $(document).ready(function() {
    $('#franchiseNumber').selectpicker();
  });
</script>
<script>
  $(document).ready(function() {
    let salesChartInstance = null;

    function renderSalesChart(year, userFilter = '') {
      console.log("Fetching sales data for year:", year, "userFilter:", userFilter);

      $.ajax({
        url: '<?php echo base_url('results/getClientChartData'); ?>',
        type: 'GET',
        data: {
          year: year,
          userFilter: userFilter
        },
        dataType: 'json',
        success: function(response) {
          console.log("Sales data received:", response);

          // Ensure array is 12 months long, default to 0 if invalid
          const clients = Array.isArray(response.clients) && response.clients.length === 12 ?
            response.clients :
            Array(12).fill(0);

          console.log("Clients data:", clients);

          const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          $('#chartTitle').text(year + ' Performance' + (userFilter ? ' for ' + $('#userSelector option:selected').text() : ''));

          const options = {
            chart: {
              type: 'bar',
              height: 350,
              toolbar: {
                show: true
              }
            },
            series: [{
              name: 'Converted Clients',
              data: clients
            }],
            xaxis: {
              categories: months,
              title: {
                text: 'Months'
              }
            },
            yaxis: {
              title: {
                text: 'Count'
              }
            },
            plotOptions: {
              bar: {
                columnWidth: '40%',
                endingShape: 'rounded'
              }
            },
            dataLabels: {
              enabled: true,
              formatter: val => val > 0 ? val : ''
            },
            stroke: {
              show: true,
              width: 2,
              colors: ['transparent']
            },
            colors: ['#008FFB'],
            fill: {
              opacity: 1
            },
            tooltip: {
              y: {
                formatter: val => val + " clients"
              }
            },
            legend: {
              position: 'top'
            }
          };

          const chartElement = document.querySelector("#salesChart");
          if (chartElement) {
            if (salesChartInstance) salesChartInstance.destroy();
            salesChartInstance = new ApexCharts(chartElement, options);
            salesChartInstance.render();
          } else {
            console.error("Chart element #salesChart not found.");
          }
        },
        error: function(xhr, status, error) {
          console.error("AJAX Error:", status, error, xhr.responseText);
        }
      });
    }

    // Fetch users for the filter dropdown
    function loadUsers() {
      $.ajax({
        url: '<?php echo base_url('results/getUsersForFilter'); ?>',
        type: 'GET',
        dataType: 'json',
        success: function(response) {
          if (response && Array.isArray(response.users)) {
            const userSelector = $('#userSelector');
            userSelector.empty(); // Clear existing options
            userSelector.append('<option value="">All Users</option>'); // Add "All Users" option
            response.users.forEach(user => {
              userSelector.append(`<option value="${user.userId}">${user.name}</option>`);
            });
          }
        },
        error: function(xhr, status, error) {
          console.error("Error fetching users:", status, error);
        }
      });
    }

    // Initial render with current year and no user filter
    const currentYear = new Date().getFullYear();
    renderSalesChart(currentYear);
    loadUsers();

    // Update chart on year or user change
    $('#yearSelector, #userSelector').on('change', function() {
      const year = parseInt($('#yearSelector').val(), 10);
      const userFilter = $('#userSelector').val();
      renderSalesChart(year, userFilter);
    });
  });
</script>

<script>
  $(document).ready(function() {
    let admissionChartInstance = null;

    function renderAdmissionChart(year, franchiseFilter = '') {
      console.log("Fetching admission data for year:", year, "franchiseFilter:", franchiseFilter);

      $.ajax({
        url: '<?php echo base_url('admissiondetailsnew/getAdmissionChartData'); ?>',
        type: 'GET',
        data: {
          year: year,
          franchiseFilter: franchiseFilter
        },
        dataType: 'json',
        success: function(response) {
          console.log("Admission data received:", response);

          const admissions = Array.isArray(response.admissions) && response.admissions.length === 12 ?
            response.admissions :
            Array(12).fill(0);

          console.log("Admissions data:", admissions);

          const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          $('#admissionChartTitle').text(year + ' Admission Details' + (franchiseFilter ? ' for Franchise ' + $('#franchiseSelector option:selected').text() : ''));

          const options = {
            chart: {
              type: 'bar',
              height: 350,
              toolbar: {
                show: true
              }
            },
            series: [{
              name: 'Admissions',
              data: admissions
            }],
            xaxis: {
              categories: months,
              title: {
                text: 'Months'
              }
            },
            yaxis: {
              title: {
                text: 'Admission Count'
              }
            },
            plotOptions: {
              bar: {
                columnWidth: '40%',
                endingShape: 'rounded'
              }
            },
            dataLabels: {
              enabled: true,
              formatter: val => val > 0 ? val : ''
            },
            stroke: {
              show: true,
              width: 2,
              colors: ['transparent']
            },
            colors: ['#00E396'],
            fill: {
              opacity: 1
            },
            tooltip: {
              y: {
                formatter: val => val + " admissions"
              }
            },
            legend: {
              position: 'top'
            }
          };

          const chartElement = document.querySelector("#admissionChart");
          if (chartElement) {
            if (admissionChartInstance) admissionChartInstance.destroy();
            admissionChartInstance = new ApexCharts(chartElement, options);
            admissionChartInstance.render();
          } else {
            console.error("Chart element #admissionChart not found.");
          }
        },
        error: function(xhr, status, error) {
          console.error("AJAX Error:", status, error, xhr.responseText);
        }
      });
    }

    // Initial render with current year and no franchise filter
    const currentYear = new Date().getFullYear();
    renderAdmissionChart(currentYear);

    // Update chart on year or franchise change
    $('#admissionYearSelector, #franchiseSelector').on('change', function() {
      const year = parseInt($('#admissionYearSelector').val(), 10);
      const franchiseFilter = $('#franchiseSelector').val();
      renderAdmissionChart(year, franchiseFilter);
    });
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Initialize Training Chart
    var trainingChartOptions = {
      chart: {
        type: 'bar',
        height: 350
      },
      series: [{
        name: 'Training Schedules',
        data: []
      }],
      xaxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      plotOptions: {
        bar: {
          columnWidth: '45%'
        }
      },
      noData: {
        text: 'Loading...'
      }
    };

    var trainingChart = new ApexCharts(document.querySelector("#trainingChart"), trainingChartOptions);
    trainingChart.render();

    // Function to fetch training chart data
    function fetchTrainingChartData(year) {
      $.ajax({
        url: '<?php echo base_url(); ?>training/getTrainingChartData',
        type: 'POST',
        data: {
          year: year
        },
        dataType: 'json',
        success: function(response) {
          trainingChart.updateSeries([{
            name: 'Training Schedules',
            data: response.data

          }]);
        },
        error: function() {
          trainingChart.updateOptions({
            noData: {
              text: 'Error loading data'
            }
          });
        }
      });
    }

    // Initial load
    fetchTrainingChartData($('#trainingYear').val());

    // Year change event
    $('#trainingYear').on('change', function() {
      fetchTrainingChartData($(this).val());
    });
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap Select
    $('#franchiseNumber').selectpicker();

    // Initialize Despatch Chart
    var despatchChartOptions = {
      chart: {
        type: 'bar',
        height: 350
      },
      series: [{
        name: 'Despatch Orders',
        data: []
      }],
      xaxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      plotOptions: {
        bar: {
          columnWidth: '30%'
        }
      },
      noData: {
        text: 'Loading...'
      }
    };

    var despatchChart = new ApexCharts(document.querySelector("#despatchChart"), despatchChartOptions);
    despatchChart.render();

    // Function to fetch despatch chart data
    function fetchDespatchChartData(year, franchiseNumber) {
      console.log('Fetching despatch data for year:', year, 'franchiseNumber:', franchiseNumber);
      despatchChart.updateOptions({
        noData: {
          text: 'Loading...'
        }
      });

      $.ajax({
        url: '<?php echo base_url(); ?>despatch/getDespatchChartData',
        type: 'POST',
        data: {
          year: year,
          franchiseNumber: franchiseNumber
        },
        dataType: 'json',
        success: function(response) {
          console.log('Despatch data received:', response);
          if (response.error) {
            despatchChart.updateOptions({
              noData: {
                text: response.error
              }
            });
            return;
          }
          const data = response.data || Array(12).fill(0);
          despatchChart.updateSeries([{
            name: 'Despatch Orders',
            data: data
          }]);
          if (data.every(val => val === 0)) {
            despatchChart.updateOptions({
              noData: {
                text: 'No despatch orders found for the selected criteria'
              }
            });
          }
        },
        error: function(xhr, status, error) {
          console.error('AJAX Error:', status, error, xhr.responseText);
          let errorMessage = 'Error loading data. Please try again.';
          if (xhr.status === 401) {
            errorMessage = 'Session expired. Please log in.';
          } else if (xhr.status === 403) {
            errorMessage = 'No franchise assigned.';
          }
          despatchChart.updateOptions({
            noData: {
              text: errorMessage
            }
          });
        }
      });
    }

    // Determine initial franchise number based on role
    var initialYear = $('#despatchYear').val() || '<?php echo date('Y'); ?>';
    var initialFranchiseNumber = '<?php echo in_array($role, [1, 14, 16, 23, 29, 31]) ? ($franchiseFilter ?? "") : ($this->session->userdata('franchiseNumber') ?? ""); ?>';

    // Initial load
    fetchDespatchChartData(initialYear, initialFranchiseNumber);

    // Franchise and Year change events
    $('#franchiseNumber, #despatchYear').on('change', function() {
      var franchiseNumber = $('#franchiseNumber').val() || '<?php echo in_array($role, [1, 14, 16, 23, 29, 31]) ? "" : ($this->session->userdata('franchiseNumber') ?? ""); ?>';
      var year = $('#despatchYear').val() || '<?php echo date('Y'); ?>';
      console.log('Dropdown changed - Franchise:', franchiseNumber, 'Year:', year);
      fetchDespatchChartData(year, franchiseNumber);
    });
  });
</script>
<script>
  $(document).ready(function() {
    $('#month').on('change', function(e) {
      e.preventDefault(); // Prevent default form submission

      // Get the selected month
      var month = $(this).val();

      // Make AJAX request to fetch updated leaderboard data
      $.ajax({
        url: '<?php echo base_url('Results/fetch_leaderboard'); ?>',
        type: 'POST',
        data: {
          month: month
        },
        success: function(data) {
          // Update the leaderboard content
          $('#leaderboardContent').html(data);
        },
        error: function(xhr, status, error) {
          console.error('Error:', error);
          $('#leaderboardContent').html('<p>Error loading data. Please try again.</p>');
        }
      });

      return false; // Additional safeguard to prevent form submission
    });
  });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>