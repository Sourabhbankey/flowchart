<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee Daily Report
            <small>Manage Daily Reports</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="form-group text-right">
                    <a href="<?php echo base_url('Empdailyreport/add'); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Add New Report</a>
                </div>
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Daily Reports List</h3>
                    </div>
                    <div class="box-body">
                        <?php if ($error = $this->session->flashdata('error')): ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($success = $this->session->flashdata('success')): ?>
                            <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $success; ?>
                            </div>
                        <?php endif; ?>

                        <!-- Fetch all users once -->
                        <?php
                        $this->db->select('userId, name');
                        $this->db->from('tbl_users');
                        $users = $this->db->get()->result();
                        $userMap = [];
                        foreach ($users as $user) {
                            $userMap[$user->userId] = htmlspecialchars($user->name);
                        }
                        ?>

                        <table id="dailyReportTable" class="table  table-striped">
                            <thead>
                                <tr>
                                    <th>Employee Name</th>
                                    <th>Report Title</th>
                                    <th>Reporting</th>
                                    <th>Description</th>
                                    <th>Created Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($records)): ?>
                                    <?php foreach ($records as $report): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($report->dailyRepempName); ?></td>
                                            <td><?php echo htmlspecialchars($report->dailyRepTitle); ?></td>
                                            <!-- <td>
                                                <?php
                                                if (!empty($report->dailyempDeartment)) {
                                                    $userIds = array_filter(explode(',', $report->dailyempDeartment), 'is_numeric');
                                                    $userNames = [];
                                                    foreach ($userIds as $userId) {
                                                        if (isset($userMap[$userId])) {
                                                            $userNames[] = $userMap[$userId];
                                                        }
                                                    }
                                                    echo !empty($userNames) ? implode(', ', $userNames) : 'N/A';
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </td> -->
                                            <td><?php echo $report->userName; ?></td>
                                            <td><?php echo substr(strip_tags($report->description), 0, 100) . (strlen(strip_tags($report->description)) > 100 ? '...' : ''); ?></td>
                                            <td><?php echo date('Y-m-d h:i A', strtotime($report->createdDtm)); ?></td>
                                            <td>
                                                <a href="<?php echo base_url('Empdailyreport/edit/' . $report->dailyreportId); ?>" class="btn btn-sm btn-info" title="Edit">
                                                    <i class="fa fa-pencil"></i>
                                                </a>
                                                <!-- <a href="<?php echo base_url('Empdailyreport/delete/' . $report->dailyreportId); ?>" class="btn btn-sm btn-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this report?');">
                                                    <i class="fa fa-trash"></i>
                                                </a> -->
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No reports found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                     <div class="box-footer clearfix">
                    <div class="br-pagi">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>
</div>
<style>
    /* Ensure box-tools content is aligned properly */
    .box-tools .d-flex {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 10px;
        /* Space between elements in box-tools */
    }

    .box-tools form {
        margin-bottom: 0;
        /* Remove default form margin */
    }

    .text-right.mb-3 {
        margin-bottom: 15px;
        /* Space below the Add New button */
    }
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>
<script>
    $(document).ready(function() {
        $('#dailyReportTable').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true
        });
    });

    $(document).ready(function() {
        $("#example_paginate").hide();
        // $("#example_info").hide();
    });
</script>
<!-- DataTables CSS and JS -->

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">

<!-- jQuery (load only once) -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- DataTables Core -->
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<!-- DataTables Responsive Extension -->
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>

