<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee Daily Report
            <small>Edit Daily Report</small>
        </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Edit Daily Report</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="dailyReportForm" action="<?php echo base_url('Empdailyreport/update'); ?>" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="dailyreportId" value="<?php echo $report->dailyreportId; ?>">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dailyRepempName">Employee Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('dailyRepempName', $report->dailyRepempName); ?>" id="dailyRepempName" name="dailyRepempName" maxlength="255" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dailyRepTitle">Report Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('dailyRepTitle', $report->dailyRepTitle); ?>" id="dailyRepTitle" name="dailyRepTitle" maxlength="255" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dailyempDeartment">Reporting <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="dailyempDeartment" name="dailyempDeartment" required>
                                            <option value="0">Select User</option>
                                            <?php
                                            if (!empty($users)) {
                                                foreach ($users as $rl) {
                                                    $userText = htmlspecialchars($rl->name);
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if ($rl->userId == set_value('dailyempDeartment', $report->dailyempDeartment)) { echo "selected=selected"; } ?>><?php echo $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"><?php echo set_value('description', $report->description); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Update" />
                            <a href="<?php echo base_url('Empdailyreport'); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $error; ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?php echo base_url('Empdailyreport/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>

<script>
    const form = document.getElementById('dailyReportForm');
    const submitBtn = document.getElementById('submitBtn');
    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault();
            return;
        }
        submitBtn.disabled = true;
        submitBtn.innerText = 'Updating...';
    });
</script>