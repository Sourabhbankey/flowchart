<?php
$followupId = $followuprecordInfo->followupId;
 $description = $followuprecordInfo->description;
 
 $description2 = $followuprecordInfo->description2;
 $description3 = $followuprecordInfo->description3;
 $description4 = $followuprecordInfo->description4;
 $status = $followuprecordInfo->status;
 $lastcall = $followuprecordInfo->lastcall;
$nextfollowup = $followuprecordInfo->nextfollowup;
$salesTeamAssign = $followuprecordInfo->salesTeamAssign;
// $productNae = $salesrecordInfo->productName;
// $dateOfsale =m $salesrecordInfo->dateOfsale;
// $prodQuantity = $salesrecordInfo->prodQuantity;
// $soldTo = $salesrecordInfo->soldTo;
// $updatedStock = $salesrecordInfo->updatedStock;
// $description = $salesrecordInfo->description;
$finalfranchisecost = $followuprecordInfo->finalfranchisecost;

$amountreceived = $followuprecordInfo->amountreceived;
$initialkitsoffered =$followuprecordInfo->initialkitsoffered;
$premisestatus = $followuprecordInfo->premisestatus;
$expectedinstallationdate = $followuprecordInfo->expectedinstallationdate;
$additionaloffer = $followuprecordInfo->additionaloffer;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> FollowUp Record Management
        <small>Add / Edit FollowUp Record</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter FollowUp Record Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>followup/editFollowuprecord" method="post" id="editFollowuprecord" role="form">
                        <div class="box-body">
                        <div class="row">
                                <input type="hidden" name="followupId" value="<?php echo $followupId; ?>">
                            
                              <div class="col-md-4">                                
    <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control required" id="description" readonly name="description" maxlength="256"><?php echo $description; ?></textarea>
    </div>
</div>

<?php
$readonly2 = !empty($description2) ? 'readonly' : '';
$readonly3 = !empty($description3) || empty($description2) ? 'readonly' : '';
$readonly4 = !empty($description4) || empty($description3) ? 'readonly' : '';
?>

<div class="col-md-4">                                
    <div class="form-group">
        <label for="description2">Follow Up 1</label>
        <textarea class="form-control" id="description2" name="description2" maxlength="256" <?php echo $readonly2; ?>><?php echo $description2; ?></textarea>
    </div>
</div>

<div class="col-md-4">                                
    <div class="form-group">
        <label for="description3">Follow Up 2</label>
        <textarea class="form-control" id="description3" name="description3" maxlength="256" <?php echo $readonly3; ?>><?php echo $description3; ?></textarea>
    </div>
</div>

<div class="col-md-4">                                
    <div class="form-group">
        <label for="description4">Follow Up 3</label>
        <textarea class="form-control" id="description4" name="description4" maxlength="256" <?php echo $readonly4; ?>><?php echo $description4; ?></textarea>
    </div>
</div>

                                 <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Status</label>
                                        <select class="form-control required" id="status" name="status">
    <option value="">Select Status</option> <!-- Default empty option -->
    <option value="Interested" <?= ($status == 'Interested') ? 'selected' : '' ?>>Interested</option>
    <option value="Not Interested" <?= ($status == 'Not Interested') ? 'selected' : '' ?>>Not Interested</option>
    <option value="Future Clients" <?= ($status == 'Future Clients') ? 'selected' : '' ?>>Future Clients</option>
    <option value="Positive Leads" <?= ($status == 'Positive Leads') ? 'selected' : '' ?>>Positive Leads</option>
    <option value="Hot Lead" <?= ($status == 'Hot Lead') ? 'selected' : '' ?>>Hot Lead</option>
    <option value="Converted leads" <?= ($status == 'Converted leads') ? 'selected' : '' ?>>Converted leads</option>
    <option value="Discussion Pending" <?= ($status == 'Discussion Pending') ? 'selected' : '' ?>>Discussion Pending</option>
</select>


                                    </div> 
                                </div> 
 <div class="col-md-4">                                
    <div class="form-group">
         <label for="dateOfsale">Last call</label>
             <input type="date" class="form-control required" value="<?php echo $lastcall; ?>" id="lastcall" name="lastcall" maxlength="256" />
       </div>
  </div>
    <div class="col-md-4">                                
        <div class="form-group">
           <label for="dateOfsale">Nextfollowup</label>
              <input type="date" class="form-control required" value="<?php echo $nextfollowup; ?>" id="nextfollowup" name="nextfollowup" maxlength="256" />
        </div>
     </div>

                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Final franchise cost</label>
                                        <input required type="text" class="form-control required" value="<?php echo $finalfranchisecost; ?>" id="finalfranchisecost" name="finalfranchisecost" maxlength="256" />
                                    </div>
                                </div>  
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Amount Resceived</label>
                                        <input required type="text" class="form-control required" value="<?php echo $amountreceived; ?>" id="amountreceived" name="amountreceived" maxlength="256" />
                                    </div>
                                </div> 
                                  <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Initial kits offered</label>
                                        <input required type="text" class="form-control required" value="<?php echo $initialkitsoffered; ?>" id="initialkitsoffered" name="initialkitsoffered" maxlength="256" />
                                    </div>
                                </div> 
                              <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="productCode">Premise Status</label>
                                      <select class="form-control required" id="premisestatus" name="premisestatus" required>
    <option value="ready" <?php echo (trim($premisestatus) == "ready") ? "selected" : ""; ?>>Ready</option>
<option value="underprocess" <?php echo (trim($premisestatus) == "underprocess") ? "selected" : ""; ?>>Underprocess</option>

</select>

                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Expected installation date</label>
                                        <input required type="date" class="form-control required" value="<?php echo $expectedinstallationdate; ?>" id="expectedinstallationdate" name="expectedinstallationdate" maxlength="256" />
                                    </div>
                                </div> 
                                   <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prodQuantity">Additional offerings</label>
                                        <input required type="text" class="form-control required" value="<?php echo $additionaloffer; ?>" id="additionaloffer" name="additionaloffer" maxlength="256" />
                                    </div>
                                </div>
     <?php if ($role == 2 || $role == 1 || $role == 14) { ?>
<div class="col-md-4">
    <div class="form-group">
        <label for="assignedUser">Assign User</label>
        <select class="form-control" id="salesTeamAssign" name="salesTeamAssign">
            <option value="">Select User</option>
            <?php foreach ($users as $user) { ?>
                <option value="<?php echo $user['userId']; ?>" 
                    <?php echo (!empty($salesTeamAssign) && $salesTeamAssign == $user['userId']) ? 'selected' : ''; ?>>
                    <?php echo $user['name']; ?>
                </option>
            <?php } ?>   
        </select>
    </div>
</div> 
<?php } ?>


                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>