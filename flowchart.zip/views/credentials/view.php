<?php
$credId = $credentialsInfo->credId;
$credTitle = $credentialsInfo->credTitle;
$franchiseNumber = $credentialsInfo->franchiseNumber;
$credType = $credentialsInfo->credType;
$description = $credentialsInfo->description;

// New fields
$wcredType2 = $credentialsInfo->wcredType2 ?? '';
$webmId = $credentialsInfo->webmId ?? '';
$webmPass = $credentialsInfo->webmPass ?? '';
/*$wDate = $credentialsInfo->wDate ?? '';
*/
$esappcredType3 = $credentialsInfo->esappcredType3 ?? '';
$esappUserId = $credentialsInfo->esappUserId ?? '';
$esappPass = $credentialsInfo->esappPass ?? '';
/*$esappDate = $credentialsInfo->esappDate ?? '';*/

$shoppicredType4 = $credentialsInfo->shoppicredType4 ?? '';
$shoppiId = $credentialsInfo->shoppiId ?? '';
$shoppiPass = $credentialsInfo->shoppiPass ?? '';
/*$shoppiDate = $credentialsInfo->shoppiDate ?? '';*/

$prepcredType5 = $credentialsInfo->prepcredType5 ?? '';
$prepId = $credentialsInfo->prepId ?? '';
$prepPass = $credentialsInfo->prepPass ?? '';
/*$prepDate = $credentialsInfo->prepDate ?? '';*/

$webcredType5 = $credentialsInfo->webcredType5 ?? '';
$webLink = $credentialsInfo->webLink ?? '';
/*$webDate = $credentialsInfo->webDate ?? '';*/

$wDate = !empty($credentialsInfo->wDate) && $credentialsInfo->wDate != '0000-00-00 00:00:00' ? date('Y-m-d', strtotime($credentialsInfo->wDate)) : '';
$esappDate = !empty($credentialsInfo->esappDate) && $credentialsInfo->esappDate != '0000-00-00 00:00:00' ? date('Y-m-d', strtotime($credentialsInfo->esappDate)) : '';
$shoppiDate = !empty($credentialsInfo->shoppiDate) && $credentialsInfo->shoppiDate != '0000-00-00 00:00:00' ? date('Y-m-d', strtotime($credentialsInfo->shoppiDate)) : '';
$prepDate = !empty($credentialsInfo->prepDate) && $credentialsInfo->prepDate != '0000-00-00 00:00:00' ? date('Y-m-d', strtotime($credentialsInfo->prepDate)) : '';
$webDate = !empty($credentialsInfo->webDate) && $credentialsInfo->webDate != '0000-00-00 00:00:00' ? date('Y-m-d', strtotime($credentialsInfo->webDate)) : '';

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Credentials
            <small>Add / Edit </small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->

                    <form role="form" action="<?php echo base_url() ?>credentials/editCredentials" method="post" id="editInvestors" role="form">
                        <div class="box-body">
                            <div class="row">
                                  <?php if ($role == 14 || $role == 1 || $role == 22 || $role == 25  ) { ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="roomName">Cred Title</label>
                                        <input type="text" class="form-control required" value="<?php echo $credTitle; ?>" id="credTitle" name="credTitle" maxlength="256" readonly />
                                        <input type="hidden" value="<?php echo $credId; ?>" name="credId" id="credId" />
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="roomName">Franchise Number</label>
                                        <input type="text" class="form-control required" readonly
                                            value="<?php echo !empty($franchiseNumber) ? $franchiseNumber : 'N/A'; ?>"
                                            id="franchiseNumber" name="franchiseNumber" maxlength="256" />

                                    </div>

                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="prodListdespatch">Applications</label>
                                        <select class="form-control required" disabled name="credType" id="credType">
                                            <option value="webmail" <?php echo ($credType == "webmail") ? "selected" : ""; ?>>WebMail</option>
                                            <option value="app" <?php echo ($credType == "app") ? "selected" : ""; ?>>Edumeta App</option>
                                            <option value="website" <?php echo ($credType == "website") ? "selected" : ""; ?>>Website</option>
                                            <option value="prepongo" <?php echo ($credType == "prepongo") ? "selected" : ""; ?>>PrepOnGo</option>
                                            <option value="shoppingportal" <?php echo ($credType == "shoppingportal") ? "selected" : ""; ?>>Shopping Portal</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description" readonly><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <hr>
                                    <h4>Webmail Credentials</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Web Cred Type 2</label>
                                        <input type="text" class="form-control" name="wcredType2" value="<?= $wcredType2 ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Webmail ID</label>
                                        <input type="text" class="form-control" name="webmId" value="<?= $webmId ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Webmail Password</label>
                                        <input type="text" class="form-control" name="webmPass" value="<?= $webmPass ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Webmail Date</label>
                                        <input type="date" class="form-control" name="wDate" value="<?= $wDate ?>" readonly />
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <hr>
                                    <h4>Edumeta App Credentials</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>App Cred Type 3</label>
                                        <input type="text" class="form-control" name="esappcredType3" value="<?= $esappcredType3 ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Edumeta App ID</label>
                                        <input type="text" class="form-control" name="esappUserId" value="<?= $esappUserId ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Edumeta App Password</label>
                                        <input type="text" class="form-control" name="esappPass" value="<?= $esappPass ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Edumeta App Date</label>
                                        <input type="date" class="form-control" name="esappDate" value="<?= $esappDate ?>" readonly />
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <hr>
                                    <h4>Shopping Portal Credentials</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Shopping Cred Type 4</label>
                                        <input type="text" class="form-control" name="shoppicredType4" value="<?= $shoppicredType4 ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Shopping Portal ID</label>
                                        <input type="text" class="form-control" name="shoppiId" value="<?= $shoppiId ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Shopping Portal Password</label>
                                        <input type="text" class="form-control" name="shoppiPass" value="<?= $shoppiPass ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Shopping Portal Date</label>
                                        <input type="date" class="form-control" name="shoppiDate" value="<?= $shoppiDate ?>" readonly />
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <hr>
                                    <h4>Prepongo Credentials</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Prep Cred Type 5</label>
                                        <input type="text" class="form-control" name="prepcredType5" value="<?= $prepcredType5 ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Prepongo ID</label>
                                        <input type="text" class="form-control" name="prepId" value="<?= $prepId ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Prepongo Password</label>
                                        <input type="text" class="form-control" name="prepPass" value="<?= $prepPass ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Prepongo Date</label>
                                        <input type="date" class="form-control" name="prepDate" value="<?= $prepDate ?>" readonly />
                                    </div>
                                </div>
  <?php } ?>
                                <div class="col-md-12">
                                    <hr>
                                    <h4>Website Credentials</h4>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Web Cred Type 5m</label>
                                        <input type="text" class="form-control" name="webcredType5" value="<?= $webcredType5 ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Website Link</label>
                                        <input type="text" class="form-control" name="webLink" value="<?= $webLink ?>" readonly />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Website Date</label>
                                        <input type="date" class="form-control" name="webDate" value="<?= $webDate ?>" readonly />
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->

                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>