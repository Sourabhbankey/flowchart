<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Credentials 
        <small>Add / Edit Credentials</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Credentials Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addFaq" action="<?php echo base_url() ?>credentials/addNewCredentials" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">                                
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                                    <option value="">Select Franchise</option>
                                                                     <?php
                                                                    if (!empty($branchDetail)) {
                                                                        foreach ($branchDetail as $bd) {
                                                                      $franchiseNumber = $bd->franchiseNumber;
                                                                    ?>
                                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                              <?php
                                                                  }
                                                               }
                                                            ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                            <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                                <option value="0">Select Role</option>
                                            </select>
                                        </div>
                                    </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="orderNumber">Cred Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('credTitle'); ?>" id="credTitle" name="credTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                                 <div class="col-md-4">                                
           <div class="form-group">
            <label for="prodListdespatch">Applications </label>
              <select class="form-control required" name="credType" id="credType">
         <option value="webmail">WebMail</option>
         <option value="app">Edumeta App</option>
         <option value="website">Website</option>
         <option value="prepongo">PrepOnGo</option>
         <option value="shoppingportal">Shopping Portal</option>
          </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description"> Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
     <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            /*filebrowserUploadUrl: "<?= base_url('training/upload'); ?>",*/
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber !== "") {
        $.ajax({
            url: "<?php echo base_url('credentials/fetchAssignedUsers'); ?>",
            type: "POST",
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $("#branchFranchiseAssigned").html(response);
                  $('#branchFranchiseAssigned option[value="0"]').remove();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: " + status + " - " + error);
            }
        });
    } else {
     $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
    }
}
</script>