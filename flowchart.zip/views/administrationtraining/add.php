
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Administration Training
        <small>Add / Edit Administration Training</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Administration Training Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>administrationtraining/addNewAdministrationtraining" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                                <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                    <option value="">Select Franchise</option>
                                                    <?php
                                                    if (!empty($branchDetail)) {
                                                        foreach ($branchDetail as $bd) {
                                                            $franchiseNumber = $bd->franchiseNumber;
                                                            ?>
                                                            <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
   <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                                <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                                    <option value="0">Select Role</option>
                                                </select>
                                            </div>
                                        </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Training Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('meetingTitle'); ?>" id="meetingTitle" name="meetingTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="despatchTitle">Attendees - (HO) <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php echo set_value('attendeesHO'); ?>" id="attendeesHO" name="attendeesHO" maxlength="256"> -->
                                      <!-- <select class="form-control required" id="attendeesHO" name="attendeesHO[]" multiple> -->
                                      <select class="form-control required" id="attendees" name="attendeesHO[]"  multiple data-live-search="true" required> 
                                        <option value="0">Select User</option>
                                        <?php
                                        if (!empty($users)) {
                                            foreach ($users as $rl) {
                                                $userText = $rl->name;
                                                ?>
                                                <option value="<?php echo $rl->userId ?>" <?php if (in_array($rl->userId, (array) set_value('attendeesHO'))) { echo "selected=selected"; } ?>>
                                                    <?= $userText ?>
                                                </option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Attended By (Franchise) <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('attendedByfranchise'); ?>" id="attendedByfranchise" name="attendedByfranchise" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="adminTrainingFor">Admin Training For <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php echo set_value('adminTrainingFor'); ?>" id="adminTrainingFor" name="adminTrainingFor" maxlength="256"> -->
                                        <select class="form-control required" id="adminTrainingFor" name="adminTrainingFor" required >
                                          <option value="">Select Admin Training For</option>
                                          <option value="Facebook">Facebook</option>
                                          <option value="Instagram">Instagram</option>
                                          <option value="Google Profile Verification">Google Profile Verification</option>
                                          <option value="Biometric Machine">Biometric Machine</option>
                                          <option value="Camera">Camera</option>
                                          <option value="eduMETA App">eduMETA App</option>
                                          <option value="FlowChart">FlowChart</option>
                                          <option value="Shopping Portal">Shopping Portal</option>
                                          <option value="Training Portal on LMS">Training Portal on LMS</option>
                                        </select>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Date Of Training <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateMeeting'); ?>" id="dateMeeting" name="dateMeeting" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Time of Training (In Minutes) <span class="re-mend-field">*</span></label>
                                        <input required type="time" class="form-control required" value="<?php echo set_value('timeMeeting'); ?>" id="timeMeeting" name="timeMeeting" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Duration Of Training <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('durationMeeting'); ?>" id="durationMeeting" name="durationMeeting" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="trainer">Trainer <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('trainer'); ?>" id="trainer" name="trainer" maxlength="256">
                                    </div>   
                                </div>
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="spManger">Support Manager <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php //echo set_value('spManger'); ?>" id="spManger" name="spManger" maxlength="256">
                                    </div>   
                                </div> -->
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Type of Meeting <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="trypeofMeeting" name="trypeofMeeting" required >
                                          <option value="">Select Type of Training</option>
                                          <option value="Common-All">Common (All)</option>
                                          <option value="Group">Group</option>
                                          <option value="Individul">Individul</option>
                                        </select>   
                                    </div>   
                                </div> -->
                                
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('administrationtraining/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
<script>
/*$(document).ready(function() {
    $('#attendees').change(function() {
        var selectedValues = $(this).val();
        
        if (selectedValues.includes('selectAll')) {
            // Select all options except "Select All"
            $('#attendees option').each(function() {
                if ($(this).val() !== 'selectAll') {
                    $(this).prop('selected', true);
                }
            });
            // Deselect "Select All" option
            $('#attendees option[value="selectAll"]').prop('selected', false);
        } else {
            // If any option is deselected, ensure "Select All" is not selected
            if (selectedValues.length < $('#attendees option').length - 1) {
                $('#attendees option[value="selectAll"]').prop('selected', false);
            }
        }

        // Refresh the selectpicker plugin (if using)
        $('#attendees').selectpicker('refresh');
    });
});*/
$(document).ready(function() {
    // Refresh the select picker before any selection is made
    $('#attendees').selectpicker('refresh');

    $('#attendees').change(function() {
        // This part is to refresh the select picker again after a change (if needed)
        $('#attendees').selectpicker('refresh');
    });
});
</script>    
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("administrationtraining/fetchAssignedUsers"); ?>', // Update to match your controller and method
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
        $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
    }
}
</script>
