<?php
$adminMeetingId = $administrationtrainingInfo->adminMeetingId;
$meetingTitle = $administrationtrainingInfo->meetingTitle;
$attendedByfranchise = $administrationtrainingInfo->attendedByfranchise;
$adminTrainingFor =$administrationtrainingInfo->adminTrainingFor;
$dateMeeting = $administrationtrainingInfo->dateMeeting;
$timeMeeting = $administrationtrainingInfo->timeMeeting;
$durationMeeting = $administrationtrainingInfo->durationMeeting;
$trypeofMeeting = $administrationtrainingInfo->trypeofMeeting;
$franchiseNumberArray = explode(",",$administrationtrainingInfo->franchiseNumber);
$description = $administrationtrainingInfo->description;
$attendeesHO = $administrationtrainingInfo->attendeesHO;
$trainer = $administrationtrainingInfo->trainer;
/*$selectUserId ='';*/
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Administration Training Management
        <small>Add / Edit Support Meeting</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Administration Training Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>administrationtraining/editAdministrationtraining" method="post" id="editAdministrationtraining" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Training Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $meetingTitle; ?>" id="meetingTitle" name="meetingTitle" maxlength="256" readonly />
                                        <input type="hidden" value="<?php echo $adminMeetingId; ?>" name="adminMeetingId" id="adminMeetingId" />
                                    </div>
                                    
                                </div>
                                <!-- <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise No. </label>
                                        <input type="text" class="form-control required" value="<?php //echo $franchiseNumber; ?>" id="franchiseNumber" name="franchiseNumber" maxlength="256" />
                                    </div>
                                    
                                </div> -->
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Attended By Franchise <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo $attendedByfranchise; ?>" id="attendedByfranchise" name="attendedByfranchise" maxlength="256" readonly />
                                        
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="adminTrainingFor">Admin Training For <span class="re-mend-field">*</span></label>
                                        <!-- <input type="text" class="form-control required" value="<?php //echo $adminTrainingFor; ?>" id="adminTrainingFor" name="adminTrainingFor" maxlength="256" /> -->
                                        <select class="form-control required" id="adminTrainingFor" name="adminTrainingFor" required disabled >
                                           <option value="<?php echo $adminTrainingFor; ?>" <?php echo "selected=selected"; ?>><?php echo $adminTrainingFor; ?></option>
                                           <option value="Facebook">Facebook</option>
                                          <option value="Instagram">Instagram</option>
                                          <option value="Google Profile Verification">Google Profile Verification</option>
                                          <option value="Biometric Machine">Biometric Machine</option>
                                          <option value="Camera">Camera</option>
                                          <option value="eduMETA App">eduMETA App</option>
                                        </select>  
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Date Of Training <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateMeeting; ?>" id="dateMeeting" name="dateMeeting" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Time of Training (In Minutes) <span class="re-mend-field">*</span></label>
                                        <input required type="time" class="form-control required" value="<?php echo $timeMeeting; ?>" id="timeMeeting" name="timeMeeting" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Duration Of Training <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $durationMeeting; ?>" id="durationMeeting" name="durationMeeting" maxlength="256" readonly>
                                    </div>   
                                </div>
                               
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true" disabled>
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;

                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>" <?php if(in_array($franchiseNumber,$franchiseNumberArray)){echo "selected=selected";} ?>><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="despatchTitle">Attendees (HO) <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo $attendeesHO; ?>" id="attendeesHO" name="attendeesHO" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="trainer">Trainer <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $trainer; ?>" id="trainer" name="trainer" maxlength="256" readonly>
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description" readonly><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('administrationtraining/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>