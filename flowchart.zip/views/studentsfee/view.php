<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Student Fee Plan
            <!-- <small>View Template</small> -->
        </h1>
    </section>
        <section class="content">
            <div class="row">
                <div class="col-md-10">
                    <div class="box box-primary">
                        <div class="box-header">
                            <!-- <h3 class="box-title">Student Fee Plan Details</h3> -->
                            <div class="box-tools">
                            </button>
                                <a href="<?php echo base_url('studentsfee/studentsfeeListing'); ?>" class="btn btn-default btn-sm">
                                    <i class="fa fa-arrow-left"></i> Back to Listing
                                </a>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="container-fluid">
                                <div class="card">
                                    <div class="card-body">
                                        <!-- Basic Details -->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <strong>Student Name:</strong> <?= htmlspecialchars($studentsfeeInfo->student_name, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Class:</strong> <?= htmlspecialchars($studentsfeeInfo->className, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Section:</strong> <?= htmlspecialchars($studentsfeeInfo->sectionName, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Register No:</strong> <?= htmlspecialchars($studentsfeeInfo->register_no, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Roll No:</strong> <?= htmlspecialchars($studentsfeeInfo->roll_no, ENT_QUOTES, 'UTF-8') ?><br>
                                            </div>
                                            <div class="col-md-6">
                                                <strong>Mobile:</strong> <?= htmlspecialchars($studentsfeeInfo->mobile_number, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Email:</strong> <?= htmlspecialchars($studentsfeeInfo->email, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Guardian Name:</strong> <?= htmlspecialchars($studentsfeeInfo->guardian_name, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Franchise:</strong> <?= htmlspecialchars($studentsfeeInfo->franchiseNumber, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>Assigned To:</strong> <?= htmlspecialchars($studentsfeeInfo->brspFranchiseAssigned, ENT_QUOTES, 'UTF-8') ?><br>
                                            </div>
                                        </div>

                                        <hr>

                                        <!-- Fee Details -->
                                        <h5>Fees</h5>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <strong>Admission Fee:</strong> ₹<?= htmlspecialchars($studentsfeeInfo->admission_fee, ENT_QUOTES, 'UTF-8') ?><br>
                                                <strong>First Month Fee:</strong> ₹<?= htmlspecialchars($studentsfeeInfo->first_month_fee, ENT_QUOTES, 'UTF-8') ?><br>
                                            </div>
                                        </div>
                                        <hr>
                                        <!-- Installments -->
                                        <h5>Installments</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Amount (₹)</th>
                                                        <th>Status</th>
                                                        <th>Date</th>
                                                        <th>Late Fee</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php for ($i = 1; $i <= 10; $i++): ?>
                                                        <?php 
                                                            $amt = "installment{$i}_amt";
                                                            if (!empty($studentsfeeInfo->$amt)):
                                                                $status = htmlspecialchars($studentsfeeInfo->{"installment{$i}_status"}, ENT_QUOTES, 'UTF-8');
                                                                $date = htmlspecialchars($studentsfeeInfo->{"installment{$i}_date"}, ENT_QUOTES, 'UTF-8');
                                                                $late_fee = htmlspecialchars($studentsfeeInfo->{"installment{$i}_late_fee"}, ENT_QUOTES, 'UTF-8');

                                                                // Set badge class and row class
                                                                $badgeClass = 'badge-secondary';
                                                                $rowClass = '';

                                                                if (strtolower($status) === 'paid') {
                                                                    $badgeClass = 'badge-success';
                                                                    $rowClass = 'table-success';
                                                                } elseif (strtolower($status) === 'pending') {
                                                                    $badgeClass = 'badge-warning';
                                                                    $rowClass = 'table-warning';
                                                                } elseif (strtolower($status) === 'late') {
                                                                    $badgeClass = 'badge-danger';
                                                                    $rowClass = 'table-danger';
                                                                }

                                                                // Tooltip for late
                                                                $tooltip = (strtolower($status) === 'late') ? 'data-toggle="tooltip" title="Payment is overdue!"' : '';
                                                        ?>
                                                        <tr class="<?= $rowClass ?>">
                                                            <td><?= $i ?></td>
                                                            <td>₹<?= htmlspecialchars($studentsfeeInfo->$amt, ENT_QUOTES, 'UTF-8') ?></td>
                                                            <td>
                                                                <span class="badge <?= $badgeClass ?>" <?= $tooltip ?>>
                                                                    <?= ucfirst($status) ?>
                                                                    <?php if (strtolower($status) === 'late'): ?>
                                                                        <i class="fa fa-exclamation-circle ml-1"></i>
                                                                    <?php endif; ?>
                                                                </span>
                                                            </td>
                                                            <td><?= $date ?></td>
                                                            <td><?= $late_fee ?></td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>

                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="mt-3">
                                            <a href="<?= base_url('studentsfee/studentsfeeListing') ?>" class="btn btn-secondary">Back to List</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</div>
<!-- Newstyle -->
<style type="text/css">
    .table-success, .table-success>td, .table-success>th {
    background-color: #c3e6cb;
}
.badge-success {
    color: #fff;
    background-color: #28a745;
}
.badge {
    display: inline-block;
    padding: .25em .4em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: .25rem;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
.table-warning, .table-warning>td, .table-warning>th {
    background-color: #ffeeba;
}
.badge-warning {
    color: #212529;
    background-color: #ffc107;
}
.btn-secondary {
    color: #fff;
    background-color: #6c757d;
    border-color: #6c757d;
}
</style>
<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

