<?php
$feeId = $studentsfeeInfo->feeId;
$student_id = $studentsfeeInfo->student_id;
$franchiseNumber = $studentsfeeInfo->franchiseNumber;
$brspFranchiseAssigned = $studentsfeeInfo->brspFranchiseAssigned;
$className = $studentsfeeInfo->className;
$sectionName = $studentsfeeInfo->sectionName;
$student_name = $studentsfeeInfo->student_name;
$mobile_number = $studentsfeeInfo->mobile_number;
$register_no = $studentsfeeInfo->register_no;
$roll_no = $studentsfeeInfo->roll_no;
$email = $studentsfeeInfo->email;
$guardian_name = $studentsfeeInfo->guardian_name;
$admission_fee = $studentsfeeInfo->admission_fee;
$first_month_fee = $studentsfeeInfo->first_month_fee;
// Installment 1
$installment1_amt = $studentsfeeInfo->installment1_amt;
$installment1_status = $studentsfeeInfo->installment1_status;
$installment1_date = $studentsfeeInfo->installment1_date;
$installment1_late_fee = $studentsfeeInfo->installment1_late_fee;
// Installment 2
$installment2_amt = $studentsfeeInfo->installment2_amt;
$installment2_status = $studentsfeeInfo->installment2_status;
$installment2_date = $studentsfeeInfo->installment2_date;
$installment2_late_fee = $studentsfeeInfo->installment2_late_fee;
// Installment 3
$installment3_amt = $studentsfeeInfo->installment3_amt;
$installment3_status = $studentsfeeInfo->installment3_status;
$installment3_date = $studentsfeeInfo->installment3_date;
$installment3_late_fee = $studentsfeeInfo->installment3_late_fee;
// Installment 4
$installment4_amt = $studentsfeeInfo->installment4_amt;
$installment4_status = $studentsfeeInfo->installment4_status;
$installment4_date = $studentsfeeInfo->installment4_date;
$installment4_late_fee = $studentsfeeInfo->installment4_late_fee;
// Installment 5
$installment5_amt = $studentsfeeInfo->installment5_amt;
$installment5_status = $studentsfeeInfo->installment5_status;
$installment5_date = $studentsfeeInfo->installment5_date;
$installment5_late_fee = $studentsfeeInfo->installment5_late_fee;
// Installment 6
$installment6_amt = $studentsfeeInfo->installment6_amt;
$installment6_status = $studentsfeeInfo->installment6_status;
$installment6_date = $studentsfeeInfo->installment6_date;
$installment6_late_fee = $studentsfeeInfo->installment6_late_fee;
// Installment 7
$installment7_amt = $studentsfeeInfo->installment7_amt;
$installment7_status = $studentsfeeInfo->installment7_status;
$installment7_date = $studentsfeeInfo->installment7_date;
$installment7_late_fee = $studentsfeeInfo->installment7_late_fee;
// Installment 8
$installment8_amt = $studentsfeeInfo->installment8_amt;
$installment8_status = $studentsfeeInfo->installment8_status;
$installment8_date = $studentsfeeInfo->installment8_date;
$installment8_late_fee = $studentsfeeInfo->installment8_late_fee;
// Installment 9
$installment9_amt = $studentsfeeInfo->installment9_amt;
$installment9_status = $studentsfeeInfo->installment9_status;
$installment9_date = $studentsfeeInfo->installment9_date;
$installment9_late_fee = $studentsfeeInfo->installment9_late_fee;
// Installment 10
$installment10_amt = $studentsfeeInfo->installment10_amt;
$installment10_status = $studentsfeeInfo->installment10_status;
$installment10_date = $studentsfeeInfo->installment10_date;
$installment10_late_fee = $studentsfeeInfo->installment10_late_fee;
?>



<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Student Fee Management
        <!-- <small>Add / Edit Blog</small> -->
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Student Fee Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>studentsfee/editStudentsfee" method="post" id="editStudentsfee" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="student_name">Student Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $student_name; ?>" id="student_name" name="student_name" maxlength="256" />
                                        <input type="hidden" value="<?php echo $feeId; ?>" name="feeId" id="feeId" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise Number <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseNumber; ?>" id="franchiseNumber" name="franchiseNumber" maxlength="256" />
                                        
                                    </div>   
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Franchise Assigned<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $brspFranchiseAssigned; ?>" id="brspFranchiseAssigned" name="brspFranchiseAssigned" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="className">Class Name</label>
                                      <input type="text" class="form-control" id="className" value="<?php echo $className; ?>" name="className" maxlength="100">
                                    </div>
                                  </div>

                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="sectionName">Section Name</label>
                                      <input type="text" class="form-control" id="sectionName" value="<?php echo $sectionName; ?>" name="sectionName" maxlength="100">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="mobile_number">Mobile Number</label>
                                      <input type="text" class="form-control" id="mobile_number" value="<?php echo $mobile_number; ?>" name="mobile_number" maxlength="15">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="register_no">Register No</label>
                                      <input type="text" class="form-control" id="register_no" value="<?php echo $register_no; ?>" name="register_no" maxlength="50">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="roll_no">Roll No</label>
                                      <input type="text" class="form-control" id="roll_no" value="<?php echo $roll_no; ?>" name="roll_no" maxlength="50">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="email">Email</label>
                                      <input type="email" class="form-control" id="email" value="<?php echo $email; ?>" name="email" maxlength="100">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="guardian_name">Guardian Name</label>
                                      <input type="text" class="form-control" id="guardian_name" value="<?php echo $guardian_name; ?>" name="guardian_name" maxlength="100">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="admission_fee">Admission Fee</label>
                                      <input type="number" step="0.01" class="form-control" id="admission_fee" value="<?php echo $admission_fee; ?>" name="admission_fee">
                                    </div>
                                  </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                      <label for="first_month_fee">First Month Fee</label>
                                      <input type="number" step="0.01" class="form-control" id="first_month_fee" value="<?php echo $first_month_fee; ?>" name="first_month_fee">
                                    </div>
                                  </div>
                                  <!-- Installment 1 -->
                                    <?php for ($i = 1; $i <= 10; $i++): 
                                        $amt = $studentsfeeInfo->{'installment' . $i . '_amt'};
                                        $status = $studentsfeeInfo->{'installment' . $i . '_status'};
                                        $date = $studentsfeeInfo->{'installment' . $i . '_date'};
                                        $late_fee = $studentsfeeInfo->{'installment' . $i . '_late_fee'};

                                        // Skip installment if all fields are empty
                                        if (empty($amt) && empty($status) && empty($date) && empty($late_fee)) {
                                            continue;
                                        }
                                    ?>
                                        <div class="col-md-12">
                                            <h4>Installment <?php echo $i; ?></h4>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="installment<?php echo $i; ?>_amt">Amount</label>
                                                <input type="number" step="0.01" class="form-control" id="installment<?php echo $i; ?>_amt" name="installment<?php echo $i; ?>_amt" value="<?php echo $amt; ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="installment<?php echo $i; ?>_status">Status</label>
                                                <select class="form-control" name="installment<?php echo $i; ?>_status">
                                                    <option value="">Select</option>
                                                    <option value="Pending" <?php echo ($status == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                                    <option value="Paid" <?php echo ($status == 'Paid') ? 'selected' : ''; ?>>Paid</option>
                                                    <option value="Late" <?php echo ($status == 'Late') ? 'selected' : ''; ?>>Late</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="installment<?php echo $i; ?>_date">Date</label>
                                                <input type="date" class="form-control" id="installment<?php echo $i; ?>_date" name="installment<?php echo $i; ?>_date" value="<?php echo $date; ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="installment<?php echo $i; ?>_late_fee">Late Fee</label>
                                                <input type="number" step="0.01" class="form-control" id="installment<?php echo $i; ?>_late_fee" name="installment<?php echo $i; ?>_late_fee" value="<?php echo $late_fee; ?>">
                                            </div>
                                        </div>
                                    <?php endfor; ?>


                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #e72f05 !important;
            border: 1px solid #8b8787 !important;
        }
        .select2-container--default .select2-selection--multiple .select2-selection__choice__remove{
            color: #fff !important;
        }
    </style>
</div>
<script>
    $(document).ready(function() {
        $('#publishedPlatform').select2();
    });
</script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>