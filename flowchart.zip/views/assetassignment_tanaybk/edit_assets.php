<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Assets Overview</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen px-4 py-8">
  <div class="max-w-5xl mx-auto">
    <h1 class="text-3xl font-bold mb-8 text-center text-gray-800">User Assets Overview</h1>
    
    <div id="user-assets" class="grid grid-cols-1 gap-6">
      <!-- User data will be dynamically inserted here -->
    </div>

    <!-- No data message -->
    <div id="no-data" class="hidden text-center text-gray-600 mt-4">
      No user data available.
    </div>
  </div>

  <script>
    const userAssetsContainer = document.getElementById('user-assets');
    const noDataMessage = document.getElementById('no-data');

    function renderUserAssets(data) {
      userAssetsContainer.innerHTML = '';
      if (data.length === 0) {
        noDataMessage.classList.remove('hidden');
        return;
      }

      noDataMessage.classList.add('hidden');
      data.forEach(user => {
        const card = document.createElement('div');
        card.className = 'bg-white p-6 rounded-xl shadow-lg';
        card.innerHTML = `
          <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-semibold text-gray-800">User: ${user.username}</h2>
            <button onclick="deleteUser(${user.id})" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition">
              Delete User
            </button>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <p class="text-sm font-medium text-gray-700">Products:</p>
              <ul class="list-disc pl-5 text-gray-600">
                ${user.product_list.map((item, index) => `
                  <li class="flex items-center gap-2">
                    ${item.product} (${item.brand})
                    <button onclick="deleteProduct(${user.id}, ${index})" class="text-red-500 hover:text-red-700 font-bold">×</button>
                  </li>
                `).join('')}
              </ul>
            </div>
            <div>
              <p class="text-sm font-medium text-gray-700">Status: <span class="text-gray-600">${user.status}</span></p>
              <p class="text-sm font-medium text-gray-700">Date: <span class="text-gray-600">${user.date}</span></p>
              <p class="text-sm font-medium text-gray-700">Description: <span class="text-gray-600">${user.description || 'N/A'}</span></p>
            </div>
          </div>
        `;
        userAssetsContainer.appendChild(card);
      });
    }

    function deleteUser(id) {
      if (confirm('Are you sure you want to delete this user and all their data?')) {
        fetch('<?php echo base_url('blog/delete/'); ?>' + id, { method: 'DELETE' })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              fetchData();
            } else {
              alert('Error deleting user.');
            }
          })
          .catch(error => alert('Error deleting user: ' + error));
      }
    }

    function deleteProduct(userId, productIndex) {
      if (confirm('Are you sure you want to delete this product?')) {
        fetch('<?php echo base_url('blog/delete_product/'); ?>' + userId + '/' + productIndex, { method: 'DELETE' })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              fetchData();
            } else {
              alert('Error deleting product.');
            }
          })
          .catch(error => alert('Error deleting product: ' + error));
      }
    }

    function fetchData() {
      fetch('<?php echo base_url('blog/get_assets'); ?>')
        .then(response => response.json())
        .then(data => renderUserAssets(data))
        .catch(error => {
          console.error('Error fetching data:', error);
          document.getElementById('no-data').classList.remove('hidden');
        });
    }

    // Initial data fetch
    fetchData();
  </script>
</body>
</html>