<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Assets and Assignment</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center px-4">

  <div class="bg-white p-8 rounded-xl shadow-lg w-full max-w-3xl">
    <h1 class="text-3xl font-bold mb-8 text-center text-gray-800">Assets and Assignment</h1>
    
    <form id="assetForm" action="<?php echo base_url('blog/submit'); ?>" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">

      <!-- Username -->
      <div class="col-span-1 md:col-span-2">
        <label for="username" class="block text-sm font-medium text-gray-700 mb-1">Username</label>
        <input type="text" id="username" name="username" placeholder="Enter your username" required
          class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>

      <!-- Product and Brand Input -->
      <div class="col-span-1 md:col-span-2">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label for="product-select" class="block text-sm font-medium text-gray-700 mb-1">Select Product</label>
            <select id="product-select" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">-- Choose a Product --</option>
              <option>Mobile</option>
              <option>Sim card</option>
              <option>Laptop</option>
              <option>Mouse</option>
              <option>Bag</option>
              <option>ID</option>
              <option>T-Shirt</option>
              <option>Hoodie</option>
            </select>
          </div>
          <div>
            <label for="brand-input" class="block text-sm font-medium text-gray-700 mb-1">Brand Name</label>
            <input type="text" id="brand-input" placeholder="Enter brand name" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
          </div>
        </div>
        <div class="mt-4 flex justify-end">
          <button type="button" id="add-product" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
            Add
          </button>
        </div>
      </div>

      <!-- Selected Products List -->
      <div class="col-span-1 md:col-span-2">
        <label class="block text-sm font-medium text-gray-700 mb-1">Selected Products</label>
        <ul id="selected-products" class="flex flex-wrap gap-2"></ul>
      </div>

      <!-- Hidden input to hold selected products and brands -->
      <input type="hidden" name="product_list" id="product_list">

      <!-- Status -->
      <div>
        <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Status</label>
        <select id="status" name="status" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
          <option value="">-- Select Status --</option>
          <option>Yes</option>
          <option>No</option>
        </select>
      </div>

      <!-- Date -->
      <div>
        <label for="date" class="block text-sm font-medium text-gray-700 mb-1">Date</label>
        <input type="date" id="date" name="date" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
      </div>

      <!-- Description -->
      <div>
        <label for="description" class="block text-sm font-medium text-gray-700 mb-1">Description</label>
        <textarea id="description" name="description" rows="3" placeholder="Enter description" class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
      </div>

      <!-- Submit Button -->
      <div class="col-span-1 md:col-span-2 flex justify-center">
        <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition">
          Submit
        </button>
      </div>

    </form>
  </div>

  <script>
    const addBtn = document.getElementById('add-product');
    const productSelect = document.getElementById('product-select');
    const brandInput = document.getElementById('brand-input');
    const selectedList = document.getElementById('selected-products');
    const hiddenInput = document.getElementById('product_list');
    let selectedProducts = [];

    addBtn.addEventListener('click', () => {
      const product = productSelect.value.trim();
      const brand = brandInput.value.trim();
      if (product && brand) {
        selectedProducts.push({ product, brand });
        updateList();
        productSelect.value = '';
        brandInput.value = '';
      } else {
        alert('Please select a product and enter a brand name.');
      }
    });

    function updateList() {
      selectedList.innerHTML = '';
      selectedProducts.forEach((item, index) => {
        const li = document.createElement('li');
        li.className = 'bg-blue-100 text-blue-700 px-3 py-1 rounded flex items-center gap-2';
        li.innerHTML = `
          <span>${item.product} (${item.brand})</span>
          <button type="button" class="text-red-500 hover:text-red-700 font-bold" onclick="removeProduct(${index})">×</button>
        `;
        selectedList.appendChild(li);
      });
      // Store as JSON string to preserve product-brand pairs
      hiddenInput.value = JSON.stringify(selectedProducts);
    }

    function removeProduct(index) {
      selectedProducts.splice(index, 1);
      updateList();
    }
  </script>

</body>
</html>