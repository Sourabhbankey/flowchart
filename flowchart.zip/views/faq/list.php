<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> FAQ'S Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <?php  if($is_admin == 1) { ?>
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>faq/add"><i class="fa fa-plus"></i> Add New FAQ'S</a>
                </div>
            </div>
        <?php } ?>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">FAQ'S List</h3>
                    <div class="box-tools">
                        <form action="<?php echo base_url() ?>faq/faqListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div><!-- /.box-header -->
                <div class="accordion" id="faqAccordion">
    <?php
    if (!empty($records)) {
        $index = 0; // Initialize index for accordion item
        foreach ($records as $record) {
    ?>
    <div class="accordion-item">
        <p class="accordion-header" id="heading<?php echo $index; ?>">
            <button class="accordion-button <?php echo ($index == 0) ? 'active-color' : 'default-color'; ?>" 
                type="button" data-bs-toggle="collapse" 
                data-bs-target="#collapse<?php echo $index; ?>" 
                aria-expanded="<?php echo ($index == 0) ? 'true' : 'false'; ?>" 
                aria-controls="collapse<?php echo $index; ?>">
                <?php echo $record->faqTitle; ?>
            </button>
        </p>
        <div id="collapse<?php echo $index; ?>" 
            class="accordion-collapse collapse <?php echo ($index == 0) ? 'show' : ''; ?>" 
            aria-labelledby="heading<?php echo $index; ?>" 
            data-bs-parent="#faqAccordion">
            <div class="accordion-body">
                <p><?php echo $record->description; ?></p>
                <p><strong>Created On:</strong> <?php echo date("d-m-Y", strtotime($record->createdDtm)); ?></p>
                <?php if ($is_admin == 1) { ?>
                <div class="d-flex justify-content-start">
                    <a class="btn btn-sm btn-info" href="<?php echo base_url().'faq/edit/'.$record->faqId; ?>" title="Edit"><i class="fa fa-pencil"></i> Edit</a>
                    <a class="btn btn-sm btn-danger deleteFaq" href="#" data-faqid="<?php echo $record->faqId; ?>" title="Delete"><i class="fa fa-trash"></i> Delete</a>
                    <a class="btn btn-sm btn-info" href="<?php echo base_url().'faq/view/'.$record->faqId; ?>" title="View"><i class="fa fa-eye"></i> View</a>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php
            $index++; // Increment the index for the next FAQ
        }
    }
    ?>
</div>

                <div class="box-footer clearfix">
                    <div class="br-pagi">
                    <p>Showing <?php echo $start; ?> to <?php echo $end; ?> of <?php echo $total_records; ?> records</p>
                    <?php echo $this->pagination->create_links(); ?>
                </div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "faq/faqListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
    #faqAccordion {
        padding: 1em;
    }
    /* Accordion Container */
.accordion {
  display: flex;
  flex-direction: column;
}

.accordion-item {
  border: 1px solid #dee2e6;
  border-radius: .25rem;
}

.accordion-header {
  background-color: #f8f9fa;
  padding: .75rem 1.25rem;
  margin-bottom: 0;
}

.accordion-button {
  display: flex;
  align-items: center;
  width: 100%;
  background-color: transparent;
  border: none;
  padding: .75rem 1.25rem;
  font-size: 1.75rem;
  text-align: left;
  color: #0d6efd;
  transition: background-color .2s ease;
  font-weight: 600;
}

.accordion-button:not(.collapsed) {
  color: #0d6efd;
  background-color: #e7f1fe;
}

.accordion-button:focus {
  outline: none;
  box-shadow: none;
}

.accordion-button.collapsed {
  color: #0d6efd;
}

.accordion-collapse {
  display: none;
}

.accordion-collapse.show {
  display: block;
}

.accordion-body {
  padding: 1.25rem;
  background-color: #ffffff;
  border-top: 1px solid #dee2e6;
}

.accordion-flush .accordion-item {
  border-radius: 0;
  border-top: 0;
}

.accordion-flush .accordion-header {
  background-color: transparent;
  border-color: #dee2e6;
}

.accordion-flush .accordion-button {
  border-radius: 0;
}

.accordion-item:last-child .accordion-body {
  border-bottom: 0;
}

.accordion-button:not(.collapsed) {
  background-color: #e7f1fe;
}

.accordion-button.collapsed {
  background-color: transparent;
}
/*Icon*/
/* Accordion Container */
.accordion {
  display: flex;
  flex-direction: column;
}

.accordion-item {
  border: 1px solid #dee2e6;
  border-radius: .25rem;
}

.accordion-header {
  background-color: #f8f9fa;
  padding: .75rem 1.25rem;
  margin-bottom: 0;
}
.accordion-button::after {
  content: '\f078'; /* Font Awesome downwards icon */
  font-family: 'Font Awesome 5 Free'; 
  font-weight: 900;
  position: absolute;
  right: 3.25rem;
  font-size: 1.75rem;
  color: #0d6efd;
  transition: transform .2s ease;
}

.accordion-button:not(.collapsed)::after {
  content: '\f077'; /* Font Awesome upwards icon */
  transform: rotate(180deg); /* Rotate the icon when expanded */
}

.accordion-button:focus {
  outline: none;
  box-shadow: none;
}

.accordion-collapse {
  display: none;
}

.accordion-collapse.show {
  display: block;
}

.accordion-body {
  padding: 1.25rem;
  background-color: #ffffff;
  border-top: 1px solid #dee2e6;
}

.accordion-flush .accordion-item {
  border-radius: 0;
  border-top: 0;
}

.accordion-flush .accordion-header {
  background-color: transparent;
  border-color: #dee2e6;
}

.accordion-flush .accordion-button {
  border-radius: 0;
}

.accordion-item:last-child .accordion-body {
  border-bottom: 0;
}
.accordion-button {
    color: black !important;
    transition: none !important; /* Removes delay */
}

/* Active color (blue when clicked) */
.accordion-button.active-color {
    color: #0d6efd !important;
}
.accordion-collapse {
    transition: none !important;
}
</style>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<script>
document.addEventListener("DOMContentLoaded", function () {
    const accordionButtons = document.querySelectorAll(".accordion-button");

    accordionButtons.forEach(button => {
        button.addEventListener("click", function () {
            // Reset all buttons to default color
            accordionButtons.forEach(btn => {
                btn.classList.remove("active-color");
                btn.classList.add("default-color");
            });

            // Change only the clicked button to active color
            this.classList.remove("default-color");
            this.classList.add("active-color");
        });
    });
});

</script>