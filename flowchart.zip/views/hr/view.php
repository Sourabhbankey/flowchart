<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Leave Management
        <small>Add / Edit Leave</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Leave Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
              
    <h3>View Leave</h3>
    
    <table class="table table-bordered no-padding1">
        <tr>
            <th>Leave Type</th>
            <td><?php echo $leaveInfo->leave_type; ?></td>
        </tr>
        <tr>
            <th>Start Date</th>
            <td><?php echo $leaveInfo->start_date; ?></td>
        </tr>
        <tr>
            <th>End Date</th>
            <td><?php echo $leaveInfo->end_date; ?></td>
        </tr>
        <tr>
            <th>Reason</th>
            <td><?php echo $leaveInfo->reason; ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo ucfirst($leaveInfo->status); ?></td>
        </tr>
        <tr>
            <th>Created At</th>
            <td><?php echo $leaveInfo->created_at; ?></td>
        </tr>
        <tr>
            <th>Revert Back</th>
            <td><?php echo $leaveInfo->replyByHr; ?></td>
        </tr>
        <tr>
            <th>Attachment</th>
        
  
       <td>
    <?php
    if (!empty($leaveInfo->leaveS3File)) {
        $files = explode(',', $leaveInfo->leaveS3File);
        foreach ($files as $file) {
            echo '<img src="' . htmlspecialchars($file) . '" alt="Attachment" style="max-width: 150px; height: auto; margin: 5px;">';
        }
    } else {
        echo 'No attachments';
    }
    ?>
    <button class="btn" onclick="downloadImage('<?php echo $leaveInfo->leaveS3File ?>')">
    <i class="fa fa-download"></i> Download
  </button>
</td>


        </tr>
    </table>

    <a href="<?php echo base_url('leave/leaveListing'); ?>" class="btn btn-primary">Back to List</a>

                </div>
               <form role="form" id="addreply" action="<?php echo base_url() ?>hr/addReply" method="post">
    <input type="hidden" name="leaveId" value="<?php echo $leaveInfo->leaveId; ?>"> <!-- Hidden field for ID -->
    
    <div class="form-group">
        <label for="replyByHr">Revert Back</label>
        <textarea class="form-control required" id="replyByHr" name="replyByHr" rows="5"><?php echo $leaveInfo->replyByHr; ?></textarea>
    </div>

    <div class="box-footer">
        <input type="submit" class="btn btn-primary" value="Submit" />
    </div>
</form>
            </div>

            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>





<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script>
  async function downloadImage(url) {
    try {
      console.log('Attempting to download:', url);

      // Fetch the file as a blob
      const response = await fetch(url, { mode: 'cors' });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const blob = await response.blob(); // Convert the response to a blob
      const urlObject = URL.createObjectURL(blob);

      // Create a temporary <a> element
      const a = document.createElement('a');
      const filename = url.substring(url.lastIndexOf('/') + 1); // Extract filename
      a.href = urlObject;
      a.download = filename;

      // Append and trigger click
      document.body.appendChild(a);
      a.click();

      // Cleanup
      document.body.removeChild(a);
      URL.revokeObjectURL(urlObject);
    } catch (error) {
      console.error('Error downloading the file:', error);
      alert('Failed to download the file. Please check the console for details.');
    }
  }
</script>





















///////view


