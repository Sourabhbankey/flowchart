<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Attendance Management
        </h1>
    </section>
  

    <section class="content">
     
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
       <!--    <h1>Attendance Records</h1> -->
          
            <?php  $user_id = $this->session->userdata('userId'); // Or whatever your session stores
            if ($this->session->flashdata('message')): ?>
    <p><?php echo $this->session->flashdata('message'); ?></p>
<?php endif; ?>

<?php 
    $pending_count = 0;
    $approved_count = 0;
    $rejected_count = 0;

    $user_id = $this->session->userdata('userId'); // 👈 Logged-in user's ID

    if (!empty($status_counts) && is_array($status_counts)) {
        foreach ($status_counts as $count) {
            if (isset($count->status) && isset($count->count) && isset($count->user_id)) {
                if ($count->user_id == $user_id) {  // 👈 Only count if this record is for logged-in user

                    if ($count->status == 'pending') {
                        $pending_count = $count->count;
                    } 
                    elseif ($count->status == 'approved' || $count->status == 'approved_hr' || $count->status == 'approved_manager') {
                        $approved_count += $count->count;
                    } 
                    elseif ($count->status == 'rejected' || $count->status == 'rejected_hr' || $count->status == 'rejected_manager') {
                        $rejected_count += $count->count;
                    }

                }
            }
        }
    }
?>
            <form method="post" action="<?= base_url('hr/hrListing'); ?>">
    <label for="user_id">Filter by User:</label>
    <select id="userFilter" name="userFilter" style="height: 32px;">
        <option value="0">Select User</option>
        <?php if (!empty($users)) {
            foreach ($users as $rl) { ?>
                <option value="<?= $rl->userId ?>" <?= ($rl->userId == $selectedUser) ? 'selected' : '' ?>>
                    <?= $rl->name ?>
                </option>
            <?php }
        } ?>
    </select>

    <label for="start_date">From Date:</label>
    <input type="date" name="start_date" id="start_date" value="<?= isset($start_date) ? $start_date : '' ?>" style="height: 32px;">

    <label for="end_date">To Date:</label>
    <input type="date" name="end_date" id="end_date" value="<?= isset($end_date) ? $end_date : '' ?>" style="height: 32px;">

    <input type="submit" value="Filter" class="btn btn-primary customreset-fil">
    <a href="<?= base_url('hr/hrListing'); ?>" class="btn btn-default btn-danger" onclick="resetUserFilters()">Reset</a>
</form>

            <!-- <div class="atten-rec">
                <p>Total Pending: <?php echo $pending_count; ?></p>
                <p>Total Approved: <?php echo $approved_count; ?></p>
                <p>Total Rejected: <?php echo $rejected_count; ?></p>
            </div>    
                <?php $assigned_leaves = 10; // Define the total assigned leaves per user
                $applied_leaves = 0; // Initialize applied leaves

                if (!empty($attendance_records)) {
                    foreach ($attendance_records as $record) {
                        if ($record->status == 'approved_manager' || $record->status == 'approved_hr') {
                            // Assuming leave duration is from start_date to end_date
                            $start = new DateTime($record->start_date);
                            $end = new DateTime($record->end_date);
                            $interval = $start->diff($end)->days + 1; // Include the last day

                            $applied_leaves += $interval;
                        }
                    }
                }

                $remaining_leaves = max(0, $assigned_leaves - $applied_leaves); // Ensure it doesn't go negative
                ?>
                <div class="atten-rec">
                    <p>Total Assigned Leaves: <?php echo $assigned_leaves; ?></p>
                    <p>Total Applied Leaves: <?php echo $applied_leaves; ?></p>
                    <p>Remaining Leaves: <?php echo $remaining_leaves; ?></p>
                </div> -->
                <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">HR Attendance Listing Records</h3>
                    <div class="box-tools">
                        <!--<form action="<?php //echo base_url() ?>task/taskListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>-->
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
   <table id="example" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Serial No</th>
                <th>Employee Name</th>
            <th>Status</th>
            <th>Reporting Manager</th>
            <th>From Date</th>
            <th>To Date</th>
           <!-- <th>Reason</th>-->
                <th>Actions</th>
               
            </tr>
        </thead>
        <tbody>
            <?php  $counter= 1;
            foreach ($attendance_records as $record): ?>
                <tr>
                  <td><?php echo $counter++; ?></td>
<td><?php echo $record->name; ?></td>
<td>
    <?php 
        if ($record->status == 'approved_manager') {
            echo '<span class="badge bg-success">Approved by Manager</span>';
        } 
        elseif ($record->status == 'approved_hr') {
            echo '<span class="badge bg-success">Approved by HR</span>';
        }
        elseif ($record->status == 'rejected_hr') {
            echo '<span class="badge bg-danger">Rejected by HR</span>';
        } 
        elseif ($record->status == 'rejected_manager') {
            echo '<span class="badge bg-danger">Rejected by Manager</span>';
        }
        else {
            echo '<span class="badge bg-warning text-dark">'.ucwords($record->status).'</span>'; // Pending or unknown status
        }
    ?>
</td>

<td><?php echo !empty($record->assignedToName) ? htmlspecialchars($record->assignedToName) : 'Not Assigned'; ?></td>

<td><?php echo $record->start_date; ?></td>
<td><?php echo $record->end_date; ?></td>
<td>
    <?php 
    $userId = $this->session->userdata('userId');
    $roleId = $this->session->userdata('role'); // Get the logged-in user's role ID
    $assignedTo = $record->assignedTo; // Get the assigned manager's user ID
    $hrRoleId = 26; // HR role ID

    if ($record->userId != $userId): // Ensure the applicant does not see these buttons 
    ?>
    
        <?php if ($record->status == 'pending'): ?>
            <!-- Show Manager approval buttons only if the logged-in user is the assigned manager -->
            <?php if ($userId == $assignedTo): ?>
                <a class="btn btn-primary customreset-fil" href="<?php echo base_url('hr/update_status/'.$record->leaveId.'/approved_manager'); ?>">Approve by Manager</a>
                <a class="btn btn-danger btn-secondary" href="<?php echo base_url('hr/update_status/'.$record->leaveId.'/rejected_manager'); ?>">Reject by Manager</a>

            <!-- Show HR approval buttons if role = 26 -->
            <?php elseif ($roleId == $hrRoleId): ?>
                <a class="btn btn-primary customreset-fil" href="<?php echo base_url('hr/update_status/'.$record->leaveId.'/approved_hr'); ?>">Approve by HR</a>
                <a class="btn btn-danger btn-secondary" href="<?php echo base_url('hr/update_status/'.$record->leaveId.'/rejected_hr'); ?>">Reject by HR</a>
            <?php endif; ?>

        <?php elseif ($record->status == 'approved_manager' && $roleId == $hrRoleId): ?>
            <!-- Show HR approval buttons -->
            <a class="btn btn-primary customreset-fil" href="<?php echo base_url('hr/update_status/'.$record->leaveId.'/approved_hr'); ?>">Approve by HR</a>
            <a class="btn btn-danger btn-secondary" href="<?php echo base_url('hr/update_status/'.$record->leaveId.'/rejected_hr'); ?>">Reject by HR</a>

        <?php elseif ($record->status == 'approved_hr'): ?>
            <!-- Show final approval status -->
            <span class="badge bg-success">Approved by HR</span>

        <?php elseif ($record->status == 'rejected_hr'): ?>
            <span class="badge bg-danger">Rejected by HR</span>

        <?php elseif ($record->status == 'rejected_manager'): ?>
            <span class="badge bg-danger">Rejected by Manager</span>
        <?php endif; ?>

    <?php endif; ?>

    <!-- View button (always visible) -->
    <a class="btn btn-danger btn-secondary" href="<?php echo base_url('hr/view/'.$record->leaveId); ?>">View</a>
</td>



                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</div>
</div>
</div>
    </section>
</div>

<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        min-width: 50%;
        font-weight: bold;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, 
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }
    div.dataTables_wrapper li {
        text-indent: 0;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, 
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
        content: "-";
        background-color: #d33333;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, 
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }
    .atten-rec {
    display: flex;
    flex-wrap: wrap; /* Makes it responsive on smaller screens */
    gap: 20px; /* Spacing between the items */
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    padding: 10px;
    text-align: center;
}
.atten-rec p {
    margin: 0;
    padding: 10px 15px;
    background-color: #FF9800;
    border-radius: 8px;
    flex: 1 1 auto;
    min-width: 150px;
    color: #fff;
    font-weight: 600;
}
span.badge.bg-success {
    background: #7CB342;
    padding: 8px;
}
span.badge.bg-warning.text-dark {
    background: #c33030;
    padding: 8px;
}
span.badge.bg-danger {
    background: #c33030;
    padding: 8px;
}
</style>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>

<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script>
    function resetDateFilters() {
        // Clear the date input fields when resetting the filters
        document.querySelector('input[name="start_date"]').value = '';
        document.querySelector('input[name="end_date"]').value = '';
    }
</script>
<script>
    function resetUserFilters() {
        // Clear the date input fields when resetting the filters
        document.querySelector('input[name="userFilter"]').value = '';
          document.getElementById("start_date").value = '';
    document.getElementById("end_date").value = '';
       
    }
</script>
