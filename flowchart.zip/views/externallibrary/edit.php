    <?php
    $exbrLibraryId = $externallibraryInfo->exbrLibraryId;
    $exbrLibraryTitle = $externallibraryInfo->exbrLibraryTitle;
    $exbrLibraryLink = $externallibraryInfo->exbrLibraryLink;
    $exbrLibraryPDFS3attachment = $externallibraryInfo->exbrLibraryPDFS3attachment;
    $exbrLibraryStatus = $externallibraryInfo->exbrLibraryStatus;
    $description = $externallibraryInfo->description;
    $createdDtm = $externallibraryInfo->createdDtm;

    ?>

    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <i class="fa fa-user-circle-o" aria-hidden="true"></i> External Library Management
                <!-- <small>Add / Edit </small> -->
            </h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-10">
                    <div class="box box-primary">
                        <div class="box-header">
                            <h3 class="box-title">Enter Details</h3>
                            <div class="pull-right">
                                <a href="<?php echo base_url() ?>externallibrary/externallibraryListing" class="btn btn-info">Back to Listing</a>
                            </div>
                        </div>

                        <form role="form" action="<?php echo base_url() ?>Externallibrary/editExternallibrary" method="post" id="editexternallibrary" enctype="multipart/form-data">
                            <div class="box-body">
                                <div class="row">
                                    <!-- Title -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="internaltrainingTitle">Title</label>
                                            <input type="text" class="form-control required" value="<?php echo $exbrLibraryTitle; ?>" id="exbrLibraryTitle" name="exbrLibraryTitle" maxlength="256" />
                                            <input type="hidden" value="<?php echo $exbrLibraryId; ?>" name="exbrLibraryId" id="exbrLibraryId" />
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="internaltrainingTitle">Link</label>
                                            <input type="text" class="form-control required" value="<?php echo $exbrLibraryLink; ?>" id="exbrLibraryLink" name="exbrLibraryLink" maxlength="256" />

                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exbrLibraryStatus">Status</label>
                                            <select class="form-control" name="exbrLibraryStatus" id="exbrLibraryStatus">
                                                <option value="Active" <?= $externallibraryInfo->exbrLibraryStatus == 'Active' ? 'selected' : '' ?>>Active</option>
                                                <option value="InActive" <?= $externallibraryInfo->exbrLibraryStatus == 'InActive' ? 'selected' : '' ?>>InActive</option>

                                            </select>
                                        </div>
                                    </div>

                                    <!-- Description -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                        </div>
                                    </div>



                                </div>
                            </div><!-- /.box-body -->

                            <div class="box-footer">
                                <input type="submit" class="btn btn-primary" value="Submit" />
                                <input type="reset" class="btn btn-default" value="Reset" />
                            </div>
                        </form>
                    </div>
                </div>


                <!-- Right Column -->
                <div class="col-md-4">
                    <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                        echo '<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'
                            . $error .
                            '</div>';
                    }

                    $success = $this->session->flashdata('success');
                    if ($success) {
                        echo '<div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'
                            . $success .
                            '</div>';
                    }

                    echo validation_errors(
                        '<div class="alert alert-danger alert-dismissable">',
                        ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'
                    );
                    ?>
                </div>
            </div>
        </section>

        <!-- CKEditor -->
        <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
        <script>
            CKEDITOR.replace('description', {
                filebrowserUploadMethod: 'form'
            });
            CKEDITOR.replace('reply', {
                filebrowserUploadMethod: 'form'
            });
        </script>
    </div>
    <style>
        .conversation-thread {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 5px;
            max-height: 400px;
            overflow-y: auto;
            background: #fff;
        }

        .message-box {
            margin-bottom: 15px;
            padding: 10px;
            background: #f1f1f1;
            border-radius: 5px;
        }
    </style>
    <script>
        function downloadImage(url) {
            fetch(url, {
                    mode: 'cors' // This works only if S3 allows CORS
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.blob();
                })
                .then(blob => {
                    const blobUrl = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = blobUrl;
                    a.download = url.split('/').pop(); // Use filename from URL
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                    URL.revokeObjectURL(blobUrl);
                })
                .catch(error => {
                    console.error('Download failed:', error);
                    alert('Image could not be downloaded. Please check CORS settings on S3.');
                });
        }
    </script>