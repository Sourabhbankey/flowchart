<?php
$pdcId = $pdcInfo->pdcId;
$franchiseNumberArray = explode(",", $pdcInfo->franchiseNumber);
$brspFranchiseAssigned = $pdcInfo->brspFranchiseAssigned;
$pdcNumber = $pdcInfo->pdcNumber;
$dateOfpdcSubmission = $pdcInfo->dateOfpdcSubmission;
$dateOfclearance = $pdcInfo->dateOfclearance;
/*$dateOfclearance = $pdcInfo->dateOfclearance;*/
$statusOfPDc = $pdcInfo->statusOfPDc;
$pdcAttach = $pdcInfo->pdcAttach;
$pdcAmount = $pdcInfo->pdcAmount;
$description = $pdcInfo->description;
$pdcTitle = $pdcInfo->pdcTitle;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> PDC Management
            <small>Add / Edit PDC</small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter PDC Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->

                    <form role="form" action="<?php echo base_url() ?>pdc/editPdc" method="post" id="editPdc" role="form">
                        <div class="box-body">
                            <div class="row">
                            
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" disabled>
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                            ?>
                                                    <option value="<?php echo $franchiseNumber; ?>" <?php if (in_array($franchiseNumber, $franchiseNumberArray)) {
                                                                                                        echo "selected=selected";
                                                                                                    } ?>><?php echo $franchiseNumber; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        <input type="text" value="<?php echo $brspFranchiseAssigned; ?>" name="brspFranchiseAssigned" id="brspFranchiseAssigned" />
                                    </div>
                                </div>

                                <input type="hidden" value="<?php echo $pdcId; ?>" name="pdcId" id="pdcId" />
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pdcTitle">PDC Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('pdcTitle'); ?>" id="pdcTitle" name="pdcTitle" maxlength="256" />

                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pdcAmount">PDC Amount <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $pdcAmount; ?>" id="pdcAmount" name="pdcAmount" maxlength="256" readonly />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="pdcNumber">Cheque Number <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $pdcNumber; ?>" id="pdcNumber" name="pdcNumber" maxlength="256" readonly />
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateOfpdcSubmission">Date Of Submission <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateOfpdcSubmission; ?>" id="dateOfpdcSubmission" name="dateOfpdcSubmission" maxlength="256" readonly>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="dateOfclearance">Date Of Clearance <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateOfclearance; ?>" id="dateOfclearance" name="dateOfclearance" maxlength="256" readonly>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="statusOfPDc">Status Of PDC</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusOfPDc" id="statusOfPDc" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option>
                                            <option value="Cleared" <?php echo ($pdcInfo->statusOfPDc == 'Cleared') ? 'selected' : ''; ?>>Cleared</option>
                                            <option value="Due" <?php echo ($pdcInfo->statusOfPDc == 'Due') ? 'selected' : ''; ?>>Due</option>
                                            <option value="Hold" <?php echo ($pdcInfo->statusOfPDc == 'Hold') ? 'selected' : ''; ?>>Hold</option>
                                            <option value="Cancellation" <?php echo ($pdcInfo->statusOfPDc == 'Cancellation') ? 'selected' : ''; ?>>Cancellation</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4" id="cancellationReason" style="display: none;">
                                    <div class="form-group">
                                        <label for="cancellationReason">Reason for Cancellation <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control" id="cancellationReason" name="cancellationReason" maxlength="1024"></textarea>
                                    </div>
                                </div>


                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                       <label for="pdcAttach">PDC Attchecment <span class="re-mend-field">*</span></label>
                                        <input required type="file" class="form-control required" value="<?php echo set_value('pdcAttach'); ?>" id="pdcAttach" name="pdcAttach" maxlength="256">
                                    </div>   
                                </div> -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">PDC Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>

    <script>
        function fetchAssignedFranchise(franchiseNumber) {
            if (franchiseNumber) {
                $.ajax({
                    url: '<?php echo base_url("pdc/fetchAssignedUsers"); ?>',
                    type: 'POST',
                    data: {
                        franchiseNumber: franchiseNumber
                    },
                    success: function(response) {
                        $('#branchFranchiseAssigned').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX Error: ", status, error);
                        console.error("Response Text: ", xhr.responseText);
                        alert('Error fetching data');
                    }
                });
            } else {
                $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
            }
        }

        const form = document.getElementById('yourForm');
        const submitBtn = document.getElementById('submitBtn');
        const statusOfPDc = document.getElementById('statusOfPDc');
        const cancellationReasonDiv = document.getElementById('cancellationReasonDiv');
        const cancellationReason = document.getElementById('cancellationReason');

        statusOfPDc.addEventListener('change', function() {
            if (this.value === 'Cancellation') {
                cancellationReasonDiv.style.display = 'block';
                cancellationReason.setAttribute('required', 'required');
            } else {
                cancellationReasonDiv.style.display = 'none';
                cancellationReason.removeAttribute('required');
                cancellationReason.value = '';
            }
        });

        form.addEventListener('submit', function(e) {
            if (submitBtn.disabled) {
                e.preventDefault();
                return;
            }
            submitBtn.disabled = true;
            submitBtn.innerText = 'Submitting...';
        });
    </script>

</div>