
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Scheduled Installation Management
        <small>Add / Edit Scheduled Installation</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Scheduled Installation Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourTask" action="<?php echo base_url() ?>scheduledinstallation/addNewScheduledinstallation" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                              <!--   <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="schinsTitle">Branch Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('schinsTitle'); ?>" id="schinsTitle" name="schinsTitle" maxlength="256" />
                                    </div>
                                </div> -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                              
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchSetupName">Branch Name </label>
                                        <input type="text" readonly class="form-control required" id="branchSetupName" name="schinsTitle" maxlength="256">
                                    </div>
                                </div>
                               <!--   -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" id="city" name="instaCity" maxlength="256" readonly>
                                    </div>
                                </div>
                               
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="schDateInstall">Schduled Date Of Installation <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('schDateInstall'); ?>" id="schDateInstall" name="schDateInstall" maxlength="256">
                                    </div>   
                                </div>
                             <!--    <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="schinsAddress">Address <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="schinsAddress" name="schinsAddress"></textarea>
                                    </div>
                                </div> -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="brcompAddress">Branch Complete Address <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="brcompAddress" name="schinsAddress" readonly></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="installTL">Installation Team Leader <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('installTL'); ?>" id="installTL" name="installTL" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="contactTL">Team Leader Contact No.<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('contactTL'); ?>" id="contactTL" name="contactTL" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="installTeam">Installation Team <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('installTeam'); ?>" id="installTeam" name="installTeam" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="installTeamNum">Installation Team Contact No.<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('installTeamNum'); ?>" id="installTeamNum" name="installTeamNum" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="travelingFrom">Travelling From <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('travelingFrom'); ?>" id="travelingFrom" name="travelingFrom" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="travelingTo">Travelling To <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('travelingTo'); ?>" id="travelingTo" name="travelingTo" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload Tickets</label>
                                        <input required type="file" name="file" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="dateOfDespatch">Date Of Travel <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateOfDespatch'); ?>" id="dateOfDespatch" name="dateOfDespatch" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="modeOfTravel">Mode Of Travel <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('modeOfTravel'); ?>" id="modeOfTravel" name="modeOfTravel" maxlength="256">
                                    </div>   
                                </div>
                                 <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="modeOfTravel">Date Of Installation <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateofinstall'); ?>" id="dateofinstall" name="dateofinstall" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="installStartedTime">Installation Started Time<span class="re-mend-field">*</span></label>
                                        <input required type="time" class="form-control required" value="<?php echo set_value('installStartedTime'); ?>" id="installStartedTime" name="installStartedTime" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="installFinishedTime">Finished at <span class="re-mend-field">*</span></label>
                                        <input required type="time" class="form-control required" value="<?php echo set_value('installFinishedTime'); ?>" id="installFinishedTime" name="installFinishedTime" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="schinsAddress">Damaged Materials <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="dmMaterials" name="dmMaterials"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload Damaged Materials</label>
                                        <input required type="file" name="dmfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="schinsAddress">Damaged Materials Description<span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="dmMaterialsdesc" name="dmMaterialsdesc"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="missingMaterials">Missing Materials <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo set_value('missingMaterials'); ?>" id="missingMaterials" name="missingMaterials" maxlength="256"> -->
                                        <textarea required class="form-control required" id="missingMaterials" name="missingMaterials" maxlength="256"><?php echo set_value('missingMaterials'); ?></textarea>

                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="writtenfeedTickets">Upload Written Feedback</label>
                                        <input type="file" name="writtenfeedfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="writtenfeedTickets">Upload Installation Attachement</label>
                                        <input type="file" name="installattachfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="hedtitle">Branch Installation Images</h4>
                                        <h4 class="subhedtitle">Play Group</h4>  
                                    </div>  
                                </div>
                                <div class="col-md-6">                              
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="pgUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="pg1Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Nursery</h4>  
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="nurUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="nur1Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">KG-1</h4>  
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="kgUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="kg1Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">KG-2</h4>  
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="kgUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="kg1Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Reception</h4>  
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="recUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="recUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Play Area</h4>
                                    </div>  
                                </div>
                                
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="playUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="playUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Camera</h4>
                                    </div>  
                                </div>
                                
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="camUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="camUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Bio Metric</h4>
                                    </div>  
                                </div>
                                
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="bioMUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="bioMUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Washroom</h4>
                                    </div>  
                                </div>
                                
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="washUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="washUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Full Premise Front View</h4>
                                    </div>  
                                </div>
                                
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="preUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="preUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h4 class="subhedtitle">Other Images</h4>
                                    </div>  
                                </div>
                                
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 1</label>
                                        <input type="file" name="othUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 2</label>
                                        <input type="file" name="oth1Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 3</label>
                                        <input type="file" name="oth2Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 4</label>
                                        <input type="file" name="oth3Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Upload 5</label>
                                        <input type="file" name="oth4Uploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Pre Installation Video</label>
                                        <input type="file" name="previdUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Post Installation Video</label>
                                        <input type="file" name="postInstaUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadTickets">Feedback  Video</label>
                                        <input type="file" name="feedbackUploadfile" multiple>
                                    </div>  
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Installation Remark <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h6>Expences</h6>
                                    </div>  
                                </div>
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="expSrnum">Sr. No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('expSrnum'); ?>" id="expSrnum" name="expSrnum" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="expTitle">Expense Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('expTitle'); ?>" id="expTitle" name="expTitle" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="expDate">Date <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('expDate'); ?>" id="expDate" name="expDate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="uploadExpense">Expense Attachement</label>
                                        <input type="file" name="expUploadfile" multiple>
                                    </div>  
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .subhedtitle{
            background: #80b0ec;
            padding: 0.5rem;
            text-align: center;
            font-weight: 600;
            color: #fff;
        }
    </style>
</div>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber !== "") {
        $.ajax({
            url: '<?= base_url("scheduledinstallation/getBranchDetails") ?>',
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            dataType: 'json',
            success: function (response) {
                if (Object.keys(response).length > 0) {
                    $('#branchSetupName').val(response.branchSetupName);
                    $('#brcompAddress').val(response.brcompAddress);
                    $('#city').val(response.city);
                    // Optionally set state or others
                } else {
                    $('#branchSetupName').val('');
                    $('#brcompAddress').val('');
                    $('#city').val('');
                    alert("No data found for selected franchise.");
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX error:", error);
                alert("Error fetching branch details.");
            }
        });
    } else {
        $('#branchSetupName, #brcompAddress, #city').val('');
    }
}
</script>
