
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Digital Marketing Franchise Management
        <small>Add / Edit Digital Marketing Franchise </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Digital Marketing Franchise Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>dmfranchse/addNewDmfranchse" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true" required>
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                     <option value="<?php echo $franchiseNumber; ?>" ><?php echo $franchiseNumber; ?></option>
                                                    <?php

                                                }
                                            }
                                            ?>     
                                        </select>
                                    </div>
                                </div> -->

                                  <div class="col-md-4">
                        <div class="form-group">
                            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                <option value="">Select Franchise</option>
                                <?php
                                if (!empty($branchDetail)) {
                                    foreach ($branchDetail as $bd) {
                                        $franchiseNumber = $bd->franchiseNumber;
                                        ?>
                                        <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                            <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                <option value="0">Select Role</option>
                            </select>
                        </div>
                    </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dmfranchseTitle">Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('dmfranchseTitle'); ?>" id="dmfranchseTitle" name="dmfranchseTitle" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="doneBy">Done By <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="doneBy" name="doneBy" required >
                                          <option value="">Select Type of Training</option>
                                          <option value="Franchise">Franchise</option>
                                          <option value="HR">HR</option>
                                          <option value="Marketing and sales">Marketing and sales</option>
                                          <option value="Admissions">Admissions</option>

                                        </select>   
                                    </div>   
                                </div>
                                <!-- <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Support Manager</label>
                                         <select class="form-control required" id="brspFranchiseAssigned" name="brspFranchiseAssigned">
                                            <option value="0">Select Support Manager</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('brspFranchiseAssigned')) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                    
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>
                                    
                                </div> -->
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="numOfLeads">No. Of Leads Generated</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('numOfLeads'); ?>" id="numOfLeads" name="numOfLeads" maxlength="256">
                                    </div>   
                                </div>
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfrequest">Date Of Request <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateOfrequest'); ?>" id="dateOfrequest" name="dateOfrequest" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="CampaStartdate">Campaign Start Date <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('CampaStartdate'); ?>" id="CampaStartdate" name="CampaStartdate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="CampaEnddate">Campaign End Date <span class="re-mend-field">*</span></label>
                                        <input  type="date" class="form-control required" value="<?php echo set_value('CampaEnddate'); ?>" id="CampaEnddate" name="CampaEnddate" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Platform <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('platform'); ?>" id="platform" name="platform" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Upload Attachment </label>
                                        <input  type="file" name="file" multiple>
                                    </div>
                                    
                                </div>   
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="attachmentTitle">Receipt Attachment </label>
                                        <input  type="file" name="file2" multiple>
                                    </div>
                                    
                                </div>  
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="meetingTitle">Amount</label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('amount'); ?>" id="amount" name="amount" maxlength="256">
                                    </div>   
                                </div> 
                              <div class="col-md-4">                                
    <div class="form-group">
        <label>&nbsp;</label><br>
        <a href="#" target="_blank" class="btn btn-success">Pay Now</a>
    </div>   
</div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
       <script>
        CKEDITOR.replace('description', {
            filebrowserUploadUrl: "<?= base_url('dmfranchse/upload'); ?>",
            filebrowserUploadMethod: 'form'
        });
    </script>
</div>

<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("dmfranchse/fetchAssignedUsers"); ?>', // Update to match your controller and method
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
                  $('#branchFranchiseAssigned option[value="0"]').remove();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
       $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
    }
}
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>


