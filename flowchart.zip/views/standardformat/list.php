<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Standard Format Management
            <!-- <small>Add, Edit, Delete</small> -->
        </h1>
    </section>
    <section class="content">
        <!-- Hidden CSRF Token Fields -->
        <input type="hidden" id="csrf_token_name" value="<?php echo $this->security->get_csrf_token_name(); ?>">
        <input type="hidden" id="csrf_token_hash" value="<?php echo $this->security->get_csrf_hash(); ?>">

        <?php if ($is_admin == 1 || $role == 18 || $role != 25) { ?>
            <div class="row">
                <div class="col-xs-12 text-right">
                    <div class="form-group">
                        <a class="btn btn-primary" href="<?php echo base_url(); ?>standardformat/add"><i class="fa fa-plus"></i> Add New Standard Format</a>
                    </div>
                </div>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-md-12">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Standard Format List</h3>
                    </div>
                    <div class="box-body table-responsive no-padding1">
                        <?php
                        /*function getReadingTime($text)
                        {
                            $wordCount = str_word_count(strip_tags($text));
                            $readingTime = ceil($wordCount / 200);
                            return $readingTime;
                        }*/
                        ?>
                        <div class="row">
                            <?php
                            if (!empty($records)) {
                                $count = 0;
                                foreach ($records as $record) {
                                    if ($count % 3 == 0 && $count != 0) {
                                        echo '</div><div class="row">';
                                    }
                                    //$readingTime = getReadingTime($record->description);
                            ?>
                                    <div class="col-md-4">
                                        <div class="card">
                                            <div class="card-body">
                                                 <?php if (isset($record->standformatS3File) && !empty($record->standformatS3File)): ?>
                                            <a href="<?php echo $record->standformatS3File; ?>" target="_blank">
                                                <img src="<?php echo $record->standformatS3File; ?>" style="height: 50px !important; width: 50px;">VIEW
                                            </a>
                                        <?php else: ?>
                                            No attachment
                                        <?php endif; ?>
                                                <h5 class="card-title"><?php echo $record->standTitle; ?></h5>
                                                <p class="card-text"><strong>Published Date:</strong> <?php echo $record->publishedDate; ?></p>
                                                  <p class="card-text"><strong> Guideline Category:</strong> <?php echo $record->standCategoryType; ?></p>
                                                <p class="card-text blog-desc"><?php echo $record->description; ?></p>
                                                <p class="card-text"><strong>Created On:</strong> <?php echo date("d-m-Y", strtotime($record->createdDtm)); ?></p>
                                                <!-- <p class="card-text"><strong>Reading Time:</strong> <?php //echo $readingTime; ?> minute(s)</p> -->
                                                
                                               
                                
                                                <?php if ($is_admin == 1 || $role == 18) { ?>
                                                    <div class="actions mt-2">
                                                        <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'standardformat/edit/' . $record->standId; ?>" title="Edit"><i class="fa fa-pencil"></i> Edit</a>
                                                        <a class="btn btn-sm btn-danger deletestandId" href="#" data-standId="<?php echo $record->standId; ?>" title="Delete"><i class="fa fa-trash"></i> Delete</a>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                    $count++;
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="box-footer clearfix">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    .card {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 20px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .card-img-top {
        width: 100%;
    }

    .card-title {
        font-size: 1.2em;
        font-weight: bold;
    }

    .card-text {
        font-size: 0.9em;
        color: #555;
    }

    .blogbtn {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 8px 16px;
        text-decoration: none;
        border-radius: 5px;
    }

    .blogbtn:hover {
        background-color: #0056b3;
    }

    .actions a {
        margin-right: 10px;
    }

    .actions.mt-2 {
        margin: 10px 0px 0px 0px;
    }

    .row {
        margin-right: -10px;
        margin-left: -10px;
    }
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script>
$(document).ready(function () {
    $('.read-more').on('click', function (e) {
        e.preventDefault();

        var blogLink = $(this).attr('href');
        var blogId = $(this).data('blogid');
        var countSpan = $('#opened-count-' + blogId);

        $.ajax({
            url: '<?php echo base_url("blog/incrementOpenedCount"); ?>',
            type: 'POST',
            data: { blogId: blogId },
            dataType: 'json',
            success: function (response) {
                if (response && response.newCount !== undefined) {
                    countSpan.text(response.newCount);
                }
                window.open(blogLink, '_blank');
            },
            error: function () {
                window.open(blogLink, '_blank');
            }
        });
    });
});
</script>