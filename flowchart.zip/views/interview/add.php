
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Interview Management
        <small>Add / Edit </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Interview Details</h3>
                    </div><!-- /.box-header -->
                    
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addStaff" action="<?php echo base_url() ?>interview/addNewInterview" method="post" role="form" enctype="multipart/form-data">
                      <div class="box-body">
                            <div class="row">
                                 <div class="col-md-12">                                
                                    <div class="form-group">
                                      <h2 class="mb-4 hrfrm-onbord-title">Information</h2>
                                    </div>
                                  </div>
                                  <div class="col-md-4">                                
                                    <div class="form-group">                                
                                      <label class="form-label">Date Of Interview</label>
                                      <input type="date" name="date_of_interview" class="form-control" required>
                                    </div>
                                  </div>  
                                   <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Mode of interview </label>
                                      <select name="mode_of_interview" class="form-control" required>
                                        <option value="Online">Online</option>
                                        <option value="Offline">Offline</option>
                                      </select>
                                    </div>
                                    </div>
                                  <div class="col-md-4">                                                              
                                    <div class="form-group">
                                      <label class="form-label">Candidate Name</label>
                                      <input type="text" name="candidate_name" class="form-control" required>
                                    </div>
                                  </div>  
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Mobile Number</label>
                                      <input type="tel" name="mobile_number" class="form-control" required>
                                    </div>
                                  </div>  
                                   <!--  <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Gender</label>
                                      <select name="gender" class="form-control" required>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                      </select>
                                    </div>
                                  </div>   -->
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Alternate Number</label>
                                      <input type="tel" name="second_number" class="form-control" required>
                                    </div>
                                  </div>
                                  
                                   
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Email</label>
                                      <input type="email" name="email" class="form-control" required>
                                    </div>
                                  </div>
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">City</label>
                                      <input type="text" name="city" class="form-control" required>
                                    </div>
                                  </div>
                                    
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Highest qualification</label>
                                      <input type="text" name="highest_qualification" class="form-control" required>
                                    </div>
                                  </div>
                                    
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Total experience</label>
                                      <input type="text" name="total_experience" class="form-control" required>
                                    </div>
                                    </div>
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Previous organization</label>
                                      <input type="text" name="previous_organization" class="form-control" required>
                                    </div>
                                    </div>
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Experience in previous org</label>
                                      <input type="text" name="experience_in_previous_org" class="form-control" required>
                                    </div>
                                    </div>
                                    
                                     <div class="col-md-4">
                                      <div class="form-group">
                                <label>CV received</label>
                                <input type="text" name="cv_received" class="form-control">
                            </div>
                             </div>
                              <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Salary expectations</label>
                                      <input type="text" name="salary_expectations" class="form-control" required>
                                    </div>
                                    </div>
                                      <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Last salary drawn</label>
                                      <input type="text" name="last_salary_drawn" class="form-control" required>
                                    </div>
                                    </div>
                                      <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">IQ rating</label>
                                      <input type="text" name=" iq_rating" class="form-control" required>
                                    </div>
                                    </div>
                                      <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Communication Rating</label>
                                      <input type="text" name="communication_rating" class="form-control" required>
                                    </div>
                                    </div>
                                      <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Confidence rating</label>
                                      <input type="text" name="confidence_rating" class="form-control" required>
                                    </div>
                                    </div>
                                      <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Overall rating</label>
                                      <input type="text" name="overall_rating" class="form-control" required>
                                    </div>
                                    </div>
                                      <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Age</label>
                                      <input type="text" name="age" class="form-control" required>
                                    </div>
                                    </div>
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Marital Status</label>
                                      <select name="marital_status" class="form-control" required>
                                        <option value="Single">Single</option>
                                        <option value="Married">Married</option>
                                      </select>
                                    </div>
                                    </div>
                                   
                                  <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Remarks</label>
                                      <input type="text" name="remarks" class="form-control" required>
                                    </div>
                                    </div>
                                   
                                  <div class="col-md-4">
                               <div class="form-group">
                                <label>Resume Attach</label>
                                <input type="file" name="file" class="form-control">
                            </div>
                            </div>
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Second round on</label>
                                      <input type="date" name="second_round_on" class="form-control" >
                                    </div>
                                    </div>
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Selected</label>
                                      <input type="text" name="selected" class="form-control">
                                    </div>
                                    </div>

                                    
                                    
                                   <div class="col-md-4">
                                    <div class="form-group">
                                <label>Salary offered</label>
                                <input type="text" name="salary_offered" class="form-control">
                            </div>
                            </div>
                         
                                    <div class="col-md-4">                                
                                    <div class="form-group">
                                      <label class="form-label">Working hours</label>
                                      <input type="text" name="working_hours" class="form-control" required>
                                    </div>
                                  </div>  
                                   
                                  </div>
                              </div>  
                                  <div class="box-footer">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                  </div>
                              
                            </form>
                        </div>  
                    </div>          
                </div>
            <!-- </div> -->
            <div class="col-md-4">                                
                                    <div class="form-group">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .hrfrm-onbord-title{
          text-align: center;
          background: #e7e7e7;
          margin: auto;
          border-radius: 5px;
          padding: 3px;
        }
    </style>
</div>
<script type="text/javascript">
   
    function toggleLastWorking(status) {
        document.getElementById('lastWorkingDiv').style.display = (status === 'inactive') ? 'block' : 'none';
    }
</script>
<script>
function toggleRelationFields(value) {
    if(value === 'father') {
        document.getElementById('fatherFields').style.display = 'block';
        document.getElementById('spouseFields').style.display = 'none';
    } else {
        document.getElementById('fatherFields').style.display = 'none';
        document.getElementById('spouseFields').style.display = 'block';
    }
}
</script>
<script>
function togglePoliceVerification() {
    var check = document.getElementById('policeVerificationCheck');
    var field = document.getElementById('policeVerificationField');
    field.style.display = check.checked ? 'block' : 'none';
}
</script>
