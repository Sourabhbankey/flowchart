<?php
$interviewId = $interviewInfo->interviewId;
$candidate_name = $interviewInfo->candidate_name;
$date_of_interview = $interviewInfo->date_of_interview;
$mode_of_interview = $interviewInfo->mode_of_interview;
$mobile_number = $interviewInfo->mobile_number ?? '';
$second_number = $interviewInfo->second_number;
$email = $interviewInfo->email;
$city = $interviewInfo->city;
$highest_qualification = $interviewInfo->highest_qualification;
$total_experience = $interviewInfo->total_experience ?? '';
$previous_organization = $interviewInfo->previous_organization ?? '';
$experience_in_previous_org = $interviewInfo->experience_in_previous_org ?? '';
$cv_received = $interviewInfo->cv_received ?? '';
$salary_expectations = $interviewInfo->salary_expectations ?? '';
$last_salary_drawn = $interviewInfo->last_salary_drawn ?? '';
$iq_rating = $interviewInfo->iq_rating;
$communication_rating = $interviewInfo->communication_rating ?? '';
$confidence_rating = $interviewInfo->confidence_rating ?? '';
$overall_rating = $interviewInfo->overall_rating ?? '';
$age = $interviewInfo->age ?? '';
$marital_status = $interviewInfo->marital_status ?? '';
$remarks = $interviewInfo->remarks ?? '';
$second_round_on = $interviewInfo->second_round_on ?? '';
$selected = $interviewInfo->selected ?? '';
$salary_offered = $interviewInfo->salary_offered ?? '';
$resumeS3attachment = $interviewInfo->resumeS3attachment ?? '';
$working_hours = $interviewInfo->working_hours;

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Interview  Management
        <small>Add / Edit  </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>interview/editinterview" method="post" id="editStaff" role="form" enctype="multipart/form-data">
                      
                    <input type="hidden" name="interviewId" value="<?php echo $interviewId; ?>">

                    <h2 class="mb-4">Personal Information</h2>
                    <div class="row g-3">
                      <div class="col-md-4">
                        <label class="form-label">Date Of Interview</label>
                        <input type="text" name="date_of_interview" class="form-control" value="<?php echo $date_of_interview; ?>" >
                      </div>
                       <div class="col-md-4">
                        <label class="form-label">Mode of interview</label>
                      <select name="mode_of_interview" class="form-select" required>
                          <option value="Online" <?php echo ($mode_of_interview == 'Online') ? 'selected' : ''; ?>>Online</option>
                          <option value="Offline" <?php echo ($mode_of_interview == 'Offline') ? 'selected' : ''; ?>>Offline</option>
                        </select>
                        
                        </div>
                      <div class="col-md-4">
                        <label class="form-label">Candidate Name</label>
                        <input type="text" name="candidate_name" class="form-control" value="<?php echo $candidate_name; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Mobile Number</label>
                        <input type="tel" name="mobile_number" class="form-control" value="<?php echo $mobile_number; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Alternate Number</label>
                        <input type="tel" name="second_number" class="form-control" value="<?php echo $second_number; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Email</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $email; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">City</label>
                        <input type="text" name="city" class="form-control" value="<?php echo $city; ?>" >
                      </div>
                       <div class="col-md-4">
                        <label class="form-label">Highest qualification</label>
                        <input type="text" name="highest_qualification" class="form-control" value="<?php echo $highest_qualification; ?>" >
                      </div>

                       <div class="col-md-4">
                        <label class="form-label">Total experience</label>
                        <input type="text" name="total_experience" class="form-control" value="<?php echo $total_experience; ?>" >
                      </div>

                      <div class="col-md-4">
                        <label class="form-label">Previous organization</label>
                        <input type="text" name="previous_organization" class="form-control" value="<?php echo $previous_organization; ?>" >
                      </div>

                      <div class="col-md-4">
                        <label class="form-label">Experience in previous org</label>
                        <input type="text" name="experience_in_previous_org" class="form-control" value="<?php echo $experience_in_previous_org; ?>" >
                      </div>

                      <div class="col-md-4">
                        <label class="form-label">CV received</label>
                        <input type="text" name="cv_received" class="form-control" value="<?php echo $cv_received; ?>" >
                      </div>

                      <div class="col-md-4">
                        <label class="form-label">Salary expectations</label>
                        <input type="text" name="salary_expectations" class="form-control" value="<?php echo $salary_expectations; ?>" >
                      </div>

                      <div class="col-md-4">
                        <label class="form-label">Last salary drawn</label>
                        <input type="text" name="last_salary_drawn" class="form-control" value="<?php echo $last_salary_drawn; ?>" >
                      </div>

                    <div class="col-md-4">
                        <label class="form-label">IQ rating</label>
                        <input type="text" name="iq_rating" class="form-control" value="<?php echo $iq_rating; ?>" >
                      </div>

                  <div class="col-md-4">
                        <label class="form-label">Communication rating</label>
                        <input type="text" name="communication_rating" class="form-control" value="<?php echo $communication_rating; ?>" >
                      </div>

                      <div class="col-md-4">
                        <label class="form-label">Confidence rating</label>
                        <input type="text" name="confidence_rating" class="form-control" value="<?php echo $confidence_rating; ?>" >
                      </div>

                   <div class="col-md-4">
                        <label class="form-label">Overall rating</label>
                        <input type="text" name="overall_rating" class="form-control" value="<?php echo $overall_rating; ?>" >
                      </div> 
                       <div class="col-md-4">
                        <label class="form-label">Age</label>
                        <input type="text" name="age" class="form-control" value="<?php echo $age; ?>" >
                      </div>



                      <div class="col-md-4">
                        <label class="form-label">Marital Status</label>
                        <select name="marital_status" class="form-select" required>
                          <option value="Single" <?php echo ($marital_status == 'Single') ? 'selected' : ''; ?>>Single</option>
                          <option value="Married" <?php echo ($marital_status == 'Married') ? 'selected' : ''; ?>>Married</option>
                        </select>
                      </div>
                   
                       <div class="col-md-4">
                        <label class="form-label">Remarks</label>
                        <input type="text" name="remarks" class="form-control" value="<?php echo $remarks; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Second round on</label>
                        <input type="date" name="second_round_on" class="form-control" value="<?php echo $second_round_on; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Selected</label>
                        <input type="text" name="selected" class="form-control" value="<?php echo $selected; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Salary offered</label>
                        <input type="text" name="salary_offered" class="form-control" value="<?php echo $salary_offered; ?>" >
                      </div>
                      <div class="col-md-4">
                        <label class="form-label">Working hours</label>
                        <input type="text" name="working_hours" class="form-control" value="<?php echo $working_hours; ?>" >
                      </div>

 
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
         </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>