<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Admission  Details Management
        <small>Add / Edit Admission</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Admission  Details Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" action="<?php echo base_url() ?>admissiondetails/addNewAdmissiondetails" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                   <div class="col-md-4">
                                    <?php  if($role==25) { ?>
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"  required onchange="fetchAssignedFranchise(this.value)">
                                            <option value="">Select Franchise</option>
                                          
                                                    <option value="<?php echo $this->session->userdata('franchiseNumber'); ?>">
                                                    <?php echo $this->session->userdata('franchiseNumber'); ?>
                                                </option>
                                                    <?php
                                             
                                            ?>
                                        </select>
                                    </div>
                                <?php } 
                                else { ?>
                            <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                               <?php  } ?>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                        <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                                            <option value="0">Select Role</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="name">Student Name<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('name'); ?>" id="name" name="name" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="enrollNum">Enrollment Nummber<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('enrollNum'); ?>" id="enrollNum" name="enrollNum" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="class">Class <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo set_value('class'); ?>" id="class" name="class" maxlength="256"> -->
                                        <select class="form-control required" id="class" name="class" required >
                                            <option value="">Select Class </option>
                                            <option value="Toddlers">Toddlers</option>
                                            <option value="Play Group">Play Group</option> 
                                            <option value="Nursery">Nursery</option>
                                            <option value="KG-1">KG-1</option>
                                            <option value="KG-2">KG-2</option> 
                                            <option value="1st">1st</option> 
                                            <option value="2nd">2nd</option>
                                            <option value="3rd">3rd</option>
                                            <option value="4th">4th</option>
                                            <option value="5th">5th</option>
                                            <option value="Day Care">Day Care</option>        
                                        </select>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfAdmission">Date Of Admission <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('dateOfAdmission'); ?>" id="dateOfAdmission" name="dateOfAdmission" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="program">Program <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="program" name="program" required >
                                            <option value="">Select Program Type</option>
                                            <option value="Regular">Regular</option> 
                                            <option value="Settler">Settler</option>
                                            <option value="Summer Camp">Summer Camp</option>
                                            <option value="Day Care">Day Care</option>        
                                        </select>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="birthday">Date Of Birth <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo set_value('birthday'); ?>" id="birthday" name="birthday" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="age">Age <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('age'); ?>" id="age" name="age" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-8">                                
                                    <div class="form-group">
                                        <label for="gender">Gender <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="gender" name="gender" required >
                                            <option value="">Select Gender Type</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>        
                                        </select>
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fathername">Father's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('fathername'); ?>" id="fathername" name="fathername" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fatheremail">Father's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo set_value('fatheremail'); ?>" id="fatheremail" name="fatheremail" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="fatherMobile_no">Father's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('fatherMobile_no'); ?>" id="fatherMobile_no" name="fatherMobile_no" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="mothername">Mother's Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('mothername'); ?>" id="mothername" name="mothername" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="motheremail">Mother's E-mail <span class="re-mend-field">*</span></label>
                                        <input required type="email" class="form-control required" value="<?php echo set_value('motheremail'); ?>" id="motheremail" name="motheremail" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="motherMobile_no">Mother's Mobile No. <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('motherMobile_no'); ?>" id="motherMobile_no" name="motherMobile_no" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="bloodGroup">Blood Group <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('bloodGroup'); ?>" id="bloodGroup" name="bloodGroup" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="motherTongue">Mother Tongue <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('motherTongue'); ?>" id="motherTongue" name="motherTongue" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="religion">Religion <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('religion'); ?>" id="religion" name="religion" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="caste">Caste <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('caste'); ?>" id="caste" name="caste" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('city'); ?>" id="city" name="city" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="state">State <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('state'); ?>" id="state" name="state" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label for="address">Address<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('address'); ?>" id="address" name="address" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="totalFee">Total Fee <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value('totalFee'); ?>" id="totalFee" name="totalFee" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="previousSchool">Previous School <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="previousSchool" name="previousSchool"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="remark">Remark <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="remark" name="remark"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber) {
        $.ajax({
            url: '<?php echo base_url("admissiondetails/fetchAssignedUsers"); ?>', // Update to match your controller and method
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            success: function(response) {
                $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
                  $('#branchFranchiseAssigned option[value="0"]').remove();
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", status, error);
                console.error("Response Text: ", xhr.responseText);
                alert('Error fetching data');
            }
        });
    } else {
       $('#branchFranchiseAssigned').html('<option value="">No Growth Manager Available</option>');
    }
}
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>