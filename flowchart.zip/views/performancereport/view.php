<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-bar-chart" aria-hidden="true"></i> Performance Report View
        </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <label for="monthFilter">Select Month</label>
                    <form action="<?php echo base_url() ?>performancereport/monthlyPerformance" method="POST" id="searchList">
                        <div class="input-group">
                            <select class="form-control input-sm" id="monthFilter" name="monthFilter">
                                <option value="">All Months</option>
                                <?php 
                                $months = [
                                    "January", "February", "March", "April", "May", "June", 
                                    "July", "August", "September", "October", "November", "December"
                                ];
                                foreach ($months as $month) { 
                                    $selected = (!empty($monthFilter) && $monthFilter == $month) ? 'selected' : '';
                                ?>
                                    <option value="<?= $month ?>" <?= $selected ?>><?= $month ?></option>
                                <?php } ?>
                            </select>
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- <div class="row">
            <div class="col-md-12">
                <div class="alert alert-info">
                    <strong>Average Performance Count:</strong> <?= number_format($averagePerformance, 2) ?>
                </div>
            </div>
        </div> -->
        
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding">
                        <table id="performanceTable" class="display responsive nowrap" style="width:100%">
    <thead>
        <tr>
            <th>Sr. No.</th>
            <th>Name</th>
            <th>Month</th>
            <th>Total Performance Count</th>
            <th>Average Performance Count</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if (!empty($records)) {
            $srNo = 1;
            foreach ($records as $record) {
        ?>
            <tr>
                <td><?= $srNo++ ?></td>
                <td><?= $record->performerName ?></td>
                <td><?= $record->performannceMonths ?></td>
                <td><?= number_format($record->totalPerformance, 2) ?></td>
                <td><?= number_format($record->averagePerformance, 2) ?></td>
            </tr>
        <?php
            }
        } else {
        ?>
            <tr>
                <td colspan="5" class="text-center">No records found.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#performanceTable').DataTable();
    });
</script>

<!-- DataTables CSS & JS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
