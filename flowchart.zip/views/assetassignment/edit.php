<?php 
$assetsId      = $assetInfo->assetsId;
$userID        = $assetInfo->userID;

$BrandName    = $assetInfo->BrandName;
$Status       = $assetInfo->Status;
$assetsTitle1  = $assetInfo->assetsTitle1;
$assignDate   = $assetInfo->assignDate;

$BrandName2    = $assetInfo->BrandName2;
$Status2       = $assetInfo->Status2;
$assetsTitle2  = $assetInfo->assetsTitle2;
$assignDate2   = $assetInfo->assignDate2;

$BrandName3    = $assetInfo->BrandName3;
$Status3       = $assetInfo->Status3;
$assetsTitle3  = $assetInfo->assetsTitle3;
$assignDate3   = $assetInfo->assignDate3;

$BrandName4    = $assetInfo->BrandName4;
$Status4       = $assetInfo->Status4;
$assetsTitle4  = $assetInfo->assetsTitle4;
$assignDate4   = $assetInfo->assignDate4;

$BrandName5    = $assetInfo->BrandName5;
$Status5       = $assetInfo->Status5;
$assetsTitle5  = $assetInfo->assetsTitle5;
$assignDate5   = $assetInfo->assignDate5;

$BrandName6    = $assetInfo->BrandName6;
$Status6       = $assetInfo->Status6;
$assetsTitle6  = $assetInfo->assetsTitle6;
$assignDate6   = $assetInfo->assignDate6;

$BrandName7    = $assetInfo->BrandName7;
$Status7       = $assetInfo->Status7;
$assetsTitle7  = $assetInfo->assetsTitle7;
$assignDate7   = $assetInfo->assignDate7;

$BrandName8    = $assetInfo->BrandName8;
$Status8       = $assetInfo->Status8;
$assetsTitle8  = $assetInfo->assetsTitle8;
$assignDate8   = $assetInfo->assignDate8;

$BrandName9    = $assetInfo->BrandName9;
$Status9       = $assetInfo->Status9;
$assetsTitle9  = $assetInfo->assetsTitle9;
$assignDate9   = $assetInfo->assignDate9;

$description   = $assetInfo->description;

$selectuserID  = (int) $assetInfo->userID;
?>



<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Asset Assignment
        <small>Add / Edit Asset</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Asset Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>assetassignment/editassetassignment
" enctype="multipart/form-data" method="post" id="editassetassignment" role="form">
                        <div class="box-body">
                        <div class="row">
                        <!-- STart Ac-Section -->
                        <input type="hidden" name="assetsId" value="<?= isset($assetInfo->assetsId) ? $assetInfo->assetsId : '' ?>">
                          <div class="col-md-6">                                
    <div class="form-group">
        <label for="userID">User Name</label>
         <select class="form-control required disaction1" id="userID" name="userID">
                                            <option value="0">Select User</option>
                                            <?php if (!empty($users)) {
                                                foreach ($users as $rl) {
                                                    $userText = $rl->name; ?>
                                                    <option value="<?php echo $rl->userId; ?>" <?php if (
                                                    $rl->userId == $userID
                                                ) {
                                                    echo "selected=selected";
                                                } ?>><?= $userText ?></option>
                                                  <?php
                                                  }
                                                  } ?>
                                                 </select>

                                            </div>
                                        </div>

                              <div class="col-md-6">                                
    <div class="form-group">
        <label for="modeOforder">assetsTitle1<span class="re-mend-field">*</span></label>
        <select class="form-control required" id="assetsTitle1" name="assetsTitle1" >
            <option value="">Select Type</option>
            <option value="Mobile" <?php if ($assetsTitle1 == 'Mobile') echo 'selected'; ?>>Mobile</option>
            <option value="Sim card" <?php if ($assetsTitle1 == 'Sim card') echo 'selected'; ?>>Sim card</option>
            <option value="Laptop" <?php if ($assetsTitle1 == 'Laptop') echo 'selected'; ?>>Laptop</option>
            <option value="Mouse" <?php if ($assetsTitle1 == 'Mouse') echo 'selected'; ?>>Mouse</option>
            <option value="Bag" <?php if ($assetsTitle1 == 'Bag') echo 'selected'; ?>>Bag</option>
            <option value="ID" <?php if ($assetsTitle1 == 'ID') echo 'selected'; ?>>ID</option>
            <option value="T-Shirt" <?php if ($assetsTitle1 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
             <option value="Hoodie" <?php if ($assetsTitle1 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
        </select>
    </div>
</div>
                                <?php
// Example: get value from post or set default
$Status = isset($_POST['Status']) ? $_POST['Status'] : (isset($Status) ? $Status : '');
?>

<div class="col-md-4">                                
    <div class="form-group">
        <label for="Status">Status</label>
        <select class="form-control required" name="Status" id="Status">
            <option value="">Select Status</option>
            <option value="Issued" <?php echo (trim($Status) == 'Issued') ? 'selected' : ''; ?>>Issued</option>
            <option value="Returned" <?php echo (trim($Status) == 'Returned') ? 'selected' : ''; ?>>Returned</option>
        </select>
    </div>
</div>

                                    
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName; ?>" id="BrandName" name="BrandName" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate <span class="re-mend-field">*</span></label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate; ?>" id="assignDate" name="assignDate" maxlength="256" />
                                    </div>
                                </div>
                               
                              
 
                              <div class="col-md-3">                                
    <div class="form-group">
        <label for="modeOforder">assetsTitle2</label>
        <select class="form-control required" id="assetsTitle2" name="assetsTitle2">
            <option value="">Select Type</option>
            <option value="Mobile" <?php if ($assetsTitle2 == 'Mobile') echo 'selected'; ?>>Mobile</option>
            <option value="Sim card" <?php if ($assetsTitle2 == 'Sim card') echo 'selected'; ?>>Sim card</option>
            <option value="Laptop" <?php if ($assetsTitle2 == 'Laptop') echo 'selected'; ?>>Laptop</option>
            <option value="Mouse" <?php if ($assetsTitle2 == 'Mouse') echo 'selected'; ?>>Mouse</option>
            <option value="Bag" <?php if ($assetsTitle2 == 'Bag') echo 'selected'; ?>>Bag</option>
            <option value="ID" <?php if ($assetsTitle2 == 'ID') echo 'selected'; ?>>ID</option>
            <option value="T-Shirt" <?php if ($assetsTitle2 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
             <option value="Hoodie" <?php if ($assetsTitle2 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
        </select>
    </div>
</div>
                                <?php
// Example: get value from post or set default
$Status2 = isset($_POST['Status2']) ? $_POST['Status2'] : (isset($Status2) ? $Status2 : '');
?>

<div class="col-md-3">                                
    <div class="form-group">
        <label for="Status">Status</label>
        <select class="form-control required" name="Status2" id="Status2">
            <option value="">Select Status</option>
            <option value="Issued" <?php echo (trim($Status2) == 'Issued') ? 'selected' : ''; ?>>Issued</option>
            <option value="Returned" <?php echo (trim($Status2) == 'Returned') ? 'selected' : ''; ?>>Returned</option>
        </select>
    </div>
</div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName2; ?>" id="BrandName2" name="BrandName2" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate2; ?>" id="assignDate2" name="assignDate2" maxlength="256" />
                                    </div>
                                </div>
                               
                              
 
                              <div class="col-md-3">                                
<div class="form-group">
        <label for="modeOforder">assetsTitle3</label>
        <select class="form-control required" id="assetsTitle3" name="assetsTitle3">
            <option value="">Select Type</option>
            <option value="Mobile" <?php if ($assetsTitle3 == 'Mobile') echo 'selected'; ?>>Mobile</option>
            <option value="Sim card" <?php if ($assetsTitle3 == 'Sim card') echo 'selected'; ?>>Sim card</option>
            <option value="Laptop" <?php if ($assetsTitle3 == 'Laptop') echo 'selected'; ?>>Laptop</option>
            <option value="Mouse" <?php if ($assetsTitle3 == 'Mouse') echo 'selected'; ?>>Mouse</option>
            <option value="Bag" <?php if ($assetsTitle3 == 'Bag') echo 'selected'; ?>>Bag</option>
            <option value="ID" <?php if ($assetsTitle3 == 'ID') echo 'selected'; ?>>ID</option>
            <option value="T-Shirt" <?php if ($assetsTitle3 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
             <option value="Hoodie" <?php if ($assetsTitle3 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
        </select>
    </div>
</div>
                            <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status3" name="Status3">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status3 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status3 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>


                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName3 </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName3; ?>" id="BrandName3" name="BrandName3" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate3 </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate3; ?>" id="assignDate3" name="assignDate3" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="modeOforder">assetsTitle4</label>
                                        <select class="form-control required" id="assetsTitle4" name="assetsTitle4">
                                            <option value="">Select Type</option>
                                            <option value="Mobile" <?php if ($assetsTitle4 == 'Mobile') echo 'selected'; ?>>Mobile</option>
                                            <option value="Sim card" <?php if ($assetsTitle4 == 'Sim card') echo 'selected'; ?>>Sim card</option>
                                            <option value="Laptop" <?php if ($assetsTitle4 == 'Laptop') echo 'selected'; ?>>Laptop</option>
                                            <option value="Mouse" <?php if ($assetsTitle4 == 'Mouse') echo 'selected'; ?>>Mouse</option>
                                            <option value="Bag" <?php if ($assetsTitle4 == 'Bag') echo 'selected'; ?>>Bag</option>
                                            <option value="ID" <?php if ($assetsTitle4 == 'ID') echo 'selected'; ?>>ID</option>
                                            <option value="T-Shirt" <?php if ($assetsTitle4 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
                                             <option value="Hoodie" <?php if ($assetsTitle4 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status4" name="Status4">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status4 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status4 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>
 
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName4 </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName4; ?>" id="BrandName4" name="BrandName4" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate4 </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate4; ?>" id="assignDate4" name="assignDate4" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="modeOforder">assetsTitle5</label>
                                        <select class="form-control required" id="assetsTitle5" name="assetsTitle5" >
                                            <option value="">Select Type</option>
                                            <option value="Mobile" <?php if ($assetsTitle5 == 'Mobile') echo 'selected'; ?>>Mobile</option>
                                            <option value="Sim card" <?php if ($assetsTitle5 == 'Sim card') echo 'selected'; ?>>Sim card</option>
                                            <option value="Laptop" <?php if ($assetsTitle5 == 'Laptop') echo 'selected'; ?>>Laptop</option>
                                            <option value="Mouse" <?php if ($assetsTitle5 == 'Mouse') echo 'selected'; ?>>Mouse</option>
                                            <option value="Bag" <?php if ($assetsTitle5 == 'Bag') echo 'selected'; ?>>Bag</option>
                                            <option value="ID" <?php if ($assetsTitle5 == 'ID') echo 'selected'; ?>>ID</option>
                                            <option value="T-Shirt" <?php if ($assetsTitle5 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
                                             <option value="Hoodie" <?php if ($assetsTitle5 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                   <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status5" name="Status5">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status5 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status5 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName5; ?>" id="BrandName5" name="BrandName5" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate5 </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate5; ?>" id="assignDate5" name="assignDate5" maxlength="256" />
                                    </div>
                                </div>
                            <div class="col-md-3">                                
                                <div class="form-group">
                                        <label for="modeOforder">assetsTitle6</label>
                                        <select class="form-control required" id="assetsTitle6" name="assetsTitle6" >
                                            <option value="">Select Type</option>
                                            <option value="Mobile" <?php if ($assetsTitle6 == 'Mobile') echo 'selected'; ?>>Mobile</option>
                                            <option value="Sim card" <?php if ($assetsTitle6 == 'Sim card') echo 'selected'; ?>>Sim card</option>
                                            <option value="Laptop" <?php if ($assetsTitle6 == 'Laptop') echo 'selected'; ?>>Laptop</option>
                                            <option value="Mouse" <?php if ($assetsTitle6 == 'Mouse') echo 'selected'; ?>>Mouse</option>
                                            <option value="Bag" <?php if ($assetsTitle6 == 'Bag') echo 'selected'; ?>>Bag</option>
                                            <option value="ID" <?php if ($assetsTitle6 == 'ID') echo 'selected'; ?>>ID</option>
                                            <option value="T-Shirt" <?php if ($assetsTitle6 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
                                             <option value="Hoodie" <?php if ($assetsTitle6 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
                                        </select>
                                    </div>
                            </div>
                                    <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status6" name="Status6">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status6 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status6 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName6 </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName6; ?>" id="BrandName6" name="BrandName6" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate6 </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate6; ?>" id="assignDate6" name="assignDate6" maxlength="256" />
                                    </div>
                                </div>
                              <div class="col-md-3">                                
                                <div class="form-group">
                                        <label for="modeOforder">assetsTitle7</label>
                                        <select class="form-control required" id="assetsTitle7" name="assetsTitle7" >
                                            <option value="">Select Type</option>
                                            <option value="Mobile" <?php if ($assetsTitle7 == 'Mobile') echo 'selected'; ?>>Mobile</option>
                                            <option value="Sim card" <?php if ($assetsTitle7 == 'Sim card') echo 'selected'; ?>>Sim card</option>
                                            <option value="Laptop" <?php if ($assetsTitle7 == 'Laptop') echo 'selected'; ?>>Laptop</option>
                                            <option value="Mouse" <?php if ($assetsTitle7 == 'Mouse') echo 'selected'; ?>>Mouse</option>
                                            <option value="Bag" <?php if ($assetsTitle7 == 'Bag') echo 'selected'; ?>>Bag</option>
                                            <option value="ID" <?php if ($assetsTitle7 == 'ID') echo 'selected'; ?>>ID</option>
                                            <option value="T-Shirt" <?php if ($assetsTitle7 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
                                             <option value="Hoodie" <?php if ($assetsTitle7 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status7" name="Status7">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status7 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status7 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName7; ?>" id="BrandName7" name="BrandName7" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate7 </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate7; ?>" id="assignDate7" name="assignDate7" maxlength="256" />
                                    </div>
                                </div>
                               
                              <div class="col-md-3">                                
                                <div class="form-group">
                                        <label for="modeOforder">assetsTitle8</label>
                                        <select class="form-control required" id="assetsTitle8" name="assetsTitle8" >
                                            <option value="">Select Type</option>
                                            <option value="Mobile" <?php if ($assetsTitle8 == 'Mobile') echo 'selected'; ?>>Mobile</option>
                                            <option value="Sim card" <?php if ($assetsTitle8 == 'Sim card') echo 'selected'; ?>>Sim card</option>
                                            <option value="Laptop" <?php if ($assetsTitle8 == 'Laptop') echo 'selected'; ?>>Laptop</option>
                                            <option value="Mouse" <?php if ($assetsTitle8 == 'Mouse') echo 'selected'; ?>>Mouse</option>
                                            <option value="Bag" <?php if ($assetsTitle8 == 'Bag') echo 'selected'; ?>>Bag</option>
                                            <option value="ID" <?php if ($assetsTitle8 == 'ID') echo 'selected'; ?>>ID</option>
                                            <option value="T-Shirt" <?php if ($assetsTitle8 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
                                             <option value="Hoodie" <?php if ($assetsTitle8 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                   <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status8" name="Status8">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status8 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status8 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName</label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName8; ?>" id="BrandName8" name="BrandName8" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate8; ?>" id="assignDate8" name="assignDate8" maxlength="256" />
                                    </div>
                                </div>

                            <div class="col-md-3"> 
                                <div class="form-group">
                                        <label for="modeOforder">assetsTitle9</label>
                                        <select class="form-control required" id="assetsTitle9" name="assetsTitle9" >
                                            <option value="">Select Type</option>
                                            <option value="Mobile" <?php if ($assetsTitle9 == 'Mobile') echo 'selected'; ?>>Mobile</option>
                                            <option value="Sim card" <?php if ($assetsTitle9 == 'Sim card') echo 'selected'; ?>>Sim card</option>
                                            <option value="Laptop" <?php if ($assetsTitle9 == 'Laptop') echo 'selected'; ?>>Laptop</option>
                                            <option value="Mouse" <?php if ($assetsTitle9 == 'Mouse') echo 'selected'; ?>>Mouse</option>
                                            <option value="Bag" <?php if ($assetsTitle9 == 'Bag') echo 'selected'; ?>>Bag</option>
                                            <option value="ID" <?php if ($assetsTitle9 == 'ID') echo 'selected'; ?>>ID</option>
                                            <option value="T-Shirt" <?php if ($assetsTitle9 == 'T-Shirt') echo 'selected'; ?>>T-Shirt</option>
                                             <option value="Hoodie" <?php if ($assetsTitle9 == 'Hoodie') echo 'selected'; ?>>Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="taskTitle">Status</label>
                                        <select class="form-control required" id="Status9" name="Status9">
                                <option  class="clsopen" value="<?= "Issued" ?>" <?php if (
                                    $Status9 == "Issued") { echo "selected=selected";
                                } ?>>Issued</option>
                                <option class="clsclose" value="<?= "Returned" ?>" <?php if ($Status9 == "Returned") {
                                    echo "selected=selected";
                                } ?>>Returned</option>
                                 </select>
                                    </div>

                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName">BrandName </label>
                                        <input type="text" class="form-control required clsp" value="<?php echo $BrandName9; ?>" id="BrandName9" name="BrandName9" maxlength="256" />
                                    </div>
                                </div>
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate">assignDate </label>
                                        <input type="date" class="form-control required clsp" value="<?php echo $assignDate9; ?>" id="assignDate9" name="assignDate9" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea required class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>




                                   

                        <!-- End Ac-Section -->      
                      
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field{color: red;}
        /.clsp{pointer-events:none;}/
    </style>
    <script>
document.getElementById('modeOforder').addEventListener('change', function() {
    var othersField = document.getElementById('othersField');
    var otherModeInput = document.getElementById('otherMode');
    if (this.value === 'Others') {
        othersField.style.display = 'block';
        otherModeInput.setAttribute('required', 'required');
    } else {
        othersField.style.display = 'none';
        otherModeInput.removeAttribute('required');
    }
});
</script>
</div>