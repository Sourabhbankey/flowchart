<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-cube" aria-hidden="true"></i> Asset Assignment
            <small>Add / Edit</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Asset Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addAssetForm" action="<?php echo base_url() ?>assetassignment/addNewAssetassignment" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">User Name</label>
                                        <select class="form-control required" id="userID" name="userID">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                        ?>
                                                            <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('userID')) {echo "selected=selected";} ?>><?= $userText ?></option> 
                                                        <?php   
                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                </div>

                                <!-- <div class="col-md-6">                                
                                    <div class="form-group">
                                       <div class="form-group">
                                        <label for="userID">User id</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('userID'); ?>" id="userID" name="userID" maxlength="255" required />
                                    </div>
                                    </div>
                                </div> -->
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="assetsTitle1">Asset Type1</label>
                                        <select class="form-control required" name="assetsTitle1" id="assetsTitle1" required>
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                             <option value="other">Other</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="BrandName">Brand Name</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('BrandName'); ?>" id="BrandName" name="BrandName" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="Status">Status</label>
                                        <select class="form-control required" name="Status" id="Status">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                 <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="assignDate">Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('assignDate'); ?>" id="assignDate" name="assignDate"/>
                                    </div>
                                </div>

<!-- second tittle -->
  <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle2">Asset Type2</label>
                                        <select class="form-control" name="assetsTitle2" id="assetsTitle2">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName2">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName2'); ?>" id="BrandName2" name="BrandName2" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status2">Status</label>
                                        <select class="form-control" name="Status2" id="Status2">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate2">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate2'); ?>" id="assignDate2" name="assignDate2"/>
                                    </div>
                                </div>

                                <!-- third tittle -->
                                 <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle3">Asset Type3</label>
                                        <select class="form-control" name="assetsTitle3" id="assetsTitle3">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName3">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName3'); ?>" id="BrandName3" name="BrandName3" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status3">Status</label>
                                        <select class="form-control" name="Status3" id="Status3">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate3">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate3'); ?>" id="assignDate3" name="assignDate3"/>
                                    </div>
                                </div>
<!-- fouth tittle -->
     <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle4">Asset Type4</label>
                                        <select class="form-control" name="assetsTitle4" id="assetsTitle4">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName4">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName4'); ?>" id="BrandName4" name="BrandName4" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status4">Status</label>
                                        <select class="form-control" name="Status4" id="Status4">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate4">Issued Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate4'); ?>" id="assignDate4" name="assignDate4"/>
                                    </div>
                                </div>

<!-- five tittle -->
                                    <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle5">Asset Type5</label>
                                        <select class="form-control" name="assetsTitle5" id="assetsTitle5">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName5">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName5'); ?>" id="BrandName5" name="BrandName5" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status5">Status</label>
                                        <select class="form-control" name="Status5" id="Status5">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate5">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate5'); ?>" id="assignDate5" name="assignDate5"/>
                                    </div>
                                </div>
<!-- six tittle -->

                                    <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle6">Asset Type6</label>
                                        <select class="form-control" name="assetsTitle6" id="assetsTitle6">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName6">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName6'); ?>" id="BrandName6" name="BrandName6" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status6">Status</label>
                                        <select class="form-control" name="Status6" id="Status6">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate6">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate6'); ?>" id="assignDate6" name="assignDate6"/>
                                    </div>
                                </div>
<!-- seven tittle -->

                                    <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle7">Asset Type7</label>
                                        <select class="form-control" name="assetsTitle7" id="assetsTitle7">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName7">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName7'); ?>" id="BrandName7" name="BrandName7" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status7">Status</label>
                                        <select class="form-control" name="Status7" id="Status7">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate7">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate7'); ?>" id="assignDate7" name="assignDate7"/>
                                    </div>
                                </div>

<!-- eight tittle -->
                                    <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle8">Asset Type8</label>
                                        <select class="form-control" name="assetsTitle8" id="assetsTitle8">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName8">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName8'); ?>" id="BrandName8" name="BrandName8" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status8">Status</label>
                                        <select class="form-control" name="Status8" id="Status8">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate8">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate8'); ?>" id="assignDate8" name="assignDate8"/>
                                    </div>
                                </div>

<!-- nine tittle -->
                                    <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assetsTitle9">Asset Type9</label>
                                        <select class="form-control" name="assetsTitle9" id="assetsTitle9">
                                            <option value="">Select Asset</option>
                                            <option value="Mobile">Mobile</option>
                                            <option value="Sim card">Sim card</option>
                                            <option value="Laptop">Laptop</option>
                                            <option value="Mouse">Mouse</option>
                                            <option value="Bag">Bag</option>
                                            <option value="ID">ID</option>
                                            <option value="T-Shirt">T-Shirt</option>
                                            <option value="Hoodie">Hoodie</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="BrandName9">Brand Name</label>
                                        <input type="text" class="form-control" value="<?php echo set_value('BrandName9'); ?>" id="BrandName9" name="BrandName9" maxlength="255"/>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="Status9">Status</label>
                                        <select class="form-control" name="Status9" id="Status9">
                                            <option value="">Select Status</option>
                                            <option value="Issued">Issued</option>
                                            <option value="Returned">Returned</option>
                                        </select>
                                    </div>
                                </div>

                          

                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="assignDate9">Date</label>
                                        <input type="date" class="form-control" value="<?php echo set_value('assignDate9'); ?>" id="assignDate9" name="assignDate9"/>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="6"><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-3">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $error; ?>
                        </div>
                <?php endif; ?>

                <?php
                    $success = $this->session->flashdata('success');
                    if($success): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $success; ?>
                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
</body>
</html>
