<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Branches Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
    <?php  if($is_admin == 1 || $role==2) { ?>    
        <div class="row">
        <form action="<?php echo base_url()?>branches/uploadCsvFile" method="post" enctype="multipart/form-data" style ="margin-left: 15px;">
            <input type="file" name="csv_file" accept=".csv">
            </br>
            <input type="submit" value="Upload">
        </form>

            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>branches/add"><i class="fa fa-plus"></i> Add New Branch</a>
                </div>
                
            </div>
        </div>
    <?php } ?>    
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Branches List</h3>
                    <div class="box-tools">
                        <!--<form action="<?php //echo base_url() ?>branches/branchesListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>-->
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                  <!--<table class="table table-hover">-->
                    <table id="example" class="display responsive nowrap" style="width:100%">
                     <thead>   
                    <tr>
                        <th>Franchise No.</th>
                        <th>Applicant Name</th>
                        <th>Email</th>
                        <th>Mobile No.</th>
                        <th>City</th>
                        <!-- <th>Legal Documents</th> -->
                        <!---End-Despatch---->
                        <th>Created On</th>
                        <th class="text-center">Actions</th>
                    </tr>
                    </thead>
        <tbody>
                    <?php
                    if(!empty($records))
                    {
                        foreach($records as $record)
                        {
                            
                    ?>
                    <?php
                    // $query = $this->db->query("SELECT * FROM tbl_legal_documents WHERE branchesId='$record->branchesId'");
                    // echo $query->num_rows();
                    ?>
                    <tr>
                        <td> <?php //echo $record->franchiseNumber ?>
                        <?php
                        if (!empty($record->franchiseNumber)) {
                            ?> <span class="label label-success"><?php echo $record->franchiseNumber ?></span><?php
                        } else {
                            ?> <span class="label warning">Empty</span> <?php
                        }
                        ?>
                        </td>
                        <td><?php //echo $record->applicantName ?>
                        <?php
                        if (!empty($record->applicantName)) {
                            ?> <span class="label label-success"><?php echo $record->applicantName ?></span><?php
                        } else {
                            ?> <span class="label warning">Empty</span> <?php
                        }
                        ?>
                        </td>
                        <td><?php //echo $record->branchEmail ?>
                        <?php
                        if (!empty($record->branchEmail)) {
                            ?> <span class="label label-success"><?php echo $record->branchEmail ?></span><?php
                        } else {
                            ?> <span class="label warning">Empty</span> <?php
                        }
                        ?>
                        </td>
                        <td><?php //echo $record->mobile ?>
                        <?php
                        if (!empty($record->mobile)) {
                            ?> <span class="label label-success"><?php echo $record->mobile ?></span><?php
                        } else {
                            ?> <span class="label warning">Empty</span> <?php
                        }
                        ?>
                        </td>
                        <td><?php //echo $record->branchcityName ?>
                        <?php
                        if (!empty($record->branchcityName)) {
                            ?> <span class="label label-success"><?php echo $record->branchcityName ?></span><?php
                        } else {
                            ?> <span class="label warning">Empty</span> <?php
                        }
                        ?>
                        </td>
                        
                        <!--End-Despatch---->
                        <!-- <td>
                            <?php
                            $query = $this->db->query("SELECT * FROM tbl_legal_documents WHERE branchesId='$record->branchesId'");
                            $result = $query->result();

                            if (!empty($result) && isset($result[0]->access)) {
                                $accessData = json_decode($result[0]->access, true);

                                if (is_array($accessData)) {
                                    foreach ($accessData as $moduleInfo) {
                                        foreach ($moduleInfo as $key => $value) {
                                            if ($key !== 'module') {
                                                $isChecked = $value === 1 ? "checked" : "";
                                                ?>
                                                <input type='checkbox' <?= $isChecked ?> disabled >
                                                <?= ucfirst(str_replace('_', ' ', $key)) ?> <br>
                                                <?php
                                            }
                                            
                                        }
                                    }
                                }
                            }
                            ?>
                        </td>  -->

                        <td><?php //echo date("d-m-Y", strtotime($record->createdDtm)) ?>
                        <?php
                        if (!empty($record->createdDtm)) {
                            ?> <span class="label label-success"><?php echo date("d-m-Y", strtotime($record->createdDtm)) ?></span><?php
                        } else {
                            ?> <span class="label warning">Empty</span> <?php
                        }
                        ?>
                        </td>
                        <td class="text-center">
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'branches/view/'.$record->branchesId; ?>" title="View"><i class="fa fa-eye"> View </i></a>
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'branches/edit/'.$record->branchesId; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                            <?php if($is_admin == 1){
                                ?>
                                <a class="btn btn-sm btn-danger deleteBranches" href="#" data-branchesid="<?php echo $record->branchesId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                                <?php
                            }?>
                        </td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                     </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php //echo $this->pagination->create_links(); ?>
                    <div class="br-pagi"><?php echo $links; ?></div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "branches/branchesListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<style type="text/css">

    /*---New-pagination---*/
    .br-pagi a {
        box-sizing: border-box;
        display: inline-block;
        min-width: 1.5em;
        padding: .5em 1em;
        margin-left: 2px;
        text-align: center;
        text-decoration: none !important;
        cursor: pointer;
        color: inherit !important;
        border: 1px solid transparent;
        border-radius: 2px;
        background: transparent;
        border: 0.5px #000 solid;
        border-radius: 4px;
    }
    .br-pagi {
        float: right;
    }
    .br-pagi strong {
        background: #367fa9;
        color: #fff;
        box-sizing: border-box;
        display: inline-block;
        min-width: 1.5em;
        padding: .5em 1em;
        margin-left: 2px;
        text-align: center;
        text-decoration: none !important;
        cursor: pointer;
        border: 0.5px #000 solid;
        border-radius: 4px;
    }
    .br-pagi.active {
        float: right;
        text-align: right;
        padding-top: .25em;
    }
    /*--End-New-pagination---*/
    .warning {
        /*background-color: #f70000;*/
        background-color: #f700003d;
    }
    .label {
        color: #000;
    }
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    .bg-green, .callout.callout-success, .alert-success, .label-success, .modal-success .modal-body {
        background-color: #00a65a26 !important;
    }
    span.label.label-success {
        color: #000 !important;
    }
    span.label.label-warning {
        color: #000 !important;
    }
    .bg-yellow, .callout.callout-warning, .alert-warning, .label-warning, .modal-warning .modal-body {
        background-color: #f39c1273 !important;
    }
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>