<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Branch Management
        <small>Add / Edit Branch</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Branch Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addBranches" action="<?php echo base_url() ?>branches/addNewBranches" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <!----Start-Sales-Section------>
                                <?php
                                    if ($is_admin == 1 || $role==2) {
                                     ?>
                                <div class="col-md-6">    
                                
                                    <div class="form-group">
                                        <label class="control-label">Franchise No.</label><input type="text" class="form-control" autocomplete="off" name="franchiseNumber" value=""><span class="error"></span>
                                    </div>                              
                                    <div class="form-group">
                                        <label for="applicantName">Name of Applicant</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('applicantName'); ?>" id="applicantName" name="applicantName" maxlength="256" />
                                    </div>
                                    <div class="form-group">
                                        <label for="mobile">Mobile Number</label>
                                        <input type="text" class="form-control required digits" id="mobile" value="<?php echo set_value('mobile'); ?>" name="mobile" maxlength="14">
                                    </div>
                                    <div class="form-group">
                                        <label for="stateName">State</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('branchState'); ?>" id="branchState" name="branchState" maxlength="256" />
                                    </div>
                                    <div class="form-group">
                                        <label for="branchAmountReceived">Amount Received</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('branchAmountReceived'); ?>" id="branchAmountReceived" name="branchAmountReceived" maxlength="256" />
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <label for="branchAddress">Address</label>
                                        <textarea class="form-control required" id="branchAddress" name="branchAddress"></textarea>
                                    </div>  
                                    <div class="form-group">
                                        <label for="branchFrAssignedAccountsDepartment">Franchise Assigned to Accounts Department</label>
                                        <select class="form-control required" id="branchFrAssignedAccountsDepartment" name="branchFrAssignedAccountsDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ACusers))
                                            {
                                                foreach ($ACusers as $acrl)
                                                {
                                                    $acuserText = $acrl->name;
                                                    ?>
                                                    <option value="<?php echo $acrl->userId ?>" <?php if($acrl->userId == set_value('branchFrAssignedAccountsDepartmentbranchFrAssignedAdmissionDepartment')) {echo "selected=selected";} ?>><?= $acuserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedAdmissionDepartment">Franchise Assigned to Admission Department</label>
                                        <select class="form-control required" id="branchFrAssignedAdmissionDepartment" name="branchFrAssignedAdmissionDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ADMusers))
                                            {
                                                foreach ($ADMusers as $admrl)
                                                {
                                                    $admuserText = $admrl->name;
                                                    ?>
                                                    <option value="<?php echo $admrl->userId ?>" <?php if($admrl->userId == set_value('branchFrAssignedAdmissionDepartment')) {echo "selected=selected";} ?>><?= $admuserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedDispatchDepartment">Franchise Assigned to Dispatch Department</label>
                                        <select class="form-control required" id="branchFrAssignedDispatchDepartment" name="branchFrAssignedDispatchDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($DISusers))
                                            {
                                                foreach ($DISusers as $disrl)
                                                {
                                                    $disduserText = $disrl->name;
                                                    ?>
                                                    <option value="<?php echo $disrl->userId ?>" <?php if($disrl->userId == set_value('branchFrAssignedDispatchDepartment')) {echo "selected=selected";} ?>><?= $disduserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div> 
                                    <div class="form-group">
                                        <label for="branchFrAssignedAdmintrainingDepartment">Franchise Assigned to Administration Training Department</label>
                                        <select class="form-control required" id="branchFrAssignedAdmintrainingDepartment" name="branchFrAssignedAdmintrainingDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ATMusers))
                                            {
                                                foreach ($ATMusers as $atmrl)
                                                {
                                                    $atmduserText = $atmrl->name;
                                                    ?>
                                                    <option value="<?php echo $atmrl->userId ?>" <?php if($atmrl->userId == set_value('branchFrAssignedAdmintrainingDepartment')) {echo "selected=selected";} ?>><?= $atmduserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label">Booking Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="bookingDate" value=""><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email address</label>
                                        <input type="text" class="form-control required email" id="email" value="<?php echo set_value('branchEmail'); ?>" name="branchEmail" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="cityName">City</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('branchcityName'); ?>" id="branchcityName" name="branchcityName" maxlength="256" />
                                    </div>                                    
                                    <div class="form-group">
                                        <label for="branchSalesDoneby">Sales Done By</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('branchSalesDoneby'); ?>" id="branchSalesDoneby" name="branchSalesDoneby" maxlength="256" />
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                        <select class="form-control required" id="branchFranchiseAssigned" name="branchFranchiseAssigned">
                                            <option value="0">Select Role</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('branchFranchiseAssigned')) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedDesigning">Franchise Assigned to Designing</label>
                                        <select class="form-control required" id="branchFranchiseAssignedDesigning" name="branchFranchiseAssignedDesigning">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($dusers))
                                            {
                                                foreach ($dusers as $drl)
                                                {
                                                    $duserText = $drl->name;
                                                    ?>
                                                    <option value="<?php echo $drl->userId ?>" <?php if($drl->userId == set_value('branchFranchiseAssignedDesigning')) {echo "selected=selected";} ?>><?= $duserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedLegalDepartment">Franchise Assigned to LegalDepartment</label>
                                        <select class="form-control required" id="branchFranchiseAssignedLegalDepartment" name="branchFranchiseAssignedLegalDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($LDusers))
                                            {
                                                foreach ($LDusers as $ldrl)
                                                {
                                                    $lduserText = $ldrl->name;
                                                    ?>
                                                    <option value="<?php echo $ldrl->userId ?>" <?php if($ldrl->userId == set_value('branchFranchiseAssignedLegalDepartment')) {echo "selected=selected";} ?>><?= $lduserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedMaterialDepartment">Franchise Assigned to Material Department</label>
                                        <select class="form-control required" id="branchFrAssignedMaterialDepartment" name="branchFrAssignedMaterialDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($MATusers))
                                            {
                                                foreach ($MATusers as $matrl)
                                                {
                                                    $matuserText = $matrl->name;
                                                    ?>
                                                    <option value="<?php echo $matrl->userId ?>" <?php if($matrl->userId == set_value('branchFrAssignedMaterialDepartment')) {echo "selected=selected";} ?>><?= $matuserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div>  
                                    <div class="form-group">
                                        <label for="branchFrAssignedDigitalDepartment">Franchise Assigned to Digital-Marketing Department</label>
                                        <select class="form-control required" id="branchFrAssignedDigitalDepartment" name="branchFrAssignedDigitalDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($DMusers))
                                            {
                                                foreach ($DMusers as $dmrl)
                                                {
                                                    $dmuserText = $dmrl->name;
                                                    ?>
                                                    <option value="<?php echo $dmrl->userId ?>" <?php if($dmrl->userId == set_value('branchFrAssignedDigitalDepartment')) {echo "selected=selected";} ?>><?= $dmuserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div> 
                                    <div class="form-group">
                                        <label for="branchFrAssignedTrainingDepartment">Franchise Assigned to Training Department</label>
                                        <select class="form-control required" id="branchFrAssignedTrainingDepartment" name="branchFrAssignedTrainingDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($TRMusers))
                                            {
                                                foreach ($TRMusers as $trmrl)
                                                {
                                                    $trmuserText = $trmrl->name;
                                                    ?>
                                                    <option value="<?php echo $trmrl->userId ?>" <?php if($trmrl->userId == set_value('branchFrAssignedTrainingDepartment')) {echo "selected=selected";} ?>><?= $trmuserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>             
                                        </select>
                                    </div> 
                                    
                                </div>
                                <div class="col-md-12 mb-sm">
                                         <div class="form-group"><label class="control-label">Special Note for the Sales</label><textarea type="textarea" class="form-control" name="BranchSpecialNoteSales"></textarea><span class="error"></span></div>
                                    </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Complete franchise amount due date given</label><input type="date" class="form-control" autocomplete="off" name="completeFranchiseAmt" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!-- <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Confirmation Amount Date (33k + GST) (within 30days)</label><input type="date" class="form-control" autocomplete="off" name="confirmationAmt33kGST" value=""><span class="error"></span>
                                    </div>
                                </div> -->
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Undertaking And Commitment - Sales</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="undertakingCommitment" value=""><span class="error"></span>
                                    </div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Offer Plan Name </label><input type="text" class="form-control" autocomplete="off" name="offerPlanname" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Offer Amount </label><input type="text" class="form-control" autocomplete="off" name="offerName" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Discount </label><input type="text" class="form-control" autocomplete="off" name="discountAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Final Franchise Amount </label><input type="text" class="form-control" autocomplete="off" name="finalAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges (Sales) </label><input type="text" class="form-control" autocomplete="off" name="legalChargesSales" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Setup & Installation Charges </label><input type="text" class="form-control" autocomplete="off" name="brSetupinsChargSales" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">No. Of Initial Student KIT Offered </label><input type="text" class="form-control" autocomplete="off" name="numInialKitSales" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Franchise Tenure </label><input type="text" class="form-control" autocomplete="off" name="franchiseTenure" value=""><span class="error"></span></div>
                                </div>
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Sales Executive <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="salesExecutive" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Sales T.L. <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="salesTeamlead" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!----End-Sales-Section------>
                                <!---Custom-Fields-Start-->
                                <!-- <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Franchise No.</label><input type="text" class="form-control" autocomplete="off" name="franchiseNumber" value=""><span class="error"></span></div>
                                </div>
                                
                                
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Booking Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="bookingDate" value=""><span class="error"></span>
                                    </div>
                                </div> -->
                               <!--  <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Welcome Folder Status </label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="welComeFolderStatus" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="<?= ACTIVE ?>"> Yes </option><option value="<?= INACTIVE ?>"> No </option></select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Welcome Folder Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="welComeFolderDtm" value=""><span class="error"></span>
                                    </div>
                                </div> -->
                                <!----End-Sales-Section------>
                                <!----Start-Legal-Section------>
                                <?php
                                    }if ($is_admin == 1 || $role==24) {
                                     ?>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">License number</label><input type="text" class="form-control" autocomplete="off" name="licenseNumber" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">License Shared on</label><input type="date" class="form-control" autocomplete="off" name="licenseSharedon" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Valid from Date <span class="required">*</span></label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="validFromDate" value=""><span class="error"></span>
                                    </div>
                                </div>                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Valid  TIll Date <span class="required">*</span></label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="validTillDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Tenure <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="agreementTenure" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Forms and Documents completed <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="formsDocumentsCompleted" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="onboardingForm" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form Received On</label><input type="date" class="form-control" autocomplete="off" name="onboardingFormReceived" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form - Remark</label><input type="text" class="form-control" autocomplete="off" name="onboardingFormRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Final Agreement pdf shared <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="finalAgreementShared" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Draft</label><input type="date" class="form-control" autocomplete="off" name="agreementDraftdate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Draft Received On</label><input type="date" class="form-control" autocomplete="off" name="agreementDraftReceiveddate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Complete File Submitted On</label><input type="date" class="form-control" autocomplete="off" name="compFileSubmit" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">File Closer Date</label><input type="date" class="form-control" autocomplete="off" name="fileCLoserDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Status <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="branchStatus" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option></select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Status <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brInstallationStatus" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="<?= ACTIVE ?>">Installed</option><option value="<?= INACTIVE ?>"> Not Installed</option></select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Status Remark</label><input type="text" class="form-control" autocomplete="off" name="branchStatusRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Udertaking Acknowledgement Received <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="undertakingAck" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No</option></select>
                                    </div>
                                </div>
                                <!----End-Legal-Section------>                                
                                <!---Start-Social-Media-Digital-Section---->
                                <?php
                                    }if ($is_admin == 1 || $role==18) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Facebook Page Status <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="facebookPageStatus" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option></select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Facebook Page  Link</label><input type="text" class="form-control" autocomplete="off" name="facebookPageLink" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Facebook Page Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="facebookPageRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Google Map Location Status <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="googleMapLoc" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Google Map Location Link</label><input type="text" class="form-control" autocomplete="off" name="googleMapLocLink" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Google Map Location - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="googleMapLocRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Instagram Page Status <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="instagramPageStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Instagram Page ID</label><input type="text" class="form-control" autocomplete="off" name="instagramPageID" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Instagram Page - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="instagramPageRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Just Dial Page Status <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="jdPageStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Just Dial Page ID</label><input type="text" class="form-control" autocomplete="off" name="jdPageID" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Just Dial Page - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="jdPageRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Twitter Page Status <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="tweetPageStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Twitter Page ID</label><input type="text" class="form-control" autocomplete="off" name="tweetPageID" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Twitter Page - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="tweetPageRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Opted For Online Marketing <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="optOnlineMarketing" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Digital Marketing Cost With GST <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="digiMarkCost" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Digital Marketing Start Date <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="digiMarkStartDtm" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Digital Marketing End Date <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="digiMarkEndDtm" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Online Marketing Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="digiMarkReamrk" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation feedback video uploaded on FB <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="insfeedvideoUplodFB" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation feedback video uploaded on Youtube <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="insfeedvideoUplodYoutube" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation feedback video uploaded on Insta <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="insfeedvideoUplodInsta" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!---End-Social-Media-Digital-Section---->
                                <!---Start-Support-Section---->
                                <?php
                                    }if ($is_admin == 1 || $role==15) {
                                     ?>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch location address(Premise) <span class="required">*</span></label><textarea type="textarea" class="form-control" name="branchLocAddressPremise"></textarea><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Add of franchisee (person/company/society/partnership) <span class="required">*</span></label><textarea type="textarea" class="form-control" name="addOfFranchise"></textarea><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group">
                                        <label class="control-label">Permanent Address</label>
                                        <textarea class="form-control" rows="1" name="permanentAddress" placeholder="Permanent Address"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Location</label><input type="text" class="form-control" autocomplete="off" name="branchLocation" value=""><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Franchise Name</label><input type="text" class="form-control" autocomplete="off" name="franchiseName" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Type of branch</label><input type="text" class="form-control" autocomplete="off" name="typeBranch" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Current Status</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="currentStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Active</option><option value="<?= INACTIVE ?>"> InActive</option>
                                        </select>    
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admin's  Name <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="adminName" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admin's  Contact Number <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="adminContactNum" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Additional number</label><input type="tel" class="form-control" autocomplete="off" name="additionalNumber" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Edumeta Official email ID</label><input type="email" class="form-control" autocomplete="off" name="officialEmailID" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Personal Email ID</label><input type="email" class="form-control" autocomplete="off" name="personalEmailId" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">GST number</label><input type="text" class="form-control" autocomplete="off" name="gstNumber" value=""><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Undertaking And Commitment - Support</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="undertakingCommitmentSupport" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Invoice Number (Booking) <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="invoiceNumber" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Manuals-1 <span class="required"></span></label><input type="date" class="form-control" autocomplete="off" name="Manual1" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Manuals-2 <span class="required"></span></label><input type="date" class="form-control" autocomplete="off" name="Manual2" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Manuals-3 <span class="required"></span></label><input type="date" class="form-control" autocomplete="off" name="Manual3" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Reference</label><input type="text" class="form-control" autocomplete="off" name="Reference" value=""><span class="error"></span></div>
                                </div>

                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Tentative Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="installationTentativeDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Date</label><input type="date" class="form-control" autocomplete="off" name="installationDate" value=""><span class="error"></span></div>
                                </div>
                                
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Set Up/Installation completed <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="setUpInstallation" value=""><span class="error"></span></div>
                                </div>-->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Anniversary Date/ start date <span class="required">*</span></label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="branchAnniversaryDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Teacher Recruitment Done</label><input type="text" class="form-control" autocomplete="off" name="teacherRecruitment" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Anniversery</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="OwnerAnniversery" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Welcome CALL <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="welcomeCall" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Welcome MAIL <span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="welcomeMail" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Whatsapp Group <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="whatsappGroup" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Whatsapp Group - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="whatsappGroupRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Whatsapp Group Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="whatsappGroupdate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">1st Interaction Meeting</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="interactionMeeting" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-5 mb-sm">
                                    <div class="form-group"><label class="control-label">1st Interaction Meeting - Remark</label><input type="text" class="form-control" autocomplete="off" name="interactionMeetingRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!--<div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Inauguration</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="inaugurationDate" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Requirement mail</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="installationRequirementmail" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-5 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Requirement mail - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="installationRequirementmailRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Official email id shared <span class="required">*</span></label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="officialemailshared" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Interaction Date (Support)</label><input type="date" class="form-control" autocomplete="off" name="lastInteractiondate" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Discussion by</label><input type="text" class="form-control" autocomplete="off" name="lastDiscussionby" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Discussion Comment</label><input type="text" class="form-control" autocomplete="off" name="lastInteractioncomment" value=""><span class="error"></span>
                                    </div>
                                </div>                                 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Landline</label><input type="text" class="form-control" autocomplete="off" name="branchLandline" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Additional Name</label><input type="text" class="form-control" autocomplete="off" name="additionalName" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Additional Contact</label><input type="text" class="form-control" autocomplete="off" name="additionalContact" value=""><span class="error"></span>
                                    </div>
                                </div>  
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Deadine for final payment</label><input type="date" class="form-control" autocomplete="off" name="finalPaydeadline" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Time Disclipine Email</label><input type="date" class="form-control" autocomplete="off" name="timeDisclipineemail" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Uniform Disclipine Email</label><input type="date" class="form-control" autocomplete="off" name="uniformDisclipineemail" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Happiness level of branch</label><input type="text" class="form-control" autocomplete="off" name="happinessLevelbranch" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!---End-Support-Section---->
                                <!---Start-Admission-Section---->
                                <?php
                                    }if ($is_admin == 1 || $role==20) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">1st Admission Cracked on</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="admissionCracked" value=""><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">PG Decided Fee</label><input type="text" class="form-control" autocomplete="off" name="pgDecidedFee" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Nursery Decided Fee</label><input type="text" class="form-control" autocomplete="off" name="nurseryDecidedFee" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">KG-1 Decided Fee</label><input type="text" class="form-control" autocomplete="off" name="KG1DecidedFee" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">KG-2 Decided Fee</label><input type="text" class="form-control" autocomplete="off" name="KG2DecidedFee" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shared Status <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="feeSharedStatus" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="shared">Shared</option><option value="not_shared"> Not Shared</option><option value="on_hold"> On Hold</option></select>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Fees Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="feesRemark" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions PG <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmissionPG" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions NURSERY <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmissionNursary" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions KG1<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmissionKg1" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions KG2<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmissionKg2" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions1st<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmission1st" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions2nd<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmission2nd" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Total Admissions<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="totalAddmission" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admission Counselor Name<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmissionCounselor" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Last Discussion (Admissions)<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="lastDiscussaddmission" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admissions Excel Sheet Link<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="addmissionSheetlink" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Date of Excel Sheet Shared<span class="required">*</span></label><input type="date" class="form-control" autocomplete="off" name="dateexlSheetshared" value=""><span class="error"></span>
                                    </div>
                                </div>       
                                <!---End-Admissions-Section---->
                                <!---Start-Design-Promotion-Section----> 
                                <?php
                                    }if ($is_admin == 1 || $role==19) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Designs &amp; Promotional images shared <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="DesignsPromotional" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Shared</option><option value="<?= INACTIVE ?>"> Not Shared</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Designs &amp; Promotional images - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="DesignsPromotionalRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-12 mb-sm">
                                    <div class="form-group"><label class="control-label">Special Note for the branch</label><textarea type="textarea" class="form-control" name="BranchSpecialNote"></textarea><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Biometric (Installed &amp; Operating) <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="biometricInstalled" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> Pending </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Add Remark for Biometric <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="biometricRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Biometric Installed Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="biometricInstalledDate" value=""><span class="error"></span>
                                    </div>
                                </div>    
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Camera (Installed &amp; Operating) <span class="required">*</span></label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="camaraInstalled" tabindex="-1" aria-hidden="true"><option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> Pending </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Add Remark for Camera <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="camaraRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Camera Installed Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="camaraInstalledDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">EduMETA APP Training <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="eduMetaAppTraining" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Pending </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">EduMETA APP Training - Remark <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="AppTrainingRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">EduMETA APP Training - Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="AppTrainingRemarkDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                 <!--New-Design-Field---->
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Congratulations image of  branch Installation  <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="congratulationsImg" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Pending </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on FB<span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brimguploadedFBStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on FB Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="brimguploadedFBDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on Instagram<span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brimguploadedInstaStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation image upload on Instagram Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="brimguploadedInstaDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admission Open Image(Creation & sharing)</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="admissionOpenimgStatus" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Staff Hiring Image(Creation & sharing)</label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="staffHiringimgStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - March</label><input type="date" class="form-control" autocomplete="off" name="newsletterMarch" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - June</label><input type="date" class="form-control" autocomplete="off" name="newsletterJune" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - September</label><input type="date" class="form-control" autocomplete="off" name="newsletterSeptember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Newsletter in the - December</label><input type="date" class="form-control" autocomplete="off" name="newsletterDecember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Birthday Image Shared</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="OBirthDayImgStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Birthday Image Shared Date</label><input type="date" class="form-control" autocomplete="off" name="OBirthDayImgSharedDtm" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Anniversery Image Shared</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="OwnerAnnImgStatus" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No </option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Owner Anniversery Image Shared Date</label><input type="date" class="form-control" autocomplete="off" name="OwnerAnnImgSharedDtm" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!---End-Design-Promotion-Section---->
                                <!---Start-Training-Section---->
                                <?php
                                    }if ($is_admin == 1 || $role==21) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Admin Training</label><input type="date" class="form-control" autocomplete="off" name="adminTraining" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Classroom Decoration <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="classroomDecoration" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Movie Club</label><input type="date" class="form-control" autocomplete="off" name="movieClub" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Refer N Earn</label><input type="date" class="form-control" autocomplete="off" name="referEarn" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Teacher Interaction</label><input type="date" class="form-control" autocomplete="off" name="teacherInteraction" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Teacher Interview</datelabel><input type="date" class="form-control" autocomplete="off" name="teacherInterview" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Pongal Workshop</label><input type="date" class="form-control" autocomplete="off" name="pongalWorkshop" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Sankranti Workshop</label><input type="date" class="form-control" autocomplete="off" name="sankrantiWorkshop" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Republic Day Workshop</label><input type="date" class="form-control" autocomplete="off" name="republicDayWorkshop" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Bridge Course Counselling</label><input type="date" class="form-control" autocomplete="off" name="bridgeCourseCounselling" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Bulletin Board</label><input type="date" class="form-control" autocomplete="off" name="bulletinBoard" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">BridgeCourse</label><input type="date" class="form-control" autocomplete="off" name="bridgeCourse" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Settlers Program</label><input type="date" class="form-control" autocomplete="off" name="settlersProgram" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Jolly Phonic</label><input type="date" class="form-control" autocomplete="off" name="jollyPhonic" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Academics Meetings</label><input type="date" class="form-control" autocomplete="off" name="academicsMeetings" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Curiculumn Shared</label><input type="date" class="form-control" autocomplete="off" name="curiculumnShared" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Holiday / Events Listing </label><input type="date" class="form-control" autocomplete="off" name="holidaEventlisting" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Creation and Sharing of Assessment papers </label><input type="date" class="form-control" autocomplete="off" name="sharingAssessmentpapers" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Assessment Schedule creation and sharing on email </label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="assessmentSharingemail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>"> No</option>
                                    </select></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">PTM Schedule (creation and mail) </label><input type="date" class="form-control" autocomplete="off" name="PTMscheduledate" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shadow Puppet </label><input type="date" class="form-control" autocomplete="off" name="shadowPuppet" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Monthly Event Training</label><input type="date" class="form-control" autocomplete="off" name="monthlyEventtraining" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Summer Camp</label><input type="date" class="form-control" autocomplete="off" name="summertCampdate" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Winter Camp</label><input type="date" class="form-control" autocomplete="off" name="winterCampdate" value=""><span class="error"></span></div>
                                </div>

                                <!---End-Training-Section---->
                                <!---Start-Dispatch-Section---->
                                <?php
                                    }if ($is_admin == 1 || $role==23) {
                                     ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Installation Material Dispatch Date</label><input type="date" class="form-control" autocomplete="off" name="insmatDispatchdate" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Details & Receipt mail Status</label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="DetailsReceiptmail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Shared</option><option value="<?= INACTIVE ?>">Not Shared</option>
                                    </select></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Confirmation From Branch on Material Received </label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="ConfBrinsScheduledemail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>">No</option>
                                    </select></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Material Received date</label><input type="date" class="form-control" autocomplete="off" name="Materialrecdate" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Scheduled Date</label><input type="date" class="form-control" autocomplete="off" name="BrinsScheduleddate" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Scheduled Email</label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="BrinsScheduledemail" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>">Not Done</option>
                                    </select></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation - Remark</label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="brInstalationRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Video Feedback From Branch</label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="videoFeedbackbr" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>">No</option>
                                    </select></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Written Feedback From Branch</label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="writtenFeedbackbr" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Yes</option><option value="<?= INACTIVE ?>">No</option>
                                    </select></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Shared - Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="ShoppinPortSharedDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Training Status <span class="required">*</span></label><select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="ShoppinPortTraining" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>">Pending</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Training - Date</label><input type="date" class="form-control" data-plugin-datepicker="" autocomplete="off" name="ShoppinPortTrainingDate" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Shopping Portal Training - Remark</label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="ShoppinPortRemark" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Return Items</label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="returnItems" value=""><span class="error"></span>
                                    </div>
                                </div>
                               
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Mode Of Despatch <span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="modeOfDespatch" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Number Of Boxes <span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="NumOfBoxes" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">POD Number <span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="PoDNum" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Specific Items / Gifts / Offer - (If Any)   <span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="SpecificGiftOffer" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Confirmation After Branch Installation Over Phone <span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="ConfBrInsOverPhone" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Short Comming - (If Any) <span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="shortComming" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Solutions Of Short Comming<span class="required">*</span></label><input type="text" class="form-control" data-plugin-datepicker="" autocomplete="off" name="solutionShortComming" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!---End-Dispatch-Section---->
                                <!---Start-Main-Account-Section---->      
                                <?php
                                    } if ($is_admin == 1 || $role==16) {
                                     ?>                        
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Training Amount </label><input type="text" class="form-control" autocomplete="off" name="trainingAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Society Service Amount </label><input type="text" class="form-control" autocomplete="off" name="societyServiceamount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Total Amount</label><input type="text" class="form-control" autocomplete="off" name="totalAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">GST Amount</label><input type="text" class="form-control" autocomplete="off" name="gstAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">AMC with GST<span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="amcAmount" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Total Franchise Cost with GST+Society Fund</label><input type="text" class="form-control" autocomplete="off" name="totalfranchisegstFund" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges</label><input type="text" class="form-control" autocomplete="off" name="legalCharges" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges Due</label><input type="text" class="form-control" autocomplete="off" name="legalChargesdue" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Total ( with GST)+Legal Charges</label><input type="text" class="form-control" autocomplete="off" name="totalgstCharges" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Total Paid Amount</label><input type="text" class="form-control" autocomplete="off" name="totalPaidamount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Due Franchise Amount</label><input type="text" class="form-control" autocomplete="off" name="dueFranchiseamt" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">KIT Charges</label><input type="text" class="form-control" autocomplete="off" name="kitCharges" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">No. of Initial kits</label><input type="text" class="form-control" autocomplete="off" name="numinitialKit" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Total Kits amount</label><input type="text" class="form-control" autocomplete="off" name="totalKitsamt" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Kit amount Received</label><input type="text" class="form-control" autocomplete="off" name="kitamtReceived" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Due Kit amount</label><input type="text" class="form-control" autocomplete="off" name="dueKitamount" value=""><span class="error"></span></div>
                                </div>
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Final Total amount due (including Franchise)</label><input type="date" class="form-control" autocomplete="off" name="finaltotalamtDue" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Special Remark</label><input type="text" class="form-control" autocomplete="off" name="specialRemark" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Transport and travel charges including GST</label><input type="text" class="form-control" autocomplete="off" name="transporttravCharge" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Travel Amount including GST</label><input type="text" class="form-control" autocomplete="off" name="travelAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Received Travel Amount</label><input type="text" class="form-control" autocomplete="off" name="receivedtravelAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Due Travel AMT</label><input type="text" class="form-control" autocomplete="off" name="duetravelAmount" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Transport charges</label><input type="text" class="form-control" autocomplete="off" name="transportCharges" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Transport amt received</label><input type="text" class="form-control" autocomplete="off" name="transportAmtreceived" value=""><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Due Transport Charges</label><input type="text" class="form-control" autocomplete="off" name="duetransportCharges" value=""><span class="error"></span></div>
                                </div>                                       
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Upgrade UPTO Class-2</label><input type="text" class="form-control" autocomplete="off" name="upgradeUptoclass" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <!----Accounts-new-Added-fields-30-May-2023---->  
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger in the - March</label><input type="date" class="form-control" autocomplete="off" name="ledgerMarch" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger in the - June</label><input type="date" class="form-control" autocomplete="off" name="ledgerJune" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger in the - September</label><input type="date" class="form-control" autocomplete="off" name="ledgerSeptember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Ledger in the - December</label><input type="date" class="form-control" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 1st Decemeber</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus1Dec" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC Status</label><input type="date" class="form-control" autocomplete="off" name="ledgerDecember" value=""><span class="error"></span>
                                    </div>
                                </div>-->
                                
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 10th Decemeber</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus10Dec" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 15th Decemeber</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus15Dec" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 19th Decemeber</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus19Dec" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC on 20th Decemeber</label>
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="reminderAMCStatus20Dec" tabindex="-1" aria-hidden="true">
                                            <option value="">Select</option><option value="<?= ACTIVE ?>">Done</option><option value="<?= INACTIVE ?>"> Not Done</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Reminder mail for AMC Remark</label><input type="text" class="form-control" autocomplete="off" name="RemarkforAMCmail" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Invoice of AMC clearance (generate & mail)</label><input type="text" class="form-control" autocomplete="off" name="InvoiceAMCClearance" value=""><span class="error"></span>
                                    </div>
                                </div> 
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Penalty mail (In case of Non clearance)</label><input type="text" class="form-control" autocomplete="off" name="PenaltyMailnoncle" value=""><span class="error"></span>
                                    </div>
                                </div>     
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Invoice Number - (All) <span class="required">*</span></label><input type="text" class="form-control" autocomplete="off" name="invoiceNumberAll" value=""><span class="error"></span>
                                    </div>
                                </div>
                            <?php } ?>
                                <!---End-Main-Account-Section---->                                
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-3">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>