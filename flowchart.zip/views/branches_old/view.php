<?php
$branchesId = $branchesInfo->branchesId;
$applicantName = $branchesInfo->applicantName;
//$address = $branchesInfo->address;
$mobile = $branchesInfo->mobile;
$branchcityName = $branchesInfo->branchcityName;
$branchState = $branchesInfo->branchState;
$branchSalesDoneby = $branchesInfo->branchSalesDoneby;
$branchAmountReceived = $branchesInfo->branchAmountReceived;
$branchFranchiseAssigned = $branchesInfo->branchFranchiseAssigned;
$branchFranchiseAssignedDesigning = $branchesInfo->branchFranchiseAssignedDesigning;
$branchFranchiseAssignedLegalDepartment = $branchesInfo->branchFranchiseAssignedLegalDepartment;
$branchFrAssignedAccountsDepartment = $branchesInfo->branchFrAssignedAccountsDepartment;
$branchFrAssignedDispatchDepartment = $branchesInfo->branchFrAssignedDispatchDepartment;
$branchFrAssignedAdmissionDepartment = $branchesInfo->branchFrAssignedAdmissionDepartment;
$branchFrAssignedMaterialDepartment = $branchesInfo->branchFrAssignedMaterialDepartment;
$branchFrAssignedDigitalDepartment = $branchesInfo->branchFrAssignedDigitalDepartment;
$branchFrAssignedTrainingDepartment = $branchesInfo->branchFrAssignedTrainingDepartment;
$branchAddress = $branchesInfo->branchAddress;
$permanentAddress = $branchesInfo->permanentAddress;
$branchEmail = $branchesInfo->branchEmail;
//New fields added for edit.....
$franchiseNumber = $branchesInfo->franchiseNumber; 
$franchiseName = $branchesInfo->franchiseName;
$typeBranch = $branchesInfo->typeBranch;
$currentStatus = $branchesInfo->currentStatus;
$bookingDate = $branchesInfo->bookingDate;
$licenseNumber = $branchesInfo->licenseNumber;
$licenseSharedon = $branchesInfo->licenseSharedon;
$validFromDate = $branchesInfo->validFromDate;
$validTillDate = $branchesInfo->validTillDate;
$branchLocation = $branchesInfo->branchLocation;
$adminName = $branchesInfo->adminName;
$adminContactNum = $branchesInfo->adminContactNum;
$additionalNumber = $branchesInfo->additionalNumber;
$officialEmailID = $branchesInfo->officialEmailID;
$personalEmailId = $branchesInfo->personalEmailId;
$facebookPageStatus = $branchesInfo->facebookPageStatus;
$facebookPageLink = $branchesInfo->facebookPageLink;
$facebookPageRemark = $branchesInfo->facebookPageRemark;
$googleMapLoc = $branchesInfo->googleMapLoc;
$googleMapLocLink = $branchesInfo->googleMapLocLink;
$googleMapLocRemark = $branchesInfo->googleMapLocRemark;
$instagramPageStatus = $branchesInfo->instagramPageStatus;
$instagramPageID = $branchesInfo->instagramPageID;
$instagramPageRemark = $branchesInfo->instagramPageRemark;
$uniformDisclipineemail = $branchesInfo->uniformDisclipineemail;
/*---New-Field-Digital--*/
$jdPageStatus = $branchesInfo->jdPageStatus;
$jdPageID = $branchesInfo->jdPageID;
$jdPageRemark = $branchesInfo->jdPageRemark;
$tweetPageStatus = $branchesInfo->tweetPageStatus;
$tweetPageID = $branchesInfo->tweetPageID;
$tweetPageRemark = $branchesInfo->tweetPageRemark;
$digiMarkCost = $branchesInfo->digiMarkCost;
$digiMarkStartDtm = $branchesInfo->digiMarkStartDtm;
$digiMarkEndDtm = $branchesInfo->digiMarkEndDtm;
$digiMarkReamrk = $branchesInfo->digiMarkReamrk;
$insfeedvideoUplodFB = $branchesInfo->insfeedvideoUplodFB;
$insfeedvideoUplodYoutube = $branchesInfo->insfeedvideoUplodYoutube;
$insfeedvideoUplodInsta = $branchesInfo->insfeedvideoUplodInsta;
$optOnlineMarketing = $branchesInfo->optOnlineMarketing;
/*---End-Field-Digital--*/
$branchLocAddressPremise = $branchesInfo->branchLocAddressPremise;
$addOfFranchise = $branchesInfo->addOfFranchise;
$gstNumber = $branchesInfo->gstNumber;
$undertakingCommitmentSupport = $branchesInfo->undertakingCommitmentSupport;
$amcAmount = $branchesInfo->amcAmount;
$invoiceNumber = $branchesInfo->invoiceNumber;
$agreementTenure = $branchesInfo->agreementTenure;
$salesExecutive = $branchesInfo->salesExecutive;
$salesTeamlead = $branchesInfo->salesTeamlead;
$Manual1 = $branchesInfo->Manual1;
$Manual2 = $branchesInfo->Manual2;
$Manual3 = $branchesInfo->Manual3;
$Reference = $branchesInfo->Reference;
$installationTentativeDate = $branchesInfo->installationTentativeDate;
$formsDocumentsCompleted = $branchesInfo->formsDocumentsCompleted;
$setUpInstallation = $branchesInfo->setUpInstallation;
$branchAnniversaryDate = $branchesInfo->branchAnniversaryDate;
$admissionCracked = $branchesInfo->admissionCracked;
$teacherRecruitment = $branchesInfo->teacherRecruitment;
$pgDecidedFee = $branchesInfo->pgDecidedFee;
$nurseryDecidedFee = $branchesInfo->nurseryDecidedFee;
$KG1DecidedFee = $branchesInfo->KG1DecidedFee;
$KG2DecidedFee = $branchesInfo->KG2DecidedFee;
$feeSharedStatus = $branchesInfo->feeSharedStatus;
$feesRemark = $branchesInfo->feesRemark;
$addmissionPG  = $branchesInfo->addmissionPG;
$addmissionNursary  = $branchesInfo->addmissionNursary;
$addmissionKg1  = $branchesInfo->addmissionKg1;
$addmissionKg2  = $branchesInfo->addmissionKg2;
$addmission1st  = $branchesInfo->addmission1st;
$addmission2nd  = $branchesInfo->addmission2nd;
$totalAddmission  = $branchesInfo->totalAddmission;
$addmissionCounselor  = $branchesInfo->addmissionCounselor;
$lastDiscussaddmission  = $branchesInfo->lastDiscussaddmission;
$addmissionSheetlink  = $branchesInfo->addmissionSheetlink;
$dateexlSheetshared = $branchesInfo->dateexlSheetshared;
$lastInteractiondate  = $branchesInfo->lastInteractiondate;
$lastDiscussionby  = $branchesInfo->lastDiscussionby;
$lastInteractioncomment  = $branchesInfo->lastInteractioncomment;
$agreementDraftdate  = $branchesInfo->agreementDraftdate;
$branchLandline  = $branchesInfo->branchLandline;
$additionalName  = $branchesInfo->additionalName;
$finalPaydeadline  = $branchesInfo->finalPaydeadline;
$completeFranchiseAmt  = $branchesInfo->completeFranchiseAmt;
$confirmationAmt33kGST  = $branchesInfo->confirmationAmt33kGST;
$happinessLevelbranch  = $branchesInfo->happinessLevelbranch;
/*-----Start-Design--*/
$DesignsPromotional = $branchesInfo->DesignsPromotional;
$DesignsPromotionalRemark = $branchesInfo->DesignsPromotionalRemark;
$BranchSpecialNote = $branchesInfo->BranchSpecialNote;
$biometricInstalled = $branchesInfo->biometricInstalled;
$biometricRemark = $branchesInfo->biometricRemark;
$biometricInstalledDate = $branchesInfo->biometricInstalledDate;
$camaraInstalled = $branchesInfo->camaraInstalled;
$camaraRemark = $branchesInfo->camaraRemark;
$camaraInstalledDate = $branchesInfo->camaraInstalledDate;
$eduMetaAppTraining = $branchesInfo->eduMetaAppTraining;
$AppTrainingRemark = $branchesInfo->AppTrainingRemark;
$AppTrainingRemarkDate = $branchesInfo->AppTrainingRemarkDate;
/*--new-field--*/
$congratulationsImg = $branchesInfo->congratulationsImg;
$brimguploadedFBStatus = $branchesInfo->brimguploadedFBStatus;
$brimguploadedFBDate = $branchesInfo->brimguploadedFBDate;
$brimguploadedInstaStatus = $branchesInfo->brimguploadedInstaStatus;
$brimguploadedInstaDate = $branchesInfo->brimguploadedInstaDate;
$admissionOpenimgStatus = $branchesInfo->admissionOpenimgStatus;
$staffHiringimgStatus = $branchesInfo->staffHiringimgStatus;
$newsletterMarch = $branchesInfo->newsletterMarch;
$newsletterJune = $branchesInfo->newsletterJune;
$newsletterSeptember = $branchesInfo->newsletterSeptember;
$newsletterDecember = $branchesInfo->newsletterDecember;
$OBirthDayImgStatus = $branchesInfo->OBirthDayImgStatus;
$OBirthDayImgSharedDtm = $branchesInfo->OBirthDayImgSharedDtm;
$OwnerAnnImgStatus = $branchesInfo->OwnerAnnImgStatus;
$OwnerAnnImgSharedDtm = $branchesInfo->OwnerAnnImgSharedDtm;
/*-----End-Design--*/
$OwnerAnniversery = $branchesInfo->OwnerAnniversery;
$welcomeCall = $branchesInfo->welcomeCall;
$welcomeMail = $branchesInfo->welcomeMail;
$whatsappGroup = $branchesInfo->whatsappGroup;
$whatsappGroupRemark = $branchesInfo->whatsappGroupRemark;
$whatsappGroupdate = $branchesInfo->whatsappGroupdate;
$interactionMeeting = $branchesInfo->interactionMeeting;
$interactionMeetingRemark = $branchesInfo->interactionMeetingRemark;
$undertakingCommitment = $branchesInfo->undertakingCommitment;
$onboardingForm = $branchesInfo->onboardingForm;
$onboardingFormReceived = $branchesInfo->onboardingFormReceived;
$onboardingFormRemark = $branchesInfo->onboardingFormRemark;
$installationRequirementmail = $branchesInfo->installationRequirementmail;
$installationRequirementmailRemark = $branchesInfo->installationRequirementmailRemark;
$officialemailshared = $branchesInfo->officialemailshared;
$finalAgreementShared = $branchesInfo->finalAgreementShared;
$inaugurationDate = $branchesInfo->inaugurationDate;
/*---Start-Trainging-*/
$adminTraining = $branchesInfo->adminTraining;
$classroomDecoration = $branchesInfo->classroomDecoration;
$movieClub = $branchesInfo->movieClub;
$referEarn = $branchesInfo->referEarn;
$teacherInteraction = $branchesInfo->teacherInteraction;
$teacherInterview = $branchesInfo->teacherInterview;
$pongalWorkshop = $branchesInfo->pongalWorkshop;
$sankrantiWorkshop = $branchesInfo->sankrantiWorkshop;
$republicDayWorkshop = $branchesInfo->republicDayWorkshop;
$bridgeCourseCounselling = $branchesInfo->bridgeCourseCounselling;
$bulletinBoard = $branchesInfo->bulletinBoard;
$bridgeCourse = $branchesInfo->bridgeCourse;
$settlersProgram = $branchesInfo->settlersProgram;
$jollyPhonic = $branchesInfo->jollyPhonic;
$academicsMeetings = $branchesInfo->academicsMeetings;
$timeDisclipineemail = $branchesInfo->timeDisclipineemail;
$curiculumnShared = $branchesInfo->curiculumnShared;
$holidaEventlisting = $branchesInfo->holidaEventlisting;
$sharingAssessmentpapers = $branchesInfo->sharingAssessmentpapers;
$assessmentSharingemail = $branchesInfo->assessmentSharingemail;
$PTMscheduledate = $branchesInfo->PTMscheduledate;
$shadowPuppet = $branchesInfo->shadowPuppet;
$monthlyEventtraining = $branchesInfo->monthlyEventtraining;
$summertCampdate = $branchesInfo->summertCampdate;
$winterCampdate = $branchesInfo->winterCampdate;
/*---End-Trainging--*/
$offerName = $branchesInfo->offerName;
$BranchSpecialNoteSales = $branchesInfo->BranchSpecialNoteSales;
$offerPlanname = $branchesInfo->offerPlanname;
$discountAmount = $branchesInfo->discountAmount;
$finalAmount = $branchesInfo->finalAmount;
/*Added-Additioanl-field in Sales-04-07-2024*/
$legalChargesSales = $branchesInfo->legalChargesSales;
$brSetupinsChargSales = $branchesInfo->brSetupinsChargSales;
$numInialKitSales = $branchesInfo->numInialKitSales;
$franchiseTenure = $branchesInfo->franchiseTenure;
/*ENd-Additioanl-field-04-07-2024*/
$welComeFolderStatus = $branchesInfo->welComeFolderStatus;
$welComeFolderDtm = $branchesInfo->welComeFolderDtm;
$trainingAmount = $branchesInfo->trainingAmount;
$societyServiceamount = $branchesInfo->societyServiceamount;
$totalAmount = $branchesInfo->totalAmount;
$gstAmount = $branchesInfo->gstAmount;
$totalfranchisegstFund = $branchesInfo->totalfranchisegstFund;
$legalCharges = $branchesInfo->legalCharges;
$legalChargesdue = $branchesInfo->legalChargesdue;
$totalgstCharges = $branchesInfo->totalgstCharges;
$totalPaidamount = $branchesInfo->totalPaidamount;
$dueFranchiseamt = $branchesInfo->dueFranchiseamt;
$kitCharges = $branchesInfo->kitCharges;
$numinitialKit = $branchesInfo->numinitialKit;
$totalKitsamt = $branchesInfo->totalKitsamt;
$kitamtReceived = $branchesInfo->kitamtReceived;
$dueKitamount = $branchesInfo->dueKitamount;
$installationDate = $branchesInfo->installationDate;
$finaltotalamtDue = $branchesInfo->finaltotalamtDue;
$specialRemark = $branchesInfo->specialRemark;
$transporttravCharge = $branchesInfo->transporttravCharge;
$brsetupinstachargReceived = $branchesInfo->brsetupinstachargReceived;
$brsetupinstachargDue = $branchesInfo->brsetupinstachargDue;
$travelAmount = $branchesInfo->travelAmount;
$receivedtravelAmount = $branchesInfo->receivedtravelAmount;
$duetravelAmount = $branchesInfo->duetravelAmount;
$transportCharges = $branchesInfo->transportCharges;
$transportAmtreceived = $branchesInfo->transportAmtreceived;
$duetransportCharges = $branchesInfo->duetransportCharges;
$upgradeUptoclass = $branchesInfo->upgradeUptoclass;
$branchStatus = $branchesInfo->branchStatus;
$brInstallationStatus = $branchesInfo->brInstallationStatus;
$undertakingAck = $branchesInfo->undertakingAck;
$agreementDraftReceiveddate = $branchesInfo->agreementDraftReceiveddate;
$compFileSubmit = $branchesInfo->compFileSubmit;
$fileCLoserDate = $branchesInfo->fileCLoserDate;
$branchStatusRemark = $branchesInfo->branchStatusRemark;
/*---Despatch--*/
$insmatDispatchdate = $branchesInfo->insmatDispatchdate; 
$DetailsReceiptmail = $branchesInfo->DetailsReceiptmail;
$ConfBrinsScheduledemail = $branchesInfo->ConfBrinsScheduledemail;
$Materialrecdate = $branchesInfo->Materialrecdate;
$BrinsScheduleddate = $branchesInfo->BrinsScheduleddate;
$BrinsScheduledemail = $branchesInfo->BrinsScheduledemail;
$brInstalationRemark = $branchesInfo->brInstalationRemark;
$videoFeedbackbr = $branchesInfo->videoFeedbackbr;
$writtenFeedbackbr = $branchesInfo->writtenFeedbackbr;
$ShoppinPortSharedDate = $branchesInfo->ShoppinPortSharedDate;
$ShoppinPortTraining = $branchesInfo->ShoppinPortTraining;
$ShoppinPortTrainingDate = $branchesInfo->ShoppinPortTrainingDate;
$ShoppinPortRemark = $branchesInfo->ShoppinPortRemark;
$returnItems = $branchesInfo->returnItems;
$modeOfDespatch = $branchesInfo->modeOfDespatch;
$NumOfBoxes = $branchesInfo->NumOfBoxes;
$PoDNum = $branchesInfo->PoDNum;
$SpecificGiftOffer = $branchesInfo->SpecificGiftOffer;
$ConfBrInsOverPhone = $branchesInfo->ConfBrInsOverPhone;
$shortComming = $branchesInfo->shortComming;
$solutionShortComming = $branchesInfo->solutionShortComming;
/*--End-Despatch--*/
/*--new-custom-Accounts--*/
$ledgerMarch = $branchesInfo->ledgerMarch;
$ledgerJune = $branchesInfo->ledgerJune;
$ledgerSeptember = $branchesInfo->ledgerSeptember;
$ledgerDecember = $branchesInfo->ledgerDecember;
$reminderAMCStatus1Dec = $branchesInfo->reminderAMCStatus1Dec;
$reminderAMCStatus10Dec = $branchesInfo->reminderAMCStatus10Dec;
$reminderAMCStatus15Dec = $branchesInfo->reminderAMCStatus15Dec;
$reminderAMCStatus19Dec = $branchesInfo->reminderAMCStatus19Dec;
$reminderAMCStatus20Dec = $branchesInfo->reminderAMCStatus20Dec;
$RemarkforAMCmail = $branchesInfo->RemarkforAMCmail;
$InvoiceAMCClearance = $branchesInfo->InvoiceAMCClearance;
$PenaltyMailnoncle = $branchesInfo->PenaltyMailnoncle;
$invoiceNumberAll = $branchesInfo->invoiceNumberAll;

/*--End-Accounts--*/
/*---it--*/
$customWebsiteLink = $branchesInfo->customWebsiteLink;
/*--it--*/

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Branches Management
        <small>Add / Edit Brances</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Branches Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="" method="post" id="" role="form" >
                        <div class="box-body">
                          <!-- <?php //if ($role!=12 || $role!=13) {  ?> -->
                          <?php if ($role==2 || $role==20 || $role==21 || $role==21 || $role==16 || $role==17 || $role==18 || $role==19 || $role==24 || $role==23) { ?>  
                          <div class="row">
                                <div class="col-md-6 mb-sm">
                                  <div class="form-group"><label class="control-label">Franchise No.</label><input type="text" class="form-control check"  autocomplete="off" name="franchiseNumber" value="<?php echo $franchiseNumber; ?>" readonly ><span class="error"></span>
                                    </div>
                                    <div class="form-group"><label class="control-label">Branch location address(Premise) <span class="required">*</span></label><textarea type="textarea" class="form-control check" name="branchLocAddressPremise"><?php echo $branchLocAddressPremise; ?></textarea><span class="error"></span>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label class="control-label">Current Status</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="currentStatus" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($currentStatus == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($currentStatus == INACTIVE) {echo "selected=selected";} ?> >InActive</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group">
                                        <label class="control-label">Franchise Name</label><input type="text" class="form-control check" autocomplete="off" name="franchiseName" value="<?php echo $franchiseName; ?>"><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <label for="mobile">Mobile Number</label>
                                        <input type="text" class="form-control check required digits" id="mobile" value="<?php echo $mobile; ?>" readonly name="mobile" maxlength="10">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Installation Date</label><input type="date" class="form-control check" autocomplete="off" name="installationDate" value="<?php echo $installationDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                          </div>
                        <?php } ?>
                            <div class="row">
                                   <input type="hidden" value="<?php echo $branchesId; ?>" name="branchesId" id="branchesId"  />
                                   <?php
                                   if ($is_admin != 1 || $role!=2) {
                                      ?>
                                       <input type="hidden" value="<?php echo $applicantName; ?>" name="applicantName" id="applicantName" />
                                       <input type="hidden" value="<?php echo $branchAddress; ?>" name="branchAddress" id="branchAddress" />
                                      <?php
                                   }
                                    ?>
                                <?php  if($is_admin == 1 || $role==2) { ?>

                                <div class="col-md-6">   
                                <div class="form-group"><label class="control-label">Franchise No.</label><input type="text" class="form-control check"  autocomplete="off" name="franchiseNumber" value="<?php echo $franchiseNumber; ?>" readonly ><span class="error"></span></div>                             
                                    <div class="form-group">
                                        <label for="applicantName">Name of Applicant</label>
                                        <input type="text" class="form-control check required" value="<?php echo $applicantName; ?>" readonly id="applicantName" name="applicantName" maxlength="256" />
                                       
                                        
                                    </div>
                                    <div class="form-group">
                                        <label for="mobile">Mobile Number</label>
                                        <input type="text" class="form-control check required digits" id="mobile" value="<?php echo $mobile; ?>" readonly name="mobile" maxlength="10">
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Sales T.L. <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="salesTeamlead" readonly value="<?php echo $salesTeamlead; ?>"><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <label for="stateName">State</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchState; ?>" readonly id="branchState" name="branchState" maxlength="256" />
                                    </div>
                                    <div class="form-group">
                                        <label for="branchAmountReceived">Amount Received</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchAmountReceived; ?>" readonly id="branchAmountReceived" name="branchAmountReceived" maxlength="256" />
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="branchAddress">Address</label>
                                        <textarea class="form-control check required" id="branchAddress" name="branchAddress" readonly value="<?php echo $branchAddress; ?>"><?php echo $branchAddress; ?></textarea>
                                    </div>
                                    

                                    <div class="form-group">
                                        <label class="control-label">Undertaking And Commitment - Sales</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="undertakingCommitment" readonly value="<?php echo $undertakingCommitment; ?>"><span class="error"></span>
                                    </div>
                                    <!----->
                                    <div class="form-group">
                                        <label for="branchFrAssignedAdmissionDepartment">Franchise Assigned to Admission Department</label>
                                        <select class="form-control check required" id="branchFrAssignedAdmissionDepartment" readonly name="branchFrAssignedAdmissionDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ADMusers))
                                            {
                                                foreach ($ADMusers as $ADMbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $ADMbranchFranchiseAssignedDesigninguserText = $ADMbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $ADMbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($ADMbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedAdmissionDepartment', $branchFrAssignedAdmissionDepartment)) {echo "selected=selected";} ?>><?= $ADMbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?> 
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedDispatchDepartment">Franchise Assigned to Dispatch Department</label>
                                        <select class="form-control check required" id="branchFrAssignedDispatchDepartment" readonly name="branchFrAssignedDispatchDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($DISusers))
                                            {
                                                foreach ($DISusers as $DISbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $DISbranchFranchiseAssignedDesigninguserText = $DISbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $DISbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($DISbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedDispatchDepartment', $branchFrAssignedDispatchDepartment)) {echo "selected=selected";} ?>><?= $DISbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>    
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedMaterialDepartment">Franchise Assigned to Material Department</label>
                                        <select class="form-control check required" id="branchFrAssignedMaterialDepartment" readonly name="branchFrAssignedMaterialDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($MATusers))
                                            {
                                                foreach ($MATusers as $MATbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $MATbranchFranchiseAssignedDesigninguserText = $MATbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $MATbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($MATbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedMaterialDepartment', $branchFrAssignedMaterialDepartment)) {echo "selected=selected";} ?>><?= $MATbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>              
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedDigitalDepartment">Franchise Assigned to Digital Department</label>
                                        <select class="form-control check required" id="branchFrAssignedDigitalDepartment" readonly name="branchFrAssignedDigitalDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($DMusers))
                                            {
                                                foreach ($DMusers as $DMbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $DMbranchFranchiseAssignedDesigninguserText = $DMbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $DMbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($DMbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedDigitalDepartment', $branchFrAssignedDigitalDepartment)) {echo "selected=selected";} ?>><?= $DMbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFrAssignedTrainingDepartment">Franchise Assigned to Training Department</label>
                                        <select class="form-control check required" id="branchFrAssignedTrainingDepartment" readonly name="branchFrAssignedTrainingDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($TRMusers))
                                            {
                                                foreach ($TRMusers as $TRMbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $TRMbranchFranchiseAssignedDesigninguserText = $TRMbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $TRMbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($TRMbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedTrainingDepartment', $branchFrAssignedTrainingDepartment)) {echo "selected=selected";} ?>><?= $TRMbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <!------>
                                    <div class="form-group">
                                        <label class="control-label">Offer Amount </label><input type="text" class="form-control check" readonly autocomplete="off" name="offerName" value="<?php echo $offerName; ?>"><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                      <div class="form-group"><label class="control-label">Special Note for the Sales</label>
                                        <textarea class="form-control check required" id="branchAddress" name="BranchSpecialNoteSales" readonly value="<?php echo $branchAddress; ?>"><?php echo $BranchSpecialNoteSales; ?></textarea>
                                      </div>
                                    </div>                                  
                                    <div class="form-group">
                                        <!-- <label class="control-label">Complete Franchise amount Date (within 3 months from confirmation amount )</label> Replaced by-vikramsir-->
                                        <label class="control-label">Complete franchise amount due date given</label><input type="date" class="form-control check" autocomplete="off" name="completeFranchiseAmt" readonly value="<?php echo $completeFranchiseAmt; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                <div class="form-group">
                                        <label for="email">Email address</label>
                                        <input type="text" class="form-control check required email" id="email" value="<?php echo $branchEmail; ?>" readonly name="branchEmail" maxlength="128">
                                    </div>
                                    <div class="form-group">
                                        <label for="cityName">City</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchcityName; ?>" id="branchcityName" readonly name="branchcityName" maxlength="256" />
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="branchSalesDoneby">Sales Done By</label>
                                        <input type="text" class="form-control check required" value="<?php echo $branchSalesDoneby; ?>"  readonly id="branchSalesDoneby" name="branchSalesDoneby" maxlength="256" />
                                    </div>
                                    
                                    
                                    <div class="form-group"><label class="control-label">Booking Date</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="bookingDate" readonly value="<?php echo $bookingDate; ?>"><span class="error"></span>
                                    </div>
                                    <!-- <div class="form-group">
                                        <label class="control-label">Confirmation Amount Date (33k + GST) (within 30days)</label><input type="date" class="form-control check" autocomplete="off" name="confirmationAmt33kGST" value="<?php //echo $confirmationAmt33kGST; ?>"><span class="error"></span>
                                    </div> Removed by-vikramsir-->
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                                        <select class="form-control check required" readonly id="branchFranchiseAssigned" name="branchFranchiseAssigned">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('branchFranchiseAssigned', $branchFranchiseAssigned)) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedDesigning">Franchise Assigned to Designing</label>
                                        <select class="form-control check required" readonly id="branchFranchiseAssignedDesigning" name="branchFranchiseAssignedDesigning">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($dusers))
                                            {
                                                foreach ($dusers as $drl)
                                                {
                                                    $duserText = $drl->name;
                                                    ?>
                                                    <option value="<?php echo $drl->userId ?>" <?php if($drl->userId == set_value('branchFranchiseAssignedDesigning', $branchFranchiseAssignedDesigning)) {echo "selected=selected";} ?>><?= $duserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="branchFranchiseAssignedLegalDepartment">Franchise Assigned to LegalDepartment</label>
                                        <select class="form-control check required" id="branchFranchiseAssignedLegalDepartment" readonly name="branchFranchiseAssignedLegalDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($LDusers))
                                            {
                                                foreach ($LDusers as $LDbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $LDbranchFranchiseAssignedDesigninguserText = $LDbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $LDbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($LDbranchFranchiseAssignedDesigningrl->userId == set_value('branchFranchiseAssignedLegalDepartment', $branchFranchiseAssignedLegalDepartment)) {echo "selected=selected";} ?>><?= $LDbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    <!------->
                                    <div class="form-group">
                                        <label for="branchFrAssignedAccountsDepartment">Franchise Assigned to Accounts Department</label>
                                        <select class="form-control check required" id="branchFrAssignedAccountsDepartment" readonly name="branchFrAssignedAccountsDepartment">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($ACusers))
                                            {
                                                foreach ($ACusers as $ACbranchFranchiseAssignedDesigningrl)
                                                {
                                                    $ACbranchFranchiseAssignedDesigninguserText = $ACbranchFranchiseAssignedDesigningrl->name;
                                                    ?>
                                                    <option value="<?php echo $ACbranchFranchiseAssignedDesigningrl->userId ?>" <?php if($ACbranchFranchiseAssignedDesigningrl->userId == set_value('branchFrAssignedAccountsDepartment', $branchFrAssignedAccountsDepartment)) {echo "selected=selected";} ?>><?= $ACbranchFranchiseAssignedDesigninguserText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                                    
                                                
                                        </select>
                                    </div>
                                    
                                    <!--------->
                                    <div class="form-group">
                                        <label class="control-label">Offer Plan Name </label><input type="text" class="form-control check" autocomplete="off" readonly name="offerPlanname" value="<?php echo $offerPlanname; ?>"><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Discount </label><input type="text" class="form-control check" autocomplete="off" readonly name="discountAmount" value="<?php echo $discountAmount; ?>"><span class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Final Amount </label><input type="text" class="form-control check" autocomplete="off" readonly name="finalAmount" value="<?php echo $finalAmount; ?>"><span class="error"></span>
                                    </div>
                                    <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Legal Charges (Sales) </label><input type="text" class="form-control" autocomplete="off" name="legalChargesSales" readonly value="<?php echo $legalChargesSales; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Setup & Installation Charges </label><input type="text" class="form-control" autocomplete="off" name="brSetupinsChargSales" readonly value="<?php echo $brSetupinsChargSales; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">No. Of Initial Student KIT Offered </label><input type="text" class="form-control" autocomplete="off" name="numInialKitSales" readonly value="<?php echo $numInialKitSales; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Franchise Tenure </label><input type="text" class="form-control" readonly autocomplete="off" name="franchiseTenure" value="<?php echo $franchiseTenure; ?>"><span class="error"></span></div>
                                </div>
                                    
                                    
                                </div>
                            <?php }else{
                            ?>
                            <!--<input type="hidden" value="<?php //echo $applicantName; ?>" id="applicantName" name="applicantName" />
                            <input type="hidden" value="<?php //echo $branchAddress; ?>" id="branchAddress" name="branchAddress" />-->
                            
                            <!----Start-Legal-Section------>
                                <?php
                                    }if ($is_admin == 1 || $role==24) {
                                     ?>
                                  <div class="row">
                                     <?php if ($role==24) { ?>
                                     <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">LICENSE DETAIL</h4>
                                      </div>
                                    </div>
                                    <?php } ?>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">License number</label><input type="text" class="form-control check" readonly autocomplete="off" name="licenseNumber" value="<?php echo $licenseNumber; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">License Shared on</label><input type="text" class="form-control check" readonly autocomplete="off" name="licenseSharedon" value="<?php echo $licenseSharedon; ?>"><span class="error"></span></div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Valid from Date <span class="required">*</span></label><input type="date" class="form-control check" data-plugin-datepicker="" readonly autocomplete="off" name="validFromDate" value="<?php echo $validFromDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Valid  TIll Date <span class="required">*</span></label><input type="date" class="form-control check" data-plugin-datepicker="" readonly autocomplete="off" name="validTillDate" value="<?php echo $validTillDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                </div>
                               <div class="row">
                                <?php if ($role==24) { ?>
                                <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">FORMS</h4>
                                      </div>
                                    </div>
                                <?php } ?>    
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Forms and Documents completed <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" readonly name="formsDocumentsCompleted" value="<?php echo $formsDocumentsCompleted; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form</label><input type="date" class="form-control check" data-plugin-datepicker="" autocomplete="off" name="onboardingForm" readonly value="<?php echo $onboardingForm; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                 <div class="col-md-4 mb-sm">
                                    <!-- <div class="form-group"><label class="control-label">Onboarding Form Received</label><input type="date" class="form-control check" autocomplete="off" name="onboardingFormReceived" value=""><span class="error"></span>
                                    </div> -->
                                    <label class="control-label">Onboarding Form Received</label>
                                    <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" readonly name="onboardingFormReceived" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($onboardingFormReceived == ACTIVE) {echo "selected=selected";} ?>> Yes </option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($onboardingFormReceived == INACTIVE) {echo "selected=selected";} ?> > No </option>
                                        </select>
                                </div>
                                <div class="col-md-8 mb-sm">
                                    <div class="form-group"><label class="control-label">Onboarding Form - Remark</label><input type="text" class="form-control check" autocomplete="off" name="onboardingFormRemark" readonly value="<?php echo $onboardingFormRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">AGREEMENT DETAIL</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                                <div class="col-md-3 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Tenure <span class="required">*</span></label><input type="text" class="form-control check" autocomplete="off" name="agreementTenure" value="<?php echo $agreementTenure; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Final Agreement pdf shared <span class="required">*</span></label><input type="date" class="form-control check" autocomplete="off" name="finalAgreementShared" value=""><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Draft</label><input type="date" class="form-control check" autocomplete="off" name="agreementDraftdate" value="<?php echo $agreementDraftdate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Agreement Draft Received On</label><input type="date" class="form-control check" autocomplete="off" name="agreementDraftReceiveddate" value="<?php echo $agreementDraftReceiveddate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                             </div>
                             <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">FILE DETAIL</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">Complete File Subbmitted On</label><input type="date" class="form-control check" autocomplete="off" name="compFileSubmit" value="<?php echo $compFileSubmit; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                <div class="col-md-4 mb-sm">
                                    <div class="form-group"><label class="control-label">File Closer Date</label><input type="date" class="form-control check" autocomplete="off" name="fileCLoserDate" value="<?php echo $fileCLoserDate; ?>"><span class="error"></span>
                                    </div>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Udertaking Acknowledgement Received <span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="undertakingAck" tabindex="-1" aria-hidden="true">
                                            <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($undertakingAck == ACTIVE) {echo "selected=selected";} ?>>Yes</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($undertakingAck == INACTIVE) {echo "selected=selected";} ?> >No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Status <span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="branchStatus" tabindex="-1" aria-hidden="true">
                                            
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($branchStatus == ACTIVE) {echo "selected=selected";} ?>>Active</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($branchStatus == INACTIVE) {echo "selected=selected";} ?> >In Active</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Installation Status<span class="required">*</span></label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="brInstallationStatus" tabindex="-1" aria-hidden="true">
                                            
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($brInstallationStatus == ACTIVE) {echo "selected=selected";} ?>>Installed</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($brInstallationStatus == INACTIVE) {echo "selected=selected";} ?> >Not Installed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-sm">
                                    <div class="form-group"><label class="control-label">Branch Status Remark</label><input type="text" class="form-control check" autocomplete="off" name="branchStatusRemark" value="<?php echo $branchStatusRemark; ?>"><span class="error"></span>
                                    </div>
                                </div>
                                
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">BRANCH DOCUMENT - IDENTITY PROOF</h4>
                                        <h6 style="text-align: center;font-weight: bold;font-size: 14px;">INDIVIDUAL DOCUMENT</h6>
                                      </div>
                                    </div>
                                <?php } ?>
                                <!---Check-List--->
                                <!---Check-List--->
                                <?php
                                    if (!empty($legalDocumentsIndividual)) {
                                        foreach ($legalDocumentsIndividual as $record) {
                                            $module = $record['module'];
                                            ?>
                                            <?php
                                            foreach ($record as $key => $value) {
                                                ?>
                                                <?php
                                                if ($key !== 'module') {
                                                    ?>
                                                    <div class="col-md-4 mb-sm">
                                                        <div class="form-group">
                                                            <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                            <?php $fieldName = key($record); ?>
                                                            
                                                            <input type="checkbox" name="accesslegalDocumentsIndividual[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                            
                                                            <?php if ($record['module'] == 'Passport_Size_Photo') { ?>
                                                                <p class="float-left" style="margin-left: -559px;font-weight: bold;text-decoration: underline;">ADDRESS PROOF:-</p>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                <?php
                                                }
                                                ?>
                                            <?php
                                            }
                                            ?>
                                            <?php
                                        }
                                    }
                                ?>
                              </div>  
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">PROPRIETORSHIP FIRM DOCUMEN</h4>
                                      </div>
                                    </div>
                                <?php } ?>
                                <!---Check-List--->
                                <!-- check list  -->
                                <?php
                                    if(!empty($legalDocumentsProprietorship))
                                    {
                                        
                                        foreach($legalDocumentsProprietorship as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsProprietorship[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
                                                </div>
                                            <?php
                                            }
                                            ?>
                                            
                                        <?php 
                                        }
                                        ?>
                                        
                                            <?php
                                        }
                                    }
                                ?>
                              </div>
                              <div class="row">
                                <?php if ($role==24) { ?>
                               <div class="row">
                                      <div col-md-12>
                                        <h4 class="legal-hed-title">HUF - DOCUMENT</h4>
                                      </div>
                                      <?php
                                    if(!empty($legalDocumentsHUF))
                                    {
                                        
                                        foreach($legalDocumentsHUF as $record)
                                        {
                                            $module = $record['module'];
                                        ?>
                                        <?php
                                        foreach($record as $key => $value){
                                            ?>
                                            <?php
                                            if($key !== 'module'){
                                                ?>
                                                <div class="col-md-4 mb-sm">
                                                    <div class="form-group">
                                                        <label class="control-label"><?= ucfirst(str_replace('_', ' ', $record['module'])) ?></label><br>
                                                        <?php $fieldName = key($record); ;?>
                                                        
                                                        <input type="checkbox" name="accesslegalDocumentsHUF[<?= $record['module'] ?>]" <?= ($value == 1) ? 'checked' : ''; ?> />
                                                    </div>
