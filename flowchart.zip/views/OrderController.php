<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class OrderController extends CI_Controller {

    public function all_orders()
    {
        $consumerKey = 'ck_0d0bbcdd0e50d5d503b591509a3a2d2c7c20f579';
        $consumerSecret = 'cs_8caa2a781b70569c7557d08bbc38433d587f4994';

        $page = $this->input->get('page') ?? 1;
        $perPage = 10;

        $apiUrl = "https://shop.theischool.com/wp-json/wc/v3/orders?page={$page}&per_page={$perPage}";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, $consumerKey . ":" . $consumerSecret);
        curl_setopt($ch, CURLOPT_HEADER, true);
        $response = curl_exec($ch);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($response, 0, $header_size);
        $body = substr($response, $header_size);
        curl_close($ch);

        // Parse header to get total pages
        preg_match('/X-WP-TotalPages: (\d+)/i', $header, $matches);
        $totalPages = $matches[1] ?? 1;

        $orders = json_decode($body, true);
        $data['orders'] = $orders;
        $data['currentPage'] = $page;
        $data['totalPages'] = $totalPages;
        $data['showPrintButton'] = true; // Add flag to show print button

        $this->load->view('order_view', $data);
    }
}