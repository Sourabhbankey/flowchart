<?php
$emailtempId = $emailtemplateInfo->emailtempId;
$franchiseNumberArray = explode(",",$emailtemplateInfo->franchiseNumber);
$emailTemp_type  = $emailtemplateInfo->emailTemp_type;
$title  = $emailtemplateInfo->title;
$to_email = $emailtemplateInfo->to_email;
$email_body = $emailtemplateInfo->email_body;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i>Management
        <small>Add / Edit </small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter  Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                         <form role="form" action="<?php echo base_url() ?>emailtemplate/editEmailtemplate" enctype="multipart/form-data" method="post" id="editEmailtemplate">
                            <div class="box-body">
                                <div class="row">
                                    <input type="hidden" value="<?php echo $emailtempId; ?>" name="emailtempId" id="emailtempId" /> 
                                 <?php
                                  $franchiseNumberArray = isset($emailtemplateInfo->franchiseNumber)
                                      ? array_map('trim', explode(",", $emailtemplateInfo->franchiseNumber))
                                      : [];
                                  ?>
                                  <div class="col-md-12">
                                      <div class="form-group">
                                          <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                          <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" disabled>
                                              <option value="0">Select Franchise</option>
                                              <?php
                                              if (!empty($branchDetail)) {
                                                  foreach ($branchDetail as $bd) {
                                                      $franchiseNumber = trim((string)$bd->franchiseNumber);
                                                      $selected = in_array($franchiseNumber, $franchiseNumberArray) ? 'selected="selected"' : '';
                                                      echo "<option value=\"$franchiseNumber\" $selected>$franchiseNumber</option>";
                                                  }
                                              }
                                              ?>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-4"> 
                                      <div class="form-group">
                                          <label>Email Template Type:</label>
                                          <select class="form-control required" id="emailTemp_type" name="emailTemp_type" required>
                                              <option value="">-- Select Template Type --</option>
                                              <option value="welcome" <?php if($emailTemp_type == 'welcome') echo 'selected'; ?>>Welcome Template</option>
                                              <option value="reminder" <?php if($emailTemp_type == 'reminder') echo 'selected'; ?>>Reminder Template</option>
                                              <option value="followup" <?php if($emailTemp_type == 'followup') echo 'selected'; ?>>Follow-up Template</option>
                                              <option value="promotion" <?php if($emailTemp_type == 'promotion') echo 'selected'; ?>>Promotion Template</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-4"> 
                                    <div class="form-group">
                                        <label>Title:</label>
                                        <input type="text" class="form-control required" id="title" name="title" value="<?php echo $title; ?>" />
                                    </div>
                                </div>
                                <div class="col-md-4"> 
                                    <div class="form-group">
                                        <label>To Email:</label>
                                        <input type="email" class="form-control required" id="to_email" name="to_email" value="<?php echo $to_email; ?>" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                  <div class="form-group">
                                    <label for="email_body">Email Body</label>
                                    <textarea class="form-control" id="email_body" name="email_body" rows="3"><?php echo $email_body; ?></textarea>
                                  </div>
                                </div>
                          </div>
                      </div>
                      <div class="box-footer">
                          <input type="submit" class="btn btn-primary" value="Submit" />
                          <input type="reset" class="btn btn-default" value="Reset" />
                      </div>
                  </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>