<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-money" aria-hidden="true"></i> Email Template Management
            <!-- <small>List Standard Classes Fee Templates</small> -->
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="text-right mb-3">
                    <a href="<?php echo base_url(); ?>emailtemplate/add" class="btn btn-primary">
                        <i class="fa fa-plus"></i> Add New
                    </a>
                </div>
                <div class="box">
                    <!-- <div class="box-header">
                        <h3 class="box-title">Standard Classes Fee Templates</h3>
                        <div class="box-tools">
                            <div class="d-flex align-items-center">
                                <form action="<?php //echo base_url() ?>emailtemplate/classesFeeTemplateListing" method="POST" id="searchList" class="mr-3">
                                    <div class="input-group">
                                        <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm" style="width: 150px;" placeholder="Search" />
                                        <div class="input-group-btn">
                                            <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div> -->
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding1">
                      <table id="example" class="display table table-hover responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                  <th>ID</th>
                                  <th>Franchise No.</th>
                                  <th>Email Template type</th>
                                  <th>Title</th>
                                  <th>To Email</th>
                                  <th>Email Content</th>
                                  <th>Email Attache</th>
                                  <th>Created By</th>
                                  <th>Created Date</th>
                                  <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($records)) {
                                $counter=1;
                                foreach ($records as $emailtemplate) { ?>
                                    <tr>
                                          <td><?php echo $counter++; ?></td>
                                          <td><?php echo $emailtemplate->franchiseNumber; ?></td>
                                          <td><?php echo $emailtemplate->emailTemp_type; ?></td>
                                          <td><?php echo $emailtemplate->title; ?></td>
                                          <td><?php echo $emailtemplate->to_email; ?></td>
                                          <td><?php echo $emailtemplate->email_body; ?></td>
                                          <td>Attachement</td>
                                          <td><?php echo $emailtemplate->createdByName; ?></td>
                                        <td><?php echo !empty($emailtemplate->createdDtm) ? date('Y-m-d', strtotime($emailtemplate->createdDtm)) : ''; ?></td>
                                        <td>
                                              <?php
                                                $userRole = $this->session->userdata('role');
                                                if ($userRole != 25) {
                                              ?>
                                            
                                        <?php } ?>
                                           
                                            
                                        </td>
                                    </tr>
                            <?php }
                            } ?>
                        </tbody>
                </table>

                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</div>

<style>
    /* Ensure box-tools content is aligned properly */
    .box-tools .d-flex {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 10px;
        /* Space between elements in box-tools */
    }

    .box-tools form {
        margin-bottom: 0;
        /* Remove default form margin */
    }

    .text-right.mb-3 {
        margin-bottom: 15px;
        /* Space below the Add New button */
    }
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>

<script>
    $(document).ready(function() {
        $('.deleteFeeTemplate').click(function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (confirm('Are you sure you want to delete this fee emailtemplate?')) {
                $.ajax({
                    url: '<?php echo base_url('emailtemplate/deleteclassesFeeTemplate'); ?>',
                    type: 'POST',
                    data: {
                        dcfeetempId: id
                    },
                    success: function(response) {
                        alert('Fee emailtemplate deleted successfully');
                        location.reload();
                    },
                    error: function() {
                        alert('Error deleting fee emailtemplate');
                    }
                });
            }
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
