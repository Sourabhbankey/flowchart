<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Email Template Management
            <small><?php echo isset($emailtemplateInfo) ? 'Edit' : 'Add'; ?> Template</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Email Template Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" action="<?php echo base_url() ?>emailtemplate/<?php echo isset($emailtemplateInfo) ? 'editEmailtemplate' : 'addNewEmailtemplate'; ?>" enctype="multipart/form-data" method="post" id="addNewEmailtemplate">
                        <div class="box-body">
                            <div class="row">
                                <?php if (isset($emailtemplateInfo)) { ?>
                                    <input type="hidden" name="emailtempId" value="<?php echo $emailtemplateInfo->emailtempId; ?>">
                                <?php } ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchFranchiseData(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                    foreach ($branchDetail as $bd) {
                                                        $selected = ($bd->franchiseNumber == (isset($emailtemplateInfo) ? $emailtemplateInfo->franchiseNumber : $defaultFranchise)) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($bd->franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($bd->franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-4"> 
                                    <div class="form-group">
                                        <label>Template Type:</label>
                                        <select name="emailTemp_type" class="form-control" required>
                                            <option value="">-- Select Template Type --</option>
                                            <option value="welcome" <?php echo (isset($emailtemplateInfo) && $emailtemplateInfo->emailTemp_type == 'welcome') ? 'selected' : ''; ?>>Welcome Template</option>
                                            <option value="reminder" <?php echo (isset($emailtemplateInfo) && $emailtemplateInfo->emailTemp_type == 'reminder') ? 'selected' : ''; ?>>Reminder Template</option>
                                            <option value="followup" <?php echo (isset($emailtemplateInfo) && $emailtemplateInfo->emailTemp_type == 'followup') ? 'selected' : ''; ?>>Follow-up Template</option>
                                            <option value="promotion" <?php echo (isset($emailtemplateInfo) && $emailtemplateInfo->emailTemp_type == 'promotion') ? 'selected' : ''; ?>>Promotion Template</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4"> 
                                    <div class="form-group">
                                        <label>Title:</label>
                                        <input type="text" name="title" class="form-control" value="<?php echo isset($emailtemplateInfo) ? htmlspecialchars($emailtemplateInfo->title) : ''; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4"> 
                                    <div class="form-group">
                                        <label>To Email:</label>
                                        <input type="text" name="to_email" id="to_email" class="form-control" value="<?php echo isset($emailtemplateInfo) ? htmlspecialchars($emailtemplateInfo->to_email) : (isset($branchEmail) ? htmlspecialchars($branchEmail) : ''); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        <label>Email Body:</label>
                                        <textarea name="email_body" id="email_body" rows="6" class="form-control" required><?php echo isset($emailtemplateInfo) ? htmlspecialchars($emailtemplateInfo->email_body) : ''; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-4"> 
                                    <div class="form-group">
                                        <label>Attachment (Optional):</label>
                                        <input type="file" name="attachment" class="form-control">
                                        <?php if (isset($emailtemplateInfo) && !empty($emailtemplateInfo->attachment_path)) { ?>
                                            <p>Current Attachment: <a href="<?php echo $emailtemplateInfo->attachment_path; ?>" target="_blank">View</a></p>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div><!-- Row -->
                        </div><!-- Body -->

                        <div class="box-footer">
                            <button type="submit" id="submitBtn" class="btn btn-primary">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-4">
                <?php if ($error = $this->session->flashdata('error')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php if ($success = $this->session->flashdata('success')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '</div>'); ?>
            </div>
        </div>
    </section>
</div>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

<script>
    // Apply CKEditor to the textarea
    CKEDITOR.replace('email_body');

    // Fetch branch email when franchise number changes
    function fetchFranchiseData(franchiseNumber) {
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url(); ?>emailtemplate/fetchBranchEmail',
                type: 'POST',
                data: { franchiseNumber: franchiseNumber },
                dataType: 'json',
                success: function(response) {
                    if (response.branchEmail) {
                        $('#to_email').val(response.branchEmail);
                    } else {
                        $('#to_email').val('');
                        alert('No email found for the selected franchise.');
                    }
                },
                error: function() {
                    alert('Error fetching branch email.');
                }
            });
        } else {
            $('#to_email').val('');
        }
    }

    // Validate emails
    function validateEmails(input) {
        const emails = input.value.split(',').map(email => email.trim());
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        for (let email of emails) {
            if (email && !emailRegex.test(email)) {
                alert("Invalid email: " + email);
                return false;
            }
        }
        return true;
    }

    // Attach email validation to form submission
    $('#addNewEmailtemplate').on('submit', function(e) {
        const toEmailInput = document.getElementById('to_email');
        if (!validateEmails(toEmailInput)) {
            e.preventDefault();
        }
    });
</script>