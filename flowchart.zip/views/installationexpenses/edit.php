<?php
$expId = $installationexpensesInfo->expId;
$schinsTitle = $installationexpensesInfo->schinsTitle;
$instaCity = $installationexpensesInfo->instaCity;
$date = $installationexpensesInfo->date;
$schinsAddress = $installationexpensesInfo->schinsAddress;
$installTL = $installationexpensesInfo->installTL;
$contactTL = $installationexpensesInfo->contactTL;
$franchiseNumberArray = explode(",",$installationexpensesInfo->franchiseNumber);

$selectUserId ='';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Installation Expenses Management
        <!-- <small>Add / Edit Scheduled Installation</small> -->
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <!-- <h3 class="box-title">Enter Scheduled Installation Details</h3> -->
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>installationexpenses/editInstallationexpenses" method="post" id="editScheduledinstallation" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="schinsTitle">Branch Name <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $schinsTitle; ?>" id="schinsTitle" name="schinsTitle" maxlength="256" readonly/>
                                        <input type="hidden" value="<?php echo $expId; ?>" name="expId" id="expId" />
                                    </div>
                                </div>
                             <div class="col-md-3">                                
                                <div class="form-group">
                                    <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                    <input type="text" class="form-control" name="franchiseNumber_view" 
                                           value="<?php echo !empty($franchiseNumberArray) ? implode(', ', $franchiseNumberArray) : 'N/A'; ?>" 
                                           readonly />
                                    <!-- Hidden input to retain the original value -->
                                    <?php
                                    if (!empty($franchiseNumberArray)) {
                                        foreach ($franchiseNumberArray as $fn) {
                                            echo '<input type="hidden" name="franchiseNumber[]" value="' . $fn . '">';
                                        }
                                    }
                                    ?>
                                </div>
                            </div>

                                 <div class="col-md-4">
                                      <div class="form-group">
                                        <label>City</label>
                                        <input type="text" readonly class="form-control" id="city" name="instaCity" value="<?php echo $installationexpensesInfo->instaCity; ?>">
                                      </div>
                                    </div>

                                    <div class="col-md-4">
                                      <div class="form-group">
                                        <label>Installation Address</label>
                                        <input type="text" readonly class="form-control" name="schinsAddress" value="<?php echo $installationexpensesInfo->schinsAddress; ?>">
                                      </div>
                                    </div>

                                    <div class="col-md-4">
                                      <div class="form-group">
                                        <label>Installation TL</label>
                                        <input type="text" readonly class="form-control" name="installTL" value="<?php echo $installationexpensesInfo->installTL; ?>">
                                      </div>
                                    </div>

                                    <div class="col-md-4">
                                      <div class="form-group">
                                        <label>Contact TL</label>
                                        <input type="text" readonly class="form-control" name="contactTL" value="<?php echo $installationexpensesInfo->contactTL; ?>">
                                      </div>
                                    </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h2 class="subhedtitle">Expense</h2>
                                    </div>  
                                </div>  
                                <div class="col-md-12" id="expenseWrapper">
                                    <input type="hidden" name="schinstaId" value="<?= $installationexpensesInfo->id ?? '' ?>">
                                    <!-- <input type="hidden" name="franchiseNumber" value="<?= $installationexpensesInfo->franchiseNumber ?? '' ?>"> -->
                                        <!-- Initial row -->
                                            <?php
                                            $expenses = json_decode($installationexpensesInfo->expenses_json ?? '[]', true);
                                            $lastSrNo = 0;

                                            if (!empty($expenses)) {
                                                foreach ($expenses as $expense) {
                                                    $sr_no = htmlspecialchars($expense['sr_no']);
                                                    if (is_numeric($sr_no) && $sr_no > $lastSrNo) {
                                                        $lastSrNo = $sr_no; // track highest sr_no
                                                    }
                                            ?>
                                            <div class="expense-row row" data-index="<?= $sr_no ?>">
                                                <div class="col-md-1">                                
                                                    <div class="form-group">
                                                        <label>Sr.No.</label>
                                                        <input type="text" class="form-control required" name="expSrnum[]" value="<?= $sr_no ?>" readonly>
                                                    </div>   
                                                </div>
                                                <div class="col-md-3">                                
                                                    <div class="form-group">
                                                        <label>Expense Title</label>
                                                        <input type="text" class="form-control required" name="expTitle[]" value="<?= htmlspecialchars($expense['title']) ?>" readonly>
                                                    </div>   
                                                </div>
                                                <div class="col-md-2">                                
                                                    <div class="form-group">
                                                        <label>Amount</label>
                                                        <input type="text" class="form-control required" name="expAmt[]" value="<?= htmlspecialchars($expense['amount'] ?? '') ?>" readonly>
                                                    </div>   
                                                </div>
                                                <div class="col-md-3">                                
                                                    <div class="form-group">
                                                        <label>Date</label>
                                                        <input type="date" class="form-control required" name="expDate[]" value="<?= htmlspecialchars($expense['date']) ?>" readonly>
                                                    </div>   
                                                </div>
                                                <div class="col-md-3">                                
                                                    <div class="form-group">
                                                        <label>Attachment</label><br>
                                                        <?php if (!empty($expense['attachment'])): ?>
                                                            <a href="<?= htmlspecialchars($expense['attachment']) ?>" target="_blank">View</a><br>
                                                        <?php endif; ?>
                                                        <input type="file" name="expUploadfile[]" disabled>
                                                        <input type="hidden" name="existingFiles[]" value="<?= htmlspecialchars($expense['attachment']) ?>">
                                                    </div>
                                                </div>
                                                <!-- No delete button for existing entries -->
                                            </div>
                                            <?php
                                                }
                                            }
                                            ?>

                                    <!-- Container for new expense rows -->
                                    <div class="expense-row row" data-index="1">
                                            
                                    <!-- Add New Expense Button -->
                                    <div class="col-md-12">
                                        <button type="button" id="addExpenseRow" class="btn btn-success">Add New Expense</button>
                                    </div>
                            </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        button#addExpenseRow {
            float: right;
            margin-bottom: 32px;
        }
    </style>
</div>
<!-- Add New Expense Button -->
<script>
    var lastSrNoFromPHP = <?= (int)$lastSrNo ?>;
</script>

<script>
/*---------------Latest--------------------*/
    var lastSrNoFromPHP = <?= (int)$lastSrNo ?>;

    $(document).ready(function () {
        let srCounter = lastSrNoFromPHP;

        $('#addExpenseRow').on('click', function () {
            srCounter++;

            let rowHtml = `
            <div class="col-md-12 expense-row row">
                <div class="col-md-1">                                
                    <div class="form-group">
                        <label>Sr.No.</label>
                        <input type="text" class="form-control required" name="expSrnum[]" value="${srCounter}" readonly>
                    </div>   
                </div>
                <div class="col-md-3">                                
                    <div class="form-group">
                        <label>Expense Title</label>
                        <input type="text" class="form-control required" name="expTitle[]" required>
                    </div>   
                </div>
                <div class="col-md-2">                                
                    <div class="form-group">
                        <label>Amount</label>
                        <input type="text" class="form-control required" name="expAmt[]" required>
                    </div>   
                </div>
                <div class="col-md-2">                                
                    <div class="form-group">
                        <label>Date</label>
                        <input type="date" class="form-control required" name="expDate[]" required>
                    </div>   
                </div>
                <div class="col-md-3">                                
                    <div class="form-group">
                        <label>Expense Attachment</label>
                        <input type="file" name="expUploadfile[]" multiple>
                    </div>  
                </div>
                <div class="col-md-1">
                    <button type="button" class="btn btn-danger removeRow" style="margin-top:25px;">X</button>
                </div>
            </div>`;

            // Insert above the Add New Expense button
            $('#addExpenseRow').closest('.col-md-12').before(rowHtml);
        });

        // Remove a row
        $(document).on('click', '.removeRow', function () {
            $(this).closest('.expense-row').remove();
            updateSrNumbers();
        });

        // Recalculate Sr. No after row deletion
        function updateSrNumbers() {
            let newCounter = 0;
            $('input[name="expSrnum[]"]').each(function () {
                newCounter++;
                $(this).val(newCounter);
            });
            srCounter = newCounter;
        }
    });


</script>
