
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Installation Expenses Management
        <!-- <small>Add / Edit Scheduled Installation</small> -->
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <!-- <div class="box-header">
                        <h3 class="box-title">Enter Installation Expenses Details</h3>
                    </div> --><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourTask" action="<?php echo base_url() ?>installationexpenses/addNewInstallationexpenses" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                            <option value="">Select Franchise</option>
                                            <?php
                                            if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                              
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="branchSetupName">Branch Name </label>
                                        <input type="text" readonly class="form-control required" id="branchSetupName" name="schinsTitle" maxlength="256">
                                    </div>
                                </div>
                               <!--   -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="city">City <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" id="city" name="instaCity" maxlength="256" readonly>
                                    </div>
                                </div>
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <h2 class="subhedtitle">Expense</h2>
                                    </div>  
                                </div>  
                                <div class="col-md-12" id="expenseWrapper">
                                    <input type="hidden" name="schinstaId" value="<?= $installationexpensesInfo->id ?? '' ?>">
                                    <!-- <input type="hidden" name="franchiseNumber" value="<?= $installationexpensesInfo->franchiseNumber ?? '' ?>"> -->
                                        <!-- Initial row -->
                                        <div class="expense-row row" data-index="1">
                                            <div class="col-md-1">                                
                                                <div class="form-group">
                                                    <label>Sr.No.</label>
                                                    <input type="text" class="form-control required" name="expSrnum[]" required>
                                                </div>   
                                            </div>
                                            <div class="col-md-3">                                
                                                <div class="form-group">
                                                    <label>Expense Title</label>
                                                    <input type="text" class="form-control required" name="expTitle[]" required>
                                                </div>   
                                            </div>
                                            <div class="col-md-2">                                
                                                <div class="form-group">
                                                    <label>Amount</label>
                                                    <input type="text" class="form-control required" name="expAmt[]" required>
                                                </div>   
                                            </div>
                                            <div class="col-md-2">                                
                                                <div class="form-group">
                                                    <label>Date</label>
                                                    <input type="date" class="form-control required" name="expDate[]" required>
                                                </div>   
                                            </div>
                                            <div class="col-md-3">                                
                                                <div class="form-group">
                                                    <label>Expense Attachment</label>
                                                  <input type="file" name="expUploadfile[]" multiple>
                                                </div>  
                                            </div>
                                            <div class="col-md-1">
                                                <button type="button" class="btn btn-danger removeRow" style="margin-top:25px;">X</button>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Add New Expense Button -->
                                    <div class="col-md-12">
                                        <button type="button" id="addExpenseRow" class="btn btn-success">Add New Expense</button>
                                    </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .subhedtitle{
            background: #80b0ec;
            padding: 0.5rem;
            text-align: center;
            font-weight: 600;
            color: #fff;
        }
    </style>
</div>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function fetchAssignedFranchise(franchiseNumber) {
    if (franchiseNumber !== "") {
        $.ajax({
            url: '<?= base_url("installationexpenses/getBranchDetails") ?>',
            type: 'POST',
            data: { franchiseNumber: franchiseNumber },
            dataType: 'json',
            success: function (response) {
                if (Object.keys(response).length > 0) {
                    $('#branchSetupName').val(response.branchSetupName);
                    $('#brcompAddress').val(response.brcompAddress);
                    $('#city').val(response.city);
                    // Optionally set state or others
                } else {
                    $('#branchSetupName').val('');
                    $('#brcompAddress').val('');
                    $('#city').val('');
                    alert("No data found for selected franchise.");
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX error:", error);
                alert("Error fetching branch details.");
            }
        });
    } else {
        $('#branchSetupName, #brcompAddress, #city').val('');
    }
}
</script>
<!-- Expense -->
<!-- Add New Expense Button -->
<script>
$(document).ready(function () {
    let srCounter = 1; // Start from 1

    // Set initial Sr. No. for the first row
    $('input[name="expSrnum[]"]').val(srCounter);

    $('#addExpenseRow').on('click', function () {
        srCounter++; // Increment Sr. No.

        let rowHtml = `
        <div class="expense-row row">
            <div class="col-md-1">                                
                <div class="form-group">
                    <label>Sr.No.</label>
                    <input type="text" class="form-control required" name="expSrnum[]" value="${srCounter}" readonly>
                </div>   
            </div>
            <div class="col-md-3">                                
                <div class="form-group">
                    <label>Expense Title</label>
                    <input type="text" class="form-control required" name="expTitle[]" required>
                </div>   
            </div>
            <div class="col-md-2">                                
                <div class="form-group">
                    <label>Amount</label>
                    <input type="text" class="form-control required" name="expAmt[]" required>
                </div>   
            </div>
            <div class="col-md-2">                                
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" class="form-control required" name="expDate[]" required>
                </div>   
            </div>
            <div class="col-md-3">                                
                <div class="form-group">
                    <label>Expense Attachment</label>
                    <input type="file" name="expUploadfile[]" multiple>
                </div>  
            </div>
            <div class="col-md-1">
                <button type="button" class="btn btn-danger removeRow" style="margin-top:25px;">X</button>
            </div>
        </div>`;

        $('#expenseWrapper').append(rowHtml);
    });

    // Remove a row
    $(document).on('click', '.removeRow', function () {
        $(this).closest('.expense-row').remove();
        updateSrNumbers();
    });

    // Function to re-number Sr. No. after deletion
    function updateSrNumbers() {
        srCounter = 0;
        $('input[name="expSrnum[]"]').each(function () {
            srCounter++;
            $(this).val(srCounter);
        });
    }
});
</script>


<!--End Expense -->