<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i class="fa fa-user-circle-o" aria-hidden="true"></i> HR Management
      <small>Add / Edit Staff</small>
    </h1>
  </section>

  <section class="content">

    <div class="row">
      <!-- left column -->
      <div class="col-md-9">
        <!-- general form elements -->

        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Enter HR Onboarding Details</h3>
          </div><!-- /.box-header -->

          <!-- form start -->
          <?php $this->load->helper("form"); ?>
          <form role="form" id="addStaff" action="<?php echo base_url() ?>hronboard/addNewHronboard" method="post" role="form" enctype="multipart/form-data">
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <h2 class="mb-4 hrfrm-onbord-title">Personal Information</h2>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">First Name</label>
                    <input type="text" name="first_name" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Last Name</label>
                    <input type="text" name="last_name" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Date of Birth</label>
                    <input type="date" name="dob" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Gender</label>
                    <select name="gender" class="form-control" required>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Personal Email</label>
                    <input type="email" name="email" class="form-control" required>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Contact Number</label>
                    <input type="tel" name="contact_number" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Alternative Contact Number</label>
                    <input type="tel" name="alt_contact_number" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Permanent Address</label>
                    <input type="text" name="permanent_address" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Communication Address</label>
                    <input type="text" name="communication_address" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">City</label>
                    <input type="text" name="city" class="form-control" required>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">State</label>
                    <input type="text" name="state" class="form-control" required>
                  </div>
                </div>

                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Pincode</label>
                    <input type="text" name="pincode" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Nationality</label>
                    <input type="text" name="nationality" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Languages Known</label>
                    <input type="text" name="languages_known" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Marital Status</label>
                    <select name="marital_status" id="marital_status" class="form-control" required onchange="toggleAnniversaryDate()">
                      <option value="Single">Single</option>
                      <option value="Married">Married</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-4" id="anniversaryDateDiv">
                  <div class="form-group">
                    <label class="form-label">Date of Anniversary</label>
                    <input type="date" name="anniversary_date" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Social Media</label><small>(Link)</small>
                    <input type="text" name="social_media" class="form-control">
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <h2 class="mb-4 hrfrm-onbord-title">Employment Details</h2>
                  </div>
                </div>
                <!-- <h2 class="mt-5 mb-4">Employment Details</h2> -->
                <!-- <div class="row g-3"> -->
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Designation</label>
                    <input type="text" name="designation" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Joining Date</label>
                    <input type="date" name="joining_date" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Employment Status</label>
                    <select name="employment_status" class="form-control" required>
                      <option value="Full time">Full time</option>
                      <option value="Part time">Part time</option>
                      <option value="Temporary">Temporary</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Pay Rate</label>
                    <select name="pay_rate" class="form-control" required>
                      <option value="Annual">Annual</option>
                      <option value="Monthly">Monthly</option>
                      <option value="Hourly">Hourly</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Previous Organisation</label>
                    <input type="text" name="prev_organisation" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Joining Letter</label>
                    <input type="file" name="file6" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">

                  <label>Relieving Letter</label>
                  <div class="form-group">
                    <input type="file" name="file7" class="form-control">
                  </div>

                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label>Experience Letter</label>
                    <input type="file" name="file8" class="form-control">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <h2 class="mb-4 hrfrm-onbord-title">Bank Details</h2>
                  </div>
                </div>
                <!-- <h2 class="mt-5 mb-4"></h2> -->
                <!-- <div class="row g-3"> -->
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Bank Name</label>
                    <input type="text" name="bank_name" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Branch Name</label>
                    <input type="text" name="branch_name" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Account Holder Name</label>
                    <input type="text" name="account_holder" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Account Number</label>
                    <input type="text" name="account_number" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">IFSC Code</label>
                    <input type="text" name="ifsc_code" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <h2 class="mb-4 hrfrm-onbord-title">Emergency Contact</h2>
                  </div>
                </div>
                <!-- <h2 class="mt-5 mb-4"></h2> -->
                <!-- <div class="row g-3"> -->
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Emergency Contact Name</label>
                    <input type="text" name="emergency_name" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Relationship</label>
                    <input type="text" name="emergency_relationship" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Contact Number</label>
                    <input type="text" name="emergency_contact" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Address</label>
                    <input type="text" name="emergency_address" class="form-control" required>
                  </div>
                </div>

                <div class="col-md-12">
                  <div class="form-group">
                    <h2 class="mb-4 hrfrm-onbord-title">Upload Documents</h2>
                  </div>
                </div>
                <!-- <h2 class="mt-5 mb-4">Upload Documents</h2> -->
                <!-- <div class="row g-3"> -->
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Passport Size Photo</label>
                    <input type="file" name="file" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Adhar Card</label>
                    <input type="file" name="file1" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Address Proof</label>
                    <input type="file" name="file2" class="form-control" required>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">10th Marksheet</label>
                    <input type="file" name="file10" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">12th Marksheet</label>
                    <input type="file" name="file3" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Graduation Marksheet</label>
                    <input type="file" name="file4" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Post-Graduation/Other</label>
                    <input type="file" name="file5" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Certificate Upload</label>
                    <input type="file" name="file11" class="form-control">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="form-label">Police Verification</label>
                    <input type="file" name="file9" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>

          </form>
        </div>
      </div>
    </div>
    <!-- </div> -->
    <div class="col-md-4">
      <div class="form-group">
        <?php
        $this->load->helper('form');
        $error = $this->session->flashdata('error');
        if ($error) {
        ?>
          <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php } ?>
        <?php
        $success = $this->session->flashdata('success');
        if ($success) {
        ?>
          <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $this->session->flashdata('success'); ?>
          </div>
        <?php } ?>

        <div class="row">
          <div class="col-md-12">
            <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
          </div>
        </div>
      </div>
    </div>
  </section>
  <style type="text/css">
    .re-mend-field {
      color: red;
    }

    .hrfrm-onbord-title {
      text-align: center;
      background: #e7e7e7;
      margin: auto;
      border-radius: 5px;
      padding: 3px;
    }
  </style>
</div>
<script type="text/javascript">
  function toggleLastWorking(status) {
    document.getElementById('lastWorkingDiv').style.display = (status === 'inactive') ? 'block' : 'none';
  }
</script>
<script>
  function toggleRelationFields(value) {
    if (value === 'father') {
      document.getElementById('fatherFields').style.display = 'block';
      document.getElementById('spouseFields').style.display = 'none';
    } else {
      document.getElementById('fatherFields').style.display = 'none';
      document.getElementById('spouseFields').style.display = 'block';
    }
  }
</script>
<script>
  function togglePoliceVerification() {
    var check = document.getElementById('policeVerificationCheck');
    var field = document.getElementById('policeVerificationField');
    field.style.display = check.checked ? 'block' : 'none';
  }
</script>
<script>
  function toggleAnniversaryDate() {
    var maritalStatus = document.getElementById('marital_status').value;
    var anniversaryDateDiv = document.getElementById('anniversaryDateDiv');
    anniversaryDateDiv.style.display = (maritalStatus === 'Married') ? 'block' : 'none';

    // If marital status is Single, clear the anniversary date input and remove the required attribute
    var anniversaryInput = document.getElementsByName('anniversary_date')[0];
    if (maritalStatus === 'Single') {
      anniversaryInput.value = '';
      anniversaryInput.removeAttribute('required');
    } else {
      anniversaryInput.setAttribute('required', 'required');
    }
  }

  // Run the function on page load to set the initial state
  document.addEventListener('DOMContentLoaded', function() {
    toggleAnniversaryDate();
  });
</script>