<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
       
            <div class="row">
                <div class="col-xs-12 text-right">
                    <div class="form-group">
                        <a class="btn btn-primary" href="<?php echo base_url(); ?>hronboard/add"><i class="fa fa-plus"></i> Add New Employee</a>
                    </div>
                </div>
            </div>    
       
		
  
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Staff List</h3>
                    <div class="box-tools">
                        <!--<form action="<?php //echo base_url() ?>task/taskListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>-->
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding1">
                     <table id="example" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Sr. No.</th>
               <th>First Name</th>
    <th>Last Name</th>
    <th>Date of Birth</th>
    <th>Gender</th>
    <th>Email</th>
    <th>Contact No.</th>
    <th>Alt Contact No.</th>
    <th>Permanent Address</th>
    <th>Communication Address</th>
    <th>City</th>
    <th>State</th>
    <th>Pincode</th>
    <th>Nationality</th>
    <th>Languages Known</th>
    <th>Marital Status</th>
    <th>Anniversary Date</th>
    <th>Employment Status</th>
    <th>Pay Rate</th>
    <th>Bank Name</th>
    <th>Branch Name</th>
    <th>Account Holder</th>
    <th>Account No.</th>
    <th>IFSC Code</th>
    <th>Emergency Name</th>
    <th>Relationship</th>
    <th>Emergency Contact</th>
    <th>Emergency Address</th>
    <th>Passport Photo</th>
    <th>Adhar Card</th>
    <th>Address Proof</th>
    <th>12th Marksheet</th>
    <th>10th Marksheet</th> 
    <th>Qualification 1</th>
    <th>Qualification 2</th>
    <th>Qualification 3</th>
    <th>Certificate Upload</th>
    <th>Previous Joining Letter</th>
    <th>Reliving Letter</th>
    <th>Experience letter</th>
    <th>Police Verification</th>
    <th>Social media</th>
    <th>Previous Organisation</th>

                <th>Created On</th>
                <th>Updated On</th>
                    <th class="text-center">Actions</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
            if (!empty($records)) 
             $hronboardId = 1;
         {
                foreach ($records as $record) { ?>
                    <tr>
                        <td><?= $hronboardId++ ?></td>
                        <td><?= $record->first_name ?></td>
    <td><?= $record->last_name ?></td>
    <td><?= $record->dob ?></td>
    <td><?= $record->gender ?></td>
    <td><?= $record->email ?></td>
    <td><?= $record->contact_number ?></td>
    <td><?= $record->alt_contact_number ?></td>
    <td><?= $record->permanent_address ?></td>
    <td><?= $record->communication_address ?></td>
    <td><?= $record->city ?></td>
    <td><?= $record->state ?></td>
    <td><?= $record->pincode ?></td>
    <td><?= $record->nationality ?></td>
    <td><?= $record->languages_known ?></td>
    <td><?= $record->marital_status ?></td>
    <td><?= $record->anniversary_date ?></td>
    <td><?= $record->employment_status ?></td>
    <td><?= $record->pay_rate ?></td>
    <td><?= $record->bank_name ?></td>
    <td><?= $record->branch_name ?></td>
    <td><?= $record->account_holder ?></td>
    <td><?= $record->account_number ?></td>
    <td><?= $record->ifsc_code ?></td>
    <td><?= $record->emergency_name ?></td>
    <td><?= $record->emergency_relationship ?></td>
    <td><?= $record->emergency_contact ?></td>
    <td><?= $record->emergency_address ?></td>
    <td>
    <?php if (!empty($record->passport_photo)) : ?>
        <img src="<?= $record->passport_photo ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->passport_photo)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>
    <td>
    <?php if (!empty($record->id_proof)) : ?>
        <img src="<?= $record->id_proof ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->id_proof)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

    <td>
    <?php if (!empty($record->address_proof)) : ?>
        <img src="<?= $record->address_proof ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->address_proof)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>
 <td>
    <?php if (!empty($record->qualification_1)) : ?>
        <img src="<?= $record->qualification_1 ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->qualification_1)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>
  <td>
    <?php if (!empty($record->tenthS3marksheet)) : ?>
        <img src="<?= $record->tenthS3marksheet ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->tenthS3marksheet)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>


<td>
    <?php if (!empty($record->qualification_1)) : ?>
        <img src="<?= $record->qualification_1 ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->qualification_1)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

   <td>
    <?php if (!empty($record->qualification_2)) : ?>
        <img src="<?= $record->qualification_2 ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->qualification_2)) ?>" class="btn btn-primary">
            Download
        </a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

   <td>
    <?php if (!empty($record->qualification_3)) : ?>
        <img src="<?= $record->qualification_3 ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->qualification_3)) ?>" class="btn btn-primary">Download</a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

<td>
    <?php if (!empty($record->certificateS3upload)) : ?>
        <img src="<?= $record->certificateS3upload ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->certificateS3upload)) ?>" class="btn btn-primary">Download</a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

<td>
    <?php if (!empty($record->prev_com_joining_letter)) : ?>
        <img src="<?= $record->prev_com_joining_letter ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->prev_com_joining_letter)) ?>" class="btn btn-primary">Download</a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

<td>
    <?php if (!empty($record->prev_com_reliving_letter)) : ?>
        <img src="<?= $record->prev_com_reliving_letter ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->prev_com_reliving_letter)) ?>" class="btn btn-primary">Download</a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

<td>
    <?php if (!empty($record->prev_com_experience_letter)) : ?>
        <img src="<?= $record->prev_com_experience_letter ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->prev_com_experience_letter)) ?>" class="btn btn-primary">Download</a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

<td>
    <?php if (!empty($record->police_verification)) : ?>
        <img src="<?= $record->police_verification ?>" width="100" />
        <a href="<?= base_url('hronboard/download_s3_file?url=' . urlencode($record->police_verification)) ?>" class="btn btn-primary">Download</a>
    <?php else: ?>
        N/A
    <?php endif; ?>
</td>

    <td><?= $record->social_media ?></td>
    <td><?= $record->prev_organisation ?></td>
     <td><?= date("d-m-Y", strtotime($record->createdDtm)) ?></td>
                        <td>
                            <?= !empty($record->updatedDtm) ? date("d-m-Y", strtotime($record->updatedDtm)) : 'N/A' ?>
                        </td>

                       
                            <td class="text-center">
                                <a class="btn btn-sm btn-info" href="<?= base_url('hronboard/view/' . $record->hronboardId); ?>" title="Edit"><i class="fa fa-eye"></i></a>
                                <a class="btn btn-sm btn-info" href="<?= base_url('hronboard/edit/' . $record->hronboardId); ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                                 
                            </td>

                            
                      
                    </tr>
            <?php }
            } ?>
        </tbody>
    </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
				<!-- code done by yashi -->
                <div class="br-pagi">
                 <p>Showing <?= $start ?> to <?= $end ?> of <?= $total_records ?> records</p>
                    <p><?php echo $links; ?></p>
                </div>
					<!-- end -->
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
a.new-wapp {
    color: #fff;
    background: #049a04;
    padding: 5px;
    border-radius: 5px;
    font-size: 16px;
}
i.fa.fa-whatsapp {
    font-size: 20px;
}
a.new-wapp:hover {
    background: #ffffffb8;
    color: #049a04;
}
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "support/supportListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
$(document).ready(function() {
        $("#example_paginate").hide();
        $("#example_info").hide();
    });    
</script>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
