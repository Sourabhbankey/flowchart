<?php
$hronboardId = $hronboardInfo->hronboardId;
$first_name = $hronboardInfo->first_name;
$last_name = $hronboardInfo->last_name;
$dob = $hronboardInfo->dob;
$gender = $hronboardInfo->gender ?? '';
$email = $hronboardInfo->email;
$contact_number = $hronboardInfo->contact_number;
$alt_contact_number = $hronboardInfo->alt_contact_number;
$permanent_address = $hronboardInfo->permanent_address;
$communication_address = $hronboardInfo->communication_address;
$city = $hronboardInfo->city ?? '';
$state = $hronboardInfo->state ?? '';
$pincode = $hronboardInfo->pincode ?? '';
$nationality = $hronboardInfo->nationality ?? '';
$languages_known = $hronboardInfo->languages_known ?? '';
$marital_status = $hronboardInfo->marital_status ?? '';
$anniversary_date = $hronboardInfo->anniversary_date;
$designation = $hronboardInfo->designation;
$joining_date = $hronboardInfo->joining_date ?? '';
$employment_status = $hronboardInfo->employment_status ?? '';
$pay_rate = $hronboardInfo->pay_rate ?? '';
$bank_name = $hronboardInfo->bank_name ?? '';
$branch_name = $hronboardInfo->branch_name ?? '';
$account_holder = $hronboardInfo->account_holder ?? '';
$account_number = $hronboardInfo->account_number ?? '';
$ifsc_code = $hronboardInfo->ifsc_code ?? '';
$emergency_name = $hronboardInfo->emergency_name ?? '';
$emergency_relationship = $hronboardInfo->emergency_relationship ?? '';
$emergency_contact = $hronboardInfo->emergency_contact;
$emergency_address = $hronboardInfo->emergency_address ?? '';
$passport_photo = $hronboardInfo->passport_photo ?? '';
$id_proof = $hronboardInfo->id_proof ?? '';
$address_proof = $hronboardInfo->address_proof ?? '';
$qualification_1 = $hronboardInfo->qualification_1;
$qualification_2 = $hronboardInfo->qualification_2 ?? '';
$qualification_3 = $hronboardInfo->qualification_3 ?? '';
$prev_com_joining_letter = $hronboardInfo->prev_com_joining_letter ?? '';
$prev_com_reliving_letter = $hronboardInfo->prev_com_reliving_letter;
$prev_com_experience_letter = $hronboardInfo->prev_com_experience_letter ?? '';
$police_verification = $hronboardInfo->police_verification ?? '';
$social_media = $hronboardInfo->social_media ?? '';
$prev_organisation = $hronboardInfo->prev_organisation ?? '';
$tenth_marksheet = $hronboardInfo->tenth_marksheet ?? '';
$certificate_upload = $hronboardInfo-> certificate_upload ?? '';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee Management
       
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Employee Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo base_url() ?>hronboard/editHronboard" method="post" id="editStaff" enctype="multipart/form-data">
  <input type="hidden" name="hronboardId" value="<?php echo $hronboardId; ?>">
 <div class="box-body">
<h2 class="mb-4 hron-title">Personal Information</h2>

<table width="100%" cellpadding="10" cellspacing="0" border="1" style="border-collapse: collapse;">
  <tr>
    <td style="border: 1px solid #ccc;"><strong>First Name</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $first_name; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Last Name</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $last_name; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Date of Birth</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $dob; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Gender</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $gender; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Personal Email</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $email; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Contact Number</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $contact_number; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Alternative Contact Number</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $alt_contact_number; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Permanent Address</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $permanent_address; ?></td>
  </tr>
   <tr>
    <td style="border: 1px solid #ccc;"><strong>Communication Address</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $communication_address; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>City</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $city; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>State</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $state; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Pincode</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $pincode; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Nationality</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $nationality; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Languages Known</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $languages_known; ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Marital Status</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $marital_status; ?></td>
  </tr>
   <tr>
    <td style="border: 1px solid #ccc;"><strong>Anniversary Date</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo $anniversary_date; ?></td>
  </tr>
</table>




<h2 class="mt-5 mb-4 hron-title">Employment Details</h2>
<table width="100%" cellpadding="10" cellspacing="0" border="1" style="border-collapse: collapse;">
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Designation</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($designation); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Joining Date</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo date('d-m-Y', strtotime($joining_date)); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Employment Status</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($employment_status); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Pay Rate</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($pay_rate); ?></td>
  </tr>
</table>



  <h2 class="mt-5 mb-4 hron-title">Bank Details</h2>
<table width="100%" cellpadding="10" cellspacing="0" border="1" style="border-collapse: collapse;">
  <tr style="border: 1px solid #ccc;">
    <td style="border: 1px solid #ccc;"><label>Bank Name</label></td>
    <td style="border: 1px solid #ccc;">
      <input type="text" name="bank_name" value="<?php echo $bank_name; ?>" required>
    </td>
  </tr>
  <tr style="border: 1px solid #ccc;">
    <td style="border: 1px solid #ccc;"><label>Branch Name</label></td>
    <td style="border: 1px solid #ccc;">
      <input type="text" name="branch_name" value="<?php echo $branch_name; ?>" required>
    </td>
  </tr>
  <tr style="border: 1px solid #ccc;">
    <td style="border: 1px solid #ccc;"><label>Account Holder Name</label></td>
    <td style="border: 1px solid #ccc;">
      <input type="text" name="account_holder" value="<?php echo $account_holder; ?>" required>
    </td>
  </tr>
  <tr style="border: 1px solid #ccc;">
    <td style="border: 1px solid #ccc;"><label>Account Number</label></td>
    <td style="border: 1px solid #ccc;">
      <input type="text" name="account_number" value="<?php echo $account_number; ?>" required>
    </td>
  </tr>
  <tr style="border: 1px solid #ccc;">
    <td style="border: 1px solid #ccc;"><label>IFSC Code</label></td>
    <td style="border: 1px solid #ccc;">
      <input type="text" name="ifsc_code" value="<?php echo $ifsc_code; ?>" required>
    </td>
  </tr>
</table>


<h2 class="mt-5 mb-4 hron-title">Emergency Contact</h2>
<table width="100%" cellpadding="10" cellspacing="0" border="1" style="border-collapse: collapse;">
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Emergency Contact Name</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($emergency_name); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Relationship</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($emergency_relationship); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Contact Number</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($emergency_contact); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Address</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($emergency_address); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Social Media</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($social_media); ?></td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><strong>Previous Organisation</strong></td>
    <td style="border: 1px solid #ccc;"><?php echo htmlspecialchars($prev_organisation); ?></td>
  </tr>
</table>



  <h2 class="mt-5 mb-4 hron-title">Upload Documents</h2>
<table width="100%" cellpadding="10" cellspacing="0" border="1" style="border-collapse: collapse;">
  <tr>
    <td style="border: 1px solid #ccc;"><label>Passport Size Photo</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($passport_photo)) { ?>
        <img src="<?php echo $passport_photo; ?>" alt="Passport Photo" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Adhar Card</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($id_proof)) { ?>
        <img src="<?php echo $id_proof; ?>" alt="ID Proof" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Address Proof</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($address_proof)) { ?>
        <img src="<?php echo $address_proof; ?>" alt="Address Proof" width="100"><br>
      <?php } ?>
    </td>
  </tr>
   <tr>
    <td style="border: 1px solid #ccc;"><label>10th Marksheet</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($tenth_marksheet)) { ?>
        <img src="<?php echo $tenth_marksheet; ?>" alt="10th Marksheet" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>12th Marksheet</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($qualification_1)) { ?>
        <img src="<?php echo $qualification_1; ?>" alt="12th Marksheet" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Graduation Marksheet</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($qualification_2)) { ?>
        <img src="<?php echo $qualification_2; ?>" alt="Graduation Marksheet" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Post-Graduation/Other</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($qualification_3)) { ?>
        <img src="<?php echo $qualification_3; ?>" alt="PG Marksheet" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
     <tr>
    <td style="border: 1px solid #ccc;"><label>Certification</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($certificate_upload)) { ?>
        <img src="<?php echo $certificate_upload; ?>" alt="certification Upload" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Previous Company Joining Letter</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($prev_com_joining_letter)) { ?>
        <img src="<?php echo $prev_com_joining_letter; ?>" alt="Joining Letter" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Relieving Letter</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($prev_com_reliving_letter)) { ?>
        <img src="<?php echo $prev_com_reliving_letter; ?>" alt="Relieving Letter" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Experience Letter</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($prev_com_experience_letter)) { ?>
        <img src="<?php echo $prev_com_experience_letter; ?>" alt="Experience Letter" width="100"><br>
      <?php } ?>
    </td>
  </tr>
  <tr>
    <td style="border: 1px solid #ccc;"><label>Police Verification</label></td>
    <td style="border: 1px solid #ccc;">
      <?php if (!empty($police_verification)) { ?>
        <img src="<?php echo $police_verification; ?>" alt="Police Verification" width="100"><br>
      <?php } ?>
    </td>
  </tr>
</table>
</div>

  
    
                         <div class="box-footer">
                        <button type="button" class="btn btn-info" onclick="printForm()">Print</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
    <script>
function printForm() {
    var formContent = document.querySelector('.box').innerHTML;
    var printWindow = window.open('', '', 'height=800,width=1000');

    // Write the content to the print window
    printWindow.document.write('<html><head>');
    
    // Set the title to "Onboarding"
    printWindow.document.write('<title>HR Onboarding Form</title>'); 
    
    // Add necessary styles to center the logo and ensure the logo appears on each printed page
    printWindow.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">');
    printWindow.document.write('<style>');
    printWindow.document.write('body { padding: 20px; }');
    printWindow.document.write('img { max-width: 100px; margin: 0 auto; display: block; }'); // Center align the logo
    printWindow.document.write('table { width: 100%; border-collapse: collapse; }');
    printWindow.document.write('td, th { padding: 8px; text-align: left; }');
    printWindow.document.write('th { background-color: #f9f9f9; }');
    printWindow.document.write('@page { margin-top: 100px; }'); // Space from the top of the page for logo
    printWindow.document.write('.page { page-break-before: always; }'); // Add page breaks if content is long
    // Center-align the h2 titles in the print window
    printWindow.document.write('h2 { text-align: center; }');
    printWindow.document.write('h3.box-title { display: none; }');
    
    // Remove input borders for printing
    printWindow.document.write('input[type="text"], input[type="email"] { border: none; background: transparent; box-shadow: none; }');
    
    // Hide the table borders during print
    printWindow.document.write('.table-bordered { border: none; }');
    printWindow.document.write('.table-bordered th, .table-bordered td { border: none; }');

    printWindow.document.write('</style>');
    
    // Add logo at the top of each page (centered)
    printWindow.document.write('<div style="text-align: center; margin-bottom: 20px;">');
    printWindow.document.write('<img src="https://theischool.com/blog/wp-content/uploads/2022/05/logo-1.png" alt="Logo" style="max-width: 100px;">');
    printWindow.document.write('</div>');
    
    // Write the form content below the logo
    printWindow.document.write('</head><body>');
    printWindow.document.write(formContent);
    printWindow.document.write('</body></html>');

    printWindow.document.close(); // Close the document to finish writing
    printWindow.focus();
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 500);
}
</script>
<style type="text/css">
    input[type="text"], input[type="email"] { 
    border: none; 
    background: transparent; 
    box-shadow: none; 
}
.hron-title{text-align: center;}
td{padding: 10px;}
</style>
</div>