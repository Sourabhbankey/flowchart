<?php
$hronboardId = $hronboardInfo->hronboardId;
$first_name = $hronboardInfo->first_name;
$last_name = $hronboardInfo->last_name;
$dob = $hronboardInfo->dob;
$gender = $hronboardInfo->gender ?? '';
$email = $hronboardInfo->email;
$contact_number = $hronboardInfo->contact_number;
$alt_contact_number = $hronboardInfo->alt_contact_number;
$permanent_address = $hronboardInfo->permanent_address;
$communication_address = $hronboardInfo->communication_address;
$city = $hronboardInfo->city ?? '';
$state = $hronboardInfo->state ?? '';
$pincode = $hronboardInfo->pincode ?? '';
$nationality = $hronboardInfo->nationality ?? '';
$languages_known = $hronboardInfo->languages_known ?? '';
$marital_status = $hronboardInfo->marital_status ?? '';
$anniversary_date = $hronboardInfo->anniversary_date ?? '';
$designation = $hronboardInfo->designation;
$joining_date = $hronboardInfo->joining_date ?? '';
$employment_status = $hronboardInfo->employment_status ?? '';
$pay_rate = $hronboardInfo->pay_rate ?? '';
$bank_name = $hronboardInfo->bank_name ?? '';
$branch_name = $hronboardInfo->branch_name ?? '';
$account_holder = $hronboardInfo->account_holder ?? '';
$account_number = $hronboardInfo->account_number ?? '';
$ifsc_code = $hronboardInfo->ifsc_code ?? '';
$emergency_name = $hronboardInfo->emergency_name ?? '';
$emergency_relationship = $hronboardInfo->emergency_relationship ?? '';
$emergency_contact = $hronboardInfo->emergency_contact;
$emergency_address = $hronboardInfo->emergency_address ?? '';
$passport_photo = $hronboardInfo->passport_photo ?? '';
$id_proof = $hronboardInfo->id_proof ?? '';
$address_proof = $hronboardInfo->address_proof ?? '';
$tenth_marksheet = $hronboardInfo->tenth_marksheet ?? ''; // Added
$qualification_1 = $hronboardInfo->qualification_1 ?? '';
$qualification_2 = $hronboardInfo->qualification_2 ?? '';
$qualification_3 = $hronboardInfo->qualification_3 ?? '';
$certificate_upload = $hronboardInfo->certificate_upload ?? ''; // Added
$prev_com_joining_letter = $hronboardInfo->prev_com_joining_letter ?? '';
$prev_com_reliving_letter = $hronboardInfo->prev_com_reliving_letter ?? '';
$prev_com_experience_letter = $hronboardInfo->prev_com_experience_letter ?? '';
$police_verification = $hronboardInfo->police_verification ?? '';
$leave_count = $hronboardInfo->leave_count ?? '';
?>

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <i class="fa fa-user-circle-o" aria-hidden="true"></i> Staff Management
      <small>Add / Edit Staff</small>
    </h1>
  </section>

  <section class="content">
    <div class="row">
      <!-- left column -->
      <div class="col-md-9">
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header">
            <h3 class="box-title">Enter Staff Details</h3>
          </div><!-- /.box-header -->
          <!-- form start -->
          <form role="form" action="<?php echo base_url() ?>hronboard/editHronboard" method="post" id="editStaff" role="form" enctype="multipart/form-data">
            <input type="hidden" name="hronboardId" value="<?php echo $hronboardId; ?>">

            <h2 class="mb-4">Personal Information</h2>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">First Name</label>
                <input type="text" name="first_name" class="form-control" value="<?php echo $first_name; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Last Name</label>
                <input type="text" name="last_name" class="form-control" value="<?php echo $last_name; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="form-control" value="<?php echo $dob; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Gender</label>
                <select name="gender" class="form-select" required>
                  <option value="Male" <?php echo ($gender == 'Male') ? 'selected' : ''; ?>>Male</option>
                  <option value="Female" <?php echo ($gender == 'Female') ? 'selected' : ''; ?>>Female</option>
                </select>
              </div>
              <div class="col-md-4">
                <label class="form-label">Personal Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Contact Number</label>
                <input type="tel" name="contact_number" class="form-control" value="<?php echo $contact_number; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Alternative Contact Number</label>
                <input type="tel" name="alt_contact_number" class="form-control" value="<?php echo $alt_contact_number; ?>">
              </div>
              <div class="col-md-4">
                <label class="form-label">Permanent Address</label>
                <input type="text" name="permanent_address" class="form-control" value="<?php echo $permanent_address; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Communication Address</label>
                <input type="text" name="communication_address" class="form-control" value="<?php echo $communication_address; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">City</label>
                <input type="text" name="city" class="form-control" value="<?php echo $city; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">State</label>
                <input type="text" name="state" class="form-control" value="<?php echo $state; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Pincode</label>
                <input type="text" name="pincode" class="form-control" value="<?php echo $pincode; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Nationality</label>
                <input type="text" name="nationality" class="form-control" value="<?php echo $nationality; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Languages Known</label>
                <input type="text" name="languages_known" class="form-control" value="<?php echo $languages_known; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Marital Status</label>
                <select name="marital_status" class="form-select" required>
                  <option value="Single" <?php echo ($marital_status == 'Single') ? 'selected' : ''; ?>>Single</option>
                  <option value="Married" <?php echo ($marital_status == 'Married') ? 'selected' : ''; ?>>Married</option>
                </select>
              </div>
              <div class="col-md-4" id="anniversaryDateDiv">
                <label class="form-label">Date of Anniversary</label>
                <input type="date" name="anniversary_date" class="form-control" value="<?php echo $anniversary_date; ?>" <?php echo ($marital_status == 'Married') ? 'required' : ''; ?>>
              </div>
            </div>

            <h2 class="mt-5 mb-4">Employment Details</h2>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Designation</label>
                <input type="text" name="designation" class="form-control" value="<?php echo $designation; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Joining Date</label>
                <input type="date" name="joining_date" class="form-control" value="<?php echo $joining_date; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Employment Status</label>
                <select name="employment_status" class="form-select" required>
                  <option value="Full time" <?php echo ($employment_status == 'Full time') ? 'selected' : ''; ?>>Full time</option>
                  <option value="Part time" <?php echo ($employment_status == 'Part time') ? 'selected' : ''; ?>>Part time</option>
                  <option value="Temporary" <?php echo ($employment_status == 'Temporary') ? 'selected' : ''; ?>>Temporary</option>
                </select>
              </div>

              <div class="col-md-4">
                <label class="form-label">Pay Rate</label>
                <select name="pay_rate" class="form-select" required>
                  <option value="Annual" <?php echo ($pay_rate == 'Annual') ? 'selected' : ''; ?>>Annual</option>
                  <option value="Monthly" <?php echo ($pay_rate == 'Monthly') ? 'selected' : ''; ?>>Monthly</option>
                  <option value="Hourly" <?php echo ($pay_rate == 'Hourly') ? 'selected' : ''; ?>>Hourly</option>
                </select>
              </div>
            </div>

            <h2 class="mt-5 mb-4">Bank Details</h2>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Bank Name</label>
                <input type="text" name="bank_name" class="form-control" value="<?php echo $bank_name; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Branch Name</label>
                <input type="text" name="branch_name" class="form-control" value="<?php echo $branch_name; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Account Holder Name</label>
                <input type="text" name="account_holder" class="form-control" value="<?php echo $account_holder; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Account Number</label>
                <input type="text" name="account_number" class="form-control" value="<?php echo $account_number; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">IFSC Code</label>
                <input type="text" name="ifsc_code" class="form-control" value="<?php echo $ifsc_code; ?>" required>
              </div>
            </div>

            <h2 class="mt-5 mb-4">Emergency Contact</h2>
            <div class="row g-3">
              <div class="col-md-4">
                <label class="form-label">Emergency Contact Name</label>
                <input type="text" name="emergency_name" class="form-control" value="<?php echo $emergency_name; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Relationship</label>
                <input type="text" name="emergency_relationship" class="form-control" value="<?php echo $emergency_relationship; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Contact Number</label>
                <input type="text" name="emergency_contact" class="form-control" value="<?php echo $emergency_contact; ?>" required>
              </div>
              <div class="col-md-4">
                <label class="form-label">Address</label>
                <input type="text" name="emergency_address" class="form-control" value="<?php echo $emergency_address; ?>" required>
              </div>
            </div>
            <h2 class="mt-5 mb-4">Employee Leave</h2>
            <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Employment Role</label>
               <select class="form-control required" name="roleId" id="roleId">
    <option value="">Select Department</option>
    <?php foreach ($departments as $dept): ?>
        <option value="<?= $dept['roleId'] ?>" <?= ($dept['roleId'] == $selectedRoleId) ? 'selected' : '' ?>>
            <?= $dept['role'] ?>
        </option>
    <?php endforeach; ?>
</select>

              </div>
               <div class="col-md-4">
                <label class="form-label">Leave Count</label>
                <input type="text" name="leave_count" class="form-control" value="<?php echo $leave_count; ?>" >
              </div>
        </div>
            <h2 class="mt-5 mb-4">Upload Documents</h2>
            <div class="row g-3">
              <div class="col-md-4">
               <div class="form-group">
  <label class="form-label">Passport Size Photo</label>
  <?php if (!empty($passport_photo)) : ?>
    <div>
      <a href="<?php echo $passport_photo; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
    </div>
  <?php endif; ?>
  <input type="file" name="file" class="form-control">
  <input type="hidden" name="existing_file" value="<?php echo $passport_photo; ?>">
</div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Adhar Card</label>
                  <?php if (!empty($id_proof)) : ?>
                    <div>
                      <a href="<?php echo $id_proof; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file1" class="form-control">
                  <input type="hidden" name="existing_file1" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Address Proof</label>
                  <?php if (!empty($address_proof)) : ?>
                    <div>
                      <a href="<?php echo $address_proof; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file2" class="form-control">
                  <input type="hidden" name="existing_file2" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">10th Marksheet</label>
                  <?php if (!empty($tenth_marksheet)) : ?>
                    <div>
                      <a href="<?php echo $tenth_marksheet; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file10" class="form-control">
                   <input type="hidden" name="existing_file10" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">12th Marksheet</label>
                  <?php if (!empty($qualification_1)) : ?>
                    <div>
                      <a href="<?php echo $qualification_1; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file3" class="form-control">
                   <input type="hidden" name="existing_file3" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Graduation Marksheet</label>
                  <?php if (!empty($qualification_2)) : ?>
                    <div>
                      <a href="<?php echo $qualification_2; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file4" class="form-control">
                    <input type="hidden" name="existing_file4" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Post-Graduation/Other</label>
                  <?php if (!empty($qualification_3)) : ?>
                    <div>
                      <a href="<?php echo $qualification_3; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file5" class="form-control">
                    <input type="hidden" name="existing_file5" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Certificate Upload</label>
                  <?php if (!empty($certificate_upload)) : ?>
                    <div>
                      <a href="<?php echo $certificate_upload; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file11" class="form-control">
                    <input type="hidden" name="existing_file11" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Previous Company Joining Letter</label>
                  <?php if (!empty($prev_com_joining_letter)) : ?>
                    <div>
                      <a href="<?php echo $prev_com_joining_letter; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file6" class="form-control">
                    <input type="hidden" name="existing_file6" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Previous Company Relieving Letter</label>
                  <?php if (!empty($prev_com_reliving_letter)) : ?>
                    <div>
                      <a href="<?php echo $prev_com_reliving_letter; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file7" class="form-control">
                    <input type="hidden" name="existing_file7" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Previous Company Experience Letter</label>
                  <?php if (!empty($prev_com_experience_letter)) : ?>
                    <div>
                      <a href="<?php echo $prev_com_experience_letter; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file8" class="form-control">
                    <input type="hidden" name="existing_file8" value="<?php echo $address_proof; ?>">
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="form-label">Police Verification</label>
                  <?php if (!empty($police_verification)) : ?>
                    <div>
                      <a href="<?php echo $police_verification; ?>" target="_blank" class="btn btn-sm btn-info">View Current</a>
                    </div>
                  <?php endif; ?>
                  <input type="file" name="file9" class="form-control">
                </div>
              </div>
            </div>




            <div class="box-footer">
              <input type="submit" class="btn btn-primary" value="Submit" />
              <input type="reset" class="btn btn-default" value="Reset" />
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-4">
        <?php
        $this->load->helper('form');
        $error = $this->session->flashdata('error');
        if ($error) {
        ?>
          <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php } ?>
        <?php
        $success = $this->session->flashdata('success');
        if ($success) {
        ?>
          <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $this->session->flashdata('success'); ?>
          </div>
        <?php } ?>
        <div class="row">
          <div class="col-md-12">
            <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
          </div>
        </div>
      </div>
    </div>
  </section>
  <style type="text/css">
    .re-mend-field {
      color: red;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .btn-sm {
      margin-bottom: 10px;
    }
  </style>
  <script>
    // JavaScript to toggle Anniversary Date field based on Marital Status
    document.addEventListener('DOMContentLoaded', function() {
      const maritalStatusSelect = document.querySelector('select[name="marital_status"]');
      const anniversaryDateDiv = document.getElementById('anniversaryDateDiv');
      const anniversaryDateInput = anniversaryDateDiv.querySelector('input');

      function toggleAnniversaryDate() {
        if (maritalStatusSelect.value === 'Married') {
          anniversaryDateInput.required = true;
          anniversaryDateDiv.style.display = 'block';
        } else {
          anniversaryDateInput.required = false;
          anniversaryDateInput.value = '';
          anniversaryDateDiv.style.display = 'none';
        }
      }

      // Initial check
      toggleAnniversaryDate();

      // Add event listener for changes
      maritalStatusSelect.addEventListener('change', toggleAnniversaryDate);
    });
  </script>
</div>