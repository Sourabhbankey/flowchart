<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Location Approval Management
            <small>Add / Edit Location Approval</small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
                <!-- general form elements -->

                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Location Approval Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="yourForm" enctype="multipart/form-data" action="<?php echo base_url(); ?>locationapproval/addNewLocationapproval" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <!--    <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"   data-live-search="true" required>
                                            <option value="">Select Franchise</option>
                                            <?php if (!empty($branchDetail)) {
                                                foreach ($branchDetail as $bd) {
                                                    $franchiseNumber =
                                                        $bd->franchiseNumber; ?>
                                                     <option value="<?php echo $franchiseNumber; ?>" ><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            } ?>         
                                        </select>
                                    </div>
                                </div> -->

                                <div class="row" style="margin: 0px;">
                                    <?php if ($role != 25) { ?>
                                        <!-- Readonly input for role 25 to display franchise number -->
                                    
                                        <!-- Dropdown for role 14 -->
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                                <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchAssignedFranchise(this.value);">
                                                    <option value="">Select Franchise</option>
                                                    <?php
                                                    if (!empty($branchDetail)) {
                                                        $defaultFranchise = $franchiseNumber ?: '';
                                                        foreach ($branchDetail as $bd) {
                                                            $franchiseNumberOption = $bd->franchiseNumber;
                                                            $selected = ($franchiseNumberOption == $defaultFranchise) ? 'selected' : '';
                                                    ?>
                                                            <option value="<?php echo htmlspecialchars($franchiseNumberOption); ?>" <?php echo $selected; ?>>
                                                                <?php echo htmlspecialchars($franchiseNumberOption); ?>
                                                            </option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                   
                                        <!-- Hidden input for other roles (e.g., admin) -->
                                        <input type="hidden" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars($franchiseNumber); ?>">
                                    
                                    <!-- Franchise Assigned to field (visible for all roles) -->
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                            <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                                <span>Loading assigned Growth Manager...</span>
                                            </div>
                                            <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                                <!-- Dropdown for role 14 -->

                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="locationTitle">City<span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value(
                                                                                                                "locationTitle"
                                                                                                            ); ?>" id="locationTitle" name="locationTitle" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="gmapLink">Location Link - (G-Map) <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value(
                                                                                                                "gmapLink"
                                                                                                            ); ?>" id="gmapLink" name="gmapLink" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="locAddress">Branch Full Address <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo set_value("locAddress"); ?>" id="locAddress" name="locAddress" maxlength="256">
                                    </div>
                                </div>
                                <?php if ($is_admin == 1 || $role == 18) { ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="nearestBranch">Nearest Branch <span class="re-mend-field">*</span></label>
                                            <select class="form-control required" id="franchiseNumber" name="nearestBranch[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php if (!empty($branchDetail)) {
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        // Ensure you get the correct franchise number
                                                ?>
                                                        <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                                                <?php
                                                    }
                                                } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="nearestBranchDistance">Nearest Branch Distance <span class="re-mend-field">*</span></label>
                                            <input required type="text" class="form-control required" value="<?php echo set_value("nearestBranchDistance"); ?>" id="nearestBranchDistance" name="nearestBranchDistance" maxlength="256">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="locApprovalStatus">Status <span class="re-mend-field">*</span></label>
                                            <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="locApprovalStatus" tabindex="-1" aria-hidden="true">
                                                <option value="">Select</option>
                                                <option value="<?= ACTIVE ?>">Approved</option>
                                                <option value="<?= INACTIVE ?>"> Not Approved</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-8">
                                        <div class="form-group">
                                            <label for="userLoclive">Get User's Live Location <span class="re-mend-field">*</span></label>
                                            <input type="text" id="location" placeholder="Location will be displayed here" readonly>
                                            <a onclick="getLocation()" class="getloc">Get Location</a>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="description">Description <span class="re-mend-field">*</span></label>
                                            <textarea required class="form-control required" id="description" name="description"></textarea>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div><!-- /.box-body -->
                        <?php if ($role == 25 || $role == 1 || $role == 14) { ?>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="userLoclive">Get User's Live Location <span class="re-mend-field">*</span></label>
                                    <input type="text" id="location" placeholder="Location will be displayed here" name="locationGeolocation" readonly>
                                    <a onclick="getLocation()" class="getloc">Get Location</a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="acattachmentTitle"> Premise Image <span class="re-mend-field">*</span></label>
                                    <input type="file" name="locationImages[]" multiple>
                                </div>


                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="acattachmentTitle"> Video <span class="re-mend-field">*</span></label>
                                    <input type="file" name="file2">
                                </div>

                            </div>
                        <?php } ?>
                        <div class="box-footer">
                            <input type="submit" id="submitBtn" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>

                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper("form");
                $error = $this->session->flashdata("error");
                if ($error) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata(
                            "error"
                        ); ?>
                    </div>
                <?php }
                ?>
                <?php
                $success = $this->session->flashdata("success");
                if ($success) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata("success"); ?>
                    </div>
                <?php }
                ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors(
                            '<div class="alert alert-danger alert-dismissable">',
                            ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'
                        ); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .getloc{
            cursor: pointer;
        }
    </style>
</div>
<script>
    function fetchAssignedFranchise(franchiseNumber) {
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url(
                            "locationapproval/fetchAssignedUsers"
                        ); ?>', // Update to match your controller and method
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber
                },
                success: function(response) {
                    $('#branchFranchiseAssigned').html(response); // Populate the second dropdown
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    alert('Error fetching data');
                }
            });
        } else {
            $('#branchFranchiseAssigned').html('<option value="0">Select Role</option>');
        }
    }
</script>
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
<script>
    function getLocation() {
        // Check if geolocation is available
        if (navigator.geolocation) {
            // Get current position
            navigator.geolocation.getCurrentPosition(function(position) {
                // Extract latitude and longitude from the position object
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;

                // Create a Google Maps link using the coordinates
                const locationLink = `https://www.google.com/maps?q=${lat},${lon}`;

                // Update the location input field with the Google Maps link
                document.getElementById('location').value = locationLink;

                // Call the reverse geocoding function to get the address
                getAddress(lat, lon);
            }, function(error) {
                alert('Error occurred: ' + error.message);
            });
        } else {
            alert('Geolocation is not supported by this browser.');
        }
    }

    // Reverse geocoding function using Google Maps API
    function getAddress(lat, lon) {
        const apiKey = 'AIzaSyC6LKZ9QHyBM8q8L86P8XylxUqIfGESDhY'; // Replace with your Google Maps API key
        const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lon}&key=${apiKey}`;

        // Fetch the address from the Google Maps API
        fetch(geocodeUrl)
            .then(response => response.json())
            .then(data => {
                console.log(data); // Debugging: log the entire API response
                if (data.status === 'OK' && data.results.length > 0) {
                    const address = data.results[0].formatted_address;
                    document.getElementById('address').value = address; // Display address in the input field
                } else {
                    document.getElementById('address').value = "Address not found";
                }
            })
            .catch(error => {
                console.error('Error fetching address:', error);
                document.getElementById('address').value = "Error fetching address";
            });
    }
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');
        if (franchiseInput && franchiseInput.value) {
            console.log('Initializing fetchAssignedFranchise with franchiseNumber:', franchiseInput.value);
            fetchAssignedFranchise(franchiseInput.value);
        } else {
            console.warn('Franchise number input is missing or empty');
            const assignedDiv = document.getElementById('brspFranchiseAssigned');
            if (assignedDiv) {
                assignedDiv.innerText = 'Franchise number not available';
            }
        }
    });

    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue');

        if (!franchiseNumber) {
            console.warn('No franchise number provided');
            if (assignedDiv) assignedDiv.innerText = 'Select a franchise to assign';
            if (hiddenInput) hiddenInput.value = '';
            return;
        }

        console.log('Fetching assigned Growth Manager for franchise:', franchiseNumber);
        $.ajax({
            url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
            type: 'POST',
            data: {
                franchiseNumber: franchiseNumber,
                '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
            },
            dataType: 'json',
            success: function(response) {
                console.log('AJAX response:', response);
                if (response.status === 'success' && response.html) {
                    assignedDiv.innerHTML = response.html;
                    hiddenInput.value = response.userIds || '';
                } else {
                    assignedDiv.innerText = response.message || 'No Growth Manager assigned';
                    hiddenInput.value = '';
                    console.warn('No Growth Manager found:', response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', status, error);
                console.error('Response Text:', xhr.responseText);
                assignedDiv.innerText = 'Error fetching Growth Manager';
                hiddenInput.value = '';
                alert('Failed to fetch Growth Manager data. Please try again.');
            }
        });
    }
</script>