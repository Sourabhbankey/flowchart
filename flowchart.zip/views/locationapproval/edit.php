<?php
$locationApprovalId = $locationapprovalInfo->locationApprovalId;
$locationTitle = $locationapprovalInfo->locationTitle;
$gmapLink = $locationapprovalInfo->gmapLink;
$locAddress = $locationapprovalInfo->locAddress;
$nearestBranch = $locationapprovalInfo->nearestBranch;
$nearestBranchDistance = $locationapprovalInfo->nearestBranchDistance;
$locApprovalStatus = $locationapprovalInfo->locApprovalStatus;
$franchiseNumbers = explode(",", $locationapprovalInfo->franchiseNumber);
$franchiseNumberList = isset($franchiseNumberArray) ? implode(",", $franchiseNumberArray) : '';


$description = $locationapprovalInfo->description;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i>Location Approval Management
        <small>Add / Edit Location Approval</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Location Approval Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
   <form role="form" action="<?php echo base_url() ?>locationapproval/editLocationapproval" method="post" id="editLocationapproval" role="form">
    <div class="box-body">
      <div class="row">
       
            <div class="col-md-4">                      
             <div class="form-group">
              <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                <input type="text" class="form-control required" value="<?php echo !empty($franchiseNumbers) ? implode(',', $franchiseNumbers) : ''; ?>" id="franchiseNumber" name="franchiseNumber" maxlength="256" readonly  />
              </div> 
            </div>
         <div class="col-md-8">  
           <div class="form-group">
            <label for="locationTitle">City<span class="re-mend-field">*</span></label>
             <input required type="text" class="form-control required" value="<?php echo $locationTitle; ?>" id="locationTitle" name="locationTitle" maxlength="256" readonly/>
<input type="hidden" value="<?php echo $locationApprovalId; ?>" name="locationApprovalId" id="locationApprovalId" />
            </div>
           </div>    

         


          <!-- <div class="col-md-8">  
            <div class="form-group">
              <label for="locationTitle">City<span class="re-mend-field">*</span></label>
               <input required type="text" class="form-control required clsp" value="<?php echo $locationTitle; ?>" id="locationTitle" name="locationTitle" maxlength="256" />
               <input type="hidden" value="<?php echo $locationApprovalId; ?>" name="locationApprovalId" id="locationApprovalId" />
                </div>
                 </div>   -->  

             <div class="col-md-6"> 
               <div class="form-group">
                <label for="locAddress">Address <span class="re-mend-field">*</span></label>
                <input required type="text" class="form-control required clsp" value="<?php echo $locAddress; ?>" id="locAddress" name="locAddress" maxlength="256" readonly>
               </div>   
              </div>

            <div class="col-md-6"> 
              <div class="form-group">
                <label for="gmapLink">Location Link - (G-Map) <span class="re-mend-field">*</span></label><br>
                 <input required type="text" class="form-control required clsp" value="<?php echo $gmapLink; ?>" id="gmapLink" name="gmapLink" maxlength="256"  readonly />
                   <div class="gmap"><a href="<?php echo $gmapLink; ?>" target="_blank">View Map</a></div>
                    </div>
                    </div>
                         
                                
                <div class="col-md-4"> 
                 <div class="form-group">
                   <label for="nearestBranch">Nearest Branch </label>
                  <select class="form-control required" id="franchiseNumber" name="nearestBranch[]" data-live-search="true"  onchange="fetchAssignedFranchise(this.value)" multiple>
                    <option value="">Select Franchise</option>
                      <?php
                    if (!empty($branchDetail)) {
                     foreach ($branchDetail as $bd) {
                       $franchiseNumber = $bd->franchiseNumber; // Ensure you get the correct franchise number
                      ?>
                     <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                     <?php }  } ?>
                       </select>

                     </div>   
                   </div>

                   <div class="col-md-4"> 
                    <div class="form-group">
                    <label for="nearestBranchDistance">Nearest Branch Distance </label>
                      <input  type="text" class="form-control required" value="<?php echo $nearestBranchDistance; ?>" id="nearestBranchDistance" name="nearestBranchDistance" maxlength="256" readonly >
                      </div>   
                     </div>

                     <div class="col-md-4">
                      <div class="form-group">
                       <label for="locApprovalStatus">Status <span class="re-mend-field">*</span></label>
                         <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="locApprovalStatus" tabindex="-1" aria-hidden="true">
                         <option value="<?= ACTIVE ?>" <?php if($locApprovalStatus == ACTIVE) {echo "selected=selected";} ?>>Approved</option>
                          <option value="<?= INACTIVE ?>" <?php if($locApprovalStatus == INACTIVE) {echo "selected=selected";} ?> >Not Approved</option>
                         </select>
                         </div>   
                         </div>


                         <div class="col-md-12">
                          <div class="form-group">
                           <label for="description">Description <span class="re-mend-field">*</span></label>
                            <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
        .gmap a{
            background: #3c8dbc;
            color: #fff;
            padding: 7px;
            border-radius: 8px;
        }
        .gmap{margin-top: 10px;}
        .clsp{pointer-events:none;}
    </style>
</div>