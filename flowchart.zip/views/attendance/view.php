<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Record
        <small>Add / Edit  Record</small>
      </h1>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                 

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Date</th>
            <th>Status</th>
            <th>Remark</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        // Initialize counters
        $presentCount = 0;
        $absentCount = 0;
        $halfDayCount = 0;
        $leaveCount = 0;

        if (!empty($records)) { 
            foreach ($records as $record) { 
                // Count based on attendance status
                if ($record->status == 'P') {
                    $presentCount++;
                } elseif ($record->status == 'A') {
                    $absentCount++;
                } elseif ($record->status == 'HD') {
                    $halfDayCount++;
                } elseif ($record->status == 'L') {
                    $leaveCount++;
                }
        ?>
                <tr>
                    <td><?php echo date('d-m-Y', strtotime($record->date)); ?></td>
                    <td><?php echo $record->status; ?></td>
                    <td><?php echo $record->description; ?></td>
                </tr>
        <?php } ?>
        <?php } else { ?>
            <tr>
                <td colspan="3" class="text-center">No attendance records found for this month.</td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<!-- Summary Section -->
<h3>Attendance Summary</h3>
<table class="table table-bordered">
    <tr>
        <th>Present (P)</th>
        <th>Absent (A)</th>
        <th>Half Day (HD)</th>
        <th>Leave (L)</th>
    </tr>
    <tr>
        <td><?php echo $presentCount; ?></td>
        <td><?php echo $absentCount; ?></td>
        <td><?php echo $halfDayCount; ?></td>
        <td><?php echo $leaveCount; ?></td>
    </tr>
</table>

<a href="<?php echo base_url('attendance/attendanceListing'); ?>" class="btn btn-secondary">Back</a>



                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>   
</div>