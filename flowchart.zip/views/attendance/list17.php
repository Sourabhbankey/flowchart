<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Attendance Record Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
         
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <label for="datePicker">Select Date</label>
                    <form action="<?php echo base_url('attendance/attendanceListing'); ?>" method="GET" id="searchUser">
                        <div class="input-group">
                            <input type="date" name="searchDate" id="datePicker" class="form-control input-sm" value="<?php echo isset($_GET['searchDate']) ? $_GET['searchDate'] : date('Y-m-d'); ?>">
                            <button class="btn btn-primary btn-sm btn-default" style="color: #fff;"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row">    
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <label for="resultrecordlist">Search By User</label>
                         <form action="<?php echo base_url() ?>attendance/attendanceListing" method="GET" id="searchUser">
                                <div class="input-group">
                                    <select name="searchUserId" class="form-control-old input-sm">
                                        <option value="">Select User</option>
                                        <?php foreach ($users as $user): ?>
                                            <option value="<?php echo $user->userId; ?>" 
                                                <?php echo ($searchUserId == $user->userId) ? 'selected' : ''; ?>>
                                                <?php echo $user->name; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                        <button class="btn btn-primary btn-sm btn-default" style="color: #fff;"><i class="fa fa-search"></i></button>
                                </div>
                            </form>
                    </div>
            </div>
        </div> 
        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <!-- <h3 class="box-title">Record List</h3> -->
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding-old">
                      <form action="<?php echo base_url('attendance/saveAttendance'); ?>" method="POST">
                            <input type="hidden" name="attendance_date" value="<?php echo $searchDate; ?>">
                                <table id="example" class="display responsive nowrap" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No.</th>
                                                <th>User Name</th>
                                                <th>Attendance</th>
                                                <th>Remark</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                    <tbody>
                                        <?php 
                                        $sr = 1;
                                        foreach ($users as $user) { ?>
                                                    <tr>
                                                        <td><?php echo $sr++; ?></td>
                                                        <td><?php echo $user->name; ?></td>

                                                        <td>
                                                            <input type="hidden" name="attendance[<?php echo $user->userId; ?>][userId]" value="<?php echo $user->userId; ?>">
                                                            
                                                            <label class="custom-radio present">
                                                                <input type="radio" class="present" name="attendance[<?php echo $user->userId; ?>][status]" value="P" <?php echo ($user->status == 'P') ? 'checked' : ''; ?>> 
                                                                <span class="custom-radio-label">Present</span>
                                                            </label>

                                                            <label class="custom-radio absent">
                                                                <input type="radio" class="absent" name="attendance[<?php echo $user->userId; ?>][status]" value="A" <?php echo ($user->status == 'A') ? 'checked' : ''; ?>> 
                                                                <span class="custom-radio-label">Absent</span>
                                                            </label>

                                                            <label class="custom-radio late">
                                                                <input type="radio" class="late" name="attendance[<?php echo $user->userId; ?>][status]" value="L" <?php echo ($user->status == 'L') ? 'checked' : ''; ?>> 
                                                                <span class="custom-radio-label">Late</span>
                                                            </label>

                                                            <label class="custom-radio hday">
                                                                <input type="radio" class="hday" name="attendance[<?php echo $user->userId; ?>][status]" value="HD" <?php echo ($user->status == 'HD') ? 'checked' : ''; ?>> 
                                                                <span class="custom-radio-label">Half Day</span>
                                                            </label>
                                                        </td>

                                                        <td>
                                                            <input type="text" name="attendance[<?php echo $user->userId; ?>][description]" class="form-control" placeholder="Remarks" value="<?php echo isset($user->description) ? $user->description : ''; ?>">
                                                        </td>
                                                        <td>
                                                           
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                                     <!-- <button type="submit" class="btn btn-success">Save Attendance</button>
                                        </form> -->
                                    </tbody>
                                </table>
                                        <button type="submit" class="btn btn-success">Save Attendance</button>
                            </form>
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <div class="br-pagi">
                        <?php echo $this->pagination->create_links(); ?>
                    </div>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "stock/stockListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
/*Custom*/
/* Hide the default radio buttons */
input[type="radio"] {
    display: none;
}

/* Style for the labels that act as the custom radio buttons */
.custom-radio {
    position: relative;
    display: inline-block;
    padding-left: 30px; /* Space for the circle */
    cursor: pointer;
    font-size: 16px;
    line-height: 24px; /* Center the text */
}

/* Create the custom circle appearance for the radio button */
.custom-radio input:checked + .custom-radio-label::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 18px;
    height: 18px;
    border-radius: 50%;
    border: 2px solid #ccc;
    transition: background-color 0.3s ease, border-color 0.3s ease;
}

/* Color for Present */
.custom-radio.present input:checked + .custom-radio-label::before {
    background-color: #3e9f3e;
    border-color: #fff;
}

/* Color for Absent */
.custom-radio.absent input:checked + .custom-radio-label::before {
    background-color: #d12d28;
    border-color: #fff;
}

/* Color for Late */
.custom-radio.late input:checked + .custom-radio-label::before {
    background-color: #444444;
    border-color: #fff;
}

/* Color for Half Day */
.custom-radio.hday input:checked + .custom-radio-label::before {
    background-color: #ffb300;
    border-color: #fff;
}

/* Style the custom radio button label */
.custom-radio-label::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 18px;
    height: 18px;
    border-radius: 50%;
    border: 2px solid #ccc;
    background-color: #fff;
    transition: background-color 0.3s ease, border-color 0.3s ease;
}

/* Change text color of the label based on selected option */
.custom-radio.present input:checked + .custom-radio-label {
    color: #3e9f3e;
}

.custom-radio.absent input:checked + .custom-radio-label {
    color: #d12d28;
}

.custom-radio.late input:checked + .custom-radio-label {
    color: #444444;
}

.custom-radio.hday input:checked + .custom-radio-label {
    color: #ffb300;
}

/* Hide the actual radio button */
input[type="radio"]:checked + .custom-radio-label::before {
    background-color: transparent;
}

/* Text size and spacing */
.custom-radio-label {
    padding-left: 30px; /* Space between the circle and text */
    position: relative;
    font-size: 16px;
    cursor: pointer;
}
</style>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<!-- DataTables Select CSS -->
<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>

