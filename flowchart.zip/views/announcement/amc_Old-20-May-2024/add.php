<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> AMC Management
        <small>Add / Edit AMC</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter AMC Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addDespatch" action="<?php echo base_url() ?>amc/addNewAmc" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="despatchTitle">Franchise No.</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('franchiseNumber'); ?>" id="franchiseNumber" name="franchiseNum" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-5">                                
                                    <div class="form-group">
                                        <label for="brnameTitle">Branch Name</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('brnameTitle'); ?>" id="brnameTitle" name="brnameTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="brLocation">Location</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('brLocation'); ?>" id="brLocation" name="brLocation" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="brState">State</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('brState'); ?>" id="brState" name="brState" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="oldAMCdue">Old AMC Due</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('oldAMCdue'); ?>" id="oldAMCdue" name="oldAMCdue" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="curAmc">AMC</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('curAmc'); ?>" id="curAmc" name="curAmc" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Total</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('totalAmc'); ?>" id="totalAmc" name="totalAmc" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="statusAmc">Status Of AMC</label>
                                        <!-- <input type="text" class="form-control required" value="<?php //echo set_value('statusAmc'); ?>" id="statusAmc" name="statusAmc" maxlength="256" /> -->
                                        <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusAmc" tabindex="-1" aria-hidden="true">
                                        <option value="">Select</option><option value="<?= ACTIVE ?>">Paid</option><option value="<?= INACTIVE ?>"> Due</option>
                                    </select>
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="dueDateAmc">Due Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('dueDateAmc'); ?>" id="dueDateAmc" name="dueDateAmc" maxlength="256" />
                                    </div>
                                    
                                </div>
                               <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amamcYear2datecYear1">AMC Year 1</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear1'); ?>" id="amcYear1" name="amcYear1" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear1dueAmount">AMC Year 1 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear1dueAmount'); ?>" id="amcYear1dueAmount" name="amcYear1dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear1date">AMC Year-1 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('amcYear1date'); ?>" id="amcYear1date" name="amcYear1date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear2">AMC Year 2</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear2'); ?>" id="amcYear2" name="amcYear2" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear2dueAmount">AMC Year 2 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear2dueAmount'); ?>" id="amcYear2dueAmount" name="amcYear2dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear2date">AMC Year-2 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('amcYear2date'); ?>" id="amcYear2date" name="amcYear2date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear3">AMC Year 3</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear3'); ?>" id="amcYear3" name="amcYear3" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear3dueAmount">AMC Year 3 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear3dueAmount'); ?>" id="amcYear3dueAmount" name="amcYear3dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear1date">AMC Year-3 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('amcYear1date'); ?>" id="amcYear1date" name="amcYear1date" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear4">AMC Year 4</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear4'); ?>" id="amcYear4" name="amcYear4" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear4dueAmount">AMC Year 4 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear4dueAmount'); ?>" id="amcYear4dueAmount" name="amcYear4dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear1date">AMC Year-4 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('amcYear1date'); ?>" id="amcYear1date" name="amcYear1date" maxlength="256" /> 
                                    </div>
                                </div>
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear5">AMC Year 5</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear5'); ?>" id="amcYear5" name="amcYear5" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear5dueAmount">AMC Year 5 Due Amount</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('amcYear5dueAmount'); ?>" id="amcYear5dueAmount" name="amcYear5dueAmount" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="amcYear15">AMC Year-5 Date</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('amcYear15'); ?>" id="amcYear15" name="amcYear15" maxlength="256" /> 
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="descAmc">Description</label>
                                        <textarea class="form-control required" id="descAmc" name="descAmc"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>