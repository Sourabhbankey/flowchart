<?php
$amcId = $amcInfo->amcId;
$brnameTitle = $amcInfo->brnameTitle;
$franchiseNum = $amcInfo->franchiseNum;
$brLocation = $amcInfo->brLocation;
$brState = $amcInfo->brState;
$curAmc = $amcInfo->curAmc;
$oldAMCdue = $amcInfo->oldAMCdue;
$totalAmc = $amcInfo->totalAmc;
$statusAmc = $amcInfo->statusAmc;
$dueDateAmc = $amcInfo->dueDateAmc;
$descAmc = $amcInfo->descAmc;
//$selectUserId ='';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Amc Management
        <small>Add / Edit Amc</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Amc Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start --> 
                    <form role="form" action="<?php echo base_url() ?>amc/editAmc" method="post" id="editDespatch" role="form">
                        <div class="box-body">
                        <div class="row">
                                
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="franchiseNum">Franchise No.</label>
                                        <input type="text" class="form-control required" value="<?php echo $franchiseNum; ?>" id="franchiseNum" name="franchiseNum" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="brnameTitle">Branch Name</label>
                                        <input type="text" class="form-control required" value="<?php echo $brnameTitle; ?>" id="brnameTitle" name="brnameTitle" maxlength="256" />
                                        <input type="hidden" value="<?php echo $brnameTitle; ?>" name="brnameTitle" id="brnameTitle" />
                                    </div>  
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="brLocation">Location</label>
                                        <input type="text" class="form-control required" value="<?php echo $brLocation; ?>" id="brLocation" name="brLocation" maxlength="256" />                                 
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="brState">State</label>
                                        <input type="text" class="form-control required" value="<?php echo $brState; ?>" id="brState" name="brState" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="oldAMCdue">Old AMC Due</label>
                                        <input type="text" class="form-control required" value="<?php echo $oldAMCdue; ?>" id="oldAMCdue" name="oldAMCdue" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-8">                                
                                    <div class="form-group">
                                        <label for="curAmc">AMC</label>
                                        <input type="text" class="form-control required" value="<?php echo $curAmc; ?>" id="curAmc" name="curAmc" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="totalAmc">Total</label>
                                        <input type="text" class="form-control required" value="<?php echo $totalAmc; ?>" id="totalAmc" name="totalAmc" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="statusAmc">Status Of AMC</label>
                                        <select class="form-control check select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="statusAmc" tabindex="-1" aria-hidden="true">
                                        <option value="">Select Status</option>
                                        <option value="<?= ACTIVE ?>" <?php if($statusAmc == ACTIVE) {echo "selected=selected";} ?>>Paid</option>
                                        
                                        <option value="<?= INACTIVE ?>" <?php if($statusAmc == INACTIVE) {echo "selected=selected";} ?> >Due</option>
                                    </select>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dueDateAmc">Due Date</label>
                                        <input type="text" class="form-control required" value="<?php echo $dueDateAmc; ?>" id="dueDateAmc" name="dueDateAmc" maxlength="256" /> 
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="descAmc">Description</label>
                                        <textarea class="form-control required" id="descAmc" name="descAmc"><?php echo $descAmc; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>