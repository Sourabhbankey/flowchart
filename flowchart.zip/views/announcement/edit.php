<?php 
    $announcementId = $announcementInfo->announcementId; 
    $announcementName = $announcementInfo->announcementName; 
    $description = $announcementInfo->description; 
?>  

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Announcement Management
            <small>Edit Announcement</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Edit Announcement Details</h3>
                    </div>

                    <form role="form" action="<?php echo base_url('announcement/editAnnouncement'); ?>" method="post" id="editAnnouncement">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="announcementName">Title</label>
                                        <input type="text" class="form-control required" 
                                               value="<?php echo htmlspecialchars($announcementName, ENT_QUOTES, 'UTF-8'); ?>" 
                                               id="announcementName" 
                                               name="announcementName" 
                                               maxlength="256" required />
                                        <input type="hidden" value="<?php echo $announcementId; ?>" name="announcementId" id="announcementId" />
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description" rows="5" required><?php echo htmlspecialchars($description, ENT_QUOTES, 'UTF-8'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo base_url('announcement'); ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>

                </div>
            </div>

            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $error; ?>
                </div>
                <?php } ?>

                <?php 
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
