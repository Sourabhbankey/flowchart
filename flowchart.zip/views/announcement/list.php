<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Announcement Management
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
      <?php if (in_array($role, [26, 24, 2, 14, 1])) { ?>
    <div class="row">
        <div class="col-xs-12 text-right">
            <div class="form-group">
                <a class="btn btn-primary" href="<?php echo base_url(); ?>announcement/add"><i class="fa fa-plus"></i> Add New Announcement</a>
            </div>
        </div>
    </div>
<?php } ?>

        <div class="row">
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Announcement List</h3>
                    <div class="box-tools">
                        <form action="<?php echo base_url() ?>announcement/announcementListing" method="POST" id="searchList">
                            <div class="input-group">
                              <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                              <div class="input-group-btn">
                                <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                              </div>
                            </div>
                        </form>
                    </div>
                </div>
        <div class="box-body table-responsive no-padding1">        
                <div class="row">
    <?php 
    if (!empty($records)) {
        foreach ($records as $record) {
    ?>
    <div class="col-md-4"> <!-- 3 cards per row -->
        <div class="card mb-4">
            <div class="card-body">
                <!-- Image -->
                <?php if (empty($record->annattachmentS3File)) { ?>
                    <img src="https://support-smsfiles.s3.ap-south-1.amazonaws.com/attachements/1731481874-WhatsApp%20Image%202024-07-25%20at%2010.49.50.jpeg" alt="No Image" class="card-img-top mb-3">
                <?php } else { ?>
                    <img src="<?php echo $record->annattachmentS3File ?>" alt="Announcement Image" class="card-img-top mb-3" style="height: 200px; object-fit: cover;">
                <?php } ?>

                <!-- Title -->
                <h5 class="card-title"><?php echo $record->announcementName ?></h5>

                <!-- Created By -->
                <p class="card-text"><strong>Created By:</strong> <?php echo isset($record->createdByName) ? $record->createdByName : 'N/A'; ?></p>

                <!-- Created On -->
                <p class="card-text"><strong>Created On:</strong> <?php echo date("d-m-Y", strtotime($record->createdDtm)) ?></p>

                <!-- View Button -->
               <div class="btn-group" style="margin-bottom: 5px;">
                    <!-- <a href="<?php echo base_url().'announcement/view/'.$record->announcementId; ?>" class="btn btn-primary" target="_blank">View</a> -->
                    <?php if (!empty($record->annattachmentS3File)) { ?>
                        <a href="<?php echo $record->annattachmentS3File ?>" class="btn btn-primary" target="_blank">View </a>
                    <?php } ?>
                </div>


                <!-- Admin Actions -->
                <?php if ($is_admin == 1) { ?>
                <div class="actions mt-2">
                    <a class="btn btn-sm btn-info" href="<?php echo base_url().'announcement/edit/'.$record->announcementId; ?>" title="Edit"><i class="fa fa-pencil"></i> Edit</a>
                    <a class="btn btn-sm btn-danger deleteAnnouncement" href="#" data-announcementid="<?php echo $record->announcementId; ?>" title="Delete"><i class="fa fa-trash"></i> Delete</a>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <?php 
        }
    } else {
        echo '<div class="col-12"><p>No announcements found.</p></div>';
    }
    ?>
</div>
</div>    
                </div><!-- /.box-header -->
                <!-- /.box-body -->
               <div class="br-pagi">
    <?php echo $pagination; ?>
    <p>Showing <?= $start ?> to <?= $end ?> of <?= $total_records ?> records</p>
</div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "announcement/announcementListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<style type="text/css">
    .card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
.card-img-top {
    width: 100%;
}
.card-title {
    font-size: 1.2em;
    font-weight: bold;
}
.card:hover {
    background-color: #ededed;
}
</style>