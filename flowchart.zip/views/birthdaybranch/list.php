<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-building" aria-hidden="true"></i> Branch Anniversary Management
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <!-- General table elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Branch Anniversary List</h3>
                        <div class="pull-right">
                            <a href="<?php echo base_url() ?>branch/addNewBranchAnniversary" class="btn btn-primary"><i class="fa fa-plus"></i> Add New</a>
                        </div>
                    </div><!-- /.box-header -->
                    <div class="box-body">
                        <!-- Success/Error Messages -->
                        <?php
                            $this->load->helper('form');
                            $error = $this->session->flashdata('error');
                            if($error) {
                        ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo $this->session->flashdata('error'); ?>
                        </div>
                        <?php } ?>
                        <?php
                            $success = $this->session->flashdata('success');
                            if($success) {
                        ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php echo $this->session->flashdata('success'); ?>
                        </div>
                        <?php } ?>
                        <div class="row">
                            <div class="col-md-12">
                                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                            </div>
                        </div>
                        <!-- Table -->
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Branch Name</th>
                                    <th>Anniversary/Start Date</th>
                                    <th>Franchise Number</th>
                                    <th>Owner Name</th>
                                    <th>Owner Anniversary</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Sample Data (Replace with dynamic PHP loop) -->
                                <?php
                                    // Example PHP loop (to be replaced with actual data)
                                    $branches = []; // Replace with actual data from controller
                                    if(!empty($branches)) {
                                        $i = 1;
                                        foreach($branches as $branch) {
                                ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo htmlspecialchars($branch['branch_name']); ?></td>
                                    <td><?php echo htmlspecialchars($branch['anniversary_date']); ?></td>
                                    <td><?php echo htmlspecialchars($branch['franchise_number']); ?></td>
                                    <td><?php echo htmlspecialchars($branch['owner_name']); ?></td>
                                    <td><?php echo htmlspecialchars($branch['owner_anniversary']); ?></td>
                                    <td>
                                        <a href="<?php echo base_url().'branch/editBranchAnniversary/'.$branch['id']; ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i> Edit</a>
                                        <a href="<?php echo base_url().'branch/deleteBranchAnniversary/'.$branch['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this record?');"><i class="fa fa-trash"></i> Delete</a>
                                    </td>
                                </tr>
                                <?php
                                            $i++;
                                        }
                                    } else {
                                ?>
                                <tr>
                                    <td colspan="7" class="text-center">No records found</td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div><!-- /.box-body -->
                </div>
            </div>
        </div>
    </section>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script>
    jQuery(document).ready(function() {
        // Initialize Select2 if needed (not used in this table, but included for consistency)
        if (jQuery('.select2').length) {
            jQuery('.select2').select2();
        }

        // CSRF Token Handling (for potential AJAX calls)
        var getCsrfToken = function() {
            var name = jQuery('#csrf_token_name').val();
            var hash = jQuery('#csrf_token_hash').val();
            if (!name || !hash) {
                console.error('CSRF token name or hash is missing.');
                return null;
            }
            return { name: name, hash: hash };
        };
    });
</script>