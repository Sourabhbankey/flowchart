<?php
$freegiftId = $freegiftInfo->freegiftId;
$giftTitle = $freegiftInfo->giftTitle;
$approvedBy = $freegiftInfo->approvedBy;
$dateOfDespatch = $freegiftInfo->dateOfDespatch;
$modeOfDespatch = $freegiftInfo->modeOfDespatch;
$dateDelevery = $freegiftInfo->dateDelevery;
$delStatus = $freegiftInfo->delStatus;
$franchiseNumberArray = explode(",", $freegiftInfo->franchiseNumber);
$franchiseNumberList = implode(",", $franchiseNumberArray);
//print_r($franchiseNumberArray);exit;
$description = $freegiftInfo->description;
$selectUserId ='';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Free Gift Management
        <small>Add / Edit Free Gift</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Free Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>freegift/editFreegift" method="post" id="editFreegift" role="form">
                        <div class="box-body">
                        <div class="row">
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="giftTitle">Gift Title <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $giftTitle; ?>" id="giftTitle" name="giftTitle" maxlength="256" />
                                        <input type="hidden" value="<?php echo $freegiftId; ?>" name="freegiftId" id="freegiftId" />
                                    </div>
                                    
                                </div>
                                <!-- <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise <span class="re-mend-field">*</span></label>
                                     <!--    <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"  multiple data-live-search="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;

                                                    ?>
                                                    <option value="<?php echo $franchiseNumber; ?>" <?php if(in_array($franchiseNumber,$franchiseNumberArray)){echo "selected=selected";} ?>><?php echo $franchiseNumber; ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select> 
                                         <input  type="text" class="form-control required" value="<?php echo $approvedBy; ?>" id="approvedBy" name="approvedBy" maxlength="256">
                                    </div>
                                </div> -->
                                <div class="col-md-6">                                
                                   <div class="form-group">
    <label for="franchiseNumber">Franchise No.</label>
    <input type="text" 
           class="form-control required" 
           value="<?php echo isset($franchiseNumberList) ? $franchiseNumberList : ''; ?>" 
           id="franchiseNumber" 
           name="franchiseNumber" 
           maxlength="256" 
           readonly />
</div>
                                    
                                </div> 
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="approvedBy">Approved By <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $approvedBy; ?>" id="approvedBy" name="approvedBy" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateOfDespatch">Date Of Despatch <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateOfDespatch; ?>" id="dateOfDespatch" name="dateOfDespatch" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="trainingTitle">Mode Of Despatch <span class="re-mend-field">*</span></label>
                                        <input required type="text" class="form-control required" value="<?php echo $modeOfDespatch; ?>" id="modeOfDespatch" name="modeOfDespatch" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="class">Delivery Status <span class="re-mend-field">*</span></label>
                                        <!-- <input required type="text" class="form-control required" value="<?php //echo $class; ?>" id="class" name="class" maxlength="256"> -->
                                         <select class="form-control select2-hidden-accessible" data-plugin-selecttwo="" data-width="100%" data-minimum-results-for-search="Infinity" name="delStatus" tabindex="-1" aria-hidden="true">
                                            <option value="<?= INACTIVE ?>" <?php if($delStatus == INACTIVE) {echo "selected=selected";} ?> >In Process</option> 
                                            <option value="<?= ACTIVE ?>" <?php if($delStatus == ACTIVE) {echo "selected=selected";} ?>>Delivered</option>
                                        </select>
                                    </div>  
                                </div>  
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="dateDelevery">Date Of Delivery <span class="re-mend-field">*</span></label>
                                        <input required type="date" class="form-control required" value="<?php echo $dateDelevery; ?>" id="dateDelevery" name="dateDelevery" maxlength="256">
                                    </div>   
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="description" name="description"><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field {
            color: red;
        }
    </style>
</div>