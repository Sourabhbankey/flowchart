<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i> Attachment Management
        <small>Add / Edit Attachment</small>
    </h1>
    </section>
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                    <h3 class="box-title">Attachment / Upload File Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addTask" action="<?php echo base_url() ?>acattachment/addNewAcattachment" enctype="multipart/form-data" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Attachment Title</label>
                                        <input type="text" class="form-control required" value="<?php echo set_value('acattachmentitle'); ?>" id="acattachmentTitle" name="acattachmentTitle" maxlength="256" />
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Assigned To</label>
                                        <select class="form-control required" id="selectUserId" name="selectUserId">
                                            <option value="0">Select User</option>
                                             <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                    ?>
                                                    <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('selectUserId')) {echo "selected=selected";} ?>><?= $userText ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="acattachmentTitle">Upload File</label>
                                        <input required type="file" name="file" multiple>
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="taskTitle">Franchise</label>
                                        <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]"  multiple data-live-search="true">
                                            <option value="0">Select Franchise</option>
                                            <?php
                                            if(!empty($branchDetail))
                                            {
                                                foreach ($branchDetail as $bd)
                                                {
                                                    $franchiseNumber = $bd->franchiseNumber;
                                                    ?>
                                                     <option value="<?php echo $franchiseNumber; ?>" ><?php echo $franchiseNumber; ?></option>
                                                    <?php

                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                    
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Remark - Short Description</label>
                                        <textarea class="form-control required" id="description" name="description"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
    
</div>