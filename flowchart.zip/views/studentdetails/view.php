<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Student Details
            <!-- <small>View Template</small> -->
        </h1>
    </section>
        <section class="content">
            <div class="row">
                <div class="col-md-10">
                    <div class="box box-primary">
                        <div class="box-header">
                            <!-- <h3 class="box-title">Student Fee Plan Details</h3> -->
                            <div class="box-tools">
                            </button>
                                <a href="<?php echo base_url('studentdetails/view'); ?>" class="btn btn-default btn-sm">
                                    <i class="fa fa-arrow-left"></i> Back to Listing
                                </a>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="container-fluid">
                                <div class="card">
                                    <div class="card-body">
                                        <!-- Basic Details -->
                                        <div class="row">
                                            <div class="col-md-6">
                                                <strong>Student Name:</strong> <br>
                                                <strong>Class:</strong> <br>
                                                <strong>Section:</strong><br>
                                                <strong>Register No:</strong><br>
                                                <strong>Roll No:</strong> <br>
                                            </div>
                                            <div class="col-md-6">
                                                <strong>Mobile:</strong> <br>
                                                <strong>Email:</strong> <br>
                                                <strong>Guardian Name:</strong><br>
                                                <strong>Franchise:</strong> <br>
                                                <strong>Assigned To:</strong><br>
                                            </div>
                                        </div>

                                        <hr>

                                        <!-- Fee Details -->
                                        <h5>Fees</h5>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <strong>Admission Fee:</strong> ₹<br>
                                                <strong>First Month Fee:</strong> ₹<br>
                                            </div>
                                        </div>
                                        <hr>
                                        <!-- Installments -->
                                        <h5>Installments</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Amount (₹)</th>
                                                        <th>Status</th>
                                                        <th>Date</th>
                                                        <th>Late Fee</th>
                                                    </tr>
                                                </thead>
                                              
                                            </table>
                                        </div>
                                        <div class="mt-3">
                                            <a href="<?= base_url('studentdetails/view') ?>" class="btn btn-secondary">Back to List</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</div>
<!-- Newstyle -->
<style type="text/css">
    .table-success, .table-success>td, .table-success>th {
    background-color: #c3e6cb;
}
.badge-success {
    color: #fff;
    background-color: #28a745;
}
.badge {
    display: inline-block;
    padding: .25em .4em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: .25rem;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
.table-warning, .table-warning>td, .table-warning>th {
    background-color: #ffeeba;
}
.badge-warning {
    color: #212529;
    background-color: #ffc107;
}
.btn-secondary {
    color: #fff;
    background-color: #6c757d;
    border-color: #6c757d;
}
</style>
<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

