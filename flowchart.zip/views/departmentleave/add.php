<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Assign Leaves Department-wise
            <small>Add / Edit Leave</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <!-- Left column -->
            <div class="col-md-9">
                <!-- General form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Leave Details</h3>
                    </div><!-- /.box-header -->
                    
                    <!-- Form start -->
                    <?php $this->load->helper("form"); ?>
                     <form role="form" id="yourForm" action="<?php echo base_url() ?>departmentLeave/addNewDepartmentleave" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- <h3><?= isset($department) ? 'Edit' : 'Add' ?> Department Leave</h3> -->
                                <div class="col-md-12">                                
                                    <div class="form-group">
                                        <label>Department Name:</label><br>
                                        <input type="text" class="form-control required" name="department_name" value="<?= isset($department) ? $department->department_name : '' ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label>CL:</label><br>
                                        <input type="number" class="form-control required" name="cl" value="<?= isset($department) ? $department->cl : 0 ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label>SL:</label><br>
                                        <input type="number" class="form-control required" name="sl" value="<?= isset($department) ? $department->sl : 0 ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label>EL:</label><br>
                                        <input type="number" class="form-control required" name="el" value="<?= isset($department) ? $department->el : 0 ?>" required>
                                    </div>
                                </div>

                            </div><!-- /.row -->

                            
                        </div><!-- /.box-body -->

                       <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div><!-- /.box -->
            </div><!-- /.col-md-9 -->

            <!-- Right column -->
            <div class="col-md-4">
                <?php $this->load->helper('form'); ?>
                <?php if ($this->session->flashdata('error')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('success')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', 
                            ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div><!-- /.col-md-4 -->
        </div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<!-- Set minimum date for start_date and end_date -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('start_date').setAttribute('min', today);
        document.getElementById('end_date').setAttribute('min', today);
    });
</script>

<!-- Disable submit button on form submission -->
<script>
    const form = document.getElementById('yourForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
    });
</script>
