<!DOCTYPE html>
<html>
<head>
    <title>Revision History</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <h3>Revision History</h3>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Module</th>
                <th>Action</th>
                <th>Date & Time</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($revisions)): ?>
                <?php foreach ($revisions as $rev): ?>
                    <tr>
                        <td><?= $rev->userId ?></td>
                        <td><?= htmlspecialchars($rev->name) ?></td>
                        <td><?= htmlspecialchars($rev->module_name) ?></td>
                        <td><?= nl2br(htmlspecialchars($rev->action)) ?></td>
                        <td><?= $rev->changed_at ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">No revision history found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
