<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Classes Fee Template Management
            <small><?php echo isset($classesfeetemplateInfo) ? 'Edit' : 'Add'; ?> Template</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-md-8">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Classes Fee Template Details</h3>
                           <div class="pull-right">
            <a href="<?php echo base_url() ?>classesfeetemplate/classesfeetemplateListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" action="<?php echo base_url() ?>classesfeetemplate/addNewClassesfeetemplate" enctype="multipart/form-data" method="post" id="addNewClassesfeetemplate">
                        <div class="box-body">
                            <div class="row">
                                <?php if (isset($classesfeetemplateInfo)) { ?>
                                    <input type="hidden" name="classfeeId" value="<?php echo $classesfeetemplateInfo->classfeeId; ?>">
                                <?php } ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchFranchiseData(this.value)">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                    foreach ($branchDetail as $bd) {
                                                        $selected = ($bd->franchiseNumber == (isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->franchiseNumber : $defaultFranchise)) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($bd->franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($bd->franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="branchFranchiseAssigned">Franchise Assigned to <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned" required>
                                            <option value="">Select Role</option>
                                            <?php
                                            if (isset($classesfeetemplateInfo) && $classesfeetemplateInfo->brspFranchiseAssigned) {
                                                $selectedUserName = $this->classfee->getUserNameById($classesfeetemplateInfo->brspFranchiseAssigned);
                                                echo '<option value="' . htmlspecialchars($classesfeetemplateInfo->brspFranchiseAssigned) . '" selected>' . htmlspecialchars($selectedUserName) . '</option>';
                                            }
                                            ?>
                                        </select>
                                        <span id="branchFranchiseAssignedLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="brAddress">Branch Address <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="brAddress" name="brAddress" value="<?php echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->brAddress) : ''; ?>" maxlength="255" required readonly aria-describedby="brAddressLoading">
                                        <span id="brAddressLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="branchContacNum">Contact Number <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="branchContacNum" name="branchContacNum" value="<?php echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->branchContacNum) : ''; ?>" maxlength="255" required readonly aria-describedby="branchContacNumLoading">
                                        <span id="branchContacNumLoading" class="help-block" style="display: none;">Loading...</span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <!-- <div class="form-group">
                                        <label for="mission">Mission</label>
                                        <textarea class="form-control required" id="mission" name="mission"><?php //echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->mission) : ''; 
                                                                                                            ?></textarea>
                                    </div> -->
                                    <div class="form-group">
                                        <label for="mission">Mission</label>
                                        <textarea class="form-control" id="mission" name="mission" readonly>
                                At eduMETA The i-SCHOOL, we strive to deliver holistic, personalized learning so that every child can reach their full potential. Our comprehensive platform is designed to support personalized learning in schools, with a strong focus on the holistic development of each child.
                                    </textarea>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="formfee">Form Fee <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="formfee" name="formfee" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->formfee : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="admissionfees">Admission Fees <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="admissionfees" name="admissionfees" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->admissionfees : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installment1">Toddlers <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="toddlers" name="toddlers" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->toddlers : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installment1">Play Group <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="playgroup" name="playgroup" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->playgroup : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installment1">Nursery<span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="nursery" name="nursery" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->nursery : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installment1">KG-1 <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="kg1" name="kg1" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->kg1 : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installment1">KG-2 <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="kg2" name="kg2" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->kg2 : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="installment1">KIT Charges <span class="re-mend-field">*</span></label>
                                        <input type="text" class="form-control required" id="kitcharges" name="kitcharges" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->kitcharges : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="offers">Offers <span class="re-mend-field">*</span></label>
                                        <textarea class="form-control required" id="offers" name="offers"><?php echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->offers) : ''; ?></textarea>
                                    </div>
                                </div>


                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="additionalcharges">Annual Charges</label>
                                        <textarea class="form-control" id="additionalcharges" name="additionalcharges"><?php echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->additionalcharges) : ''; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="additionalcharges">Activity Charges</label>
                                        <textarea class="form-control" id="activitycharges" name="activitycharges"><?php echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->activitycharges) : ''; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="keyhighlights">Key Highlights</label>
                                        <textarea class="form-control" id="keyhighlights" name="keyhighlights"><?php echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->keyhighlights) : ''; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="installmentType">Installments Breakup <span class="re-mend-field">*</span></label>
                                        <select class="form-control required" id="installmentType" name="installmentType" required>
                                            <option value="">-- Select Option --</option>
                                            <option value="Annually (1 Installment)">Annually (1 Installment)</option>
                                            <option value="Half-Yearly (2 Installments)">Half-Yearly (2 Installments)</option>
                                            <option value="Triannual (3 Installments)">Triannual (3 Installments)</option>
                                            <option value="Quarterly (4 Installments)">Quarterly (4 Installments)</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- <div class="col-md-3 installmentdate-1">                                
                                    <div class="form-group">
                                        <label for="dateof1installment">Date of 1 Installment</label>
                                        <input  type="date" class="form-control required" id="dateof1installment" name="dateof1installment">
                                    </div>
                                </div> -->
                                <div class="col-md-3 installmentdate-2">
                                    <div class="form-group">
                                        <label for="dateof2installment">Date of 2 Installment</label>
                                        <input type="date" class="form-control required" id="dateof2installment" name="dateof2installment">
                                    </div>
                                </div>
                                <div class="col-md-3 installmentdate-3">
                                    <div class="form-group">
                                        <label for="dateof3installment">Date of 3 Installment</label>
                                        <input type="date" class="form-control required" id="dateof3installment" name="dateof3installment">
                                    </div>
                                </div>
                                <div class="col-md-3 installmentdate-4">
                                    <div class="form-group">
                                        <label for="dateof4installment">Date of 4 Installment</label>
                                        <input type="date" class="form-control required" id="dateof4installment" name="dateof4installment">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment1">1st Installment Play Group<span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment1play" name="installment1play" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment1play : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment2">2nd Installment Play Group <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment2play" name="installment2play" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment2play : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment3">3rd Installment Play Group <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment3play" name="installment3play" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment3play : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment4">4th Installment Play Group <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment4play" name="installment4play" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment4play : ''; ?>" maxlength="256" />
                                    </div>
                                </div>

                                <!-- Nursery  -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment1">1st Installment Nursery<span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment1nur" name="installment1nur" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment1nur : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment2">2nd Installment Nursery <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment2nur" name="installment2nur" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment2nur : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment3">3rd Installment Nursery <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment3nur" name="installment3nur" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment3nur : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment4">4th Installment Nursery <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment4nur" name="installment4nur" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment4nur : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <!-- KG-1 -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment1">1st Installment kg1<span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment1kg1" name="installment1kg1" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment1kg1 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment2">2nd Installment kg1 <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment2kg1" name="installment2kg1" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment2kg1 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment3">3rd Installment kg1<span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment3kg1" name="installment3kg1" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment3kg1 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment4">4th Installment KG1 <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment4kg1" name="installment4kg1" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment4kg1 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <!-- Kg-2 -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment1">1st Installment Kg2<span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment1kg2" name="installment1kg2" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment1kg2 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment2">2nd Installment Kg2 <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment2kg2" name="installment2kg2" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment2kg2 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment3">3rd Installment Kg2<span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment3kg2" name="installment3kg2" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment3kg2 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="installment4">4th Installment Kg2 <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="installment4kg2" name="installment4kg2" value="<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->installment4kg2 : ''; ?>" maxlength="256" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="lateFeeCharges">Late fee charges <span class="re-mend-field">*</span></label>
                                        <input type="number" step="0.01" class="form-control required" id="lateFeeCharges" name="lateFeeCharges" value="<?php echo isset($lateFeeCharges) ? $lateFeeCharges->lateFeeCharges : ''; ?>" maxlength="256" required />
                                    </div>
                                </div>
                                <!-- <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="pointstoremember">Points to Remember</label>
                                        <textarea class="form-control required" id="pointstoremember" name="pointstoremember"><?php //echo isset($classesfeetemplateInfo) ? htmlspecialchars($classesfeetemplateInfo->pointstoremember) : ''; 
                                                                                                                                ?></textarea>
                                    </div>
                                </div> -->
                            </div>
                        </div>

                        <div class="box-footer">
                            <button type="submit" id="submitBtn" class="btn btn-primary">Submit</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-4">
                <?php if ($error = $this->session->flashdata('error')) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $error; ?>
                    </div>
                <?php } ?>
                <?php if ($success = $this->session->flashdata('success')) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $success; ?>
                    </div>
                <?php } ?>
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '</div>'); ?>
            </div>
        </div>
    </section>
</div>

<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

<script>
    $(document).ready(function() {

        // Initialize CKEditor for description
        //CKEDITOR.replace('pointstoremember');
        // Array of element IDs to apply CKEditor to
        var editorIds = ['additionalcharges', 'activitycharges', 'keyhighlights', 'offers', 'mission', 'pointstoremember'];

        // Loop through the IDs and initialize CKEditor for each
        editorIds.forEach(function(id) {
            if (document.getElementById(id)) {
                CKEDITOR.replace(id);
            }
        });

        // Initialize Select2 for franchiseNumber and branchFranchiseAssigned
        $('#franchiseNumber').select2({
            placeholder: "Select Franchise",
            allowClear: true,
            width: '100%'
        });

        $('#branchFranchiseAssigned').select2({
            placeholder: "Select Role",
            allowClear: true,
            width: '100%'
        });

        // Fetch franchise data on page load if franchiseNumber is set
        const franchiseInput = $('#franchiseNumber');
        if (franchiseInput.is('select') && franchiseInput.val() || franchiseInput.is('input') && franchiseInput.val()) {
            fetchFranchiseData(franchiseInput.val());
        }

        // Fetch franchise data on franchiseNumber change
        $('#franchiseNumber').on('change', function() {
            fetchFranchiseData(this.value);
        });

        // Form submission handling
        $('#classesFeeTemplateForm').on('submit', function(e) {
            let submitBtn = $('#submitBtn');
            let branchFranchiseAssigned = $('#branchFranchiseAssigned').val();

            <?php if ($role != 25) { ?>
                if (!branchFranchiseAssigned) {
                    e.preventDefault();
                    alert('Please select a Growth Manager.');
                    submitBtn.prop('disabled', false).text('Submit');
                    return false;
                }
            <?php } ?>

            if (submitBtn.prop('disabled')) {
                e.preventDefault();
                return;
            }
            submitBtn.prop('disabled', true).text('Submitting...');
        });
    });

    function fetchFranchiseData(franchiseNumber) {
        const assignedSelect = $('#branchFranchiseAssigned');
        const brAddressInput = $('#brAddress');
        const branchContacNumInput = $('#branchContacNum');
        const assignedLoading = $('#branchFranchiseAssignedLoading');
        const brAddressLoading = $('#brAddressLoading');
        const branchContacNumLoading = $('#branchContacNumLoading');

        assignedSelect.prop('disabled', true);
        assignedLoading.show();
        brAddressLoading.show();
        branchContacNumLoading.show();

        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("classesfeetemplate/fetchFranchiseData"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    selectedUserId: '<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->brspFranchiseAssigned : ''; ?>',
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.userIds) {
                        let userIds = response.userIds.split(',');
                        let userNames = response.html.split(', ');
                        let selectedUserId = '<?php echo isset($classesfeetemplateInfo) ? $classesfeetemplateInfo->brspFranchiseAssigned : ''; ?>';
                        $('#assignedSelect option[value="0"]').remove();
                        assignedSelect.empty();
                        $('#assignedSelect').html('<option value="">No Growth Manager Available</option>');
                        userIds.forEach((userId, index) => {
                            let selected = (userId == selectedUserId) ? 'selected' : '';
                            assignedSelect.append(`<option value="${userId}" ${selected}>${userNames[index]}</option>`);
                        });
                    } else {
                        assignedSelect.empty();
                        assignedSelect.append('<option value="">No Growth Managers assigned</option>');
                        if (response.message) {
                            alert(response.message);
                        }
                    }

                    assignedSelect.prop('disabled', false);

                    if (response.status === 'success' && response.franchiseData) {
                        brAddressInput.val(response.franchiseData.brAddress || '');
                        branchContacNumInput.val(response.franchiseData.branchContacNum || '');
                    } else {
                        brAddressInput.val('');
                        branchContacNumInput.val('');
                        if (response.franchiseMessage) {
                            alert(response.franchiseMessage);
                        }
                    }

                    assignedLoading.hide();
                    brAddressLoading.hide();
                    branchContacNumLoading.hide();
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    assignedSelect.empty();
                    assignedSelect.append('<option value="">Failed to load Growth Managers</option>');
                    brAddressInput.val('');
                    branchContacNumInput.val('');
                    assignedLoading.hide();
                    brAddressLoading.hide();
                    branchContacNumLoading.hide();
                    alert('Failed to fetch franchise data. Please try again or contact support.');
                }
            });
        } else {
            assignedSelect.empty();
            assignedSelect.append('<option value="">Select Role</option>');
            assignedSelect.prop('disabled', false);
            brAddressInput.val('');
            branchContacNumInput.val('');
            assignedLoading.hide();
            brAddressLoading.hide();
            branchContacNumLoading.hide();
        }
    }
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const installmentSelect = document.getElementById('installmentType');

        function updateInstallmentFields() {
            const value = installmentSelect.value;

            // First hide all installment fields
            document.querySelectorAll('[class*="installmentdate-"]').forEach(el => el.style.display = 'none');

            // Determine how many installments to show
            let count = 0;
            if (value.includes("Annually")) count = 1;
            else if (value.includes("Half-Yearly")) count = 2;
            else if (value.includes("Triannual")) count = 3;
            else if (value.includes("Quarterly")) count = 4;

            // Show only the needed ones
            for (let i = 1; i <= count; i++) {
                document.querySelectorAll('.installmentdate-' + i).forEach(el => el.style.display = '');
            }
        }

        installmentSelect.addEventListener('change', updateInstallmentFields);

        // Trigger on load in case of edit
        updateInstallmentFields();

    });
</script>