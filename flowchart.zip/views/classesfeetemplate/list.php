<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-money" aria-hidden="true"></i> Standard Classes Fee Template Management
            <!-- <small>List Standard Classes Fee Templates</small> -->
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="text-right mb-3">
                    <a href="<?php echo base_url(); ?>classesfeetemplate/add" class="btn btn-primary">
                        <i class="fa fa-plus"></i> Add New
                    </a>
                </div>
                <div class="box">
                    <!-- <div class="box-header">
                        <h3 class="box-title">Standard Classes Fee Templates</h3>
                        <div class="box-tools">
                            <div class="d-flex align-items-center">
                                <form action="<?php //echo base_url() ?>classesfeetemplate/classesFeeTemplateListing" method="POST" id="searchList" class="mr-3">
                                    <div class="input-group">
                                        <input type="text" name="searchText" value="<?php //echo $searchText; ?>" class="form-control input-sm" style="width: 150px;" placeholder="Search" />
                                        <div class="input-group-btn">
                                            <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div> -->
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding1">
                      <table id="example" class="display table table-hover responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Franchise Assigned</th>
                                <th>Mission</th>
                                <th>Form Fee</th>
                                <th>Admission Fees</th>
                                <th>Franchise Number</th>
                                <th>Offers</th>
                                <th>Additional Charges</th>
                                <th>Key Highlights</th>
                                <th>Installment 1</th>
                                <th>Installment 2</th>
                                <th>Installment 3</th>
                                <th>Installment 4</th>
                                <th>Installments Breakup</th>
                                <th>Late fee charges</th>
                                <th>Points to Remember</th>
                                <th>Created By</th>
                                <th>Created Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($feeTemplates)) {
                                foreach ($feeTemplates as $template) { ?>
                                    <tr>
                                        <td><?= $template->classfeeId; ?></td>
                                        <td><?= ($template->assignedToName ?? 'N/A'); ?></td>
                                        <td><?= ($template->mission); ?></td>
                                        <td><?= is_numeric($template->formfee) ? number_format((float)$template->formfee, 2) : 'N/A'; ?></td>
                                        <td><?= is_numeric($template->admissionfees) ? number_format((float)$template->admissionfees, 2) : 'N/A'; ?></td>
                                       
                                        <td><?= ($template->franchiseNumber); ?></td>
                                        <td><?= ($template->offers); ?></td>
                                        <td><?= ($template->additionalcharges) ? number_format((float)$template->additionalcharges, 2) : 'N/A'; ?></td>
                                        <td>
                                            <ul>
                                              <li>Fee can be paid in installments.</li>
                                              <li>Educational outdoor trips as per planning.</li>
                                              <li>Settlers Session to overcome Separation Anxiety of children.</li>
                                              <li>Add on Activities: Summer and Winter Camp.</li>
                                              <li>Grooming sessions of Parents through workshops.</li>
                                              <li>Movie Club sessions for students.</li>
                                            </ul>
                                            <?= ($template->keyhighlights); ?>
                                        </td>
                                        <td><?= is_numeric($template->installment1play) ? number_format((float)$template->installment1play, 2) : 'N/A'; ?></td>
                                        <td><?= is_numeric($template->installment2play) ? number_format((float)$template->installment2play, 2) : 'N/A'; ?></td>
                                        <td><?= is_numeric($template->installment3play) ? number_format((float)$template->installment3play, 2) : 'N/A'; ?></td>
                                        <td><?= is_numeric($template->installment4play) ? number_format((float)$template->installment4play, 2) : 'N/A'; ?></td>
                                        <td><?php echo $template->installmentType; ?></td>
                                        <td><?php echo $template->lateFeeCharges; ?></td>
                                        <td><?= ($template->pointstoremember); ?></td>
                                        <td><?= ($template->createdByName); ?></td>
                                        <td><?= date('Y-m-d', strtotime($template->createdDtm)); ?></td>
                                        <td>
                                            <a class="btn btn-sm btn-info" href="<?= base_url('classesfeetemplate/edit/' . $template->classfeeId); ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                                            <a class="btn btn-sm btn-primary" href="<?= base_url('classesfeetemplate/view/' . $template->classfeeId); ?>" title="View"><i class="fa fa-eye"></i></a>
                                        </td>
                                    </tr>
                            <?php }
                            } else { ?>
                                <tr>
                                    <td colspan="18">No records found</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                </table>

                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer clearfix">
                    <div class="br-pagi">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
                </div>
                <!-- /.box -->
            </div>
        </div>
    </section>
</div>

<style>
    /* Ensure box-tools content is aligned properly */
    .box-tools .d-flex {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 10px;
        /* Space between elements in box-tools */
    }

    .box-tools form {
        margin-bottom: 0;
        /* Remove default form margin */
    }

    .text-right.mb-3 {
        margin-bottom: 15px;
        /* Space below the Add New button */
    }
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }    
/*table-css*/ 
table.dataTable>tbody>tr.child span.dtr-title {
    display: inline-block;
    /*min-width: 75px;*/
    min-width: 50%;
    font-weight: bold;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
    position: relative;
    padding-left: 30px;
    cursor: pointer;
}
div.dataTables_wrapper li {
    text-indent: 0;
}
table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
    content: "-";
    background-color: #d33333;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
}
table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before, table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
    top: 50%;
    left: 5px;
    height: 1em;
    width: 1em;
    margin-top: -9px;
    display: block;
    position: absolute;
    color: white;
    border: .15em solid white;
    border-radius: 1em;
    box-shadow: 0 0 .2em #444;
    box-sizing: content-box;
    text-align: center;
    text-indent: 0 !important;
    font-family: "Courier New",Courier,monospace;
    line-height: 1em;
    content: "+";
    background-color: #31b131;
} 
</style>

<script>
    $(document).ready(function() {
        $('.deleteFeeTemplate').click(function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            if (confirm('Are you sure you want to delete this fee template?')) {
                $.ajax({
                    url: '<?php echo base_url('classesfeetemplate/deleteclassesFeeTemplate'); ?>',
                    type: 'POST',
                    data: {
                        dcfeetempId: id
                    },
                    success: function(response) {
                        alert('Fee template deleted successfully');
                        location.reload();
                    },
                    error: function() {
                        alert('Error deleting fee template');
                    }
                });
            }
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable();
} );

$(document).ready(function() {
        $("#example_paginate").hide();
        // $("#example_info").hide();
    });
</script>

<!-- DataTables Select CSS -->
<!-- <link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet"> -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
