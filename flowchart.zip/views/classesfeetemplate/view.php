<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> Class Fee Template Management
            <!-- <small>View Template</small> -->
        </h1>
    </section>
        <section class="content">
            <div class="row">
                <div class="col-md-10">
                    <div class="box box-primary">
                        <div class="box-header">
                            <h3 class="box-title">Class Fee Template Details</h3>
                            <div class="box-tools">
                                <!-- <button type="button" class="btn btn-primary btn-sm" onclick="window.print()">
                                    <i class="fa fa-print"></i> Print
                                </button> -->
                                <button type="button" class="btn btn-success btn-sm" onclick="downloadPDF()">
                              <i class="fa fa-file-pdf-o"></i> Download PDF
                            </button>
                                <a href="<?php echo base_url('classesfeetemplate/classesfeetemplateListing'); ?>" class="btn btn-default btn-sm">
                                    <i class="fa fa-arrow-left"></i> Back to Listing
                                </a>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="row scfee">
                                <!-- New-code -->
                                <!-- Header Section -->
                                    <div class="feetemp-head">
                                         <div class="header-info">
                                            <p class="stats">www.theischool.com</p>
                                        </div>
                                        <div class="logo">
                                            <img src="<?php echo base_url('uploads/fee/logo-new.webp'); ?>" alt="Logo" >
                                        </div>
                                        <div class="header-info">
                                          <div class="stats-row">
                                             <div class="stats-row">
                                              <div class="stat-item">
                                                <div class="stat-number">950+</div>
                                                <div class="stat-label">Locations</div>
                                              </div>
                                              <div class="stat-item">
                                                <div class="stat-number">280+</div>
                                                <div class="stat-label">Cities</div>
                                              </div>
                                              <div class="stat-item">
                                                <div class="stat-number">28</div>
                                                <div class="stat-label">States</div>
                                              </div>
                                              <div class="stat-item">
                                                <div class="stat-number">25000+</div>
                                                <div class="stat-label">Students</div>
                                              </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Mission Section -->
                                        <div class="mission">
                                            <h2>Our mission is to enable all children to reach their potential with happiness</h2>
                                            <p style="font-size: larger;">
                                                <?php 
                                                //if (!empty($classesfeetemplateInfo->mission)) {
                                                    //echo htmlspecialchars($classesfeetemplateInfo->mission);
                                                //}
                                                ?>
                                                At eduMETA The i-SCHOOL, we strive to deliver holistic, personalized learning so that every child can reach their full potential. Our comprehensive platform is designed to support personalized learning in schools, with a strong focus on the holistic development of each child.
                                            </p>



                                        </div>
                                        <!-- Image Section -->
                                        <div class="main">
                                            <img src="<?php echo base_url('uploads/fee/main-new-img.webp'); ?>" alt="Main Image">
                                            <div class="text-overlay">
                                                <p>Branch no. <?= htmlspecialchars($classesfeetemplateInfo->franchiseNumber); ?></p>
                                                <p>Fee Structure</p>
                                                <p>Session 2025-26</p>
                                            </div>
                                        </div>
                                        <div class="fee-structure" style="margin-left: 30px;margin-right: 30px;">
                                            <table class="eligibility-table" style="background-color: #f9f9f9;">
                                                <tr>
                                                    <th>Minimum Age Eligibility for Admission</th>
                                                    <th>Play Group</th>
                                                    <th>Nursery</th>
                                                    <th>KG-1</th>
                                                    <th>KG-2</th>
                                                </tr>
                                                <tr style="background-color:#fff; border: 0.5px solid #9d9d9d;">
                                                    <td >Minimum Age as on 1<sup>st</sup> April 2025</td>
                                                    <td style="border: 0.5px solid #9d9d9d;">2yrs-3yrs</td>
                                                    <td style="border: 0.5px solid #9d9d9d;">3yrs-4yrs</td>
                                                    <td style="border: 0.5px solid #9d9d9d;">4yrs-5yrs</td>
                                                    <td>5yrs-6yrs</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="fees" style="margin-left: 10px;margin-right: 10px;">
                                            <table class="fee-table">
                                                <tr class="full-width">
                                                    <th colspan="7">Form Fee: <?= is_numeric($classesfeetemplateInfo->admissionfees) ? number_format((float)$classesfeetemplateInfo->formfee, 2) : 'N/A'; ?></th>
                                                </tr>
                                                <tr class="full-width">
                                                    <th colspan="7">Admission Fee : <?= is_numeric($classesfeetemplateInfo->admissionfees) ? number_format((float)$classesfeetemplateInfo->admissionfees, 2) : 'N/A'; ?></th>
                                                </tr>
                                                <tr>
                                                    <th style="background-color: white; text-align: center;">Classes</th>
                                                    <th style="background-color: white; text-align: center;">Toddlers</th>
                                                    <th style="background-color: white; text-align: center;">Play Group</th>
                                                    <th style="background-color: white; text-align: center;">Nursery</th>
                                                    <th style="background-color: white; text-align: center;">KG-1</th>
                                                    <th style="background-color: white; text-align: center;">KG-2</th>
                                                    <th style="background-color: white; text-align: center;">Kit Charges</th>
                                                </tr>
                                                <tr>
                                            <td style="background-color: white; text-align: center;">Yearly Fees</td>
                                            <td style="background-color: white;"><?php echo $classesfeetemplateInfo->toddlers; ?></td>
                                            <td style="background-color: white;"><?php echo $classesfeetemplateInfo->playgroup; ?></td>
                                            <td style="background-color: white;"><?php echo $classesfeetemplateInfo->kg1; ?></td>
                                            <td style="background-color: white;"><?php echo $classesfeetemplateInfo->kg2; ?></td>
                                            <td style="background-color: white;"><?php echo $classesfeetemplateInfo->toddlers; ?></td>
                                            <td style="background-color: white;"><?php echo $classesfeetemplateInfo->kitcharges; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="mainfac">
                                              <div class="facilities" style="margin-bottom: -30px; margin-left: 50px;">
                                             <h4>Offers: </h4>
                                                    <p>
                                                        <?= !empty($classesfeetemplateInfo->offers) ? $classesfeetemplateInfo->offers : 'N/A'; ?>
                                                    </p>

                                               <h4>Additional Charges:</h4>
                                                    <ul>
                                                        <li>Activity Charges : <?= !empty($classesfeetemplateInfo->additionalcharges)         ? $classesfeetemplateInfo->additionalcharges : 'N/A'; ?>
</li>
                                                        <li>Annual Charges : <?= !empty($classesfeetemplateInfo->additionalcharges) ? $classesfeetemplateInfo->activitycharges : 'N/A'; ?></li>
                                                    </ul>
                                            </div>
                                            <div class="prism">
                                              <img src="<?php echo base_url('uploads/fee/prismo.png'); ?>" alt="" srcset="" style="width: 230px;position: relative;top: 30%;">
                                            </div>
                                        </div>
                                        <!-- Footer Section -->
                                        <!-- <footer class="footer">
                                            <p>School address:</p>
                                            <p>Contact:</p>
                                        </footer> -->
                                        <div class="points space">
                                            <h3 style="text-align: left;">Key Highlights:</h3>
                                            <ul style="margin-bottom: 0px;">
                                                  <li>Fee can be paid in installments.</li>
                                                  <li>Educational outdoor trips as per planning.</li>
                                                  <li>Settlers Session to overcome Separation Anxiety of children.</li>
                                                  <li>Add on Activities: Summer and Winter Camp.</li>
                                                  <li>Grooming sessions of Parents through workshops.</li>
                                                  <li>Movie Club sessions for students.</li>
                                            </ul>
                                            <?= !empty($classesfeetemplateInfo->keyhighlights) ? $classesfeetemplateInfo->keyhighlights : ''; ?>
                                                
                                        </div>
                                    <div class="installments">
                                        <h3>Installments Breakup:</h3>
                                        <p><?php echo $classesfeetemplateInfo->installmentType; ?> -</p>
                                        
                                        <?php
// Determine which installments have data
$installments = [
    '1' => [
        $classesfeetemplateInfo->installment1play,
        $classesfeetemplateInfo->installment1nur,
        $classesfeetemplateInfo->installment1kg1,
        $classesfeetemplateInfo->installment1kg2
    ],
    '2' => [
        $classesfeetemplateInfo->installment2play,
        $classesfeetemplateInfo->installment2nur,
        $classesfeetemplateInfo->installment2kg1,
        $classesfeetemplateInfo->installment2kg2
    ],
    '3' => [
        $classesfeetemplateInfo->installment3play,
        $classesfeetemplateInfo->installment3nur,
        $classesfeetemplateInfo->installment3kg1,
        $classesfeetemplateInfo->installment3kg2
    ],
    '4' => [
        $classesfeetemplateInfo->installment4play,
        $classesfeetemplateInfo->installment4nur,
        $classesfeetemplateInfo->installment4kg1,
        $classesfeetemplateInfo->installment4kg2
    ],
];

// Filter out installments where all values are empty
$visibleInstallments = [];
foreach ($installments as $index => $values) {
    $hasData = false;
    foreach ($values as $value) {
        if (!empty($value)) {
            $hasData = true;
            break;
        }
    }
    if ($hasData) {
        $visibleInstallments[] = $index;
    }
}

// Label data
/*$installmentLabels = [
    '1' => ['label' => '1<sup>st</sup> Installment', 'desc' => 'At the time of <br> Admission'],
    '2' => ['label' => '2<sup>nd</sup> Installment', 'desc' => 'By 10<sup>th</sup> Sep 2025'],
    '3' => ['label' => '3<sup>rd</sup> Installment', 'desc' => 'By 10<sup>th</sup> Dec 2025'],
    '4' => ['label' => '4<sup>th</sup> Installment', 'desc' => 'By 10<sup>th</sup> Jan 2026'],
];*/
/*Date-format-function*/
function formatDateWithSup($dateStr) {
    $date = new DateTime($dateStr);
    $day = (int)$date->format('j');
    $monthYear = $date->format('M Y');

    // Determine ordinal suffix
    if ($day % 100 >= 11 && $day % 100 <= 13) {
        $suffix = 'th';
    } else {
        switch ($day % 10) {
            case 1: $suffix = 'st'; break;
            case 2: $suffix = 'nd'; break;
            case 3: $suffix = 'rd'; break;
            default: $suffix = 'th';
        }
    }

    return 'By ' . $day . '<sup>' . $suffix . '</sup> ' . $monthYear;
}
/*End-Date-format-function*/
$installmentLabels = [
    '1' => ['label' => '1<sup>st</sup> Installment', 'desc' => 'At the time of <br> Admission'],
    '2' => ['label' => '2<sup>nd</sup> Installment', 'desc' => formatDateWithSup($classesfeetemplateInfo->dateof2installment)],
    '3' => ['label' => '3<sup>rd</sup> Installment', 'desc' => formatDateWithSup($classesfeetemplateInfo->dateof3installment)],
    '4' => ['label' => '4<sup>th</sup> Installment', 'desc' => formatDateWithSup($classesfeetemplateInfo->dateof4installment)],
];
?>

                                        <table class="table table-bordered">
    <tr>
        <th style="color: black;">Classes</th>
        <?php foreach ($visibleInstallments as $i): ?>
            <th style="color: black;"><?= $installmentLabels[$i]['label']; ?></th>
        <?php endforeach; ?>
    </tr>
    <tr class="fee-composition">
        <td>Fee <br> Composition</td>
        <?php foreach ($visibleInstallments as $i): ?>
            <td><?= $installmentLabels[$i]['desc']; ?></td>
        <?php endforeach; ?>
    </tr>
    <tr>
        <td>Play Group</td>
        <?php foreach ($visibleInstallments as $i): ?>
            <td><?= $classesfeetemplateInfo->{'installment' . $i . 'play'}; ?></td>
        <?php endforeach; ?>
    </tr>
    <tr>
        <td>Nursery</td>
        <?php foreach ($visibleInstallments as $i): ?>
            <td><?= $classesfeetemplateInfo->{'installment' . $i . 'nur'}; ?></td>
        <?php endforeach; ?>
    </tr>
    <tr>
        <td>KG-1</td>
        <?php foreach ($visibleInstallments as $i): ?>
            <td><?= $classesfeetemplateInfo->{'installment' . $i . 'kg1'}; ?></td>
        <?php endforeach; ?>
    </tr>
    <tr>
        <td>KG-2</td>
        <?php foreach ($visibleInstallments as $i): ?>
            <td><?= $classesfeetemplateInfo->{'installment' . $i . 'kg2'}; ?></td>
        <?php endforeach; ?>
    </tr>
</table>

                                    </div>
                                    <div class="points space">
                                        <h3>Points to Remember</h3>
                                        <?php
                                           /* if (!empty($classesfeetemplateInfo->pointstoremember)) {
                                                echo $classesfeetemplateInfo->pointstoremember;
                                            }*/
                                        ?>

                                        <ul>
                                          <li>Cheque bounce charges are Rs.500/-.</li>
                                          <li>Kindly submit fees on time to avoid late fee charges & any inconvenience.</li>
                                          <li>Late fee charges are Rs.<?php echo $classesfeetemplateInfo->lateFeeCharges; ?>/- per day from the due date.</li>
                                          <li>Fees paid is entirely non-refundable & non-adjustable in any form.</li>
                                          <li>Preference will be given to QR/UPI/DBT (Direct Bank Transfer).</li>
                                          <li>Avoid cash payment.</li>
                                          <li>Please take all receipts for your financial transactions from the school and preserve the same till the end of the session, if required for verification.</li>
                                        </ul>

                                    </div>
                                    <div class="silder">
                                        <img src="<?php echo base_url('uploads/fee/awards-silder.webp'); ?>" alt="" style="width: 100%;">
                                    </div>
                                    <!-- Footer Section -->
                                    <footer class="footer">
                                        <p><strong> School address: <?php echo $classesfeetemplateInfo->brAddress; ?></strong></p>
                                        <p><strong> Contact: <?php echo $classesfeetemplateInfo->branchContacNum; ?></strong></p>
                                    </footer>
                                <!-- End-New-code -->
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Flash Messages -->
                <div class="col-md-4">
                    <?php if ($error = $this->session->flashdata('error')): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?= $error; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success = $this->session->flashdata('success')): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <?= $success; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
</div>

<style>
    /* Regular view styling */
    .fee-field { /* Optional: Add specific styling for fee fields if needed */ }

    /* Print-specific styling */
    @media print {
        .content-wrapper {
            margin: 0;
            padding: 0;
        }
        .content-header, .box-header, .box-tools, .alert, .sidebar, .navbar, .footer, .form-group:not(.fee-field) {
            display: none !important;
        }
        .box {
            border: none;
            box-shadow: none;
        }
        .box-body {
            padding: 0px;
        }
        .row {
            display: block;
        }
        .col-md-4, .col-md-6, .col-md-12 {
            width: 100%;
            float: none;
        }
        .fee-field {
            display: table-row !important;
        }
        .fee-field label, .fee-field p {
            display: table-cell;
            padding: 8px;
            border: 1px solid #ddd;
            vertical-align: middle;
            white-space: nowrap; /* Prevent text wrapping */
        }
        .fee-field label {
            font-weight: bold;
            background-color: #f9f9f9;
            width: 100%; /* Equal width for label */
            text-align: left;
        }
        .fee-field p {
            width: 50%; /* Equal width for value */
            text-align: center; /* Center the value */
            background-color: #fff;
        }
        .box-body::before {
            content: "Standard Fee Template";
            display: block;
            font-size: 18px;
            font-weight: bold;
            /*margin-bottom: 15px;*/
            text-align: center;
        }
        .row {
            display: table;
            width: 100%;
            border-collapse: collapse;
        }
        body, html, .content-wrapper, .box-body, .row, .main, .scfee {
        margin: 0 !important;
        padding: 0 !important;
    }

    .scfee {
        width: 100% !important;
        box-sizing: border-box;
    }
    }
</style>
<!-- New-Style-code -->
<style>
 .box-body {
    padding: 0px;
    background-color: #ebe7d5;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}
.points h3 {
    color: #9d3333;
    font-weight: 700;
    font-size: 22px;
}
.text-overlay p {
    margin: 0px 0;
    font-size: 2.2rem;
    color: #e33333;
}
.installments h3 {
        margin-bottom: 5px;
        color: #9d3333;
        font-weight: 700;
        font-size: 22px;
    }
    .points p{
        color: #000;
        padding: 0px 64px 48px 64px;
        font-weight: 500;
        font-size: 18px;
    }
    .installments p {
        font-weight: bold;
        font-size: 18px;
        color: #666262;  
    }
    .scfee {
      width: 100%;
      margin: 0;
      padding: 0;
      background-color: #ebe7d5;
    }
    .scfee table {
        width: 100%;
        table-layout: fixed; 
        page-break-inside: avoid;
      }
    .scfee th, .scfee td {
        word-wrap: break-word; 
    }
.feetemp-head{
    display: flex;
    vertical-align: middle;
    align-items: center;
    /*justify-content: space-between;*/
    justify-content: space-evenly;
}
.header-info h1 {
    font-size: 24px;
    color: #ff6600;
    margin: 0;
}

.header-info .subheading {
    font-size: 16px;
    font-weight: bold;
    color: #333;
}

.header-info .stats {
    font-size: 14px;
    color: #666;
}

/* Mission Section */
.mission p{
    font-size: 18px;
    text-align: center;
    color: #000;
    padding: 0px 64px 24px 64px;
    font-weight: 600;
}

.mission h2 {
    font-size: 22px;
    color: #9d3333;
    font-weight: 700;
    margin: 32px 32px 20px 32px;
    text-align: center;
}

/* Fee Structure Section */
.fee-structure table,
.fees table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    border: 0.5px solid #9d9d9d;
}

.fee-structure table th,
.fee-structure table td,
.fees table th,
.fees table td {
    border: 0.5px solid #9d9d9d;
    padding: 12px;
    text-align: left;
}

.fee-structure table th {
    /* background-color: #ffebcd; */
    font-weight: bold;
    border: 0.5px solid #9d9d9d
}

.fee-structure h3 {
    text-align: center;
    margin-bottom: 15px;
    color: #d9534f;
}

/* Offers Section */
.offers h4 {
    margin: 10px 0 5px;
    font-weight: bold;
}

.offers ul {
    margin: 0;
    padding: 0 0 0 20px;
}

/* Footer Section */
.footer {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
    color: #555;
}
.main{
    text-align: center;
     line-height: 1.5;
}
.silder {
    margin: 40px;
}
.points{
    margin: 120px;
}

.text-overlay{
    text-align: center;
    margin-left: 10px;
}
</style>
<style>
    
.stats-row {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  gap: 5px;
  /* font-family: Arial, sans-serif; */
  flex-wrap: wrap;
}

.stat-item {
  padding: 0 5px;
  position: relative;
}

.stat-item:not(:last-child)::after {
  content: "";
  position: absolute;
  right: 0;
  top: 10%;
  height: 80%;
  width: 1px;
  background-color: #999;
}

.stat-number {
  font-size: 13px;
  font-weight: 600;
  color: #888;
}

.stat-label {
  font-size: 13px;
  font-weight: 600;
  color: #888;
  letter-spacing: 0.5px;
}

/* Responsive for small screens */
@media (max-width: 600px) {
  .stats-row {
    flex-direction: column;
    gap: 10px;
  }

  .stat-item:not(:last-child)::after {
    display: none;
  }
}



    .main {
    position: relative;
    display: inline-block;
    width: 100%; /* Ensures responsive width */
}

.main img {
   
    display: block;
    margin: 0 auto; /* Centers the image */
        height: 290px;
        margin-bottom: 15px;
}

.text-overlay {
    position: absolute;
    top: 60%; /* Center vertically */
    left: 50%; /* Center horizontally */
    transform: translate(-50%, -50%);
    color: red; 
    text-align: center; /* Centers the text */
    font-size: 20px;
    font-weight: bold;
}

.text-overlay h1 {
    font-size: 2rem; /* Larger font for the main title */
    margin-bottom: 10px; /* Space below the title */
    margin: -15px;
}



</style>
<style>
    .fee-table {
    width: 100%;
    border-collapse: collapse;
}


.fee-table th, .fee-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.full-width th {
    text-align: left;
    background-color: #f9f9f9; 
    width: 100%;
}

 .mainfac{
      display: flex;
      margin: 84px 0px 0px 0px;
    }
    .prism{
            margin-left: 230px;
    margin-top: -20px;
}
.facilities h4{
    color: #9d3333;
    font-weight: 700;
    font-size: 22px;
}
</style>
<style>
    .installments {
        font-size: 14px;
        max-width: 880px;
        /* margin: 0 auto; */
        width: 96%;
        margin-left: auto;
        margin-right: auto;
    }
    .installments table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
      
    }

    .installments th,
    .installments td {
        border: 1px solid #000;
        padding: 6px 5px;
        text-align: center;
    }

    .installments th {
        background-color: #d9534f;
        color: #fff;
        font-weight: bold;
    }

    .fee-composition td {
        background-color: white;
        font-weight: bold;
    }

    .installments tr:nth-child(n+3) td {
        background-color: #f8d7da;
    }
    .space{
        margin: 0px 70px 42px 70px;
    }
    .scfee {
      margin: 0 !important;
      /*padding: 0 !important;*/
    }
    </style>
<!-- End-New-Style-code -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script type="text/javascript">
    /*function downloadPDF() {
  const element = document.querySelector('.scfee');
  html2pdf().from(element).set({
    margin: 0.5,
    filename: 'Standard-classes-Fee-Template.pdf',
    html2canvas: {
      scale: 2,
      useCORS: true
    },
    jsPDF: {
      unit: 'in',
      format: 'letter',
      orientation: 'portrait'
    }
  }).save();
}*/
</script>
<script type="text/javascript">
function downloadPDF() {
  const element = document.querySelector('.scfee');
  html2pdf().from(element).set({
    margin: [0, 0, 0, 0],
    //margin: 0, // No margins
    filename: 'Standard-classes-Fee-Template.pdf',
    html2canvas: {
      /*scale: 2,*/
      scale: 1,
      useCORS: true,
      scrollY: 0
    },
    jsPDF: {
      unit: 'in',
      format: 'letter',
      orientation: 'portrait'
    }
  }).save();
}
</script>
<script>
function getDaySuffix(day) {
    if (day > 3 && day < 21) return "th"; // 11th to 20th
    switch (day % 10) {
        case 1:  return "st";
        case 2:  return "nd";
        case 3:  return "rd";
        default: return "th";
    }
}

function formatDateToSuperscript(dateStr) {
    const date = new Date(dateStr);
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'short' });
    const year = date.getFullYear();
    const suffix = getDaySuffix(day);
    return `${day}<sup>${suffix}</sup> ${month} ${year}`;
}

document.getElementById('dateof1installment').addEventListener('change', function () {
    const formatted = formatDateToSuperscript(this.value);
    document.getElementById('formattedDate').innerHTML = formatted;
});
</script>

