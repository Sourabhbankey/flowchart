<?php
$classfeeId = $classesfeetemplateInfo->classfeeId;
$mission = $classesfeetemplateInfo->mission;
$formfee = $classesfeetemplateInfo->formfee;
$franchiseNumberArray = explode(",",$classesfeetemplateInfo->franchiseNumber);
$brspFranchiseAssigned = $classesfeetemplateInfo->brspFranchiseAssigned; 
$admissionfees = $classesfeetemplateInfo->admissionfees;
$toddlers = $classesfeetemplateInfo->toddlers;
$nursery = $classesfeetemplateInfo->nursery;
$kg1 = $classesfeetemplateInfo->kg1;
$kg2 = $classesfeetemplateInfo->kg2;
$kitcharges = $classesfeetemplateInfo->kitcharges;
$classes = $classesfeetemplateInfo->classes;
$offers = $classesfeetemplateInfo->offers;
$franchiseNumber = $classesfeetemplateInfo->franchiseNumber;
$additionalcharges = $classesfeetemplateInfo->additionalcharges;
$activitycharges = $classesfeetemplateInfo->activitycharges;
$keyhighlights = $classesfeetemplateInfo->keyhighlights;
$installment1play = $classesfeetemplateInfo->installment1play;
$installment2play = $classesfeetemplateInfo->installment2play;
$installment3play = $classesfeetemplateInfo->installment3play;
$installment4play = $classesfeetemplateInfo->installment4play;

$installment1nur = $classesfeetemplateInfo->installment1nur;
$installment2nur = $classesfeetemplateInfo->installment2nur;
$installment3nur = $classesfeetemplateInfo->installment3nur;
$installment4nur = $classesfeetemplateInfo->installment4nur;

$installment1kg1 = $classesfeetemplateInfo->installment1kg1;
$installment2kg1 = $classesfeetemplateInfo->installment2kg1;
$installment3kg1 = $classesfeetemplateInfo->installment3kg1;
$installment4kg1 = $classesfeetemplateInfo->installment4kg1;

$installment1kg2 = $classesfeetemplateInfo->installment1kg2;
$installment2kg2 = $classesfeetemplateInfo->installment2kg2;
$installment3kg2 = $classesfeetemplateInfo->installment3kg2;
$installment4kg2 = $classesfeetemplateInfo->installment4kg2;
$installmentType = $classesfeetemplateInfo->installmentType;
$dateof1installment = $classesfeetemplateInfo->dateof1installment;
$dateof2installment = $classesfeetemplateInfo->dateof2installment;
$dateof3installment = $classesfeetemplateInfo->dateof3installment;
$dateof4installment = $classesfeetemplateInfo->dateof4installment;
$lateFeeCharges = $classesfeetemplateInfo->lateFeeCharges;
$pointstoremember = $classesfeetemplateInfo->pointstoremember;

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-user-circle-o" aria-hidden="true"></i>Management
        <small>Add / Edit </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-9">
              <!-- general form elements -->
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter  Details</h3>
                         <div class="pull-right">
            <a href="<?php echo base_url() ?>classesfeetemplate/classesfeetemplateListing" class="btn btn-info">Back to Listing</a>
        </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                 
                         <form role="form" action="<?php echo base_url() ?>classesfeetemplate/editClassesfeetemplate" enctype="multipart/form-data" method="post" id="editClassesfeetemplate">
    <div class="box-body">
        <div class="row">
            <input type="hidden" value="<?php echo $classfeeId; ?>" name="classfeeId" id="classfeeId" />
            
            <div class="col-md-12">
                <div class="form-group">
                    <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                    <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value)">
                        <option value="<?php echo $franchiseNumber; ?>"><?php echo $franchiseNumber; ?></option>
                        <?php
                        if (!empty($branchDetail)) {
                            foreach ($branchDetail as $bd) {
                                $frNo = $bd->franchiseNumber;
                                ?>
                                <option value="<?php echo $frNo; ?>" <?php if ($frNo == $franchiseNumber) echo 'selected'; ?>><?php echo $frNo; ?></option>
                                <?php
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>

           <!--  <div class="col-md-12">
                <div class="form-group">
                    <label for="branchFranchiseAssigned">Franchise Assigned to</label>
                    <select class="form-control required" id="branchFranchiseAssigned" name="brspFranchiseAssigned">
                        <option value="0">Select Role</option>
                    
                    </select>
                </div>
            </div> --> 

            <div class="col-md-12">
                <div class="form-group">
                    <label for="mission">Mission</label>
                    <textarea class="form-control required" id="mission" name="mission"><?php echo $mission; ?></textarea>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="formfee">Form Fee <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="formfee" name="formfee" value="<?php echo $formfee; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="admissionfees">Admission Fees <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="admissionfees" name="admissionfees" value="<?php echo $admissionfees; ?>" />
                </div>
            </div>

           
            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">Toddlers <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="$toddlers" name="$toddlers" value="<?php echo $toddlers; ?>" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">Nursery <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="nursery" name="nursery" value="<?php echo $nursery; ?>" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">kg 1 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="kg1" name="kg1" value="<?php echo $kg1; ?>" />
                </div>
            </div>
             <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">kg 2 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="kg2" name="kg2" value="<?php echo $kg2; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="offers">Offers <span class="re-mend-field">*</span></label>
                    <textarea class="form-control required" id="offers" name="offers"><?php echo $offers; ?></textarea>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="additionalcharges">Additional Charges</label>
                    <textarea class="form-control required" id="additionalcharges" name="additionalcharges"><?php echo $additionalcharges; ?></textarea>
                </div>
            </div>
 <div class="col-md-12">
                <div class="form-group">
                    <label for="additionalcharges">Activity Charges</label>
                    <textarea class="form-control required" id="activitycharges" name="activitycharges"><?php echo $activitycharges; ?></textarea>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="keyhighlights">Key Highlights</label>
                    <textarea class="form-control required" id="keyhighlights" name="keyhighlights"><?php echo $keyhighlights; ?></textarea>
                </div>
            </div>

            <!-- Manually written Installment fields -->
            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">1st Installment Playgroup <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment1play" name="installment1play" value="<?php echo $installment1play; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment2">2nd Installment Playgroup <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment2play" name="installment2play" value="<?php echo $installment2play; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment3">3rd Installment Playgroup <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment3play" name="installment3play" value="<?php echo $installment3play; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment4">4th Installment Playgroup <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment4play" name="installment4play" value="<?php echo $installment4play; ?>" />
                </div>
            </div>


  <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">1st Installment Nursery <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment1nur" name="installment1nur" value="<?php echo $installment1nur; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment2">2nd Installment Nursery <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment2nur" name="installment2nur" value="<?php echo $installment2nur; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment3">3rd Installment Nursery <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment3nur" name="installment3nur" value="<?php echo $installment3nur; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment4">4th Installment Nursery <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment4nur" name="installment4nur" value="<?php echo $installment4nur; ?>" />
                </div>
            </div>




              <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">1st Installment Kg-1 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment1kg1" name="installment1kg1" value="<?php echo $installment1kg1; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment2">2nd Installment Kg-1 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment2kg1" name="installment2kg1" value="<?php echo $installment2kg1; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment3">3rd Installment Kg-1 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment3kg1" name="installment3kg1" value="<?php echo $installment3kg1; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment4">4th Installment Kg-1 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment4kg1" name="installment4kg1" value="<?php echo $installment4kg1; ?>" />
                </div>
            </div>

              <div class="col-md-12">
                <div class="form-group">
                    <label for="installment1">1st Installment Kg 2 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment1kg2" name="installment1kg2" value="<?php echo $installment1kg2; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment2">2nd Installment kg 2 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment2kg2" name="installment2kg2" value="<?php echo $installment2kg2; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment3">3rd Installment Kg-2 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment3kg2" name="installment3kg2" value="<?php echo $installment3kg2; ?>" />
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="installment4">4th Installment kg 2 <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="installment4kg2" name="installment4kg2" value="<?php echo $installment4kg2; ?>" />
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="installmentType">Installments Breakup <span class="re-mend-field">*</span></label>
                    <select class="form-control required" id="installmentType" name="installmentType" required>
                        <option value="">-- Select Option --</option>
                        <option value="annually" <?php echo (isset($installmentType) && $installmentType == 'Annually (1 Installment)') ? 'selected' : ''; ?>>Annually (1 Installment)</option>
                        <option value="half-yearly" <?php echo (isset($installmentType) && $installmentType == 'Half-Yearly (2 Installments)') ? 'selected' : ''; ?>>Half-Yearly (2 Installments)</option>
                        <option value="triannual" <?php echo (isset($installmentType) && $installmentType == 'Triannual (3 Installments)') ? 'selected' : ''; ?>>Triannual (3 Installments)</option>
                        <option value="quarterly" <?php echo (isset($installmentType) && $installmentType == 'Quarterly (4 Installments)') ? 'selected' : ''; ?>>Quarterly (4 Installments)</option>
                        
                    </select>

                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="lateFeeCharges">Late fee charges <span class="re-mend-field">*</span></label>
                    <input type="text" class="form-control required" id="lateFeeCharges" name="lateFeeCharges" value="<?php echo $lateFeeCharges; ?>" />
                </div>
            </div>
            <!-- <div class="col-md-12">
                <div class="form-group">
                    <label for="pointstoremember">Points to Remember</label>
                    <textarea class="form-control required" id="pointstoremember" name="pointstoremember"><?php //echo $pointstoremember; ?></textarea>
                </div>
            </div> -->

        </div>
    </div>

    <div class="box-footer">
        <input type="submit" class="btn btn-primary" value="Submit" />
        <input type="reset" class="btn btn-default" value="Reset" />
    </div>
</form>

                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        .re-mend-field{color: red;}
        /*.clsp{pointer-events:none;}*/
    </style>
    <script>
document.getElementById('modeOforder').addEventListener('change', function() {
    var othersField = document.getElementById('othersField');
    var otherModeInput = document.getElementById('otherMode');
    if (this.value === 'Others') {
        othersField.style.display = 'block';
        otherModeInput.setAttribute('required', 'required');
    } else {
        othersField.style.display = 'none';
        otherModeInput.removeAttribute('required');
    }
});
</script>
</div>