<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-image" aria-hidden="true"></i> Branch Installation Images & Videos
            <small>Add New Record</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Add New Branch Installation</h3>
                    </div>
                    <div class="box-body">
                        <?php
                        $error = $this->session->flashdata('error');
                        if ($error) {
                        ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <?php
                        $success = $this->session->flashdata('success');
                        if ($success) {
                        ?>
                            <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $success; ?>
                            </div>
                        <?php } ?>
                        <form id="branchInstallationForm" action="<?php echo base_url('Branchinstallationimg/addNewBranchinstallationimg'); ?>" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <!-- Left Column -->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
                                        <?php if ($role == 25) { ?>
                                            <!-- Franchise users: Non-editable field -->
                                            <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>" readonly required>
                                        <?php } else { ?>
                                            <!-- Other roles: Dropdown with default selection -->
                                            <select class="form-control required" id="franchiseNumber" name="franchiseNumber" data-live-search="true" required onchange="fetchAssignedFranchise(this.value);">
                                                <option value="">Select Franchise</option>
                                                <?php
                                                if (!empty($branchDetail)) {
                                                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                                                    foreach ($branchDetail as $bd) {
                                                        $franchiseNumber = $bd->franchiseNumber;
                                                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                                                ?>
                                                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                                                            <?php echo htmlspecialchars($franchiseNumber); ?>
                                                        </option>
                                                <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="brspFranchiseAssigned">Franchise Assigned to</label>
                                        <div id="brspFranchiseAssigned" class="form-control" style="height: auto; min-height: 34px;">
                                            <span>Select a franchise to assign</span>
                                        </div>
                                        <input type="hidden" name="brspFranchiseAssigned" id="brspFranchiseAssignedValue">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="brimgvideoTitle">Title <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="brimgvideoTitle" name="brimgvideoTitle" value="<?php echo set_value('brimgvideoTitle'); ?>" maxlength="255" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="empimgS3attachment">Image Attachments </label>
                                        <input type="file" name="files[]" class="form-control" multiple />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="empvideosS3attachment">Video Attachments</label>
                                        <input type="file" name="file2" class="form-control" accept="video/mp4,video/avi,video/quicktime" />
                                    </div>
                                </div>
                            </div>
                            <!-- Full Width Description -->
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="5"><?php echo set_value('description'); ?></textarea>
                                <?php echo form_error('description', '<div class="text-danger">', '</div>'); ?>
                            </div>
                            <div class="box-footer">
                                <button type="submit" id="submitBtn" class="btn btn-primary">Submit</button>
                                <a href="<?php echo base_url('Branchinstallationimg/branchInstallationListing'); ?>" class="btn btn-default">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<style type="text/css">
    .re-mend-field {
        color: red;
    }
</style>

<script>
    const form = document.getElementById('branchInstallationForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function(e) {
        const franchiseInput = document.getElementById('franchiseNumber');
        if (!franchiseInput.value) {
            e.preventDefault();
            alert('Please select or ensure a valid Franchise Number.');
            submitBtn.disabled = false;
            submitBtn.innerText = 'Submit';
            return;
        }
        if (submitBtn.disabled) {
            e.preventDefault(); // Prevent form submission if already disabled
            return;
        }
        submitBtn.disabled = true; // Disable button
        submitBtn.innerText = 'Submitting...'; // Indicate submission
    });

    // Function to fetch assigned Growth Manager based on franchise number
    function fetchAssignedFranchise(franchiseNumber) {
        const assignedDiv = document.getElementById('brspFranchiseAssigned');
        const hiddenInput = document.getElementById('brspFranchiseAssignedValue');
        if (franchiseNumber) {
            $.ajax({
                url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
                type: 'POST',
                data: {
                    franchiseNumber: franchiseNumber,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success' && response.html) {
                        assignedDiv.innerHTML = response.html; // Display Growth Manager's name(s)
                        hiddenInput.value = response.userIds || ''; // Set hidden input to userIds
                    } else {
                        assignedDiv.innerText = 'No Growth Manager assigned';
                        hiddenInput.value = ''; // Clear hidden input
                        alert(response.message || 'No Growth Manager found for this franchise');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", status, error);
                    console.error("Response Text: ", xhr.responseText);
                    assignedDiv.innerText = 'Error fetching Growth Manager';
                    hiddenInput.value = ''; // Clear hidden input
                    alert('Error fetching Growth Manager data');
                }
            });
        } else {
            assignedDiv.innerText = 'Select a franchise to assign';
            hiddenInput.value = ''; // Clear hidden input
        }
    }

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        const franchiseInput = document.getElementById('franchiseNumber');

        // For dropdown (non-readonly, roles other than 25)
        if (franchiseInput && franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
            fetchAssignedFranchise(franchiseInput.value);
        }

        // For readonly input (role 25)
        if (franchiseInput && franchiseInput.readOnly && franchiseInput.value) {
            fetchAssignedFranchise(franchiseInput.value);
        }
    });
</script>