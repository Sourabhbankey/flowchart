<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-image" aria-hidden="true"></i> Branch Installation Images & Videos
            <small>Manage Records</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="form-group text-right">
                    <a href="<?php echo base_url('Branchinstallationimg/add'); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Add New Record</a>
                </div>
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Branch Installation List</h3>
                        <div class="box-tools">
                        </div>
                    </div>
                    <div class="box-body">
                        <?php
                        $error = $this->session->flashdata('error');
                        if ($error) {
                        ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <?php
                        $success = $this->session->flashdata('success');
                        if ($success) {
                        ?>
                            <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $success; ?>
                            </div>
                        <?php } ?>
                        <table id="branchInstallationTable" class="table  table-striped">
                            <thead>
                                <tr>
                                    <th>Franchise Number</th>
                                    <th>Title</th>
                                    <th>Images/Video</th>
                                   
                                    <th>Description</th>
                                    <th>Created Date</th>
                                    <?php if ($role == 14 || $is_admin == 1) { ?>
                                        <th>Actions</th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($records)) { ?>
                                    <?php foreach ($records as $record) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($record->franchiseNumber); ?></td>
                                            <td><?php echo htmlspecialchars($record->brimgvideoTitle); ?></td>
                                          <td> <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'Branchinstallationimg/view/' . $record->brimgvideoId; ?>"><i class="fa fa-eye"></i></a></td>
                                            <td><?php echo substr(strip_tags($record->description), 0, 100) . (strlen(strip_tags($record->description)) > 100 ? '...' : ''); ?></td>
                                            <td><?php echo date('Y-m-d h:i A', strtotime($record->createdDtm)); ?></td>
                                            <?php if ($role == 14 || $is_admin == 1) { ?>
                                                <td>
                                                    <a href="<?php echo base_url('Branchinstallationimg/edit/' . $record->brimgvideoId); ?>" class="btn btn-sm btn-info" title="Edit">
                                                        <i class="fa fa-pencil"></i>
                                                    </a>
                                                 
                                                  <!-- <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'Branchinstallationimg/view/' . $record->brimgvideoId; ?>"><i class="fa fa-eye"></i></a> -->
                                            
                                                    <a href="#" class="btn btn-sm btn-danger" title="Delete">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            <?php } ?>
                                        </tr>
                                    <?php } ?>
                                <?php } else { ?>
                                    <tr>
    <td colspan="<?php echo ($role == 14 || $is_admin == 1) ? 7 : 7; ?>" class="text-center">No records found.</td>
</tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="box-footer clearfix">
                        <div class="pagination-wrapper">
                            <?php echo $this->pagination->create_links(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css" rel="stylesheet">

<!-- jQuery (must be included before DataTables) -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<!-- Common JS -->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>

<script type="text/javascript">
    $(document).ready(function() {
        // Initialize DataTables
        $('#branchInstallationTable').DataTable({
            "responsive": true,
            "paging": false, // Use CodeIgniter pagination
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });

        // Handle CodeIgniter pagination clicks
        $('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = $(this).attr('href');
            if (link && link !== '#') {
                window.location.href = link;
            }
        });
    });
</script>

<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        min-width: 50%;
        font-weight: bold;
    }
    table.dataTable.dtr-inline.collapsed tbody tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody >tr.parent>th.dtr-control:before {
        content: '-';
        background-color: #d33333;
    }
    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: 'Courier New', Courier, monospace;
        line-height: 1em;
        content: '+';
        background-color: #31b131;
    }
    /* Pagination CSS */
    .pagination-wrapper {
        margin-top: 10px;
    }
    .pagination .page-item {
        margin: 5px;
    }
    .pagination .page-link {
       
        padding: 8px 16px;

    }
    .pagination .page-link:hover {
        background-color: #e9ecef;
        color: #0056b3;
    }
 
    .pagination .page-item.disabled .page-link {
        color: #6c757d;
        pointer-events: none;
        background-color: #fff;
        border-color: #ddd;
    }
</style>