<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-image" aria-hidden="true"></i> Branch Installation Images & Videos
            <small>Edit Record</small>
        </h1>
    </section>

    <section class="content">
        <div class="row">
            <div class="col-xs-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Edit Branch Installation</h3>
                    </div>
                    <div class="box-body">
                        <?php
                        $error = $this->session->flashdata('error');
                        if ($error) {
                        ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $error; ?>
                            </div>
                        <?php } ?>
                        <?php
                        $success = $this->session->flashdata('success');
                        if ($success) {
                        ?>
                            <div class="alert alert-success alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <?php echo $success; ?>
                            </div>
                        <?php } ?>
                        <form action="<?php echo base_url('Branchinstallationimg/update'); ?>" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="brimgvideoId" value="<?php echo $record->brimgvideoId; ?>">
                            <div class="form-group">
                                <label for="franchiseNumber">Franchise Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="franchiseNumber" name="franchiseNumber" value="<?php echo htmlspecialchars(set_value('franchiseNumber', $record->franchiseNumber)); ?>" maxlength="255" readonly required>
                                <?php echo form_error('franchiseNumber', '<div class="text-danger">', '</div>'); ?>
                            </div>
                            <div class="form-group">
                                <label for="brimgvideoTitle">Title <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="brimgvideoTitle" name="brimgvideoTitle" value="<?php echo htmlspecialchars(set_value('brimgvideoTitle', $record->brimgvideoTitle)); ?>" maxlength="255" required>
                                <?php echo form_error('brimgvideoTitle', '<div class="text-danger">', '</div>'); ?>
                            </div>
                           
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="5"><?php echo htmlspecialchars(set_value('description', $record->description)); ?></textarea>
                                <?php echo form_error('description', '<div class="text-danger">', '</div>'); ?>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?php echo base_url('Branchinstallationimg/branchInstallationListing'); ?>" class="btn btn-default">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>