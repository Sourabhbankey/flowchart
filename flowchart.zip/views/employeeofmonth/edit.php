<?php
$empofmonthsId = $employeeofmonthInfo->empofmonthsId;
$assignedTo = $employeeofmonthInfo->assignedTo;
$empDeartment = $employeeofmonthInfo->empDeartment;
$dateofMonths = $employeeofmonthInfo->dateofMonths;
$description = $employeeofmonthInfo->description;
$empsingleattachment = $employeeofmonthInfo->empsingleattachment;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee of the Month Management
            <small>Add / Edit Employee of the Month</small>
        </h1>
    </section>
    
    <section class="content">
        <div class="row">
            <!-- Left column -->
            <div class="col-md-9">
                <!-- General form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Employee of the Month Details</h3>
                    </div>
                    <!-- Form start -->
                    <form role="form" action="<?php echo base_url() ?>employeeofmonth/editEmployeeofmonth" method="post" id="editEmployeeofmonth" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="assignedTo">Employee Name</label>
                                        <select class="form-control required" name="assignedTo" id="assignedTo" required>
                                            <option value="">Select Employee</option>
                                            <?php foreach ($users as $user): ?>
                                                <option value="<?php echo $user->userId; ?>" <?php echo ($user->userId == $assignedTo) ? 'selected="selected"' : ''; ?>>
                                                    <?php echo $user->name; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="hidden" value="<?php echo $empofmonthsId; ?>" name="empofmonthsId" id="empofmonthsId" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="empDeartment">Department</label>
                                        <select class="form-control required" name="empDeartment" id="empDeartment" required>
                                            <option value="">Select Department</option>
                                            <option value="Onboarding Department" <?php echo ($empDeartment == 'Onboarding Department') ? 'selected="selected"' : ''; ?>>Onboarding Department</option>
                                            <option value="GrowthDepartment" <?php echo ($empDeartment == 'GrowthDepartment') ? 'selected="selected"' : ''; ?>>GrowthDepartment</option>
                                            <option value="Accounts Department" <?php echo ($empDeartment == 'Accounts Department') ? 'selected="selected"' : ''; ?>>Accounts Department</option>
                                            <option value="DigitalMarketing" <?php echo ($empDeartment == 'DigitalMarketing') ? 'selected="selected"' : ''; ?>>DigitalMarketing</option>
                                            <option value="Design Department" <?php echo ($empDeartment == 'Design Department') ? 'selected="selected"' : ''; ?>>Design Department</option>
                                            <option value="AdmissionsDepartment" <?php echo ($empDeartment == 'AdmissionsDepartment') ? 'selected="selected"' : ''; ?>>AdmissionsDepartment</option>
                                            <option value="Training Department" <?php echo ($empDeartment == 'Training Department') ? 'selected="selected"' : ''; ?>>Training Department</option>
                                            <option value="DespatchDepartment" <?php echo ($empDeartment == 'DespatchDepartment') ? 'selected="selected"' : ''; ?>>DespatchDepartment</option>
                                            <option value="LegalDepartment" <?php echo ($empDeartment == 'LegalDepartment') ? 'selected="selected"' : ''; ?>>LegalDepartment</option>
                                            <option value="Social Media Department" <?php echo ($empDeartment == 'Social Media Department') ? 'selected="selected"' : ''; ?>>Social Media Department</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="dateofMonths">Date of Month</label>
                                        <input type="date" class="form-control required" value="<?php echo date('Y-m-d', strtotime($dateofMonths)); ?>" id="dateofMonths" name="dateofMonths" required />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="files">Images</label>
                                        <input type="file" name="files[]" id="files" multiple accept="image/*" />
                                        <input type="hidden" name="existing_empsingleattachment" value="<?php echo $empsingleattachment; ?>" />
                                        <?php if (!empty($empsingleattachment)): ?>
                                            <p>Current Images:</p>
                                            <?php foreach (explode(',', $empsingleattachment) as $img): ?>
                                                <?php if (!empty(trim($img))): ?>
                                                    <img src="<?php echo $img; ?>" alt="Image" style="max-width:100px; max-height:80px; margin-right:5px; border:1px solid #ccc;" />
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control required" id="description" name="description" rows="6" required><?php echo $description; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-3">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if ($error) {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $error; ?>                    
                </div>
                <?php } ?>
                <?php
                    $success = $this->session->flashdata('success');
                    if ($success) {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $success; ?>
                </div>
                <?php } ?>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- CKEditor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>
    <script>
        // Client-side validation
        document.getElementById('editEmployeeofmonth').addEventListener('submit', function(e) {
            const assignedTo = document.getElementById('assignedTo').value;
            const empDeartment = document.getElementById('empDeartment').value;
            const dateofMonths = document.getElementById('dateofMonths').value;
            const description = CKEDITOR.instances.description.getData();

            if (!assignedTo || !empDeartment || !dateofMonths || !description) {
                e.preventDefault();
                alert('Please fill out all required fields.');
            }
        });
    </script>
</div>