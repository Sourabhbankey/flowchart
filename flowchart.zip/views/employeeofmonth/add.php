<div class="content-wrapper">
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Employee of the Month
            <small>Add / Edit</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Employee Details</h3>
                    </div>
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addEmpOfMonth" action="<?php echo base_url() ?>employeeofmonth/addNewEmployeeofmonth" method="post" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                               <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="empName">Employee Name</label>
                                       
                                         <select class="form-control required" id="assignedTo" name="assignedTo">
                                            <option value="0">Select User</option>
                                            <?php
                                            if(!empty($users))
                                            {
                                                foreach ($users as $rl)
                                                {
                                                    $userText = $rl->name;
                                                        ?>
                                                            <option value="<?php echo $rl->userId ?>" <?php if($rl->userId == set_value('assignedTo')) {echo "selected=selected";} ?>><?= $userText ?></option> 
                                                        <?php   
                                                }
                                            }
                                            ?>         
                                        </select>
                                    </div>
                                </div> 
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="empDeartment">Employee</label>
                                        <!-- <input type="text" class="form-control required" value="<?php //echo set_value('empDeartment'); ?>" id="empDeartment" name="empDeartment" maxlength="255" required /> -->
                                      <select class="form-control required" name="empDeartment" id="empDeartment">
                                                <option value="">Select Department</option>
                                                <option value="Onboarding Department">Onboarding Department</option>
                                                <option value="GrowthDepartment">GrowthDepartment</option>
                                                <option value="Accounts Department">Accounts Department</option>
                                                <option value="DigitalMarketing">DigitalMarketing</option>
                                                <option value="Design Department">Design Department</option>
                                                <option value="AdmissionsDepartment">AdmissionsDepartment</option>
                                                <option value="Training Department">Training Department</option>
                                                <option value="IT Department">IT Department</option>
                                                <option value="DespatchDepartment">DespatchDepartment</option>
                                                <option value="LegalDepartment">LegalDepartment</option>
                                                <option value="Social Media Department">Social Media Department</option>
                                        </select> 
                                         
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="dateofMonths">Date of Month</label>
                                        <input type="date" class="form-control required" value="<?php echo set_value('dateofMonths'); ?>" id="dateofMonths" name="dateofMonths" required />
                                    </div>
                                </div>
                               <div class="col-md-6">                                
    <div class="form-group">
        <label for="eventS3attachment">Image Attachments </label>
        <input type="file" name="files[]" class="form-control" multiple /> 
    </div>
</div>
                                <!-- <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="empgroupattachment">Group Attachments (in zip Format)</label>
                                        <input type="file" name="empgroupattachment[]" class="form-control" multiple />
                                    </div>
                                </div> -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="6"><?php echo set_value('description'); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-md-3">
                <?php
                    $error = $this->session->flashdata('error');
                    if($error): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $error; ?>
                        </div>
                <?php endif; ?>

                <?php
                    $success = $this->session->flashdata('success');
                    if($success): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <?php echo $success; ?>
                        </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', '<button type="button" class="close" data-dismiss="alert">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- CKEditor for description -->
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
    </body>
</html>



<?php