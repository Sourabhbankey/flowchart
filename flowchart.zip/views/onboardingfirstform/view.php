<?php
$onboardFirstFormId = $onboardingfirstformInfo->onboardFirstFormId;
$full_name = $onboardingfirstformInfo->full_name;
$email = $onboardingfirstformInfo->email;
$contact = $onboardingfirstformInfo->contact;
$gender = $onboardingfirstformInfo->gender;
$alternate_contact = $onboardingfirstformInfo->alternate_contact;
$dob = $onboardingfirstformInfo->dob;
$communication_address = $onboardingfirstformInfo->communication_address;
$city = $onboardingfirstformInfo->city;
$state = $onboardingfirstformInfo->state;
$pincode = $onboardingfirstformInfo->pincode;
$pan_card_no = $onboardingfirstformInfo->pan_card_no;
$aadhar_card = $onboardingfirstformInfo->aadhar_card;
$nationality = $onboardingfirstformInfo->nationality;
$permanent_address = $onboardingfirstformInfo->permanent_address;
$pcity = $onboardingfirstformInfo->pcity;
$pstate = $onboardingfirstformInfo->pstate;
$ppincode = $onboardingfirstformInfo->ppincode;
$marital_status = $onboardingfirstformInfo->marital_status;
$spouse = $onboardingfirstformInfo->spouse;
$number_of_children = $onboardingfirstformInfo->number_of_children;
$highest_education = $onboardingfirstformInfo->highest_education;
$qualifications = $onboardingfirstformInfo->qualifications;
$university = $onboardingfirstformInfo->university;
$year_of_qualification = $onboardingfirstformInfo->year_of_qualification;
$certificate_course_award = $onboardingfirstformInfo->certificate_course_award;
$year_received = $onboardingfirstformInfo->year_received;
$awarded_by = $onboardingfirstformInfo->awarded_by;
$english_spoken = $onboardingfirstformInfo->english_spoken;
$other_skills = $onboardingfirstformInfo->other_skills;
$mathematics_proficiency = $onboardingfirstformInfo->mathematics_proficiency;
$english_written_proficiency = $onboardingfirstformInfo->english_written_proficiency;
$current_employer_name = $onboardingfirstformInfo->current_employer_name;
$current_position = $onboardingfirstformInfo->current_position;
$current_date_joined = $onboardingfirstformInfo->current_date_joined;
$current_business_address = $onboardingfirstformInfo->current_business_address;
$current_monthly_income = $onboardingfirstformInfo->current_monthly_income;
$previous_employer_name = $onboardingfirstformInfo->previous_employer_name;
$previous_monthly_income = $onboardingfirstformInfo->previous_monthly_income;
$previous_date_joined = $onboardingfirstformInfo->previous_date_joined;
$previous_business_address = $onboardingfirstformInfo->previous_business_address;
$previous_last_position = $onboardingfirstformInfo->previous_last_position;
$previous_date_left = $onboardingfirstformInfo->previous_date_left;
$previous_reasons_for_leaving = $onboardingfirstformInfo->previous_reasons_for_leaving;
$particular_select = $onboardingfirstformInfo->particular_select;
$father_full_name = $onboardingfirstformInfo->father_full_name;
$father_pan_card = $onboardingfirstformInfo->father_pan_card;
$father_nationality = $onboardingfirstformInfo->father_nationality;
$father_aadhar_card = $onboardingfirstformInfo->father_aadhar_card;
$father_mobile = $onboardingfirstformInfo->father_mobile;
$father_position = $onboardingfirstformInfo->father_position;
$father_organization = $onboardingfirstformInfo->father_organization;
$father_business_address = $onboardingfirstformInfo->father_business_address;
$father_monthly_income = $onboardingfirstformInfo->father_monthly_income;
$spouse_dob = $onboardingfirstformInfo->spouse_dob;
$spouse_position = $onboardingfirstformInfo->spouse_position;
$spouse_organization = $onboardingfirstformInfo->spouse_organization;
$spouse_business_address = $onboardingfirstformInfo->spouse_business_address;
$spouse_monthly_income = $onboardingfirstformInfo->spouse_monthly_income;
$average_monthly_income = $onboardingfirstformInfo->average_monthly_income;
$applied_before = $onboardingfirstformInfo->applied_before;
$application_details = $onboardingfirstformInfo->application_details;
$ideal_centre_reason = $onboardingfirstformInfo->ideal_centre_reason;
$source_info = $onboardingfirstformInfo->source_info;
$current_centre = $onboardingfirstformInfo->current_centre;
$reason_for_applying = $onboardingfirstformInfo->reason_for_applying;
$aadhar_file = $onboardingfirstformInfo->aadhar_file;
$pan_file = $onboardingfirstformInfo->pan_file;
$created_at = $onboardingfirstformInfo->created_at;
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Record Management
            <small>Add / Edit</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-10">
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Details</h3>
                    </div><!-- /.box-header -->
                    <form role="form" action="<?php echo base_url() ?>Onboardingfirstform/editOnboardingfirstform" method="post" id="editOnboardingfirstform" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <!-- Table Structure -->
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Field Name</th>
                                            <th>Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><label>Full Name</label></td>
                                            <td><input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($full_name); ?>" /></td>
                                        </tr>
                                        <tr>
                                            <td><label>Email</label></td>
                                            <td><input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($email); ?>" /></td>
                                        </tr>
                                        <input type="hidden" name="onboardFirstFormId" value="<?php echo htmlspecialchars($onboardFirstFormId); ?>" />

                                        <?php
                                        $fields = [
                                            'contact', 'gender', 'alternate_contact', 'dob', 'communication_address', 'city', 'state', 'pincode',
                                            'pan_card_no', 'aadhar_card', 'nationality', 'permanent_address', 'pcity', 'pstate', 'ppincode',
                                            'marital_status', 'spouse', 'number_of_children', 'highest_education', 'qualifications', 'university',
                                            'year_of_qualification', 'certificate_course_award', 'year_received', 'awarded_by', 'english_spoken',
                                            'other_skills', 'mathematics_proficiency', 'english_written_proficiency', 'current_employer_name',
                                            'current_position', 'current_date_joined', 'current_business_address', 'current_monthly_income',
                                            'previous_employer_name', 'previous_monthly_income', 'previous_date_joined', 'previous_business_address',
                                            'previous_last_position', 'previous_date_left', 'previous_reasons_for_leaving', 'particular_select',
                                            'father_full_name', 'father_pan_card', 'father_nationality', 'father_aadhar_card', 'father_mobile',
                                            'father_position', 'father_organization', 'father_business_address', 'father_monthly_income',
                                            'spouse_dob', 'spouse_position', 'spouse_organization', 'spouse_business_address', 'spouse_monthly_income',
                                            'average_monthly_income', 'applied_before', 'application_details', 'ideal_centre_reason', 'source_info',
                                            'current_centre', 'reason_for_applying'
                                        ];

                                        foreach ($fields as $field) {
                                            $value = isset($$field) ? $$field : '';
                                            echo '<tr>
                                                    <td><label>' . ucwords(str_replace("_", " ", $field)) . '</label></td>
                                                    <td><input type="text" class="form-control" name="' . $field . '" value="' . htmlspecialchars($value) . '" /></td>
                                                </tr>';
                                        }
                                        ?>

                                        <!-- File upload for Aadhar -->
                                        <tr>
                                            <td><label>Aadhar File</label></td>
                                            <td>
                                                <?php if (!empty($aadhar_file)) {
                                                    $fileExtension = pathinfo($aadhar_file, PATHINFO_EXTENSION);
                                                    if (in_array(strtolower($fileExtension), ['jpg', 'jpeg', 'png'])) { ?>
                                                        <img src="<?php echo htmlspecialchars($aadhar_file); ?>" alt="Aadhar" width="100"><br>
                                                    <?php } elseif (strtolower($fileExtension) === 'pdf') { ?>
                                                        <button type="button" class="btn btn-primary btn-sm view-pdf" data-file="<?php echo htmlspecialchars($aadhar_file); ?>">View PDF</button>
                                                    <?php }
                                                } ?>
                                            </td>
                                        </tr>

                                        <!-- File upload for PAN -->
                                        <tr>
                                            <td><label>PAN File</label></td>
                                            <td>
                                                <?php if (!empty($pan_file)) {
                                                    $fileExtension = pathinfo($pan_file, PATHINFO_EXTENSION);
                                                    if (in_array(strtolower($fileExtension), ['jpg', 'jpeg', 'png'])) { ?>
                                                        <img src="<?php echo htmlspecialchars($pan_file); ?>" alt="PAN" width="100"><br>
                                                    <?php } elseif (strtolower($fileExtension) === 'pdf') { ?>
                                                        <button type="button" class="btn btn-primary btn-sm view-pdf" data-file="<?php echo htmlspecialchars($pan_file); ?>">View PDF</button>
                                                    <?php }
                                                } ?>
                                              
                                            </td>
                                        </tr>
                                    </tbody>
                                </table> <!-- End of table -->
                            </div> <!-- End of row -->
                        </div> <!-- End of box-body -->

                        <div class="box-footer">
                            <!-- <button type="submit" class="btn btn-success">Save Changes</button> -->
                            <button type="button" class="btn btn-info" onclick="printForm()">Print</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- CKEditor (optional, as no description field exists) -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            filebrowserUploadMethod: 'form'
        });
    </script>

    <!-- JavaScript for Print and PDF Viewing -->
    <script>
        function printForm() {
            var formContent = document.querySelector('.box').innerHTML;
            var printWindow = window.open('', '', 'height=800,width=1000');

            printWindow.document.write('<html><head>');
            printWindow.document.write('<title>Onboarding First Form</title>');
            printWindow.document.write('<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">');
            printWindow.document.write('<style>');
            printWindow.document.write('body { padding: 20px; }');
            printWindow.document.write('img { max-width: 100px; margin: 0 auto; display: block; }');
            printWindow.document.write('table { width: 100%; border-collapse: collapse; }');
            printWindow.document.write('td, th { padding: 8px; text-align: left; }');
            printWindow.document.write('th { background-color: #f9f9f9; }');
            printWindow.document.write('@page { margin-top: 100px; }');
            printWindow.document.write('.page { page-break-before: always; }');
            printWindow.document.write('input[type="text"], input[type="email"] { border: none; background: transparent; box-shadow: none; }');
            printWindow.document.write('.table-bordered { border: none; }');
            printWindow.document.write('.table-bordered th, .table-bordered td { border: none; }');
            printWindow.document.write('.view-pdf { display: none; }'); // Hide View PDF buttons in print
            printWindow.document.write('</style>');
            printWindow.document.write('<div style="text-align: center; margin-bottom: 20px;">');
            printWindow.document.write('<img src="https://theischool.com/blog/wp-content/uploads/2022/05/logo-1.png" alt="Logo" style="max-width: 100px;">');
            printWindow.document.write('</div>');
            printWindow.document.write('</head><body>');
            printWindow.document.write(formContent);
            printWindow.document.write('</body></html>');

            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
        }

        // Handle View PDF button clicks
        document.querySelectorAll('.view-pdf').forEach(button => {
            button.addEventListener('click', function() {
                const fileUrl = this.getAttribute('data-file');
                window.open(fileUrl, '_blank'); // Open PDF in a new tab
            });
        });
    </script>

    <!-- CSS for Form and Buttons -->
    <style type="text/css">
        input[type="text"], input[type="email"] {
            border: none;
            background: transparent;
            box-shadow: none;
        }
        .view-pdf {
            margin-bottom: 10px;
        }
        .form-control-file {
            margin-top: 10px;
        }
    </style>
</div>