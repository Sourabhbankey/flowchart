<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Onboardingfirstform Record Management
            <small>Add, Edit, Delete</small>
        </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <!-- Add button for new record (optional) -->
                <a class="btn btn-primary" href="<?php echo base_url(); ?>onboardingfirstform/add">Add New</a>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 text-left">
                <div class="form-group">
                    <form action="<?php echo base_url() ?>onboardingfirstform/onboardingfirstformListing" method="GET" id="searchUser">
                        <div class="row">
                            <div class="col-md-12">
                                <?php
                                $this->load->helper('form');
                                $error = $this->session->flashdata('error');
                                if ($error) {
                                ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <?php echo $this->session->flashdata('error'); ?>
                                    </div>
                                <?php } ?>
                                <?php
                                $success = $this->session->flashdata('success');
                                if ($success) {
                                ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <?php echo $this->session->flashdata('success'); ?>
                                    </div>
                                <?php } ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="box">
                                    <div class="box-header">
                                        <h3 class="box-title">Record List</h3>
                                        <div class="box-tools">
                                            <!-- Search form (uncomment if needed) -->
                                            <!-- <form action="<?php echo base_url() ?>onboardingfirstform/onboardingfirstformListing" method="POST" id="searchList">
                                                <div class="input-group">
                                                    <input type="text" name="searchText" value="<?php echo $searchText; ?>" class="form-control input-sm pull-right" style="width: 150px;" placeholder="Search"/>
                                                    <div class="input-group-btn">
                                                        <button class="btn btn-sm btn-default searchList"><i class="fa fa-search"></i></button>
                                                    </div>
                                                </div>
                                            </form> -->
                                        </div>
                                    </div><!-- /.box-header -->
                                    <div class="box-body table-responsive no-padding1">
                                        <table id="example" class="display responsive nowrap" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>Sr. No.</th>
                                                    <th>Franchise</th>
                                                    <th>Email</th>
                                                    <th>Contact</th>
                                                    <th>Gender</th>
                                                    <th>Full Name</th>
                                                    <th>Alternate Contact No</th>
                                                    <th>Date Of Birth</th>
                                                    <th>Communication Address</th>
                                                    <th>City</th>                                                  
                                                    <th>State</th>
                                                    <th>Pincode</th>
                                                    <th>PanCard Number</th>
                                                    <th>Aadhar Number</th>
                                                    <th>Nationality</th>
                                                    <th>Permanent Address</th>
                                                    <th>Permanent City</th>
                                                    <th>Permanent State</th>
                                                    <th>Permanent Pincode</th>
                                                    <th>Marital Status</th>
                                                    <th>Spouse</th>
                                                    <th>Number of Children</th>
                                                    <th>Highest Education</th>
                                                    <th>Qualification</th>
                                                    <th>University</th>
                                                    <th>Year Of Qualification</th>
                                                    <th>Certificate Course Award</th>
                                                    <th>Year Received</th>
                                                    <th>Awarded By</th>
                                                    <th>English Spoken</th>
                                                    <th>Other Skills</th>
                                                    <th>Mathematics Proficiency</th>
                                                    <th>English Written Proficiency</th>
                                                    <th>Current Employer Name</th>
                                                    <th>Current Position</th>
                                                    <th>Current Date Joined</th>
                                                    <th>Current Business Address</th>
                                                    <th>Current Monthly Income</th>
                                                    <th>Previous Employer Name</th>
                                                    <th>Previous Monthly Income</th>
                                                    <th>Previous Date Joined</th>
                                                    <th>Previous Business Address</th>
                                                    <th>Previous Last Position</th>
                                                    <th>Previous Date Left</th>
                                                    <th>Previous Reasons For Leaving</th>
                                                    <th>Particular Select</th>
                                                    <th>Father Full Name</th>
                                                    <th>Father Pancard</th>
                                                    <th>Father Nationality</th>
                                                    <th>Father Aadhar Card</th>
                                                    <th>Father Mobile</th>
                                                    <th>Father Position</th>
                                                    <th>Father Organization</th>
                                                    <th>Father Business Address</th>
                                                    <th>Father Monthly Income</th>
                                                    <th>Spouse Dob</th>
                                                    <th>Spouse Position</th>
                                                    <th>Spouse Organization</th>
                                                    <th>Spouse Business Address</th>
                                                    <th>Spouse Monthly Income</th>
                                                    <th>Average Monthly Income</th>
                                                    <th>Applied Before</th>
                                                    <th>Application Details</th>
                                                    <th>Ideal Centre Reason</th>
                                                    <th>Source Info</th>
                                                    <th>Current Centre</th>
                                                    <th>Reason For Applying</th>
                                                    <th>Aadhar File</th>
                                                    <th>Pan File</th>
                                                    <th>Created At</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if (!empty($records)) {
                                                    foreach ($records as $record) {
                                                ?>
                                                        <tr>
                                                            <td><?php echo htmlspecialchars($record->onboardFirstFormId); ?></td>
                                                            <td><?php echo htmlspecialchars($record->franchiseNumber); ?></td>
                                                            <td><?php echo htmlspecialchars($record->email); ?></td>
                                                            <td><?php echo htmlspecialchars($record->contact); ?></td>
                                                            <td><?php echo htmlspecialchars($record->gender); ?></td>
                                                            <td><?php echo htmlspecialchars($record->full_name); ?></td>
                                                            <td><?php echo htmlspecialchars($record->alternate_contact); ?></td>
                                                            <td><?php echo htmlspecialchars($record->dob); ?></td>
                                                            <td><?php echo htmlspecialchars($record->communication_address); ?></td>
                                                            <td><?php echo htmlspecialchars($record->city); ?></td>
                                                            <td><?php echo htmlspecialchars($record->state); ?></td>
                                                            <td><?php echo htmlspecialchars($record->pincode); ?></td>
                                                            <td><?php echo htmlspecialchars($record->pan_card_no); ?></td>
                                                            <td><?php echo htmlspecialchars($record->aadhar_card); ?></td>
                                                            <td><?php echo htmlspecialchars($record->nationality); ?></td>
                                                            <td><?php echo htmlspecialchars($record->permanent_address); ?></td>
                                                            <td><?php echo htmlspecialchars($record->pcity); ?></td>
                                                            <td><?php echo htmlspecialchars($record->pstate); ?></td>
                                                            <td><?php echo htmlspecialchars($record->ppincode); ?></td>
                                                            <td><?php echo htmlspecialchars($record->marital_status); ?></td>
                                                            <td><?php echo htmlspecialchars($record->spouse); ?></td>
                                                            <td><?php echo htmlspecialchars($record->number_of_children); ?></td>
                                                            <td><?php echo htmlspecialchars($record->highest_education); ?></td>
                                                            <td><?php echo htmlspecialchars($record->qualifications); ?></td>
                                                            <td><?php echo htmlspecialchars($record->university); ?></td>
                                                            <td><?php echo htmlspecialchars($record->year_of_qualification); ?></td>
                                                            <td><?php echo htmlspecialchars($record->certificate_course_award); ?></td>
                                                            <td><?php echo htmlspecialchars($record->year_received); ?></td>
                                                            <td><?php echo htmlspecialchars($record->awarded_by); ?></td>
                                                            <td><?php echo htmlspecialchars($record->english_spoken); ?></td>
                                                            <td><?php echo htmlspecialchars($record->other_skills); ?></td>
                                                            <td><?php echo htmlspecialchars($record->mathematics_proficiency); ?></td>
                                                            <td><?php echo htmlspecialchars($record->english_written_proficiency); ?></td>
                                                            <td><?php echo htmlspecialchars($record->current_employer_name); ?></td>
                                                            <td><?php echo htmlspecialchars($record->current_position); ?></td>
                                                            <td><?php echo htmlspecialchars($record->current_date_joined); ?></td>
                                                            <td><?php echo htmlspecialchars($record->current_business_address); ?></td>
                                                            <td><?php echo htmlspecialchars($record->current_monthly_income); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_employer_name); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_monthly_income); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_date_joined); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_business_address); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_last_position); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_date_left); ?></td>
                                                            <td><?php echo htmlspecialchars($record->previous_reasons_for_leaving); ?></td>
                                                            <td><?php echo htmlspecialchars($record->particular_select); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_full_name); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_pan_card); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_nationality); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_aadhar_card); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_mobile); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_position); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_organization); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_business_address); ?></td>
                                                            <td><?php echo htmlspecialchars($record->father_monthly_income); ?></td>
                                                            <td><?php echo htmlspecialchars($record->spouse_dob); ?></td>
                                                            <td><?php echo htmlspecialchars($record->spouse_position); ?></td>
                                                            <td><?php echo htmlspecialchars($record->spouse_organization); ?></td>
                                                            <td><?php echo htmlspecialchars($record->spouse_business_address); ?></td>
                                                            <td><?php echo htmlspecialchars($record->spouse_monthly_income); ?></td>
                                                            <td><?php echo htmlspecialchars($record->average_monthly_income); ?></td>
                                                            <td><?php echo htmlspecialchars($record->applied_before); ?></td>
                                                            <td><?php echo htmlspecialchars($record->application_details); ?></td>
                                                            <td><?php echo htmlspecialchars($record->ideal_centre_reason); ?></td>
                                                            <td><?php echo htmlspecialchars($record->source_info); ?></td>
                                                            <td><?php echo htmlspecialchars($record->current_centre); ?></td>
                                                            <td><?php echo htmlspecialchars($record->reason_for_applying); ?></td>
                                                            <td>
                                                                <?php if (!empty($record->aadhar_file)) {
                                                                    $fileExtension = pathinfo($record->aadhar_file, PATHINFO_EXTENSION);
                                                                    if (in_array(strtolower($fileExtension), ['jpg', 'jpeg', 'png'])) { ?>
                                                                        <img src="<?php echo htmlspecialchars($record->aadhar_file); ?>" alt="Aadhar Card" width="100">
                                                                    <?php } elseif (strtolower($fileExtension) === 'pdf') { ?>
                                                                        <button type="button" class="btn btn-primary btn-sm view-pdf" data-file="<?php echo htmlspecialchars($record->aadhar_file); ?>">View PDF</button>
                                                                    <?php } else {
                                                                        echo "Invalid File";
                                                                    }
                                                                } else {
                                                                    echo "No File";
                                                                } ?>
                                                            </td>
                                                            <td>
                                                                <?php if (!empty($record->pan_file)) {
                                                                    $fileExtension = pathinfo($record->pan_file, PATHINFO_EXTENSION);
                                                                    if (in_array(strtolower($fileExtension), ['jpg', 'jpeg', 'png'])) { ?>
                                                                        <img src="<?php echo htmlspecialchars($record->pan_file); ?>" alt="PAN Card" width="100">
                                                                    <?php } elseif (strtolower($fileExtension) === 'pdf') { ?>
                                                                        <button type="button" class="btn btn-primary btn-sm view-pdf" data-file="<?php echo htmlspecialchars($record->pan_file); ?>">View PDF</button>
                                                                    <?php } else {
                                                                        echo "Invalid File";
                                                                    }
                                                                } else {
                                                                    echo "No File";
                                                                } ?>
                                                            </td>
                                                            <td><?php echo htmlspecialchars($record->created_at); ?></td>
                                                            <td class="text-center">
                                                                <a class="btn btn-sm btn-info" href="<?php echo base_url() . 'onboardingfirstform/view/' . $record->onboardFirstFormId; ?>" title="View"><i class="fa fa-eye"></i></a>
                                                                <a class="btn btn-sm btn-danger deletepdc" href="#" data-trainingid="<?php echo $record->onboardFirstFormId; ?>" title="Delete"><i class="fa fa-trash"></i></a>
                                                            </td>
                                                        </tr>
                                                <?php }
                                                } ?>
                                            </tbody>
                                        </table>
                                    </div><!-- /.box-body -->
                                    <div class="box-footer clearfix">
                                        <div class="br-pagi">
                                            <?php echo $this->pagination->create_links(); ?>
                                        </div>
                                    </div>
                                </div><!-- /.box -->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
    jQuery(document).ready(function() {
        // Initialize DataTable with responsive settings
        $('#example').DataTable({
            responsive: true,
            columnDefs: [
                { targets: [0, -1], responsivePriority: 1 } // Ensure Sr. No. and Action columns are always visible
            ]
        });

        // Handle pagination clicks
        jQuery('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchUser").attr("action", baseURL + "onboardingfirstform/onboardingfirstformListing/" + value);
            jQuery("#searchUser").submit();
        });

        // Handle View PDF button clicks
        jQuery(document).on('click', '.view-pdf', function() {
            var fileUrl = jQuery(this).data('file');
            window.open(fileUrl, '_blank');
        });

        // Handle delete button (assuming deletepdc is handled in common.js)
        jQuery('.deletepdc').click(function(e) {
            e.preventDefault();
            var trainingId = jQuery(this).data('trainingid');
            if (confirm('Are you sure you want to delete this record?')) {
                jQuery.ajax({
                    url: '<?php echo base_url(); ?>onboardingfirstform/delete/' + trainingId,
                    type: 'POST',
                    data: {
                        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                    },
                    success: function(response) {
                        if (response.status === 'success') {
                            location.reload();
                        } else {
                            alert('Error deleting record');
                        }
                    },
                    error: function() {
                        alert('Error deleting record');
                    }
                });
            }
        });
    });
</script>

<style type="text/css">
    tr:nth-child(even) {
        background-color: #D6EEEE !important;
    }

    /*table-css*/
    table.dataTable>tbody>tr.child span.dtr-title {
        display: inline-block;
        /*min-width: 75px;*/
        min-width: 50%;
        font-weight: bold;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control {
        position: relative;
        padding-left: 30px;
        cursor: pointer;
    }

    div.dataTables_wrapper li {
        text-indent: 0;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
        content: "-";
        background-color: #d33333;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
        top: 50%;
        left: 5px;
        height: 1em;
        width: 1em;
        margin-top: -9px;
        display: block;
        position: absolute;
        color: white;
        border: .15em solid white;
        border-radius: 1em;
        box-shadow: 0 0 .2em #444;
        box-sizing: content-box;
        text-align: center;
        text-indent: 0 !important;
        font-family: "Courier New", Courier, monospace;
        line-height: 1em;
        content: "+";
        background-color: #31b131;
    }
</style>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('ul.pagination li a').click(function(e) {
            e.preventDefault();
            var link = jQuery(this).get(0).href;
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "training/trainingListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });
    /*$(document).ready(function() {
            $("#example_paginate").hide();
            $("#example_info").hide();
        }); */
</script>
<!-- DataTables Select CSS -->
<link href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css" rel="stylesheet">

<!-- DataTables Select JS -->
<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js" type="text/javascript"></script>