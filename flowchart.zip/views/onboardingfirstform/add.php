<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <i class="fa fa-user-circle-o" aria-hidden="true"></i> Onboarding Application Form
            <small>Add / Edit Onboarding</small>
        </h1>
    </section>

    <section class="content">

        <div class="row">
            <!-- left column -->
            <div class="col-md-10">
                <!-- general form elements -->

                <div class="box box-primary">
                    <!-- <div class="box-header">
                        <h3 class="box-title">Enter Onboarding Details</h3>
                    </div> --><!-- /.box-header -->
                    <!-- form start -->
                    <?php $this->load->helper("form"); ?>
                    <form role="form" id="addFaq" action="<?php echo base_url() ?>onboardingfirstform/addNewOnboardingfirstform" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div id="step1" class="form-step">
                                <h3 class="text-center">Personal Details</h3>
                                <div class="row">
                                <div class="col-md-8">
    <div class="form-group">
        <?php if ($role != 25) { ?>
            <label for="franchiseNumber">Franchise <span class="re-mend-field">*</span></label>
        <?php } ?>
        <?php if ($role == 25) { ?>
            <!-- Hidden input for role 25 -->
            <input type="hidden" name="franchiseNumber[]" value="<?php echo htmlspecialchars($this->session->userdata('franchiseNumber')); ?>">
        <?php } else { ?>
            <!-- Other roles: Dropdown with default selection -->
            <select class="form-control required" id="franchiseNumber" name="franchiseNumber[]" data-live-search="true" required onchange="fetchAssignedFranchise(this.value); fetchStaffByFranchise(this.value);">
                <option value="">Select Franchise</option>
                <?php
                if (!empty($branchDetail)) {
                    $defaultFranchise = $this->session->userdata('franchiseNumber') ?: '';
                    foreach ($branchDetail as $bd) {
                        $franchiseNumber = $bd->franchiseNumber;
                        $selected = ($franchiseNumber == $defaultFranchise) ? 'selected' : '';
                ?>
                        <option value="<?php echo htmlspecialchars($franchiseNumber); ?>" <?php echo $selected; ?>>
                            <?php echo htmlspecialchars($franchiseNumber); ?>
                        </option>
                <?php
                    }
                }
                ?>
            </select>
        <?php } ?>
    </div>
</div>
                                    <div class="col-md-6 form-group">
                                        <label for="full_name">Full Name <br>(As in Pan Card/Aadhar/Voter’s ID)</label>
                                        <input type="text" name="full_name" placeholder="Full Name (As in Pan Card/Aadhar/Voter’s ID)" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group" style="padding-top:20px">
                                        <label for="email">E-mail</label>
                                        <input type="email" name="email" placeholder="Your Email" class="form-control" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="contact">Contact No.</label>
                                        <input type="number" name="contact" placeholder="Mobile Number" class="form-control" required oninput="validateContact(this)" pattern="\d{10}">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="alternate_contact">Alternate Number</label>
                                        <input type="number" name="alternate_contact" placeholder="Alternate Number" class="form-control" required oninput="validateContact(this)" pattern="\d{10}">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="dob">D.O.B</label>
                                        <input type="date" name="dob" placeholder="Date of Birth (dd-mm-yyyy)" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="communication_address">Communication Address</label>
                                        <input type="text" name="communication_address" placeholder="Communication Address" class="form-control" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <label for="city">City</label>
                                        <input type="text" name="city" placeholder="City" class="form-control" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="state">State</label>
                                        <input type="text" name="state" placeholder="State" class="form-control" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="pincode">Pincode</label>
                                        <input type="text" name="pincode" placeholder="Pincode" class="form-control" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="pan_card_no">Pan Card</label>
                                        <input type="text" name="pan_card_no" placeholder="Pan Card No" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="aadhar_card">Aadhar Card</label>
                                        <input type="text" name="aadhar_card" placeholder="Aadhar Card" class="form-control" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="nationality">Nationality</label>
                                        <input type="text" name="nationality" placeholder="Nationality" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="permanent_address">Permanent Address</label>
                                        <input type="text" name="permanent_address" placeholder="Permanent Address" class="form-control" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <label for="pcity">City</label>
                                        <input type="text" name="pcity" placeholder="City" class="form-control" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="pstate">State</label>
                                        <input type="text" name="pstate" placeholder="State" class="form-control" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <label for="ppincode">Pincode</label>
                                        <input type="text" name="ppincode" placeholder="Pincode" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="gender">Gender:</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="">Select Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="marital_status">Marital Status:</label>
                                    <select name="marital_status" id="marital_status" class="form-control" required onchange="toggleSpouseAndChildrenFields()">
                                        <option value="">Select Marital Status</option>
                                        <option value="single">Single</option>
                                        <option value="married">Married</option>
                                        <option value="divorce">Divorced</option>
                                    </select>
                                </div>

                                <div class="form-group" id="spouse_name_field" style="display: none;">
                                    <label for="spouse">Name of Spouse</label>
                                    <input type="text" name="spouse" id="spouse" class="form-control" placeholder="Name of Spouse">
                                </div>

                                <div class="form-group" id="children_number_field" style="display: none;">
                                    <label for="numberchildern">Number of Children</label>
                                    <input type="number" name="numberchildern" id="numberchildern" class="form-control" placeholder="Number of Children">
                                </div>
                                <div class="box-footer">
                                    <div class="text-center">
                                        <button type="button" class="btn btn-primary" onclick="nextStep(1)">Next</button>
                                    </div>
                                </div>
                            </div>

                            <div id="step2" class="form-step" style="display: none;">
                                <h3 class="text-center">Educational Qualifications</h3>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="highest_education">Highest Educational Level:</label>
                                        <select name="highest_education" id="highest_education" class="form-control" required>
                                            <option value="">Select Education Level</option>
                                            <option value="Higher Secondary">Higher Secondary</option>
                                            <option value="Diploma">Diploma</option>
                                            <option value="Graduate">Graduate</option>
                                            <option value="Post Graduate">Post Graduate</option>
                                            <option value="Doctorate">Doctorate</option>
                                        </select>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label for="qualifications">Qualifications:</label>
                                        <input type="text" name="qualifications" placeholder="Qualifications (e.g., BTech, M.Sc, MBA)" class="form-control" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="university">University/College/School/Institute:</label>
                                        <input type="text" name="university" placeholder="University/College/School/Institute" class="form-control" required>
                                    </div>

                                    <div class="col-md-6 form-group">
                                        <label for="year_of_qualification">Year of Qualification Achieved:</label>
                                        <input type="number" name="year_of_qualification" placeholder="Year of Qualification Achieved" class="form-control" required>
                                    </div>
                                </div>

                                <h3 class="text-center">Certificate/Course/Award Information</h3>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="certificate_course_award">Certificate/Course/Award</label>
                                        <input type="text" name="certificate_course_award" placeholder="Certificate/Course/Award" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="year_received">Year Received</label>
                                        <input type="text" name="year_received" placeholder="Year Received" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="awarded_by">Awarded By</label>
                                        <input type="text" name="awarded_by" placeholder="Awarded By" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label>Special Skills, Abilities, Etc. (Circle proficiency level, 5 for excellence to 1 for poor)</label><br>
                                        <div class="mb-2">
                                            <strong>English Spoken:</strong>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="english_spoken" value="5" class="form-check-input" required checked>
                                                <label class="form-check-label">5</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="english_spoken" value="4" class="form-check-input">
                                                <label class="form-check-label">4</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="english_spoken" value="3" class="form-check-input">
                                                <label class="form-check-label">3</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="english_spoken" value="2" class="form-check-input">
                                                <label class="form-check-label">2</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="english_spoken" value="1" class="form-check-input">
                                                <label class="form-check-label">1</label>
                                            </div>
                                        </div>
                                        <div>
                                            <strong>Other Skills:</strong>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="other_skills" value="5" class="form-check-input" required checked>
                                                <label class="form-check-label">5</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="other_skills" value="4" class="form-check-input">
                                                <label class="form-check-label">4</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="other_skills" value="3" class="form-check-input">
                                                <label class="form-check-label">3</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="other_skills" value="2" class="form-check-input">
                                                <label class="form-check-label">2</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input type="radio" name="other_skills" value="1" class="form-check-input">
                                                <label class="form-check-label">1</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <label>Mathematics:</label>
                                <div>
                                    <label class="radio-inline">
                                        <input type="radio" name="mathematics_proficiency" value="5" required checked> 5
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="mathematics_proficiency" value="4"> 4
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="mathematics_proficiency" value="3"> 3
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="mathematics_proficiency" value="2"> 2
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="mathematics_proficiency" value="1"> 1
                                    </label>
                                </div>

                                <label>English Written:</label>
                                <div>
                                    <label class="radio-inline">
                                        <input type="radio" name="english_written_proficiency" value="5" required checked> 5
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="english_written_proficiency" value="4"> 4
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="english_written_proficiency" value="3"> 3
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="english_written_proficiency" value="2"> 2
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="english_written_proficiency" value="1"> 1
                                    </label>
                                </div>

                                <h3 class="text-center">Employment/Business History</h3>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="current_employer_name"> Current Employer/Business Owned: Name of Company</label>
                                        <input type="text" name="current_employer_name" placeholder="Name of Company" class="form-control">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="current_position">Business Position</label>
                                        <input type="text" name="current_position" placeholder="Position" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="current_date_joined">Date Joined</label>
                                        <input type="date" name="current_date_joined" placeholder="Date Joined (dd-mm-yyyy)" class="form-control">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="current_business_address">Business Address</label>
                                        <input type="text" name="current_business_address" placeholder="Business Address" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="current_monthly_income">Monthly Income</label>
                                        <input type="number" name="current_monthly_income" placeholder="Monthly Income" class="form-control">
                                    </div>
                                </div>

                                <h4 class="text-center">Previous Employer or Other Business Owned</h4>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="previous_employer_name">Name of Company</label>
                                        <input type="text" name="previous_employer_name" placeholder="Name of Company" class="form-control">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="previous_monthly_income">Monthly Income</label>
                                        <input type="number" name="previous_monthly_income" placeholder="Monthly Income" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="previous_date_joined">Date Joined</label>
                                        <input type="date" name="previous_date_joined" placeholder="Date Joined (dd-mm-yyyy)" class="form-control">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="previous_business_address">Business Address</label>
                                        <input type="text" name="previous_business_address" placeholder="Business Address" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="previous_last_position">Last Position Held</label>
                                        <input type="text" name="previous_last_position" placeholder="Last Position Held" class="form-control">
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="previous_date_left">Date Left</label>
                                        <input type="date" name="previous_date_left" placeholder="Date Left (dd-mm-yyyy)" class="form-control">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 form-group">
                                        <label for="previous_reasons_for_leaving">Reasons for Leaving</label>
                                        <textarea name="previous_reasons_for_leaving" placeholder="Reasons for Leaving" class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="box-footer">
                                    <div class="form-group text-center">
                                        <button type="button" class="btn btn-secondary" onclick="prevStep(2)">Previous</button>
                                        <button type="button" class="btn btn-primary" onclick="nextStep(2)">Next</button>
                                    </div>
                                </div>
                            </div>

                            <div id="step3" class="form-step" style="display: none;">
                                <h3 class="text-center">Father's / Spouse’s Particulars</h3>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="father_spouse_select">Select Particular:</label>
                                        <select name="father_spouse_select" id="father_spouse_select" class="form-control" required onchange="toggleDetails()">
                                            <option value="">-- Select --</option>
                                            <option value="father">Father</option>
                                            <option value="spouse">Spouse</option>
                                        </select>
                                    </div>

                                    <div class="col-md-6">
                                        <label for="spouse_dob"> Date of Birth:</label>
                                        <input type="date" name="spouse_dob" id="spouse_dob" class="form-control">
                                    </div>
                                </div>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="father_name">Full Name (As in Pan Card/Aadhar):</label>
                                        <input type="text" name="father_name" id="father_name" placeholder="Father Name" class="form-control" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="father_pan_card">PAN Card No.:</label>
                                        <input type="text" name="father_pan_card" id="father_pan_card" placeholder="Pan Card No." class="form-control" required>
                                    </div>
                                </div>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="father_nationality">Nationality:</label>
                                        <input type="text" name="father_nationality" id="father_nationality" placeholder="Nationality" class="form-control" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="father_aadhar_card">Aadhar Card No.:</label>
                                        <input type="text" name="father_aadhar_card" id="father_aadhar_card" placeholder="Aadhar Card No." class="form-control" required>
                                    </div>
                                </div>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="father_mobile">Mobile Number:</label>
                                        <input type="number" name="father_mobile" id="father_mobile" placeholder="Mobile Number" class="form-control" required oninput="validateContact(this)" pattern="\d{10}">
                                    </div>
                                </div>

                                <div id="father_employment">
                                    <h4 class="text-center mt-4">Father's Employment</h4>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label for="father_position">Position:</label>
                                            <input type="text" name="father_position" id="father_position" placeholder="Position" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="father_organization">Name of Organisation:</label>
                                            <input type="text" name="father_organization" id="father_organization" placeholder="Name of Organisation" class="form-control">
                                        </div>
                                    </div>

                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label for="father_business_address">Business Address:</label>
                                            <input type="text" name="father_business_address" id="father_business_address" placeholder="Business Address" class="form-control">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="father_monthly_income">Monthly Income:</label>
                                            <input type="number" name="father_monthly_income" id="father_monthly_income" placeholder="Monthly Income" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <h4 class="text-center mt-4">Spouse's Employment</h4>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="spouse_position">Position:</label>
                                        <input type="text" name="spouse_position" id="spouse_position" placeholder="Spouse Position" class="form-control">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="spouse_organization">Name of Organisation:</label>
                                        <input type="text" name="spouse_organization" id="spouse_organization" placeholder="Name of Organisation" class="form-control">
                                    </div>
                                </div>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="spouse_business_address">Business Address:</label>
                                        <input type="text" name="spouse_business_address" id="spouse_business_address" placeholder="Business Address" class="form-control">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="spouse_monthly_income">Monthly Income:</label>
                                        <input type="number" name="spouse_monthly_income" id="spouse_monthly_income" placeholder="Monthly Income" class="form-control">
                                    </div>
                                </div>

                                <h4 class="text-center mt-4">Financial Statement</h4>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="average_monthly_income">Average Monthly Income (INR):</label>
                                        <input type="number" name="average_monthly_income" id="average_monthly_income" placeholder="Average Monthly Income (INR)" class="form-control" required>
                                    </div>
                                </div>

                                <!-- <div class="form-group text-center mt-4">
                        <button type="button" class="btn btn-secondary" onclick="prevStep(3)">Previous</button>
                        <button type="button" class="btn btn-primary" onclick="nextStep(3)">Next</button>
                    </div> -->
                                <div class="box-footer">
                                    <div class="form-group text-center">
                                        <button type="button" class="btn btn-secondary" onclick="prevStep(3)">Previous</button>
                                        <button type="button" class="btn btn-primary" onclick="nextStep(3)">Next</button>
                                    </div>
                                </div>
                            </div>

                            <div id="step4" class="form-step" style="display: none;">
                                <h3 class="text-center">Other Information</h3>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label>Have you, your spouse OR any of your family member ever applied for any center before? <br> If yes, please state details & Year:</label>
                                        <select name="appliedBefore" id="appliedBefore" class="form-control" required onchange="toggleApplicationDetails()">
                                            <option value="">-- Select --</option>
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </select>
                                    </div>

                                    <div class="col-md-6" id="applicationDetailsDiv" style="display: none;">
                                        <label></label>
                                        <input type="text" name="application_details" id="application_details" placeholder="Details & Year" class="form-control">
                                    </div>
                                </div>

                                <div class="row g-3 mt-3">
                                    <div class="col-md-6">
                                        <label>How did you learn about eduMETA’s Centre Opportunity?</label>
                                        <textarea name="ideal_centre_reason" id="ideal_centre_reason" placeholder="Why an ideal centre?" class="form-control" rows="3"></textarea>
                                    </div>

                                    <div class="col-md-6">
                                        <label>Why are you applying for the centre?</label>
                                        <input type="text" name="source_info" id="source_info" placeholder="Source of information" class="form-control">
                                    </div>
                                </div>

                                <div class="row g-3 mt-3">
                                    <!-- <div class="col-md-6">
                            <label>Current Centre:</label>
                            <input type="text" name="current_centre" id="current_centre" placeholder="Current Centre" class="form-control">
                        </div> -->

                                    <div class="col-md-6">
                                        <label>Why applying for the centre?</label>
                                        <textarea name="reason_for_applying" id="reason_for_applying" placeholder="Reason for applying" class="form-control" rows="3"></textarea>
                                    </div>
                                </div>

                                <div class="row g-3 mt-3">
                                    <div class="col-md-6">
                                        <label>Upload Aadhar Card Image:</label>
                                        <input type="file" name="file" class="form-control-file" id="file" accept="image/*">
                                    </div>

                                    <div class="col-md-6">
                                        <label>Upload PAN Card Image:</label>
                                        <input type="file" name="file2" class="form-control-file" id="file2" accept="image/*">
                                    </div>
                                </div>

                                <div class="form-group mt-4">
                                    <div class="form-check">
                                        <input type="checkbox" name="declaration" id="declaration" class="form-check-input" required>
                                        <label for="declaration" class="form-check-label">
                                            I do hereby represent that all the above answers are true and complete to the best of my knowledge and belief. I recognize that eduMETA is not in any way obligated to franchise a learning centre to me because of our execution of this document. I acknowledge that any false statement on this application shall be considered sufficient cause to deny any further consideration or cause revocation of any signed agreement with eduMETA.
                                        </label>
                                    </div>
                                </div>
                                <div class="box-footer">
                                    <div class="form-group text-center">
                                        <button type="button" class="btn btn-secondary" onclick="prevStep(4)">Previous</button>
                                        <input type="submit" value="Submit" class="btn btn-success">
                                        <input type="reset" class="btn btn-default" value="Reset" />
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->

                        <!-- <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div> -->
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                $this->load->helper('form');
                $error = $this->session->flashdata('error');
                if ($error) {
                ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                <?php } ?>
                <?php
                $success = $this->session->flashdata('success');
                if ($success) {
                ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php echo $this->session->flashdata('success'); ?>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Editor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('description', {
            /*filebrowserUploadUrl: "<?= base_url('training/upload'); ?>",*/
            filebrowserUploadMethod: 'form'
        });
    </script>
    <script>
        function toggleSpouseAndChildrenFields() {
            var maritalStatus = document.getElementById('marital_status').value;
            var spouseNameField = document.getElementById('spouse_name_field');
            var childrenNumberField = document.getElementById('children_number_field');

            if (maritalStatus === 'married') {
                spouseNameField.style.display = 'block';
                childrenNumberField.style.display = 'block';
            } else {
                spouseNameField.style.display = 'none';
                childrenNumberField.style.display = 'none';
            }
        }

        function nextStep(stepNumber) {
            const currentStep = document.getElementById('step' + stepNumber);
            const nextStep = document.getElementById('step' + (stepNumber + 1));

            const requiredFields = currentStep.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                let errorDiv;

                if (field.nextElementSibling && field.nextElementSibling.classList.contains('invalid-feedback')) {
                    errorDiv = field.nextElementSibling;
                    errorDiv.remove();
                }

                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                    errorDiv = document.createElement('div');
                    errorDiv.classList.add('invalid-feedback');
                    errorDiv.innerText = 'This field is required';
                    field.parentNode.appendChild(errorDiv);
                } else if (field.type === "email") {
                    let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                    if (!emailPattern.test(field.value.trim())) {
                        isValid = false;
                        field.classList.add('is-invalid');
                        errorDiv = document.createElement('div');
                        errorDiv.classList.add('invalid-feedback');
                        errorDiv.innerText = 'Please enter a valid email address';
                        field.parentNode.appendChild(errorDiv);
                    } else {
                        field.classList.remove('is-invalid');
                    }
                } else if (field.name === 'contact' || field.name === 'alternate_contact' || field.name === 'father_mobile') {
                    if (field.value.trim().length !== 10) {
                        isValid = false;
                        field.classList.add('is-invalid');
                        errorDiv = document.createElement('div');
                        errorDiv.classList.add('invalid-feedback');
                        errorDiv.innerText = 'Please enter a valid 10-digit phone number';
                        field.parentNode.appendChild(errorDiv);
                    } else {
                        field.classList.remove('is-invalid');
                    }
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (isValid && nextStep) {
                currentStep.style.display = 'none';
                nextStep.style.display = 'block';
            }
        }

        function prevStep(stepNumber) {
            const currentStep = document.getElementById('step' + stepNumber);
            const prevStep = document.getElementById('step' + (stepNumber - 1));

            if (currentStep && prevStep) {
                currentStep.style.display = 'none';
                prevStep.style.display = 'block';
            }
        }

        function toggleDetails() {
            const selectedValue = document.getElementById('father_spouse_select').value;
            const fatherEmploymentSection = document.getElementById('father_employment');

            if (selectedValue === 'spouse') {
                fatherEmploymentSection.style.display = 'none';
                document.querySelectorAll('#father_employment input').forEach(input => {
                    input.removeAttribute('required');
                });
            } else {
                fatherEmploymentSection.style.display = 'block';
                document.querySelectorAll('#father_employment input').forEach(input => {
                    input.setAttribute('required', 'required');
                });
            }
        }

        function toggleApplicationDetails() {
            const appliedBefore = document.getElementById('appliedBefore').value;
            const applicationDetailsDiv = document.getElementById('applicationDetailsDiv');

            if (appliedBefore === 'yes') {
                applicationDetailsDiv.style.display = 'block';
            } else {
                applicationDetailsDiv.style.display = 'none';
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            document.getElementById('father_employment').style.display = 'none';
        });
    </script>

    <script>
        const form = document.getElementById('yourForm');
        const submitBtn = document.getElementById('submitBtn');

        form.addEventListener('submit', function(e) {
            if (submitBtn.disabled) {
                e.preventDefault(); // Prevent form submission if already disabled
                return;
            }
            submitBtn.disabled = true; // Disable button
            submitBtn.innerText = 'Submitting...'; // Optional: Indicate submission
        });

        // Updated fetchAssignedFranchise function to fetch Growth Manager's name
        function fetchAssignedFranchise(franchiseNumber) {
            const assignedDiv = document.getElementById('brspFranchiseAssigned');
            const hiddenInput = document.getElementById('brspFranchiseAssignedValue'); // Reference hidden input
            if (franchiseNumber) {
                $.ajax({
                    url: '<?php echo base_url("admissiondetailsnew/fetchAssignedUsers"); ?>',
                    type: 'POST',
                    data: {
                        franchiseNumber: franchiseNumber,
                        '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success' && response.html) {
                            assignedDiv.innerHTML = response.html; // Display Growth Manager's name(s)
                            hiddenInput.value = response.userIds || ''; // Set hidden input to userIds
                        } else {
                            assignedDiv.innerText = 'No Growth Manager assigned';
                            hiddenInput.value = ''; // Clear hidden input
                            alert(response.message || 'No Growth Manager found for this franchise');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX Error: ", status, error);
                        console.error("Response Text: ", xhr.responseText);
                        assignedDiv.innerText = 'Error fetching Growth Manager';
                        hiddenInput.value = ''; // Clear hidden input
                        alert('Error fetching Growth Manager data');
                    }
                });
            } else {
                assignedDiv.innerText = 'Select a franchise to assign';
                hiddenInput.value = ''; // Clear hidden input
            }
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            const franchiseInput = document.getElementById('franchiseNumber');

            // For dropdown (non-readonly, roles other than 25)
            if (franchiseInput && franchiseInput.tagName === 'SELECT' && franchiseInput.value) {
                fetchAssignedFranchise(franchiseInput.value);
                // Trigger staff fetch if needed
                // fetchStaffByFranchise(franchiseInput.value);
            }

            // For readonly input (role 25)
            if (franchiseInput && franchiseInput.readOnly) {
                fetchAssignedFranchise(franchiseInput.value);
                // Trigger staff fetch if needed
                // fetchStaffByFranchise(franchiseInput.value);
            }
        });
    </script>
    <style type="text/css">
        .invalid-feedback {
            width: 100%;
            margin-top: .25rem;
            font-size: .875em;
            color: #e10303;
        }

        .form-check.form-check-inline {
            display: inline;
        }
    </style>
</div>