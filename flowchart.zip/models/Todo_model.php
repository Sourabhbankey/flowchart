<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Todo_model (Todo Model)
 * Todo model class to handle Todo related data 
 * @author : Ashish
 * @version : 1.1
 * @since : 11 Nov 2024
 */
class Todo_model extends CI_Model
{
    /**
     * This function is used to get the todo listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
function todoListingCount($searchText = '', $status = NULL, $userId = NULL, $startDate = NULL, $endDate = NULL)
{
    $this->db->select('todoId');
    $this->db->from('tbl_todo');

    if (!empty($searchText)) {
        $this->db->group_start();
        $this->db->like('todoTitle', $searchText);
        $this->db->or_like('description', $searchText);
        $this->db->group_end();
    }

    if ($status !== NULL) {
        $this->db->where('status', $status);
    }

    if (!empty($userId)) {
        $this->db->where('createdBy', $userId);
    }

    if (!empty($startDate)) {
        $this->db->where('DATE(createdDtm) >=', $startDate);
    }

    if (!empty($endDate)) {
        $this->db->where('DATE(createdDtm) <=', $endDate);
    }

    return $this->db->count_all_results();
}


function todoListing($searchText = '', $offset, $per_page, $status = NULL, $userId = NULL, $startDate = NULL, $endDate = NULL)
{
    $this->db->select('*');
    $this->db->from('tbl_todo');

    if (!empty($searchText)) {
        $this->db->group_start();
        $this->db->like('todoTitle', $searchText);
        $this->db->or_like('description', $searchText);
        $this->db->group_end();
    }

    if ($status !== NULL) {
        $this->db->where('status', $status);
    }

    if (!empty($userId)) {
        $this->db->where('createdBy', $userId);
    }

    if (!empty($startDate)) {
        $this->db->where('DATE(createdDtm) >=', $startDate);
    }

    if (!empty($endDate)) {
        $this->db->where('DATE(createdDtm) <=', $endDate);
    }

    $this->db->limit($per_page, $offset);
    $this->db->order_by('createdDtm', 'DESC');

    $query = $this->db->get();
    return $query->result();
}

    /**
     * This function is used to add new todo to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewTodo($todoInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_todo', $todoInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get todo information by id
     * @param number $todoId : This is todo id
     * @return array $result : This is todo information
     */
    function getTodoInfo($todoId) 
    {
        $this->db->select('*'); // Specified columns including status
        $this->db->from('tbl_todo');
        $this->db->where('todoId', $todoId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    /**
     * This function is used to update the todo information
     * @param array $todoInfo : This is todo updated information
     * @param number $todoId : This is todo id
     */
    function editTodo($todoInfo, $todoId)
    {
        $this->db->where('todoId', $todoId);
        $this->db->update('tbl_todo', $todoInfo);
        
        return TRUE;
    }
}