<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Class_model (Class Model)
 * Class model class to handle Class-related data
 * @author : Ashish
 * @version : 1.0
 * @since : 28 May 2024
 */
class Teacherassign_model extends CI_Model
{
    /**
     * Get the Class listing count
     * @param string $searchText : Optional search text
     * @return number $count : Row count
     */
    function TeacherassignListingCount($searchText)
    {
        $this->db->select('*');
        $this->db->from('tbl_assignclasstecher as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.ClassName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * Get the Class listing
     * @param string $searchText : Optional search text
     * @param number $page : Pagination offset
     * @param number $segment : Pagination limit
     * @return array $result : Result
     */
   function TeacherassignListing($searchText, $page, $segment)
{
    $this->db->select('BaseTbl.*, T.teacherName');  // Select teacherName from join
    $this->db->from('tbl_assignclasstecher as BaseTbl');
    $this->db->join('tbl_techers_list as T', 'T.techerId = BaseTbl.techerId', 'left'); // join teacher

    if (!empty($searchText)) {
        $likeCriteria = "(BaseTbl.className LIKE '%" . $searchText . "%' OR T.teacherName LIKE '%" . $searchText . "%')";
        $this->db->where($likeCriteria);
    }

    $this->db->where('BaseTbl.isDeleted', 0);
    $this->db->order_by('BaseTbl.agingclsteacherId', 'DESC');
    $this->db->limit($page, $segment);

    $query = $this->db->get();
    return $query->result();
}

    /**
     * Increment the opened count for a Class
     * @param number $ClassId : Class ID
     * @return number|boolean : Updated count or false
     */
    

    
    
    /**
     * Add a new Class
     * @return number $insert_id : Last inserted ID
     */
    function addNewTeacherassign($TeacherassignInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_assignclasstecher', $TeacherassignInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * Get Class information by ID
     * @param number $ClassId : Class ID
     * @return object $result : Class information
     */
    function getTeacherassignInfo($agingclsteacherId)
    {
        $this->db->select('*');
        $this->db->from('tbl_assignclasstecher');
        $this->db->where('agingclsteacherId', $agingclsteacherId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    /**
     * Update Class information
     * @param array $ClassInfo : Updated Class information
     * @param number $ClassId : Class ID
     * @return boolean
     */
    function editTeacherassign($TeacherassignInfo, $agingclsteacherId)
    {
        $this->db->where('agingclsteacherId', $agingclsteacherId);
        $this->db->update('tbl_assignclasstecher', $TeacherassignInfo);
        
        return TRUE;
    }
     public function getUsersByFranchise($franchiseNumber) {
        $this->db->select('tbl_users.userId, tbl_users.name');
        $this->db->from('tbl_branches');
        $this->db->join('tbl_users', 'tbl_branches.branchFranchiseAssigned = tbl_users.userId', 'inner');
        $this->db->where('tbl_branches.franchiseNumber', $franchiseNumber);
        $this->db->where('tbl_branches.isDeleted', 0);
        $query = $this->db->get();
    
        return $query->result();
    }
    public function getAllTeachers() {
   return $this->db->get_where('tbl_techers_list', ['isDeleted' => 0])->result();
}


public function getAllClasses() {

    return $this->db->get_where('tbl_class', ['isDeleted' => 0])->result();
}


public function getAllSections() {
    return $this->db->get_where('tbl_classSection', ['isDeleted' => 0])->result();
}
public function getTeachersByFranchise($franchiseNumber)
{
    return $this->db
        ->select('techerId, teacherName')
        ->from('tbl_techers_list')
        ->where('franchiseNumber', $franchiseNumber)
        ->where('isDeleted', 0)
        ->get()
        ->result();
}
}