<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Salesrecord_model (Salesrecord Model)
 * Salesrecord model class to get to handle Salesrecord related data 
 * @author : Ashish Singh
 * @version : 1.0
 * @since : 02 Jul 2024
 */
class Top10clients_model extends CI_Model
{
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
public function top10clientsListingCount($searchText, $userId, $userRole, $searchUserId = '', $fromDate = '', $toDate = '')
{
    $this->db->select('COUNT(*) as count');
    $this->db->from('tbl_top10clients_sales as BaseTbl');
    $this->db->join('tbl_users as U', 'BaseTbl.userId = U.userId', 'left');

    if (!empty($searchText)) {
        $this->db->group_start();
        $this->db->like('BaseTbl.clientname', $searchText);
        $this->db->or_like('BaseTbl.emailid', $searchText);
        $this->db->or_like('BaseTbl.contactno', $searchText);
        $this->db->group_end();
    }

    if (!empty($searchUserId)) {
        $this->db->where('BaseTbl.userId', $searchUserId);
    }

    if (!empty($fromDate)) {
        $this->db->where('BaseTbl.issuedon >=', $fromDate);
    }

    if (!empty($toDate)) {
        $this->db->where('BaseTbl.issuedon <=', $toDate);
    }

    // Fetch users assigned to this Team Lead (role 31)
    $subQuery = "(SELECT userId FROM tbl_top10clients_sales WHERE salesTeamAssign = $userId)";

    if (in_array($userRole, [28, 14])) {
        // Admin/Manager roles can view all records
    } elseif ($userRole == 31) {  
        // Team Leader (role 31) can see their own data and assigned users
        $this->db->where("(BaseTbl.userId = $userId OR BaseTbl.salesTeamAssign = $userId)", NULL, FALSE);
    } elseif ($userRole == 29) {
        // Users (role 29) can only see their own data
        $this->db->where('BaseTbl.userId', $userId);
    }

    $this->db->where('BaseTbl.isDeleted', 0);
    $query = $this->db->get();
    return $query->row()->count;
}

public function top10clientsrecordListing($searchText, $limit, $offset, $userId, $userRole, $searchUserId = '', $fromDate = '', $toDate = '')
{
    $this->db->select('BaseTbl.top10clientId, BaseTbl.issuedon, BaseTbl.firstcall, BaseTbl.clientname, 
                       BaseTbl.contactno, BaseTbl.altercontactno, BaseTbl.emailid, BaseTbl.city, 
                       BaseTbl.location, BaseTbl.lastcall, BaseTbl.nextfollowup, BaseTbl.salesTeamAssign, 
                       BaseTbl.status, BaseTbl.description, BaseTbl.description2, 
                       U.name as userName');
    $this->db->from('tbl_top10clients_sales as BaseTbl');
    $this->db->join('tbl_users as U', 'BaseTbl.userId = U.userId', 'left');

    if (!empty($searchText)) {
        $this->db->group_start();
        $this->db->like('BaseTbl.clientname', $searchText);
        $this->db->or_like('BaseTbl.emailid', $searchText);
        $this->db->or_like('BaseTbl.contactno', $searchText);
        $this->db->group_end();
    }

    if (!empty($searchUserId)) {
        $this->db->where('BaseTbl.userId', $searchUserId);
    }

    if (!empty($fromDate)) {
        $this->db->where('BaseTbl.issuedon >=', $fromDate);
    }

    if (!empty($toDate)) {
        $this->db->where('BaseTbl.issuedon <=', $toDate);
    }

    // Fetch users assigned to this Team Lead (role 31)
    $subQuery = "(SELECT userId FROM tbl_top10clients_sales WHERE salesTeamAssign = $userId)";

    if (in_array($userRole, [28, 14])) {
        // Admin/Manager roles can view all records
    } elseif ($userRole == 31) {  
        // Team Leader (role 31) can see their own data and assigned users
        $this->db->where("(BaseTbl.userId = $userId OR BaseTbl.salesTeamAssign = $userId)", NULL, FALSE);
    } elseif ($userRole == 29) {
        // Users (role 29) can only see their own data
        $this->db->where('BaseTbl.userId', $userId);
    }

    $this->db->where('BaseTbl.isDeleted', 0);
    $this->db->order_by('BaseTbl.top10clientId', 'DESC');
    $this->db->limit($limit, $offset);

    $query = $this->db->get();
    return $query->result();
}




    /**
     * This function is used to add new booking to system
     * @return number $insert_id : This is last inserted id
     */
	 
	 
	 
    function addNewTop10clientsrecord($top10clientsrecordInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_top10clients_sales', $top10clientsrecordInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get booking information by id
     * @param number $bookingId : This is booking id
     * @return array $result : This is booking information
     */
    
      function getTop10clientsrecordInfo($top10clientId)
    {
    $this->db->select('top10clientId,top10clientName ,top10clientEmail,top10clientContact,top10clientcity,top10clientlocation,description,salesTeamAssign,status');
        $this->db->from('tbl_top10clients_sales');
        $this->db->where('top10clientId', $top10clientId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    
    /**
     * This function is used to update the booking information
     * @param array $bookingInfo : This is booking updated information
     * @param number $bookingId : This is booking id
     */
   /* function editfollowuprecord($FollowuprecordInfo, $followupId)
    {
        $this->db->where('followupId', $followupId);
        $this->db->update('tbl_followup_sales', $FollowuprecordInfo);
        
        return TRUE;
    }*/
	
	public function editTop10clientsrecord($Top10clientsrecordInfo, $top10clientId)
{
    $this->db->where('top10clientId', $top10clientId);
    $this->db->update('tbl_top10clients_sales', $Top10clientsrecordInfo);
    
    // Print last executed query
    /*echo $this->db->last_query();
    exit;*/
     return TRUE;
    
}

public function getAllUsers()
{
    $this->db->select('userId, name');
    $this->db->from('tbl_users');
    $this->db->where('isDeleted', 0);
    $this->db->where_in('roleId', [34, 31, 28, 29]); 
    $query = $this->db->get();
    return $query->result();
}




}