<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Task_model (Task Model)
 * Task model class to get to handle task related data 
 * @author : Kishor Mali
 * @version : 1.5
 * @since : 18 Jun 2022
 */
class Task_model extends CI_Model
{
    /**
     * This function is used to get the task listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function taskListingCount($searchText)
    {
        $this->db->select('BaseTbl.taskId, BaseTbl.taskTitle, BaseTbl.description, BaseTbl.taskattchS3File,  BaseTbl.createdDtm');
        $this->db->from('tbl_task as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.taskTitle LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * This function is used to get the task listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function taskListing($searchText, $page, $segment)
    {
        $this->db->select('BaseTbl.taskId, BaseTbl.taskTitle, BaseTbl.description, BaseTbl.createdDtm,BaseTbl.assignedTo, BaseTbl.assignedBy, BaseTbl.taskattchS3File, BaseTbl.status, BaseTbl.updatedDtm');
        $this->db->from('tbl_task as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.taskTitle LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.taskId', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    
    /**
     * This function is used to add new task to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewTask($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_task', $taskInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get task information by id
     * @param number $taskId : This is task id
     * @return array $result : This is task information
     */
    function getTaskInfo($taskId)
    {
        $this->db->select('taskId, taskTitle, description, status, assignedBy, assignedTo, taskattchS3File,createdDtm ');
        $this->db->from('tbl_task');
        $this->db->where('taskId', $taskId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    function getRepyData($taskId)
    {
        $this->db->select('reply, taskId,repliedBy, createdDtm');
        $this->db->from('tbl_task_reply');
        $this->db->where('taskId', $taskId);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the task information
     * @param array $taskInfo : This is task updated information
     * @param number $taskId : This is task id
     */
    function editTask($taskInfo, $taskId)
    {
        $this->db->where('taskId', $taskId);
        $this->db->update('tbl_task', $taskInfo);
        
        return TRUE;
    }
    function replyTask($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_task_reply', $taskInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    /**
     * This function is used to get the user  information
     * @return array $result : This is result of the query
     */
    function getUser()
    {
        $this->db->select('userTbl.userId, userTbl.name, userTbl.roleId, userTbl.isAdmin, userTbl.email');
        $this->db->from('tbl_users as userTbl');
        $this->db->where_not_in('userTbl.roleId', [1,14]);
        $query = $this->db->get();
        return $query->result();
    }


    function updateMsg($taskID,$vendorId){
        $gwtSms     = $this->db->query("SELECT * FROM tbl_task WHERE taskId='$taskID'");
        $dataFinal  = $gwtSms->row();
        $id1        = $dataFinal->assignedBy;
        $id2        = $dataFinal->assignedTo;
        if ($id1 == $vendorId) {
            $gwtSmsCount = $this->db->query("UPDATE tbl_task_reply SET msgRead = NULL WHERE repliedBy='$dataFinal->assignedTo'");  
            return $gwtSmsCount;
        }elseif ($id2 == $vendorId) {
            $gwtSmsCount = $this->db->query("UPDATE tbl_task_reply SET msgRead = NULL WHERE repliedBy='$dataFinal->assignedBy'");
            return $gwtSmsCount;
        }
        
    }
 /*public function getTotalTrainingRecordsCountByFranchise($franchiseNumber) {
    $this->db->where('franchiseNumber', $franchiseNumber);
    $this->db->from('tbl_task');
    return $this->db->count_all_results();
	}*/
    public function getTotalTrainingRecordsCountByFranchise($franchiseNumber, $statusFilter = '') {
    $this->db->where('franchiseNumber', $franchiseNumber);
    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }
    $this->db->from('tbl_task');
    return $this->db->count_all_results();
}

	
	/*public function getTrainingRecordsByFranchise($franchiseNumber, $limit, $start) {
    $this->db->where('franchiseNumber', $franchiseNumber);
    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
	}
	*/
    public function getTrainingRecordsByFranchise($franchiseNumber, $limit, $start, $statusFilter = '') {
    $this->db->where('franchiseNumber', $franchiseNumber);
    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }
    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
}
/**/
	/*public function getTotalTrainingRecordsCount() {
    return $this->db->count_all('tbl_task');
	}*/

    public function getTotalTrainingRecordsCount($statusFilter = '') {
    $this->db->select('COUNT(*) as count');
    $this->db->from('tbl_task');

    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }

    $query = $this->db->get();
    return $query->row()->count;
}
	
	/*public function getAllTrainingRecords($limit, $start) {
    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
	}*/

/*public function getAllTrainingRecords($limit, $offset, $statusFilter = '') {
    $this->db->select('*');
    $this->db->from('tbl_task');

    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }

    $this->db->limit($limit, $offset);
    $query = $this->db->get();
    return $query->result();
}*/
public function getAllTrainingRecords($limit, $offset, $statusFilter = '', $franchiseFilter = '') {
    $this->db->select('*');
    $this->db->from('tbl_task');

    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }
    if (!empty($franchiseFilter)) {
        $this->db->where('franchiseNumber', $franchiseFilter);
    }

    $this->db->limit($limit, $offset);
    $query = $this->db->get();
    return $query->result();
}



	/*public function getTotalTrainingRecordsCountByRole($userId) {
    // Checking if the user is either assigned to the task, is the one who assigned it, or is in the collaborators list
    $this->db->group_start();
        $this->db->where('assignedTo', $userId);
        $this->db->or_where('assignedBy', $userId);
		 $this->db->or_where('collabrators', $userId);
       $this->db->or_where("FIND_IN_SET('collabrators', $userId) >", 0);
		$this->db->group_end();
		$this->db->from('tbl_task');
    
    return $this->db->count_all_results();
} */
 
public function getTotalTrainingRecordsCountByRole($userId, $statusFilter = '') {
    $this->db->group_start();
        $this->db->where('assignedTo', $userId);
        $this->db->or_where('assignedBy', $userId);
        $this->db->or_where('collabrators', $userId);
        $this->db->or_where("FIND_IN_SET('$userId', collabrators) >", 0);
    $this->db->group_end();

    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }

    $this->db->from('tbl_task');
    return $this->db->count_all_results();
}


	/*public function getTrainingRecordsByRole($userId, $limit, $start) {
    $this->db->group_start();
        $this->db->where('assignedTo', $userId);
        $this->db->or_where('assignedBy', $userId);
        $this->db->or_where('collabrators', $userId);
    $this->db->or_where("FIND_IN_SET('collabrators', $userId) >", 0);
    $this->db->group_end(); 	
    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
	}*/
	
public function getTrainingRecordsByRole($userId, $limit, $start, $statusFilter = '') {
    $this->db->group_start();
        $this->db->where('assignedTo', $userId);
        $this->db->or_where('assignedBy', $userId);
        $this->db->or_where('collabrators', $userId);
        $this->db->or_where("FIND_IN_SET('$userId', collabrators) >", 0);
    $this->db->group_end();

    if (!empty($statusFilter)) {
        $this->db->where('status', $statusFilter);
    }

    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
}

	public function get_users_without_franchise() {
    $this->db->where('roleId !=', 25);
    $query = $this->db->get('tbl_users'); 
    return $query->result();
    }
	/*
public function getTrainingRecordsByCollaborator($userId) {
    $this->db->where('collabrators', $userId);
	
    $this->db->from('tbl_task');
    return $this->db->count_all_results();
	}
	
	public function getTotalTrainingRecordsCountByCollaborator($userId, $limit, $start) {
    $this->db->where('collabrators', $userId);
	
    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
	}
	
public function isUserCollaborator($userId) {
    $this->db->select('collabrators');
    $this->db->from('tbl_task');
    $this->db->where("FIND_IN_SET('$userId', collabrators) >", 0); // Checking if userId is in collaborators
    $query = $this->db->get();
    
    return $query->num_rows() > 0; // Return true if user is a collaborator in any task
}
*/
}