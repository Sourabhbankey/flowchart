<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Support_model (Support Model)
 * Support model class to handle task related data 
 * @author : Ashish
 * @version : 1.0
 * @since : 28 May 2024
 */
class Support_model extends CI_Model
{
    /**
     * This function is used to get the support listing count
     * @param string $searchText : Optional search text
     * @return number $count : Row count
     */
    function supportListingCount($searchText)
    {
        $this->db->select('BaseTbl.supportMeetingId, BaseTbl.meetingTitle, BaseTbl.attendedByfranchise, BaseTbl.dateMeeting, BaseTbl.timeMeeting, BaseTbl.durationMeeting, BaseTbl.trypeofMeeting, BaseTbl.attendeesHO, BaseTbl.franchiseNumber, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_support as BaseTbl');
        if (!empty($searchText)) {
            $searchText = $this->db->escape_like_str($searchText);
            $this->db->like('BaseTbl.meetingTitle', $searchText);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
  
    function supportListing($searchText, $page, $segment)
    {
        $this->db->select('BaseTbl.supportMeetingId, BaseTbl.meetingTitle, BaseTbl.attendedByfranchise, BaseTbl.dateMeeting, BaseTbl.timeMeeting, BaseTbl.durationMeeting, BaseTbl.trypeofMeeting, BaseTbl.attendeesHO, BaseTbl.franchiseNumber, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_support as BaseTbl');
        if (!empty($searchText)) {
            $searchText = $this->db->escape_like_str($searchText);
            $this->db->like('BaseTbl.meetingTitle', $searchText);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        // Sort by createdDtm to show latest records first
        $this->db->order_by('BaseTbl.createdDtm', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        return $query->result();
    }
    
   
    function addNewSupport($supportInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_support', $supportInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
   
    function getsupportInfo($supportMeetingId)
    {
        $this->db->select('*');
        $this->db->from('tbl_support');
        $this->db->where('supportMeetingId', $supportMeetingId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
   
    function editSupport($supportInfo, $supportMeetingId)
    {
        $this->db->where('supportMeetingId', $supportMeetingId);
        $this->db->update('tbl_support', $supportInfo);
        
        return TRUE;
    }
    
  
    function getFranchise()
    {
        $this->db->select('userTbl.userId, userTbl.name, userTbl.roleId, userTbl.isAdmin, userTbl.email, userTbl.franchiseNumber');
        $this->db->from('tbl_users as userTbl');
        $this->db->where('userTbl.roleId', 25);
        $query = $this->db->get();
        return $query->result();
    }
    
    
    function getUser()
    {
        $this->db->select('userTbl.userId, userTbl.name');
        $this->db->from('tbl_users as userTbl');
        $this->db->where_not_in('userTbl.roleId', [1, 14, 2]);
        $this->db->where('userTbl.roleId', 15);
        $query = $this->db->get();
        return $query->result();
    }
    
    
    public function getAllacattachmentRecords()
    {
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
    
    public function getattachmentRecordsByFranchise($franchiseNumber)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
    
    public function get_count($franchiseFilter = null)
    {
        if ($franchiseFilter) {
            $this->db->where('franchiseNumber', $franchiseFilter);
        }
        return $this->db->count_all_results('tbl_support');
    }
    
    
    public function get_data($limit, $start, $franchiseFilter = null)
    {
        $this->db->limit($limit, $start);
        if ($franchiseFilter) {
            $this->db->where('franchiseNumber', $franchiseFilter);
        }
        $this->db->order_by('createdDtm', 'DESC'); // Ensure latest records first
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
    
    public function get_count_by_franchise($roleId, $franchiseFilter = null)
    {
        $this->db->where('brspFranchiseAssigned', $roleId);
        if ($franchiseFilter) {
            $this->db->where('franchiseNumber', $franchiseFilter);
        }
        return $this->db->count_all_results('tbl_support');
    }
    
    
    public function get_data_by_franchise($roleId, $limit, $start, $franchiseFilter = null)
    {
        $this->db->where('brspFranchiseAssigned', $roleId);
        $this->db->limit($limit, $start);
        if ($franchiseFilter) {
            $this->db->where('franchiseNumber', $franchiseFilter);
        }
        $this->db->order_by('createdDtm', 'DESC'); // Ensure latest records first
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
    
    public function getTotalTrainingRecordsCountByFranchise($franchiseNumber)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        $this->db->from('tbl_support');
        return $this->db->count_all_results();
    }
    
    
    public function getTrainingRecordsByFranchise($franchiseNumber, $limit, $start)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC'); // Ensure latest records first
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
    
    public function getTotalTrainingRecordsCount()
    {
        return $this->db->count_all('tbl_support');
    }
    
    
    public function getAllTrainingRecords($limit, $start)
    {
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC'); // Ensure latest records first
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
    
    public function getTotalTrainingRecordsCountByRole($roleId)
    {
        $this->db->where('brspFranchiseAssigned', $roleId);
        $this->db->from('tbl_support');
        return $this->db->count_all_results();
    }
    
    
    public function getTrainingRecordsByRole($roleId, $limit, $start)
    {
        $this->db->where('brspFranchiseAssigned', $roleId);
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC'); // Ensure latest records first
        $query = $this->db->get('tbl_support');
        return $query->result();
    }
    
   
    public function getFranchiseNumberByUserId($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_users');
        $this->db->where('userId', $userId);
        $query = $this->db->get();
        $result = $query->row();
        return $result ? $result->franchiseNumber : null;
    }
    public function getRescheduledSupportCount() {
    $this->db->where('status', 'Rescheduled');
    return $this->db->count_all_results('tbl_support');
}
   
    public function getUsersByFranchise($franchiseNumber)
    {
        $this->db->select('tbl_users.userId, tbl_users.name');
        $this->db->from('tbl_branches');
        $this->db->join('tbl_users', 'tbl_branches.branchFranchiseAssigned = tbl_users.userId', 'inner');
        $this->db->where('tbl_branches.franchiseNumber', $franchiseNumber);
        $this->db->where('tbl_branches.isDeleted', 0);
        return $this->db->get()->result();
    }
    
    /**
     * This function is used to get franchises assigned to a user
     * @param number $userId : User ID
     * @return array : Array of franchise numbers
     */
    public function getFranchisesForUser($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_branches');
        $this->db->where('branchfranchiseassigned', $userId);
        $query = $this->db->get();
        return $query->num_rows() > 0 ? $query->result() : [];
    }

    public function getSupportById($supportMeetingId)
{
    $this->db->where('supportMeetingId', $supportMeetingId);
    $query = $this->db->get('tbl_support');

    if ($query->num_rows() > 0) {
        return $query->row(); // return as object
    } else {
        return null;
    }
}

}