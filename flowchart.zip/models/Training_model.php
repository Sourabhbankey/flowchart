<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Training_model (Training Model)
 * Training model class to handle training-related data 
 * @author : Ashish
 * @version : 1.0
 * @since : 08 June 2023
 */
class Training_model extends CI_Model
{
    /**
     * Get the training listing count
     * @param string $searchText : Optional search text
     * @return number $count : Row count
     */
    function trainingListingCount($searchText)
    {
        $this->db->select('BaseTbl.trainingId, BaseTbl.trainingTitle, BaseTbl.nameOfTrainer, BaseTbl.dateTraing, BaseTbl.timeTraing, BaseTbl.durationTraining, BaseTbl.trypeofTraining, BaseTbl.statusofTraining, BaseTbl.attendees, BaseTbl.franchiseNumber, BaseTbl.description, BaseTbl.attachments3training, BaseTbl.createdDtm');
        $this->db->from('tbl_training as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.trainingTitle LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * Get the training listing
     * @param string $searchText : Optional search text
     * @param number $page : Pagination offset
     * @param number $segment : Pagination limit
     * @return array $result : Result
     */
    function trainingListing($searchText, $page, $segment)
    {
        $this->db->select('BaseTbl.trainingId, BaseTbl.trainingTitle, BaseTbl.nameOfTrainer, BaseTbl.dateTraing, BaseTbl.timeTraing, BaseTbl.durationTraining, BaseTbl.trypeofTraining, BaseTbl.statusofTraining, BaseTbl.attendees, BaseTbl.franchiseNumber, BaseTbl.description, BaseTbl.attachments3training, BaseTbl.createdDtm');
        $this->db->from('tbl_training as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.trainingTitle LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.trainingId', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * Add new training
     * @return number $insert_id : Last inserted ID
     */
    function addNewTraining($trainingInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_training', $trainingInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * Get user information
     * @return array $result : Query result
     */
    function getUser()
    {
        $this->db->select('userTbl.userId, userTbl.name, userTbl.roleId, userTbl.isAdmin, userTbl.email');
        $this->db->from('tbl_users as userTbl');
        $this->db->where_not_in('userTbl.roleId', [1,14]);
        $query = $this->db->get();
        return $query->result();
    }
    
    /**
     * Get training information by ID
     * @param number $trainingId : Training ID
     * @return array $result : Training information
     */
    function getTrainingInfo($trainingId)
    {
        $this->db->select('trainingId, trainingTitle, nameOfTrainer, dateTraing, timeTraing, durationTraining, trypeofTraining, attendees, statusofTraining, franchiseNumber, description, attachments3training, createdDtm');
        $this->db->from('tbl_training');
        $this->db->where('trainingId', $trainingId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    /**
     * Update training information
     * @param array $trainingInfo : Updated training information
     * @param number $trainingId : Training ID
     * @return bool
     */
    function editTraining($trainingInfo, $trainingId)
    {
        $this->db->where('trainingId', $trainingId);
        $this->db->update('tbl_training', $trainingInfo);
        
        return TRUE;
    }
    
    /**
     * Get franchise information
     * @return array $result : Query result
     */
    function getFranchise()
    {
        $this->db->select('userTbl.userId, userTbl.name, userTbl.roleId, userTbl.isAdmin, userTbl.email, userTbl.franchiseNumber');
        $this->db->from('tbl_users as userTbl');
        $this->db->where('userTbl.roleId', 25);
        $query = $this->db->get();
        return $query->result();
    }
    
    /**
     * Get franchise number by user ID
     * @param number $userId : User ID
     * @return string|null
     */
    public function getFranchiseNumberByUserId($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_users');
        $this->db->where('userId', $userId);
        $query = $this->db->get();
        $result = $query->row();
        return $result ? $result->franchiseNumber : null;
    }
    
    /**
     * Get training count with filters
     * @param string|null $franchiseFilter
     * @param string|null $typeOfTraining
     * @return number
     */
    public function get_count($franchiseFilter = null, $typeOfTraining = null)
    {
        if ($franchiseFilter) {
            $franchises = explode(',', $franchiseFilter);
            $this->db->group_start();
            foreach ($franchises as $franchise) {
                $this->db->or_where("FIND_IN_SET('$franchise', franchiseNumber) >", 0);
            }
            $this->db->group_end();
        }

        if ($typeOfTraining) {
            $this->db->where('trypeofTraining', $typeOfTraining);
        }
        $this->db->where('isDeleted', 0);
        return $this->db->count_all_results('tbl_training');
    }
    
    /**
     * Get training count by franchise
     * @param string $franchiseNumbers
     * @param string|null $franchiseFilter
     * @param string|null $typeOfTraining
     * @return number
     */
    public function get_count_by_franchise($franchiseNumbers, $franchiseFilter = null, $typeOfTraining = null)
    {
        $franchises = explode(',', $franchiseNumbers);
        $this->db->group_start();
        foreach ($franchises as $franchise) {
            $this->db->or_where("FIND_IN_SET('$franchise', franchiseNumber) >", 0);
        }
        $this->db->group_end();

        if ($franchiseFilter) {
            $filterFranchises = explode(',', $franchiseFilter);
            $this->db->group_start();
            foreach ($filterFranchises as $filterFranchise) {
                $this->db->or_where("FIND_IN_SET('$filterFranchise', franchiseNumber) >", 0);
            }
            $this->db->group_end();
        }

        if ($typeOfTraining) {
            $this->db->where('trypeofTraining', $typeOfTraining);
        }
        $this->db->where('isDeleted', 0);
        return $this->db->count_all_results('tbl_training');
    }
    
    /**
     * Get training data with filters
     * @param number $limit
     * @param number $start
     * @param string|null $franchiseFilter
     * @param string|null $typeOfTraining
     * @return array
     */
    public function get_data($limit, $start, $franchiseFilter = null, $typeOfTraining = null)
    {
        $this->db->select('trainingId, trainingTitle, nameOfTrainer, dateTraing, timeTraing, durationTraining, trypeofTraining, statusofTraining, attendees, franchiseNumber, description, attachments3training, createdDtm');
        $this->db->from('tbl_training');
        $this->db->limit($limit, $start);

        if (!empty($franchiseFilter)) {
            $this->db->group_start();
            foreach (explode(',', $franchiseFilter) as $filter) {
                $this->db->or_where("FIND_IN_SET('$filter', franchiseNumber) >", 0);
            }
            $this->db->group_end();
        }

        if (!empty($typeOfTraining)) {
            $this->db->where('trypeofTraining', $typeOfTraining);
        }

        $this->db->where('isDeleted', 0);
        $this->db->order_by('trainingId', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }
    
    /**
     * Get training data by franchise
     * @param string $franchiseNumbers
     * @param number $limit
     * @param number $start
     * @param string|null $franchiseFilter
     * @param string|null $typeOfTraining
     * @return array
     */
    public function get_data_by_franchise($franchiseNumbers, $limit, $start, $franchiseFilter = null, $typeOfTraining = null)
    {
        $this->db->select('trainingId, trainingTitle, nameOfTrainer, dateTraing, timeTraing, durationTraining, trypeofTraining, statusofTraining, attendees, franchiseNumber, description, attachments3training, createdDtm');
        $this->db->from('tbl_training');
        $this->db->limit($limit, $start);

        if (!empty($franchiseNumbers)) {
            $this->db->group_start();
            foreach (explode(',', $franchiseNumbers) as $franchise) {
                $this->db->or_where("FIND_IN_SET('$franchise', franchiseNumber) >", 0);
            }
            $this->db->group_end();
        }

        if (!empty($franchiseFilter)) {
            $this->db->group_start();
            foreach (explode(',', $franchiseFilter) as $filter) {
                $this->db->or_where("FIND_IN_SET('$filter', franchiseNumber) >", 0);
            }
            $this->db->group_end();
        }

        if (!empty($typeOfTraining)) {
            $this->db->where('trypeofTraining', $typeOfTraining);
        }

        $this->db->where('isDeleted', 0);
        $this->db->order_by('trainingId', 'DESC');
        $query = $this->db->get();
        return $query->result();
    }
    
    /**
     * Get all user roles except roleId 25
     * @return array
     */
    function getAllUserRole()
    {
        $this->db->select('userTbl.userId, userTbl.name');
        $this->db->from('tbl_users as userTbl');
        $this->db->where('userTbl.roleId !=', 25);
        $query = $this->db->get();
        return $query->result();
    }
    public function getGrowthManagersByFranchiseNumber($franchiseNumber)
{
    $this->db->select('branchFranchiseAssigned as userId');
    $this->db->from('tbl_branches');
    $this->db->where('franchiseNumber', $franchiseNumber);
    $this->db->where('branchFranchiseAssigned IS NOT NULL');
    $query = $this->db->get();

    $results = $query->result();

    $userIds = array_unique(array_map(function($row) {
        return $row->userId;
    }, $results));

    if (empty($userIds)) {
        return [];
    }

    // Get user details of assigned Growth Managers
    $this->db->select('*');
    $this->db->from('tbl_users');
    $this->db->where_in('userId', $userIds);
    $usersQuery = $this->db->get();

    return $usersQuery->result();
}

}