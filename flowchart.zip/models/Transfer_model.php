<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Transfer_model (Transfer Model)
 * Transfer model class to get to handle Transfer related data 
 * @author : Ashish Singh
 * @version : 1.0
 * @since : 17 May 2025
 */
class Transfer_model extends CI_Model
{
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
function TransferListingCount($searchText)
{
    $this->db->select('*');
    $this->db->from('tbl_stud_transfer as BaseTbl');

    // Search filter
    if (!empty($searchText)) {
        $this->db->like('BaseTbl.franchiseName', $searchText);
    }

    // Filter for assigned users only (not for admins)
    $roleId = $this->session->userdata('role');
    $userId = $this->session->userdata('userId');

    if ($roleId != 1 && $roleId != 14) {
        $this->db->where('BaseTbl.brspFranchiseAssigned', $userId);
    }

    return $this->db->count_all_results();
}


function TransferListing($searchText, $limit, $offset)
{
    $this->db->select('BaseTbl.*, Users.name as createdByName');
    $this->db->from('tbl_stud_transfer as BaseTbl');
    $this->db->join('tbl_users as Users', 'Users.userId = BaseTbl.createdBy', 'left');

    // Search filter
    if (!empty($searchText)) {
        $this->db->like('BaseTbl.franchiseName', $searchText);
    }

    // Filter for assigned users only (not for admins)
    $roleId = $this->session->userdata('role');
    $userId = $this->session->userdata('userId');

    if ($roleId != 1 && $roleId != 14) {
        $this->db->where('BaseTbl.brspFranchiseAssigned', $userId);
    }

    $this->db->order_by('BaseTbl.transId', 'DESC');
    $this->db->limit($limit, $offset);

    return $this->db->get()->result();
}


    
    /**
     * This function is used to add new booking to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewTransfer($TransferInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_stud_transfer', $TransferInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get booking information by id
     * @param number $bookingId : This is booking id
     * @return array $result : This is booking information
     */
    function getTransferInfo($transId)
    {
        $this->db->select('*');
        $this->db->from('tbl_stud_transfer');
        $this->db->where('transId', $transId);
      //  $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    
    /**
     * This function is used to update the booking information
     * @param array $bookingInfo : This is booking updated information
     * @param number $bookingId : This is booking id
     */
    function editTransfer($TransferInfo, $transId)
    {
        $this->db->where('transId', $transId);
        $this->db->update('tbl_stud_transfer', $TransferInfo);
        
        return TRUE;
    }
     public function getManagersByFranchise($franchiseNumber)
    {
        return $this->db->select('u.userId, u.name')
                        ->from('tbl_users as u')
                        ->join('tbl_branches as b', 'b.branchFranchiseAssigned = u.userId')
                        ->where('b.franchiseNumber', $franchiseNumber)
                        ->get()
                        ->result();
    }



    public function getFranchiseNameByNumber($franchiseNumber)
{
    $result = $this->db->select('franchiseName')
                       ->from('tbl_branches')
                       ->where('franchiseNumber', $franchiseNumber)
                       ->get()
                       ->row();
    
    return $result ? $result->franchiseName : null;
}



public function getGrowthManagersByFranchiseNumber($franchiseNumber)
{
    return $this->db->select('u.userId, u.name')
                    ->from('tbl_users as u')
                    ->join('tbl_branches as b', 'b.branchFranchiseAssigned = u.userId')
                    ->where('b.franchiseNumber', $franchiseNumber)
                    ->get()
                    ->result();
}
    /**
     * This function is used to get franchise details
     * @param string $franchiseNumber : This is franchise number
     * @return object $result : This is franchise information
     */
    public function getFranchiseDetails($franchiseNumber)
    {
        return $this->db->select('*')
                        ->from('tbl_branches as f')
                        ->where('f.franchiseNumber', $franchiseNumber)
                        ->get()
                        ->row();
    }
}