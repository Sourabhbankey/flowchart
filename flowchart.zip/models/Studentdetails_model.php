<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class : StudentDetails_model
 * Model to handle database operations for tbl_admission_details_2526 table.
 * @author : Ashish
 * @version : 1.0
 * @since : 16 May 2023
 */
class StudentDetails_model extends CI_Model
{
    /**
     * Get the count of student records
     * @param string $searchText : Optional search text for filtering by name
     * @return number $count : Number of rows
     */
    function studentListingCount($searchText)
    {
        $this->db->select('admid, name, enrollNum, class, program, dateOfAdmission');
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        if (!empty($searchText)) {
            $this->db->like('BaseTbl.name', $searchText); // Search by student name
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * Get student records with pagination
     * @param string $searchText : Optional search text
     * @param number $page : Pagination limit
     * @param number $segment : Pagination offset
     * @return array $result : List of student records
     */
    function studentListing($searchText, $page, $segment)
    {
        $this->db->select('BaseTbl.admid, BaseTbl.name, BaseTbl.enrollNum, BaseTbl.class, BaseTbl.program, BaseTbl.dateOfAdmission, BaseTbl.brspFranchiseAssigned, BaseTbl.franchiseNumber');
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        if (!empty($searchText)) {
            $this->db->like('BaseTbl.name', $searchText);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.dateOfAdmission', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * Add a new student record
     * @param array $studentInfo : Student data to insert
     * @return number $insert_id : Last inserted ID
     */
    function addNewStudent($studentInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_admission_details_2526', $studentInfo);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * Get student information by ID
     * @param number $studentId : Student record ID
     * @return object $result : Student information
     */
    function getStudentInfo($studentId)
    {
        $this->db->select('*');
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        $this->db->where('BaseTbl.admid', $studentId);
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    /**
     * Update a student record
     * @param array $studentInfo : Updated student data
     * @param number $studentId : Student record ID
     * @return bool
     */
    function editStudent($studentInfo, $studentId)
    {
        $this->db->trans_start();
        $this->db->where('admid', $studentId);
        $this->db->update('tbl_admission_details_2526', $studentInfo);
        $affected_rows = $this->db->affected_rows();
        $this->db->trans_complete();
        
        return $affected_rows > 0;
    }
    
    /**
     * Delete a student record (soft delete)
     * @param number $studentId : Student record ID
     * @return bool
     */
    function deleteStudent($studentId)
    {
        $this->db->trans_start();
        $this->db->where('admid', $studentId);
        $this->db->update('tbl_admission_details_2526', array('isDeleted' => 1));
        $affected_rows = $this->db->affected_rows();
        $this->db->trans_complete();
        
        return $affected_rows > 0;
    }

    /**
     * Get student records by franchise number
     * @param string $franchiseNumber : Franchise number to filter
     * @param number $limit : Pagination limit
     * @param number $start : Pagination offset
     * @return array $result : List of student records
     */
    public function getStudentsByFranchise($franchiseNumber, $limit, $start)
    {
        $this->db->select('BaseTbl.admid, BaseTbl.name, BaseTbl.enrollNum, BaseTbl.class, BaseTbl.program, BaseTbl.dateOfAdmission, BaseTbl.brspFranchiseAssigned, BaseTbl.franchiseNumber');
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        $this->db->where('BaseTbl.franchiseNumber', $franchiseNumber);
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.dateOfAdmission', 'DESC');
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * Get count of student records by franchise number
     * @param string $franchiseNumber : Franchise number to filter
     * @return number $count : Number of rows
     */
    public function getStudentCountByFranchise($franchiseNumber)
    {
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        $this->db->where('BaseTbl.franchiseNumber', $franchiseNumber);
        $this->db->where('BaseTbl.isDeleted', 0);
        return $this->db->count_all_results();
    }

    /**
     * Get total count of student records
     * @return number $count : Number of rows
     */
    public function getTotalStudentCount()
    {
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        $this->db->where('BaseTbl.isDeleted', 0);
        return $this->db->count_all_results();
    }

    /**
     * Get all student records with pagination
     * @param number $limit : Pagination limit
     * @param number $start : Pagination offset
     * @return array $result : List of student records
     */
    public function getAllStudents($limit, $start)
    {
        $this->db->select('BaseTbl.admid, BaseTbl.name, BaseTbl.enrollNum, BaseTbl.class, BaseTbl.program, BaseTbl.dateOfAdmission, BaseTbl.brspFranchiseAssigned, BaseTbl.franchiseNumber');
        $this->db->from('tbl_admission_details_2526 as BaseTbl');
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.dateOfAdmission', 'DESC');
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        
        return $query->result();
    }
}