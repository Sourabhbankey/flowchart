<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Whatsapp_model extends CI_Model {

    private $api_url = "https://wamum.jiocx.com/apggw/api/v1.0/mobeep/messages";
    private $username;
    private $password;

    public function __construct() {
        parent::__construct();
        $this->load->config('config');
        $this->username = $this->config->item('jiocx-jiowa-mobeep');
        $this->password = $this->config->item('9iU3p9iwZVSKB71q');
    }

    public function send_login_notification($phone_number)
    {
        $formatted_number = preg_replace('/[^0-9]/', '', $phone_number); // e.g., 919876543210

        $url = $this->api_url . "?phonenumberID=" . $formatted_number;

        $payload = json_encode([
            "template" => [
                "name" => "login_success", // Template name from Meta
                "language" => [
                    "code" => "en_US"
                ],
                "components" => [
                    [
                        "type" => "body",
                        "parameters" => [
                            [ "type" => "text", "text" => "Rahul" ],      // user_name
                            [ "type" => "text", "text" => "MyApp" ],      // app_name
                            [ "type" => "text", "text" => date("h:i A") ] // login_time
                        ]
                    ]
                ]
            ]
        ]);

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_USERPWD, "{$this->username}:{$this->password}");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 200) {
            return true;
        } else {
            log_message('error', "WhatsApp API Error: {$response}");
            return false;
        }
    }
}
