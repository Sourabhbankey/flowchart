<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Despatch_model (Despatch Model)
 * Despatch model class to get to handle despatch related data 
 * @author : Ashish
 * @version : 1.0
 * @since : 08 June 2023
 */
class Admission_model extends CI_Model
{
    /**
     * This function is used to get the despatch listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */


}     