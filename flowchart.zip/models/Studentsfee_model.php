<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Studentsfee_model extends CI_Model
{
    public function addNewStudentsfee($studentsfeeInfo)
    {
        $this->db->insert('tbl_student_fee_plan', $studentsfeeInfo);
        return $this->db->insert_id();
    }

    public function editStudentsfee($studentsfeeInfo, $feeId)
    {
        $this->db->where('feeId', $feeId);
        return $this->db->update('tbl_student_fee_plan', $studentsfeeInfo);
    }

    public function getstudentsfeeInfo($feeId)
    {
        $this->db->where('feeId', $feeId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get('tbl_student_fee_plan');
        return $query->row();
    }

    public function getUser()
    {
        $this->db->select('userId, name');
        $this->db->from('tbl_users');
        $this->db->where('roleId', 15);
        return $this->db->get()->result();
    }

    public function getUsersByFranchise($franchiseNumber)
    {
        $this->db->select('tbl_users.userId, tbl_users.name');
        $this->db->from('tbl_branches');
        $this->db->join('tbl_users', 'tbl_branches.branchFranchiseAssigned = tbl_users.userId');
        $this->db->where('tbl_branches.franchiseNumber', $franchiseNumber);
        $this->db->where('tbl_branches.isDeleted', 0);
        return $this->db->get()->result();
    }

    public function getFranchisesForUser($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_branches');
        $this->db->where('branchfranchiseassigned', $userId);
        return $this->db->get()->result();
    }

    public function getFranchiseNumberByUserId($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_users');
        $this->db->where('userId', $userId);
        $row = $this->db->get()->row();
        return $row ? $row->franchiseNumber : null;
    }

    public function getTotalStudentsfeeRecordsCount()
    {
        return $this->db->count_all('tbl_student_fee_plan');
    }

    public function getAllStudentsfeeRecords($limit, $start)
    {
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC');
        return $this->db->get('tbl_student_fee_plan')->result();
    }

    public function getTotalStudentsfeeRecordsCountByFranchise($franchiseNumber)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        return $this->db->count_all_results('tbl_student_fee_plan');
    }

    public function getStudentsfeeRecordsByFranchise($franchiseNumber, $limit, $start)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC');
        return $this->db->get('tbl_student_fee_plan')->result();
    }

    public function getTotalStudentsfeeRecordsCountByRole($userId)
    {
        $this->db->where('brspFranchiseAssigned', $userId);
        return $this->db->count_all_results('tbl_student_fee_plan');
    }

    public function getStudentsfeeRecordsByRole($userId, $limit, $start)
    {
        $this->db->where('brspFranchiseAssigned', $userId);
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC');
        return $this->db->get('tbl_student_fee_plan')->result();
    }

    public function get_count_by_franchise($userId, $franchiseNumber = null)
    {
        $this->db->where('brspFranchiseAssigned', $userId);
        if ($franchiseNumber) {
            $this->db->where('franchiseNumber', $franchiseNumber);
        }
        return $this->db->count_all_results('tbl_student_fee_plan');
    }

    public function get_data_by_franchise($userId, $limit, $start, $franchiseNumber = null)
    {
        $this->db->where('brspFranchiseAssigned', $userId);
        if ($franchiseNumber) {
            $this->db->where('franchiseNumber', $franchiseNumber);
        }
        $this->db->limit($limit, $start);
        $this->db->order_by('createdDtm', 'DESC');
        return $this->db->get('tbl_student_fee_plan')->result();
    }

    public function getSupportById($feeId)
    {
        $this->db->where('feeId', $feeId);
        $query = $this->db->get('tbl_student_fee_plan');
        return $query->row();
    }

    public function getRescheduledSupportCount()
    {
        $this->db->where('status', 'Rescheduled');
        return $this->db->count_all_results('tbl_student_fee_plan');
    }
}
