<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Task_model (Task Model)
 * Task model class to get to handle task related data 
 * @author : Kishor Mali
 * @version : 1.5
 * @since : 18 Jun 2022
 */
class Task_model extends CI_Model
{
    /**
     * This function is used to get the task listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function taskListingCount($searchText = '', $status = '', $startDate = '', $endDate = '')
    {
        $this->db->select('BaseTbl.taskId, BaseTbl.taskTitle, BaseTbl.description, BaseTbl.taskattchS3File, BaseTbl.createdDtm');
        $this->db->from('tbl_task as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.taskTitle LIKE '%" . $this->db->escape_like_str($searchText) . "%')";
            $this->db->where($likeCriteria);
        }
        if (!empty($status) && $status != 'All') {
            $this->db->where('BaseTbl.status', $status);
        }
        if (!empty($startDate)) {
            $this->db->where('DATE(BaseTbl.createdDtm) >=', $startDate);
        }
        if (!empty($endDate)) {
            $this->db->where('DATE(BaseTbl.createdDtm) <=', $endDate);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();

        return $query->num_rows();
    }
    /**
     * This function is used to get the task listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
  function taskListing($searchText = '', $page, $segment, $status = '', $startDate = '', $endDate = '')
{
    $this->db->select('BaseTbl.taskId, BaseTbl.taskTitle, BaseTbl.description, BaseTbl.createdDtm, BaseTbl.assignedTo, BaseTbl.assignedBy, BaseTbl.taskattchS3File, BaseTbl.status, BaseTbl.updatedDtm, BaseTbl.collabrators, BaseTbl.updatedBy');
    $this->db->from('tbl_task as BaseTbl');
    if (!empty($searchText)) {
        $likeCriteria = "(BaseTbl.taskTitle LIKE '%" . $this->db->escape_like_str($searchText) . "%')";
        $this->db->where($likeCriteria);
    }
    if (!empty($status) && $status != 'All') {
        $this->db->where('BaseTbl.status', $status);
    }
    if (!empty($startDate)) {
        $this->db->where('DATE(BaseTbl.createdDtm) >=', $startDate);
    }
    if (!empty($endDate)) {
        $this->db->where('DATE(BaseTbl.createdDtm) <=', $endDate);
    }
    $this->db->where('BaseTbl.isDeleted', 0);
    $this->db->order_by('BaseTbl.taskId', 'DESC');
    $this->db->limit($page, $segment);
    $query = $this->db->get();

    return $query->result();
}

   public function autoCloseTasks()
{
    $this->db->trans_start();

    // Calculate the date 15 days ago
    $fifteenDaysAgo = date('Y-m-d H:i:s', strtotime('-15 days'));

    // Fetch tasks to be closed
    $this->db->select('taskId, taskTitle, assignedTo, collabrators');
    $this->db->where('status', 'Open');
    $this->db->where('createdDtm <=', $fifteenDaysAgo);
    $this->db->where('isDeleted', 0);
    $query = $this->db->get('tbl_task');
    $tasks = $query->result();

    // Update tasks to closed
    $this->db->where('status', 'Open');
    $this->db->where('createdDtm <=', $fifteenDaysAgo);
    $this->db->where('isDeleted', 0);
    $this->db->update('tbl_task', [
        'status' => 'Closed',
        'updatedDtm' => date('Y-m-d H:i:s'),
        'updatedBy' => 0 // System update
    ]);

    // Insert notifications for affected tasks
    foreach ($tasks as $task) {
        // Notify assigned user
        $notificationData = [
            'userId' => $task->assignedTo,
            'message' => "Task '{$task->taskTitle}' was automatically closed after 15 days.",
            'taskId' => $task->taskId,
            'is_read' => 0,
            'created_at' => date('Y-m-d H:i:s')
        ];
        $this->db->insert('tbl_notifications', $notificationData);

        // Notify collaborators
        if (!empty($task->collabrators)) {
            $collaboratorsArray = explode(',', $task->collabrators);
            foreach ($collaboratorsArray as $collaboratorId) {
                $collaboratorNotification = [
                    'userId' => trim($collaboratorId),
                    'message' => "Task '{$task->taskTitle}' was automatically closed after 15 days.",
                    'taskId' => $task->taskId,
                    'is_read' => 0,
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->db->insert('tbl_notifications', $collaboratorNotification);
            }
        }
    }

    $this->db->trans_complete();

    return $this->db->trans_status();
}

    public function getCollaboratorNames($collaboratorIds)
    {
        // Convert the IDs into a format suitable for querying
        $this->db->where_in('id', $collaboratorIds);
        $query = $this->db->get('users'); // Assuming 'users' is the table holding the users
        $result = $query->result();

        // Extract names
        $names = [];
        foreach ($result as $user) {
            $names[] = $user->name; // Assuming 'name' is the field storing the name
        }

        return implode(', ', $names); // Return a comma-separated list of names
    }


    /**
     * This function is used to add new task to system
     * @return number $insert_id : This is last inserted id
     */
    /* public function addNewTask($taskInfo)
{
    $this->db->trans_start();
    $this->db->insert('tbl_task', $taskInfo);
    $insert_id = $this->db->insert_id();

    if ($insert_id) {
        // Insert Notification
        $notificationData = [
            'userId' => $taskInfo['assignedTo'], // Receiver of notification
            'message' => 'New task assigned: ' . $taskInfo['taskTitle'],
            'is_read' => 0, // 0 means unread
            'created_at' => date('Y-m-d H:i:s')
        ];
        $this->db->insert('tbl_notifications', $notificationData);
    }

    $this->db->trans_complete();

    return $insert_id;
}
*/

    public function addNewTask($taskInfo)
    {
        $this->db->trans_start();

        // Insert the task into `tbl_task`
        $this->db->insert('tbl_task', $taskInfo);
        $insert_id = $this->db->insert_id(); // Get the inserted task ID

        if ($insert_id) {
            // Insert Notification for Assigned User
            $notificationData = [
                'userId' => $taskInfo['assignedTo'], // Receiver of notification
                'message' => 'New task assigned: ' . $taskInfo['taskTitle'],
                'taskId' => $insert_id, // Include taskId
                'is_read' => 0, // 0 means unread
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->db->insert('tbl_notifications', $notificationData);

            // Handle Collaborators (if any)
            if (!empty($taskInfo['collabrators'])) {
                $collaboratorsArray = explode(',', $taskInfo['collabrators']); // Convert to array

                foreach ($collaboratorsArray as $collaboratorId) {
                    $collaboratorNotification = [
                        'userId' => trim($collaboratorId), // Store each collaborator separately
                        'message' => 'You have been added as a collaborator on task: ' . $taskInfo['taskTitle'],
                        'taskId' => $insert_id, // Include taskId for redirection
                        'is_read' => 0,
                        'created_at' => date('Y-m-d H:i:s')
                    ];
                    $this->db->insert('tbl_notifications', $collaboratorNotification);
                }
            }
        }

        $this->db->trans_complete();

        return $insert_id;
    }

    /**
     * This function used to get task information by id
     * @param number $taskId : This is task id
     * @return array $result : This is task information
     */
    function getTaskInfo($taskId)
    {
        $this->db->select('taskId, taskTitle, description, status, assignedBy, assignedTo, taskattchS3File, createdDtm,collabrators');
        $this->db->from('tbl_task');
        $this->db->where('taskId', $taskId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();

        return $query->row();
    }
    public function getRepyData($taskId)
    {
        $this->db->select('tr.reply, tr.taskId, tr.repliedBy, tr.createdDtm, tr.taskreplyattchS3File, u.name AS username');
        $this->db->from('tbl_task_reply tr');
        $this->db->join('tbl_users u', 'u.userId = tr.repliedBy', 'left');
        $this->db->where('tr.taskId', $taskId);
        $this->db->order_by('tr.id', 'DESC');

        $query = $this->db->get();
        $result = $query->result();

        $baseUrl = base_url('./uploads/attachments/');

        foreach ($result as &$reply) {
            $files = json_decode($reply->taskreplyattchS3File, true);
            $reply->taskreplyattchS3File = is_array($files) ? array_map(fn($file) => $baseUrl . $file, $files) : [];
        }

        return $result;
    }


    /**
     * This function is used to update the task information
     * @param array $taskInfo : This is task updated information
     * @param number $taskId : This is task id
     */
    function editTask($taskInfo, $taskId)
    {

        $this->db->where('taskId', $taskId);
        $this->db->update('tbl_task', $taskInfo);
        // $this->db->update('collabrators', $taskInfo);

        return TRUE;
    }
    function replyTask($taskInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_task_reply', $taskInfo);

        $insert_id = $this->db->insert_id();

        $this->db->trans_complete();

        return $insert_id;
    }
    /**
     * This function is used to get the user  information
     * @return array $result : This is result of the query
     */
    function getUser()
    {
        $this->db->select('userTbl.userId, userTbl.name, userTbl.roleId, userTbl.isAdmin, userTbl.email');
        $this->db->from('tbl_users as userTbl');
        $this->db->where_not_in('userTbl.roleId', [1, 14, 25]);
        $query = $this->db->get();
        return $query->result();
    }


    function updateMsg($taskID, $vendorId)
    {
        $gwtSms     = $this->db->query("SELECT * FROM tbl_task WHERE taskId='$taskID'");
        $dataFinal  = $gwtSms->row();
        $id1        = $dataFinal->assignedBy;
        $id2        = $dataFinal->assignedTo;
        if ($id1 == $vendorId) {
            $gwtSmsCount = $this->db->query("UPDATE tbl_task_reply SET msgRead = NULL WHERE repliedBy='$dataFinal->assignedTo'");
            return $gwtSmsCount;
        } elseif ($id2 == $vendorId) {
            $gwtSmsCount = $this->db->query("UPDATE tbl_task_reply SET msgRead = NULL WHERE repliedBy='$dataFinal->assignedBy'");
            return $gwtSmsCount;
        }
    }
    public function getTotalTrainingRecordsCountByFranchise($franchiseNumber)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        $this->db->from('tbl_task');
        return $this->db->count_all_results();
    }

    public function getTrainingRecordsByFranchise($franchiseNumber, $limit, $start)
    {
        $this->db->where('franchiseNumber', $franchiseNumber);
        $this->db->order_by('taskId', 'DESC'); // Order latest first
        $this->db->limit($limit, $start);
        $query = $this->db->get('tbl_task');
        return $query->result();
    }


   public function getTotalTrainingRecordsCount($fromDate = '', $toDate = '', $statusFilter = 'All')
{
    if (!empty($fromDate)) {
        $this->db->where('DATE(createdDtm) >=', $fromDate);
    }
    if (!empty($toDate)) {
        $this->db->where('DATE(createdDtm) <=', $toDate);
    }
    if (!empty($statusFilter) && $statusFilter != 'All') {
        $this->db->where('status', $statusFilter);  // Exact match
    }
    $this->db->from('tbl_task');
    return $this->db->count_all_results();
}
public function getAllTrainingRecords($limit, $start, $fromDate = '', $toDate = '', $statusFilter = 'All')
{
    if (!empty($fromDate)) {
        $this->db->where('DATE(createdDtm) >=', $fromDate);
    }
    if (!empty($toDate)) {
        $this->db->where('DATE(createdDtm) <=', $toDate);
    }
    if (!empty($statusFilter) && $statusFilter != 'All') {
        $this->db->where('status', $statusFilter);
    }
    $this->db->order_by('taskId', 'DESC');
    $this->db->limit($limit, $start);
    $query = $this->db->get('tbl_task');
    return $query->result();
}


   
public function getTotalTrainingRecordsCountByRole($userId, $statusFilter = 'All', $fromDate = '', $toDate = '')
{
    $this->db->group_start();
        $this->db->where('assignedTo', $userId);
        $this->db->or_where('assignedBy', $userId);
        $this->db->or_where("FIND_IN_SET('$userId', collabrators) >", 0);
    $this->db->group_end();

    if (!empty($statusFilter) && $statusFilter != 'All') {
        $this->db->where('status', $statusFilter);
    }

    if (!empty($fromDate)) {
        $this->db->where('DATE(createdDtm) >=', $fromDate);
    }

    if (!empty($toDate)) {
        $this->db->where('DATE(createdDtm) <=', $toDate);
    }

    $this->db->from('tbl_task');
    return $this->db->count_all_results();
}

public function getTrainingRecordsByRole($userId, $limit, $start, $statusFilter = 'All', $fromDate = '', $toDate = '')
{
    $this->db->select('taskId, taskTitle, description, createdDtm, assignedTo, assignedBy, taskattchS3File, status, updatedDtm, collabrators, updatedBy');

    $this->db->group_start();
        $this->db->where('assignedTo', $userId);
        $this->db->or_where('assignedBy', $userId);
        $this->db->or_where("FIND_IN_SET('$userId', collabrators) >", 0);
    $this->db->group_end();

    if (!empty($statusFilter) && $statusFilter != 'All') {
        $this->db->where('status', $statusFilter);
    }

    if (!empty($fromDate)) {
        $this->db->where('DATE(createdDtm) >=', $fromDate);
    }

    if (!empty($toDate)) {
        $this->db->where('DATE(createdDtm) <=', $toDate);
    }

    $this->db->order_by('taskId', 'DESC');
    $this->db->limit($limit, $start);

    $query = $this->db->get('tbl_task');
    return $query->result();
}

    public function get_users_without_franchise()
    {
        $this->db->where('roleId !=', 25);
        $query = $this->db->get('tbl_users');
        return $query->result();
    }
    public function add_task($data)
    {
        $this->db->insert('tbl_task', $data);
        $taskId = $this->db->insert_id();

        if ($taskId) {
            // Add a notification for the assigned user
            $notificationData = [
                'userId' => $data['assignedTo'], // Assuming assignedTo is the user receiving the task
                'message' => 'New task assigned: ' . $data['task_name'], // Customize message
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->db->insert('tbl_notifications', $notificationData);
            print_r($notificationData);
            exit;
        }

        return $taskId;
    }
    public function getTaskById($taskId)
    {
        $this->db->where('taskId', $taskId);
        $query = $this->db->get('tbl_task'); // Replace with your actual table name if different

        if ($query->num_rows() > 0) {
            return $query->row(); // return single task object
        } else {
            return null;
        }
    }
}
