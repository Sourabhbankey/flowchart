<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Salesrecord_model (Salesrecord Model)
 * Salesrecord model class to get to handle Salesrecord related data 
 * @author : Ashish Singh
 * @version : 1.0
 * @since : 02 Jul 2024
 */
class Topclients_model extends CI_Model
{
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function topclientsListingCount($searchText)
    {
     $this->db->select('BaseTbl.clientsId');
        $this->db->from('tbl_topclients as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.productName LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function topclientsrecordListing($searchText, $page, $segment)
    {
        $this->db->select('BaseTbl.clientsId');
        $this->db->from('tbl_topclients as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.productName LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.salesrecId', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    
    /**
     * This function is used to add new booking to system
     * @return number $insert_id : This is last inserted id
     */
	 
	 
	 
    function addNewTopclientsrecord($topclientsrecordInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_topclients', $topclientsrecordInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get booking information by id
     * @param number $bookingId : This is booking id
     * @return array $result : This is booking information
     */
    
      function getTopclientsrecordInfo($topclientsId)
    {
        $this->db->select('topclientsId');
        $this->db->from('tbl_topclients');
        $this->db->where('topclientsId', $topclientsId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    
    /**
     * This function is used to update the booking information
     * @param array $bookingInfo : This is booking updated information
     * @param number $bookingId : This is booking id
     */
    function editTopclientsrecord($topclientsrecordInfo, $topclientsId)
    {
        $this->db->where('topclientsId', $topclientsId);
        $this->db->update('tbl_topclients', $topclientsrecordInfo);
        
        return TRUE;
    }
	
	
   


	

}