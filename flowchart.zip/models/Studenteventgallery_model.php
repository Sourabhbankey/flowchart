<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Studenteventgallery_model (Student Event Gallery Model)
 * Student Event Gallery model class to handle student event gallery related data
 * @author : Ashish Singh
 * @version : 1.0
 * @since : 12 May 2025
 */
class Studenteventgallery_model extends CI_Model
{
    /**
     * Get the booking listing count
     * @param string $searchText : Optional search text
     * @return number $count : Row count
     */
    function studenteventgalleryListingCount($searchText)
    {
        $this->db->select('BaseTbl.studeventId, BaseTbl.eventName, BaseTbl.venue, BaseTbl.classType, BaseTbl.franchiseNumber, BaseTbl.brspFranchiseAssigned, BaseTbl.selectedClass, BaseTbl.studSection, BaseTbl.studList, BaseTbl.eventDate, BaseTbl.eventS3attachment, BaseTbl.eventvideoS3attachment, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }

    public function getFranchiseNumberByUserId($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_users');
        $this->db->where('userId', $userId);
        $row = $this->db->get()->row();
        return $row ? $row->franchiseNumber : null;
    }

    public function getBranchesFranchiseNumber($franchiseNumber = null)
    {
        $this->db->select('franchiseNumber, franchiseName');
        $this->db->from('tbl_branches');
        if ($franchiseNumber) {
            if (is_array($franchiseNumber)) {
                $this->db->where_in('franchiseNumber', $franchiseNumber);
            } else {
                $this->db->where('franchiseNumber', $franchiseNumber);
            }
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getClasses()
    {
        $this->db->select('className');
        $this->db->from('tbl_class');
        $this->db->where('isDeleted', 0);
        $this->db->order_by('className', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    public function getAllSections()
    {
        $this->db->select('*');
        $this->db->from('tbl_classSection');
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        return $query->result();
    }

public function getStudentsByFranchiseClassAndSection($franchiseNumber, $classNames, $sectionNames)
{
    $this->db->select('admid, name');
    $this->db->from('tbl_admission_details_2526');
    $this->db->where('franchiseNumber', $franchiseNumber);
    $this->db->where_in('class', $classNames); // Use where_in for multiple classes
    $this->db->where_in('section', $sectionNames); // Use where_in for multiple sections
    $this->db->where('isDeleted', 0);
    $query = $this->db->get();
    return $query->result();
}

    public function studenteventgalleryListingCountByFranchise($searchText, $franchiseNumber)
    {
        $this->db->select('COUNT(*) as count');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        $this->db->where('BaseTbl.franchiseNumber', $franchiseNumber);
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        return $query->row()->count;
    }

    public function getAssignedFranchisesByUserId($userId)
    {
        $this->db->select('franchiseNumber');
        $this->db->from('tbl_branches');
        $this->db->where('branchFranchiseAssigned', $userId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function studenteventgalleryListingCountByRole($searchText, $userId)
    {
        $this->db->select('COUNT(*) as count');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        return $query->row()->count;
    }

    public function studenteventgalleryListingByRole($searchText, $limit, $offset, $userId)
    {
        $this->db->select('BaseTbl.studeventId, BaseTbl.eventName, BaseTbl.venue, BaseTbl.classType, BaseTbl.selectedClass, BaseTbl.franchiseNumber, BaseTbl.brspFranchiseAssigned, BaseTbl.studSection, BaseTbl.studList, BaseTbl.eventDate, BaseTbl.eventS3attachment, BaseTbl.eventvideoS3attachment, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.studeventId', 'DESC');
        $this->db->limit($limit, $offset);
        $query = $this->db->get();
        return $query->result();
    }

    public function studenteventgalleryListingByFranchise($searchText, $limit, $offset, $franchiseNumber)
    {
        $this->db->select('BaseTbl.studeventId, BaseTbl.eventName, BaseTbl.venue, BaseTbl.classType, BaseTbl.selectedClass, BaseTbl.franchiseNumber, BaseTbl.brspFranchiseAssigned, BaseTbl.studSection, BaseTbl.studList, BaseTbl.eventDate, BaseTbl.eventS3attachment, BaseTbl.eventvideoS3attachment, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        $this->db->where('BaseTbl.franchiseNumber', $franchiseNumber);
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.studeventId', 'DESC');
        $this->db->limit($limit, $offset);
        $query = $this->db->get();
        return $query->result();
    }

    public function studenteventgalleryListingCountByFranchises($searchText, $franchiseNumbers)
    {
        $this->db->select('COUNT(*) as count');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        $this->db->where_in('BaseTbl.franchiseNumber', $franchiseNumbers);
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        return $query->row()->count;
    }

    public function getBranchByFranchiseNumber($franchiseNumber)
    {
        $this->db->select('customWebsiteLink');
        $this->db->where('franchiseNumber', $franchiseNumber);
        $query = $this->db->get('tbl_branches');
        return $query->row();
    }

    public function studenteventgalleryListingByFranchises($searchText, $limit, $offset, $franchiseNumbers)
    {
        $this->db->select('BaseTbl.studeventId, BaseTbl.eventName, BaseTbl.venue, BaseTbl.classType, BaseTbl.selectedClass, BaseTbl.franchiseNumber, BaseTbl.brspFranchiseAssigned, BaseTbl.studSection, BaseTbl.studList, BaseTbl.eventDate, BaseTbl.eventS3attachment, BaseTbl.eventvideoS3attachment, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        $this->db->where_in('BaseTbl.franchiseNumber', $franchiseNumbers);
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.studeventId', 'DESC');
        $this->db->limit($limit, $offset);
        $query = $this->db->get();
        return $query->result();
    }

    function studenteventgalleryListing($searchText, $page, $segment)
    {
        $this->db->select('BaseTbl.studeventId, BaseTbl.eventName, BaseTbl.venue, BaseTbl.classType, BaseTbl.selectedClass, BaseTbl.franchiseNumber, BaseTbl.brspFranchiseAssigned, BaseTbl.studSection, BaseTbl.studList, BaseTbl.eventDate, BaseTbl.eventS3attachment, BaseTbl.eventvideoS3attachment, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_stud_eventgallery as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.eventName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.studeventId', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        return $query->result();
    }

    function addNewstudenteventgallery($studenteventgalleryInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_stud_eventgallery', $studenteventgalleryInfo);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        
        return $insert_id;
    }

    function getstudenteventgalleryInfo($studeventId)
    {
        $this->db->select('studeventId, eventName, venue, classType, selectedClass, franchiseNumber, brspFranchiseAssigned, studSection, studList, eventDate, eventS3attachment, eventvideoS3attachment, description');
        $this->db->from('tbl_stud_eventgallery');
        $this->db->where('studeventId', $studeventId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getStudentsByClasses()
    {
        $classes = $this->input->post('classes');
        $franchiseNumber = $this->session->userdata('franchiseNumber');
        if (empty($classes)) {
            echo json_encode([]);
            return;
        }
      
        $this->db->select('admid, name');
        $this->db->from('tbl_admission_details_2526');
        $this->db->where_in('class', $classes);
        $this->db->where('franchiseNumber', $franchiseNumber);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        $students = $query->result();

        $studentData = [];
        foreach ($students as $student) {
            $studentData[] = [
                'id' => $student->admid,
                'name' => $student->name
            ];
        }

        echo json_encode($studentData);
    }

    public function getUsersByFranchise($franchiseNumber)
    {
        $this->db->select('tbl_users.userId, tbl_users.name');
        $this->db->from('tbl_branches');
        $this->db->join('tbl_users', 'tbl_branches.branchFranchiseAssigned = tbl_users.userId', 'inner');
        $this->db->where('tbl_branches.franchiseNumber', $franchiseNumber);
        $this->db->where('tbl_branches.isDeleted', 0);
        $query = $this->db->get();
        return $query->result();
    }

    public function getStudentsByFranchiseAndClass($franchiseNumber, $className)
    {
        $this->db->select('admid, name');
        $this->db->from('tbl_admission_details_2526');
        $this->db->where('franchiseNumber', $franchiseNumber);
        if (!empty($className)) {
            $this->db->where('class', $className);
        }
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        return $query->result();
    }






    public function getStudentNamesByIds($studentIds)
    {
        $this->db->select('admid, name');
        $this->db->from('tbl_admission_details_2526');
        $this->db->where_in('admid', $studentIds);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        return $query->result_array();
    }

 

    public function getStudentsByFranchiseAndClasses($franchiseNumber, $classes)
{
    $this->db->select('admid, name');
    $this->db->from('tbl_admission_details_2526');
    $this->db->where('franchiseNumber', $franchiseNumber);
    if (!empty($classes)) {
        $this->db->where_in('class', $classes);
    }
    $this->db->where('isDeleted', 0);
    $query = $this->db->get();
    return $query->result();
}

    function editstudenteventgallery($studenteventgalleryInfo, $studeventId)
    {
        $this->db->where('studeventId', $studeventId);
        $this->db->update('tbl_stud_eventgallery', $studenteventgalleryInfo);
        return TRUE;
    }
}