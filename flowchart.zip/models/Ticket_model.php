<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Announcement_model (Announcement Model)
 * Announcement model class to get to handle Announcement related data 
 * @author : Ashish Singh
 * @version : 1
 * @since : 24 Jul 2024
 */
class Ticket_model extends CI_Model
{
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
public function ticketListingCount($searchText = '')
{
    $roleId = $this->session->userdata('role');
    $userId = $this->session->userdata('userId');

    // Step 1: Get allowed franchises
    $this->db->select('franchiseNumber');
    $this->db->from('tbl_branches');
    $this->db->where("FIND_IN_SET('$userId', branchFranchiseAssigned) >", 0);
    $branchResult = $this->db->get()->result_array();
    $franchiseList = array_column($branchResult, 'franchiseNumber');

    // Step 2: Main ticket query
    $this->db->select('COUNT(*) as count');
    $this->db->from('tbl_tickets t');
    $this->db->join('tbl_users u', 't.createdBy = u.userId', 'left');

    if (!empty($searchText)) {
        $this->db->group_start();
        $this->db->like('t.title', $searchText);
        $this->db->or_like('t.description', $searchText);
        $this->db->group_end();
    }

    if (!in_array($roleId, [1, 14, 28])) {
        $this->db->group_start();
        $this->db->where('t.createdBy', $userId);

        if (!empty($franchiseList)) {
            $this->db->or_group_start();
            $this->db->where("FIND_IN_SET('$userId', t.brspfranchiseassgned) >", 0);
            $this->db->where_in('t.franchiseNumber', $franchiseList);
            $this->db->group_end();
        }

        $this->db->group_end();
    }

    $query = $this->db->get();
    $row = $query->row();
    return isset($row->count) ? $row->count : 0;
}

public function ticketListing($searchText = '', $page, $segment)
{
    $roleId = $this->session->userdata('role');
    $userId = $this->session->userdata('userId');

    // Step 1: Get allowed franchises
    $this->db->select('franchiseNumber');
    $this->db->from('tbl_branches');
    $this->db->where("FIND_IN_SET('$userId', branchFranchiseAssigned) >", 0);
    $branchResult = $this->db->get()->result_array();
    $franchiseList = array_column($branchResult, 'franchiseNumber');

    // Step 2: Main ticket query
    $this->db->select('t.*, u.name AS createdByName, r.role AS roleName');
    $this->db->from('tbl_tickets t');
    $this->db->join('tbl_users u', 't.createdBy = u.userId', 'left');
    $this->db->join('tbl_roles r', 't.roleId = r.roleId', 'left');

    if (!empty($searchText)) {
        $this->db->group_start();
        $this->db->like('t.title', $searchText);
        $this->db->or_like('t.description', $searchText);
        $this->db->group_end();
    }

    if (!in_array($roleId, [1, 14, 28])) {
        $this->db->group_start();
        $this->db->where('t.createdBy', $userId);

        if (!empty($franchiseList)) {
            $this->db->or_group_start();
            $this->db->where("FIND_IN_SET('$userId', t.brspfranchiseassgned) >", 0);
            $this->db->where_in('t.franchiseNumber', $franchiseList);
            $this->db->group_end();
        }

        $this->db->group_end();
    }

    $this->db->order_by("FIELD(t.status, 'open') DESC", NULL, FALSE);
    $this->db->order_by('t.createdDtm', 'DESC');
    $this->db->limit($page, $segment);

    $query = $this->db->get();
    return $query->result();
}


    
    /**
     * This function is used to add new booking to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewTicket($ticketInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_tickets', $ticketInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get booking information by id
     * @param number $bookingId : This is booking id
     * @return array $result : This is booking information
     */
    function getTicketInfo($ticketId)
    {
        $this->db->select('*');
        $this->db->from('tbl_tickets');
        $this->db->where('ticketId', $ticketId);
       
        $query = $this->db->get();
        
        return $query->row();
    }
    
    
    /**
     * This function is used to update the booking information
     * @param array $bookingInfo : This is booking updated information
     * @param number $bookingId : This is booking id
     */
    function editTicket($ticketInfo, $ticketId)
    {
        $this->db->where('ticketId', $ticketId);
        $this->db->update('tbl_tickets', $ticketInfo);
        
        return TRUE;
    }

    public function getAllRoles()
{
    
    $roleIds = [33, 24, 23, 21, 20, 19, 18, 16, 15, 13, 22];

    // Fetch only roles with the specified roleIds
    $this->db->select('roleId, role');
    $this->db->from('tbl_roles');
    $this->db->where_in('roleId', $roleIds);  
    
    return $this->db->get()->result_array();
}

public function getTickets($userId, $roleId)
{
    $this->db->select('*');
    $this->db->from('tbl_tickets');

    if ($roleId != 1 && $roleId != 14) {
        // Sirf apne department (userId) ke tickets dekhne milein
        $this->db->where('roleId', $userId);
    }

   ////// $this->db->order_by('created_at', 'DESC');
    $query = $this->db->get();

    return $query->result();
}
public function insertReply($data) {
    return $this->db->insert('ticket_replies', $data);
}

/*public function getRepliesByTicket($ticketId) {
    $this->db->select('ticket_replies.*, tbl_users.name as repliedByName');
    $this->db->from('ticket_replies');
    $this->db->join('tbl_users', 'tbl_users.userId = ticket_replies.repliedBy', 'left');
    $this->db->where('ticket_replies.ticketId', $ticketId);
    $this->db->order_by('ticket_replies.created_at', 'asc');
    return $this->db->get()->result();
}*/
public function getRepliesByTicket($ticketId) {
    $this->db->select('ticket_replies.*, tbl_users.name as repliedByName');
    $this->db->from('ticket_replies');
    $this->db->join('tbl_users', 'tbl_users.userId = ticket_replies.repliedBy', 'left');
    $this->db->where('ticket_replies.ticketId', $ticketId);
    $this->db->order_by('ticket_replies.created_at', 'desc'); // latest first
    return $this->db->get()->result();
}
public function getTicketById($ticketId) {
    $this->db->select('*');
    $this->db->from('tbl_tickets');
    $this->db->where('ticketId', $ticketId);
    $query = $this->db->get();

    if ($query->num_rows() == 1) {
        return $query->row(); // return as object
    } else {
        return false;
    }
}

}