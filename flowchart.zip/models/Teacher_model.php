<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Class_model (Class Model)
 * Class model class to handle Class-related data
 * @author : Ashish
 * @version : 1.0
 * @since : 28 May 2024
 */
class teacher_model extends CI_Model
{
    /**
     * Get the Class listing count
     * @param string $searchText : Optional search text
     * @return number $count : Row count
     */
    function teacherListingCount($searchText)
    {
        $this->db->select('*');
        $this->db->from('tbl_techers_list as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.ClassName LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * Get the Class listing
     * @param string $searchText : Optional search text
     * @param number $page : Pagination offset
     * @param number $segment : Pagination limit
     * @return array $result : Result
     */
    function teacherListing($searchText, $page, $segment)
    {
        $this->db->select('*');
        $this->db->from('tbl_techers_list as BaseTbl');
        if (!empty($searchText)) {
            $likeCriteria = "(BaseTbl.ClassTitle LIKE '%" . $searchText . "%')";
            $this->db->where($likeCriteria);
        }
       // $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.techerId', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * Increment the opened count for a Class
     * @param number $ClassId : Class ID
     * @return number|boolean : Updated count or false
     */
    

    
    
    /**
     * Add a new Class
     * @return number $insert_id : Last inserted ID
     */
    function addNewteacher($teacherInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_techers_list', $teacherInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * Get Class information by ID
     * @param number $ClassId : Class ID
     * @return object $result : Class information
     */
    function getteacherInfo($techerId)
    {
        $this->db->select('*');
        $this->db->from('tbl_techers_list');
        $this->db->where('techerId', $techerId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    /**
     * Update Class information
     * @param array $ClassInfo : Updated Class information
     * @param number $ClassId : Class ID
     * @return boolean
     */
    function editteacher($teacherInfo, $techerId)
    {
        $this->db->where('techerId', $techerId);
        $this->db->update('tbl_techers_list', $teacherInfo);
        
        return TRUE;
    }
     public function getUsersByFranchise($franchiseNumber) {
        $this->db->select('tbl_users.userId, tbl_users.name');
        $this->db->from('tbl_branches');
        $this->db->join('tbl_users', 'tbl_branches.branchFranchiseAssigned = tbl_users.userId', 'inner');
        $this->db->where('tbl_branches.franchiseNumber', $franchiseNumber);
        $this->db->where('tbl_branches.isDeleted', 0);
        $query = $this->db->get();
    
        return $query->result();
    }
    
}