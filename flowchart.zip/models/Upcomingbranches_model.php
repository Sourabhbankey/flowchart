<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Upcomingbranches_model (Upcomingbranches Model)
 * Upcomingbranches model class to get to handle Upcomingbranches related data 
 * @author : Ashish
 * @version : 1.0
 * @since : 15 Nov 2024
 */
class Upcomingbranches_model extends CI_Model
{
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function upcomingbranchesListingCount($searchText)
    {
        $this->db->select('BaseTbl.upcomingbranchesId, BaseTbl.upcomingbranchesName, BaseTbl.description, BaseTbl.createdDtm');
        $this->db->from('tbl_upcomingbranches as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.upcomingbranchesName LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return $query->num_rows();
    }
    
    /**
     * This function is used to get the booking listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
 public function upcomingbranchesListing($searchText, $limit, $start)
{
    $this->db->select('BranchTbl.branchesId, BranchTbl.franchiseNumber, BranchTbl.currentStatus, BranchTbl.paymentStatus,BranchTbl.createdDtm');
    $this->db->from('tbl_branches as BranchTbl');

    // Apply search filter if provided
    if (!empty($searchText)) {
        $this->db->like('BranchTbl.franchiseNumber', $searchText);
    }

    // Filter to exclude records where finaltotalamtDue is blank, 0, or NULL
    /*$this->db->where('BranchTbl.finaltotalamtDue !=', 0);
    $this->db->where('BranchTbl.finaltotalamtDue IS NOT NULL');
    $this->db->where('BranchTbl.finaltotalamtDue !=', '');*/
    $this->db->where('BranchTbl.currentStatus', 'UnInstalled-Active');
    // Order and pagination
    $this->db->order_by('BranchTbl.branchesId', 'DESC');
    $this->db->limit($limit, $start);  // Using $limit and $start for pagination

    $query = $this->db->get();
    return $query->result();  // Return the result
}




    
    /**
     * This function is used to add new booking to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewUpcomingbranches($upcomingbranchesInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_upcomingbranches', $upcomingbranchesInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get booking information by id
     * @param number $bookingId : This is booking id
     * @return array $result : This is booking information
     */
 function getUpcomingbranchesInfo($upcomingbranchesId)
    {
        $this->db->select('upcomingbranchesId, upcomingbranchesName, description,paymentStatus');
        $this->db->from('tbl_upcomingbranches');
        $this->db->where('upcomingbranchesId', $upcomingbranchesId);
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->row();
    }
   
public function getBranchById($upcomingbranchesId)
{
    $this->db->select('
        branchesId, 
        franchiseNumber, 
        finaltotalamtDue, 
        currentStatus, 
        completeFranchiseAmt,
        branchAmountReceived,
        totalPaidamount,
        applicantName,
        mobile,
        branchEmail,
        branchAddress,
        bookingDate
    ');
    $this->db->from('tbl_branches');
    $this->db->where('branchesId', $upcomingbranchesId);
    $query = $this->db->get();

    return $query->row(); // Return single row
}

    
    /**
     * This function is used to update the booking information
     * @param array $bookingInfo : This is booking updated information
     * @param number $bookingId : This is booking id
     */
  /*  function editUpcomingbranches($upcomingbranchesInfo, $upcomingbranchesId)
    {

        $this->db->where('upcomingbranchesId', $upcomingbranchesId);
        $this->db->update('tbl_upcomingbranches', $upcomingbranchesInfo);
        
        return TRUE;

    }*/
public function editUpcomingbranches($upcomingbranchesInfo, $upcomingbranchesId)
{
    // Check if the upcomingbranchesId exists in the tbl_upcomingbranches table
    $this->db->where('upcomingbranchesId', $upcomingbranchesId);
    $query = $this->db->get('tbl_upcomingbranches');
    
    // If the record exists, update it
    if ($query->num_rows() > 0) {
        $this->db->where('upcomingbranchesId', $upcomingbranchesId);
        $this->db->update('tbl_upcomingbranches', $upcomingbranchesInfo);
        return TRUE; // Successfully updated
    } else {
        // If the record doesn't exist, insert a new one
        $this->db->insert('tbl_upcomingbranches', $upcomingbranchesInfo);
        return TRUE; // Successfully inserted
    }
}

  
   public function getTotalUpcomingBranches($userRole, $userId) {
    $this->db->from('tbl_branches');
    $this->db->where('currentStatus', 'UnInstalled-Active');

    // Role-based filtering: Role 13 sees only their assigned branches
    if ($userRole == 13) {
        $this->db->where('branchFranchiseAssigned', $userId);
    }

    return $this->db->count_all_results();
}

public function getUpcomingBranches($limit, $offset, $userRole, $userId) {
    $this->db->select('
        tbl_branches.branchesId, 
        tbl_branches.franchiseNumber, 
        tbl_branches.finaltotalamtDue, 
        tbl_branches.currentStatus, 
        tbl_branches.completeFranchiseAmt, 
        tbl_upcomingbranches.paymentStatus, 
        tbl_upcomingbranches.description,
        tbl_users.name AS branchFranchiseAssignedName, 
        tbl_branches.createdDtm
    ');
    $this->db->from('tbl_branches');
    
    $this->db->join('tbl_upcomingbranches', 'tbl_branches.franchiseNumber = tbl_upcomingbranches.franchiseNumber', 'left');
    $this->db->join('tbl_users', 'tbl_branches.branchFranchiseAssigned = tbl_users.userId', 'left');

    $this->db->where('tbl_branches.currentStatus', 'UnInstalled-Active');

    // Role-based filtering: Role 13 sees only their assigned branches
    if ($userRole == 13) {
        $this->db->where('tbl_branches.branchFranchiseAssigned', $userId);
    }

    $this->db->limit($limit, $offset);
    
    $query = $this->db->get();
    return $query->result();
}



}